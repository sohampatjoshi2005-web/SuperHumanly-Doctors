import re

with open('/Users/anuragverma/Downloads/healthcare-frontend/src/components/doctor/WorkflowTab.jsx', 'r') as f:
    content = f.read()

# Replace Tabs section
old_tabs = """                      {/* Left: Tabs */}
                      <div className="flex items-end gap-1">
                        <button
                          onClick={() => setRightPaneTab('prescription')}
                          className={`flex items-center gap-2 px-6 py-3.5 rounded-t-[14px] text-[14px] font-bold tracking-tight transition-all -mb-[1px] relative z-10 ${
                            rightPaneTab === 'prescription' 
                              ? 'bg-white border-x border-t border-border/40 text-text shadow-[0_-4px_6px_-2px_rgba(0,0,0,0.02)]' 
                              : 'text-muted hover:text-text border border-transparent'
                          }`}
                        >
                          <span className={rightPaneTab === 'prescription' ? 'text-accent' : 'text-muted'} style={{ fontFamily: 'serif', fontStyle: 'italic', fontWeight: 900, fontSize: '15px' }}>Rx</span>
                          Clinical Rx
                        </button>
                        <button
                          onClick={() => setRightPaneTab('billing')}
                          className={`flex items-center gap-2 px-6 py-3.5 rounded-t-[14px] text-[14px] font-bold tracking-tight transition-all -mb-[1px] relative z-10 ${
                            rightPaneTab === 'billing' 
                              ? 'bg-white border-x border-t border-border/40 text-text shadow-[0_-4px_6px_-2px_rgba(0,0,0,0.02)]' 
                              : 'text-muted hover:text-text border border-transparent'
                          }`}
                        >
                          <Database size={16} className={rightPaneTab === 'billing' ? 'text-accent' : 'text-muted'} />
                          Billing Ledger
                        </button>
                      </div>"""

new_tabs = """                      {/* Left: Tabs */}
                      <div className="flex items-end gap-2 px-2 relative z-10">
                        <button
                          onClick={() => setRightPaneTab('prescription')}
                          className={`flex items-center gap-2 px-6 py-3.5 rounded-t-[14px] text-[14px] font-bold tracking-tight transition-colors -mb-[1px] relative ${rightPaneTab === 'prescription' ? 'text-text' : 'text-muted hover:text-text'}`}
                        >
                          {rightPaneTab === 'prescription' && (
                            <motion.div
                              layoutId="rightPaneTabBg"
                              className="absolute inset-0 bg-white border-x border-t border-border/40 rounded-t-[14px] shadow-[0_-4px_6px_-2px_rgba(0,0,0,0.02)] -z-10"
                              transition={{ type: "spring", bounce: 0.15, duration: 0.5 }}
                            />
                          )}
                          <span className={rightPaneTab === 'prescription' ? 'text-accent' : 'text-muted'} style={{ fontFamily: 'serif', fontStyle: 'italic', fontWeight: 900, fontSize: '15px' }}>Rx</span>
                          Clinical Rx
                        </button>
                        <button
                          onClick={() => setRightPaneTab('billing')}
                          className={`flex items-center gap-2 px-6 py-3.5 rounded-t-[14px] text-[14px] font-bold tracking-tight transition-colors -mb-[1px] relative ${rightPaneTab === 'billing' ? 'text-text' : 'text-muted hover:text-text'}`}
                        >
                          {rightPaneTab === 'billing' && (
                            <motion.div
                              layoutId="rightPaneTabBg"
                              className="absolute inset-0 bg-white border-x border-t border-border/40 rounded-t-[14px] shadow-[0_-4px_6px_-2px_rgba(0,0,0,0.02)] -z-10"
                              transition={{ type: "spring", bounce: 0.15, duration: 0.5 }}
                            />
                          )}
                          <Database size={16} className={rightPaneTab === 'billing' ? 'text-accent' : 'text-muted'} />
                          Billing Ledger
                        </button>
                      </div>"""

content = content.replace(old_tabs, new_tabs)

# Replace right pane headers tools
old_tools = """                      {/* Right: Tools */}
                      <div className="flex items-center gap-2.5 pb-3">"""

new_tools = """                      {/* Right: Tools */}
                      <div className="flex items-center gap-2.5 pb-3">"""

# Replace the contents block wrapper
old_prescription_start = """                    {/* Full-Height Institutional Prescription Workspace - Matching Medical Summary Style */}
                    <div className={`${rightPaneTab === 'prescription' ? 'flex' : 'hidden'} flex-1 flex-col min-h-0 shrink-0`}>
                      {displayedResult && (
                        <motion.div
                          initial={{ opacity: 0, y: -5 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="flex-1 flex flex-col min-h-0 group/narrative overflow-hidden relative bg-white"
                        >"""

new_prescription_start = """                    {/* Content Area wrapped in AnimatePresence to prevent layout shifts */}
                    <div className="flex-1 flex flex-col min-h-0 relative">
                      <AnimatePresence mode="wait">
                        {rightPaneTab === 'prescription' && displayedResult ? (
                          <motion.div
                            key="pane-prescription"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.2 }}
                            className="flex-1 flex flex-col min-h-0 shrink-0 group/narrative overflow-hidden relative bg-white"
                          >"""

content = content.replace(old_prescription_start, new_prescription_start)

# Replace the end of prescription block and start of billing block
old_prescription_end = """                        </motion.div>
                      )}
                    </div>

                    {/* --- BILLING & REIMBURSEMENT SUPPORT (COMBINED IN CARD) --- */}
                    <AnimatePresence>
                      {result && (
                        <motion.div
                          ref={billingRef}
                          layout
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className={`${rightPaneTab === 'billing' ? 'flex' : 'hidden'} flex-col h-auto z-10 min-h-0 pt-2`}
                        >"""

new_prescription_end = """                        </motion.div>
                        ) : rightPaneTab === 'billing' && result ? (
                          <motion.div
                            key="pane-billing"
                            ref={billingRef}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.2 }}
                            className="flex-col flex-1 h-auto z-10 min-h-0 pt-2 flex"
                          >"""

content = content.replace(old_prescription_end, new_prescription_end)

# Replace the end of the billing block
old_billing_end = """                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>"""

new_billing_end = """                    </motion.div>
                        ) : null}
                      </AnimatePresence>
                    </div>"""

content = content.replace(old_billing_end, new_billing_end)

with open('/Users/anuragverma/Downloads/healthcare-frontend/src/components/doctor/WorkflowTab.jsx', 'w') as f:
    f.write(content)

print("Done")
