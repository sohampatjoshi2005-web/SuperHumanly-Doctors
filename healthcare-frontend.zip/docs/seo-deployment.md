# SEO deployment (v2.0)

## Build with prerender

```bash
export VITE_SITE_URL=https://superhumanlymedical.io
export PRERENDER_API_URL=http://localhost:8000   # healthcare-backend at build time

npm run build:prerender
npm run verify:phase24
```

Skip Chromium in Docker layer builds:

```bash
PRERENDER_SKIP=1 npm run build
```

## nginx

Use `nginx.conf` at repo root:

- `try_files` serves `dist/**/index.html` before SPA fallback
- `/sitemap.xml` and `/robots.txt` proxy to healthcare-backend

## Backend contract

```
GET {PRERENDER_API_URL}/v1/seo/prerender-paths
→ { "paths": ["/", "/pricing", …, "/documentation/…/…"] }
```

Paths must match frontend `listPublicPathsForSitemap()` (see `src/seo/routes.contract.test.js`).

## Verification suite

```bash
npm run verify:seo          # full suite (includes dist checks when dist/ exists)
npm run verify:seo:dist     # baked HTML for every indexable path
npm run verify:seo:parity   # frontend ≡ backend ≡ sitemap
npm run verify:seo:perf     # LCP/CLS/font/web-vitals source gates
```

## Post-deploy checklist

See **[docs/gsc-setup.md](gsc-setup.md)** for Google Search Console property setup, sitemap submission, and URL Inspection steps.

1. Submit `https://superhumanlymedical.io/sitemap.xml` in Google Search Console
2. URL Inspection on `/`, `/pricing`, and one documentation deep link
3. View Source — confirm single canonical, `og:title`, and JSON-LD without running JS
