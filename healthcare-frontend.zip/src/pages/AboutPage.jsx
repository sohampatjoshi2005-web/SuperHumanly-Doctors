import LandingNavbar from '../components/landing/LandingNavbar';
import LandingFooter from '../components/landing/LandingFooter';
import { motion } from 'framer-motion';
import { HeartPulse, ShieldCheck, Zap, Brain, Database, Globe } from 'lucide-react';
import SEO from '../components/SEO';

export default function AboutPage() {
  return (
    <div className="bg-white min-h-screen">
      <SEO 
        title="Our Sovereignty Protocol" 
        description="Superhumanly Doctors is a fundamental redesign of clinical documentation infrastructure—built for physician autonomy and institutional medical sovereignty."
      />
      <LandingNavbar />
      
      <main className="pt-40 pb-32">
        {/* HERO SECTION */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12 mb-32 lg:mb-48">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/5 border border-accent/10 mb-8">
                <ShieldCheck size={14} className="text-accent" />
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-accent">Institutional Protocol v4.2</span>
              </div>
              <h1 className="text-[64px] lg:text-[96px] font-serif tracking-tight text-text leading-[0.85] mb-10">
                Architecture of <br />
                <span className="italic text-accent font-medium">Health Care.</span>
              </h1>
              <p className="text-[18px] lg:text-[20px] text-muted/60 font-medium leading-relaxed max-w-xl mb-12">
                Superhumanly Doctors is a fundamental redesign of clinical documentation infrastructure—built from the ground up for physician autonomy and institutional medical sovereignty.
              </p>
              <div className="flex items-center gap-6">
                 <div className="flex -space-x-4">
                    {[1,2,3,4,5].map(idx => (
                       <div key={idx} className="w-12 h-12 rounded-full bg-off border-[3px] border-white flex items-center justify-center text-[10px] font-black overflow-hidden shadow-xl ring-1 ring-border/20">
                          <img
                            src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${idx + 20}`}
                            alt=""
                            width={48}
                            height={48}
                            loading="lazy"
                            decoding="async"
                            className="w-full h-full object-cover"
                          />
                       </div>
                    ))}
                 </div>
                 <div className="flex flex-col">
                    <div className="text-[11px] font-black text-text uppercase tracking-widest">Medical Board Advisory</div>
                    <div className="text-[11px] font-bold text-muted/40 uppercase tracking-widest">Global Institutional Node</div>
                 </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
               <div className="relative aspect-square rounded-[48px] bg-off border border-border overflow-hidden group shadow-2xl">
                  <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-accent-vibrant/5 group-hover:scale-110 transition-transform duration-1000"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative w-full h-full flex items-center justify-center">
                       {/* SVG Technical Grid */}
                       <svg className="absolute inset-0 w-full h-full opacity-[0.03]" viewBox="0 0 100 100">
                          <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                             <path d="M 10 0 L 0 0 0 10" fill="none" stroke="black" strokeWidth="0.5"/>
                          </pattern>
                          <rect width="100" height="100" fill="url(#grid)" />
                       </svg>
                       <HeartPulse size={120} className="text-accent/20 absolute blur-3xl" />
                       <HeartPulse size={84} className="text-accent relative z-10 animate-pulse" />
                    </div>
                  </div>
                  {/* Floating Tech Labels */}
                  <div className="absolute top-12 left-12 p-5 bg-white/90 backdrop-blur-xl rounded-3xl border border-border shadow-2xl">
                     <div className="text-[10px] font-black uppercase tracking-widest text-accent mb-1">Intake Kernel</div>
                     <div className="text-[14px] font-mono font-bold text-text">v4.0.2 Stable</div>
                  </div>
                  <div className="absolute bottom-12 right-12 p-5 bg-white/90 backdrop-blur-xl rounded-3xl border border-border shadow-2xl text-right">
                     <div className="text-[10px] font-black uppercase tracking-widest text-accent-vibrant mb-1">Node Sovereignty</div>
                     <div className="text-[14px] font-mono font-bold text-text">Institutional Only</div>
                  </div>
               </div>
            </motion.div>
          </div>
        </section>

        {/* ARCHITECTURE DEEP-DIVE */}
        <section className="py-32 bg-off border-y border-border/40 relative overflow-hidden">
           <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
                 <div>
                    <h2 className="text-[11px] font-black uppercase tracking-[0.3em] text-accent mb-8">Technical Architecture</h2>
                    <h3 className="text-[42px] font-serif italic text-text mb-8 leading-tight">Engineering for zero-loss clinical fidelity.</h3>
                    <div className="space-y-10">
                       {[
                         { title: "Sovereign AI Weights", desc: "Private institutional nodes utilize localized AI weights, ensuring that medical reasoning logic never leaves your hospital system." },
                         { title: "FHIR R4 Throughput", desc: "Native interoperability protocols allow for 2.4k clinical resource requests per minute per node." },
                         { title: "N-Tier Redundancy", desc: "Distributed slates across multiple regions guarantee 99.99% uptime for critical clinical operations." }
                       ].map((item, i) => (
                         <div key={i} className="flex gap-6">
                            <div className="text-[14px] font-black text-accent/30 font-mono mt-1">0{i+1}</div>
                            <div>
                               <h4 className="text-[18px] font-bold text-text mb-2">{item.title}</h4>
                               <p className="text-[15px] text-muted/60 leading-relaxed font-medium">{item.desc}</p>
                            </div>
                         </div>
                       ))}
                    </div>
                 </div>
                 <div className="bg-white border border-border/60 rounded-[40px] p-10 shadow-xl shadow-black/[0.02] flex flex-col justify-between">
                    <div>
                       <div className="text-[11px] font-black uppercase tracking-widest text-muted/30 mb-8">Service Health Telemetry</div>
                       <div className="space-y-8">
                          {[
                            { label: "Institutional Encryption", val: "AES-256-GCM", status: "Active" },
                            { label: "Transcription Latency", val: "840ms", status: "Optimal" },
                            { label: "Interoperability Load", val: "Stable", status: "Verified" }
                          ].map((stat, i) => (
                             <div key={i} className="flex items-center justify-between border-b border-border/40 pb-6">
                                <div>
                                   <div className="text-[13px] font-bold text-text mb-1">{stat.label}</div>
                                   <div className="text-[11px] font-mono font-bold text-muted/40 uppercase">{stat.val}</div>
                                </div>
                                <div className="px-3 py-1 bg-green-50 text-green-600 text-[9px] font-black uppercase tracking-widest rounded-full border border-green-100">
                                   {stat.status}
                                </div>
                             </div>
                          ))}
                       </div>
                    </div>
                    <div className="mt-12 p-6 bg-accent/5 border border-accent/10 rounded-2xl">
                       <p className="text-[11px] text-accent font-bold uppercase tracking-widest leading-loose">
                         Every computational node is verified against the HIPAA Security Rule and SOC-2 Availability protocols.
                       </p>
                    </div>
                 </div>
              </div>
           </div>
        </section>

        {/* MISSION SECTION */}
        <section className="py-32 bg-text text-white relative">
           <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
              <div className="max-w-3xl mb-32">
                 <div className="w-12 h-12 rounded-2xl bg-accent-vibrant/20 flex items-center justify-center mb-10">
                    <Globe size={24} className="text-accent-vibrant" />
                 </div>
                 <h2 className="text-[11px] font-black uppercase tracking-[0.3em] text-accent-vibrant mb-8">Our Foundational Protocol</h2>
                 <p className="text-[36px] sm:text-[48px] font-serif leading-[1.1] tracking-tight">
                    "We believe clinical documentation should not be a tax on a physician's time, but an <span className="italic text-accent-vibrant">autonomous asset</span> that empowers care and preserves institutional integrity."
                 </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
                 {[
                   { icon: Brain, title: "Clinical Autonomy", desc: "Our AI models are optimized to respect physician intent while automating the administrative overhead." },
                   { icon: Database, title: "Data Sovereignty", desc: "Institutions retain absolute control over their medical data, kernels, and private AI weights." },
                   { icon: ShieldCheck, title: "Fidelity of Care", desc: "We ensure zero-loss transcription and high-veracity patient summaries for every encounter." }
                 ].map((pill, idx) => (
                   <div key={idx} className="group">
                      <div className="w-16 h-16 rounded-[24px] bg-white/5 border border-white/10 flex items-center justify-center mb-8 group-hover:bg-accent-vibrant transition-all group-hover:-translate-y-2">
                         <pill.icon size={28} className="text-accent-vibrant group-hover:text-white" />
                      </div>
                      <h4 className="text-[24px] font-serif mb-6">{pill.title}</h4>
                      <p className="text-[16px] text-white/40 leading-relaxed font-medium">
                         {pill.desc}
                      </p>
                   </div>
                 ))}
              </div>
           </div>
        </section>

        {/* STATS / VALUES SECTION */}
        <section className="py-32 lg:py-48 bg-white">
           <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
              <div className="flex flex-col lg:flex-row gap-24 lg:gap-32">
                 <div className="flex-1">
                    <h2 className="text-[48px] lg:text-[64px] font-serif mb-12 tracking-tight leading-[1] text-text">Scale of <br /><span className="italic text-accent">Modern Medicine.</span></h2>
                    <p className="text-[19px] text-muted/60 leading-relaxed max-w-xl mb-16 font-medium">
                       From solo practitioners to global healthcare groups, Superhumanly Doctors provides the computational backbone for high-fidelity clinical management.
                    </p>
                    <div className="grid grid-cols-2 gap-12">
                       <div>
                          <div className="text-[48px] font-serif font-black mb-3 tracking-tighter text-text">99.2%</div>
                          <div className="text-[11px] font-black uppercase tracking-[0.2em] text-muted/40">Clinical Accuracy Rating</div>
                       </div>
                       <div>
                          <div className="text-[48px] font-serif font-black mb-3 tracking-tighter text-text">1.2M+</div>
                          <div className="text-[11px] font-black uppercase tracking-[0.2em] text-muted/40">Encounters Scoped</div>
                       </div>
                    </div>
                 </div>
                 
                 <div className="flex-1 space-y-8">
                    <div className="p-10 rounded-[40px] bg-off border border-border group hover:bg-white hover:shadow-2xl transition-all">
                       <div className="flex gap-8">
                          <Zap size={40} className="text-accent shrink-0 group-hover:scale-110 transition-transform" />
                          <div>
                             <h4 className="text-[20px] font-bold text-text mb-3">Real-Time Processing</h4>
                             <p className="text-muted/60 text-[15px] font-medium leading-relaxed">Our Whisper-optimized intake engine processes encounters in sub-second latency.</p>
                          </div>
                       </div>
                    </div>
                    <div className="p-10 rounded-[40px] bg-off border border-border group hover:bg-white hover:shadow-2xl transition-all">
                       <div className="flex gap-8">
                          <Globe size={40} className="text-accent shrink-0 group-hover:scale-110 transition-transform" />
                          <div>
                             <h4 className="text-[20px] font-bold text-text mb-3">Global Infrastructure</h4>
                             <p className="text-muted/60 text-[15px] font-medium leading-relaxed">Multi-region, HIPAA-compliant nodes ensure your data is always proximate and sovereign.</p>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </section>
      </main>

      <LandingFooter />
    </div>
  );
}
