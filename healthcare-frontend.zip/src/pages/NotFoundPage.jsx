import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, ArrowLeft, ShieldAlert } from 'lucide-react';
import LandingNavbar from '../components/landing/LandingNavbar';
import SEO from '../components/SEO';

export default function NotFoundPage() {
  return (
    <div className="bg-white min-h-screen">
      <SEO title="Page Not Found" description="The requested page could not be found." robots="noindex,nofollow" />
      <LandingNavbar />
      
      <main className="flex flex-col items-center justify-center min-h-screen px-4 text-center">
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 0.5 }}
           className="relative"
        >
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-accent/5 blur-[100px] rounded-full -z-10"></div>
           
           <div className="mb-8 inline-flex items-center justify-center w-24 h-24 rounded-full bg-off border border-border shadow-inner">
              <ShieldAlert size={40} className="text-accent" />
           </div>
           
           <h1 className="text-[120px] font-serif font-black text-text leading-none tracking-tighter mb-4">404</h1>
           <h2 className="text-3xl font-serif text-text mb-6 italic">Repository Not Found.</h2>
           
           <p className="text-lg text-text2/60 max-w-md mx-auto mb-10 font-medium">
              The clinical record or page you are looking for has been moved, archived, or purged from our sovereign kernels.
           </p>
           
           <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/" className="w-full sm:w-auto px-8 py-4 bg-text text-white rounded-full font-black uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-black/10 flex items-center justify-center gap-2 group">
                 <Home size={18} /> Return Base
              </Link>
              <button 
                onClick={() => window.history.back()}
                className="w-full sm:w-auto px-8 py-4 border border-border rounded-full font-black uppercase tracking-widest text-text hover:bg-off transition-all flex items-center justify-center gap-2"
              >
                 <ArrowLeft size={18} /> Go Back
              </button>
           </div>
        </motion.div>
      </main>

      <div className="fixed bottom-10 left-0 w-full text-center">
         <span className="text-[10px] font-black uppercase tracking-[0.4em] text-text/20">Error Protocol: ERR_臨床_404_VOID</span>
      </div>
    </div>
  );
}
