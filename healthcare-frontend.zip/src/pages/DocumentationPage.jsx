import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  ChevronRight,
  ArrowLeft,
  Terminal,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Menu,
  X,
  Copy,
  OctagonAlert,
} from 'lucide-react';
import { Link, Navigate, useParams } from 'react-router-dom';
import LandingNavbar from '../components/landing/LandingNavbar';
import LandingFooter from '../components/landing/LandingFooter';
import SEO from '../components/SEO';
import DocTrustMeta from '../components/docs/DocTrustMeta';
import { docCategories } from '../data/docCategories';
import {
  docSectionPath,
  findDocSection,
  getDefaultDocLocation,
  resolveDocSeo,
  isMedicalDocumentationSection,
} from '../data/docRoutes';
import AcousticFlowDiagram from '../components/docs/AcousticFlowDiagram';
import ComplianceTable from '../components/docs/ComplianceTable';
import ApiReferenceHub from '../components/docs/ApiReferenceHub';
import ApiSnippetPanel from '../components/docs/ApiSnippetPanel';
import { getEndpointById } from '../data/apiReference';

const HighlightText = ({ text, highlight }) => {
  if (!highlight) return <span>{text}</span>;

  const regex = new RegExp(`(${highlight})`, 'gi');
  const parts = text.split(regex);

  return (
    <span>
      {parts.map((part, i) =>
        part.toLowerCase() === highlight.toLowerCase() ? (
          <mark key={i} className="bg-[#2563eb]/15 text-[#2563eb] rounded px-1 font-semibold">
            {part}
          </mark>
        ) : (
          <span key={i}>{part}</span>
        ),
      )}
    </span>
  );
};

export default function DocumentationPage() {
  const { categorySlug, sectionSlug } = useParams();
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const contentRef = useRef(null);

  if (!categorySlug || !sectionSlug) {
    const def = getDefaultDocLocation();
    return <Navigate to={docSectionPath(def.categorySlug, def.sectionSlug)} replace />;
  }

  const resolved = findDocSection(categorySlug, sectionSlug);
  if (!resolved) {
    const def = getDefaultDocLocation();
    return <Navigate to={docSectionPath(def.categorySlug, def.sectionSlug)} replace />;
  }

  const { category: activeCategory, section: activeSection } = resolved;
  const docSeo = resolveDocSeo({ category: activeCategory, section: activeSection });
  const showTrustMeta = isMedicalDocumentationSection(activeCategory.id);

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isMatched = (str) => str?.toLowerCase().includes(searchQuery.toLowerCase());

  const filteredCategories = docCategories
    .map((category) => {
      const matchesCategory = isMatched(category.title);
      const filteredSubcategories = category.subcategories.filter((sub) => {
        return (
          isMatched(sub.title) ||
          isMatched(sub.content.title) ||
          isMatched(sub.content.text) ||
          (sub.content.list && sub.content.list.some((l) => isMatched(l))) ||
          (sub.content.steps &&
            sub.content.steps.some((st) => isMatched(st.label) || isMatched(st.desc)))
        );
      });

      if (matchesCategory || filteredSubcategories.length > 0) {
        return {
          ...category,
          subcategories:
            matchesCategory && filteredSubcategories.length === 0
              ? category.subcategories
              : filteredSubcategories,
        };
      }
      return null;
    })
    .filter(Boolean);

  const renderSidebarContent = () => (
    <nav aria-label="Documentation sections" className="flex flex-col gap-1 w-full pb-8">
      <div className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-4 px-4">
        Clinical Directory
      </div>
      {filteredCategories.map((section) => (
        <div key={section.id} className="mb-2">
          <div
            className={`flex w-full items-center gap-3 px-4 py-3 rounded-xl text-left ${
              activeCategory.id === section.id
                ? 'bg-slate-100 text-[#0a0a0a] shadow-sm font-bold'
                : 'text-slate-600 font-medium'
            }`}
          >
            <section.icon
              size={18}
              className={
                activeCategory.id === section.id ? 'text-[#2563eb]' : 'text-slate-400'
              }
            />
            <span className="text-[14px]">
              <HighlightText text={section.title} highlight={searchQuery} />
            </span>
          </div>

          <div className="flex flex-col mt-1 space-y-1">
            {section.subcategories.map((sub) => {
              const href = docSectionPath(section.id, sub.id);
              const isActive =
                activeCategory.id === section.id && activeSection.id === sub.id;
              return (
                <Link
                  key={sub.id}
                  to={href}
                  onClick={() => setIsMobileDrawerOpen(false)}
                  className={`flex w-full items-center gap-2 pl-12 pr-4 py-2 rounded-lg text-left transition-all no-underline ${
                    isActive
                      ? 'text-[#2563eb] font-bold bg-[#2563eb]/5'
                      : 'text-slate-500 hover:text-[#0a0a0a] text-sm hover:bg-slate-50'
                  }`}
                >
                  <div
                    className={`w-1 h-1 rounded-full ${isActive ? 'bg-[#2563eb]' : 'bg-slate-300'}`}
                  />
                  <span>
                    <HighlightText text={sub.title} highlight={searchQuery} />
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      ))}
    </nav>
  );

  const getAlertStyles = (type) => {
    switch (type) {
      case 'critical':
        return {
          container: 'bg-red-50 border-red-300',
          icon: 'bg-red-100 text-red-600',
          title: 'text-red-800',
          IconComponent: OctagonAlert,
        };
      case 'warning':
        return {
          container: 'bg-orange-50 border-orange-200',
          icon: 'bg-orange-100 text-orange-600',
          title: 'text-orange-700',
          IconComponent: AlertTriangle,
        };
      default:
        return {
          container: 'bg-slate-50 border-slate-200',
          icon: 'bg-slate-200 text-slate-700',
          title: 'text-slate-500',
          IconComponent: Shield,
        };
    }
  };

  const block = activeSection.content;

  const renderSectionBody = () => (
    <article className="scroll-mt-8">
      <header className="mb-8 border-b border-slate-200 pb-8">
        <div className="flex items-center gap-3 text-[#2563eb] mb-4">
          {activeCategory.icon && <activeCategory.icon size={28} aria-hidden />}
          <span className="font-black tracking-widest uppercase text-sm">{activeCategory.title}</span>
        </div>
        <h1 className="font-serif text-3xl sm:text-4xl text-[#0a0a0a] tracking-tight">
          <HighlightText text={block.title} highlight={searchQuery} />
        </h1>
      </header>

      <p className="text-lg text-slate-600 leading-relaxed mb-8">
        <HighlightText text={block.text} highlight={searchQuery} />
      </p>

      {block.customComponent === 'AcousticFlowDiagram' && <AcousticFlowDiagram />}
      {block.customComponent === 'ComplianceTable' && <ComplianceTable />}
      {block.customComponent === 'ApiReferenceHub' && <ApiReferenceHub />}

      {activeCategory.id === 'api' &&
        activeSection.id !== 'overview' &&
        getEndpointById(activeSection.id) && (
          <ApiSnippetPanel endpointId={activeSection.id} />
        )}

      {block.badges && (
        <div className="flex flex-wrap gap-2 my-6">
          {block.badges.map((badge, bIdx) => {
            const colorMap = {
              blue: 'bg-blue-50 text-blue-700 border-blue-200',
              green: 'bg-green-50 text-green-700 border-green-200',
              indigo: 'bg-indigo-50 text-indigo-700 border-indigo-200',
              slate: 'bg-slate-100 text-slate-700 border-slate-200',
            };
            return (
              <span
                key={bIdx}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold uppercase tracking-wider border ${colorMap[badge.color] || colorMap.blue}`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-current opacity-60" />
                {badge.label}
              </span>
            );
          })}
        </div>
      )}

      {block.commandStrip && (
        <div className="my-8 relative group">
          <div className="flex items-center justify-between bg-blue-50/50 border border-blue-100 rounded-2xl p-4 pr-16 font-mono text-blue-900 text-sm shadow-sm overflow-hidden">
            <span className="truncate">
              <HighlightText text={block.commandStrip} highlight={searchQuery} />
            </span>
            <button
              type="button"
              onClick={() => handleCopy(block.commandStrip)}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-white rounded-xl border border-slate-200 hover:border-blue-300 hover:text-blue-600 transition-all text-slate-400 shadow-sm flex items-center justify-center"
              title="Copy to clipboard"
            >
              {copied ? <CheckCircle2 size={16} className="text-green-500" /> : <Copy size={16} />}
            </button>
          </div>
        </div>
      )}

      {block.list && (
        <div className="my-8 space-y-3">
          {block.list.map((item, i) => (
            <div key={i} className="flex gap-4 p-5 bg-white border border-slate-200 shadow-sm rounded-2xl">
              <div className="w-1.5 h-1.5 rounded-full bg-[#2563eb] mt-2.5 shrink-0" />
              <div className="text-slate-700 text-base leading-relaxed">
                <HighlightText text={item} highlight={searchQuery} />
              </div>
            </div>
          ))}
        </div>
      )}

      {block.alert &&
        (() => {
          const alertStyle = getAlertStyles(block.alert.type);
          return (
            <div
              className={`my-8 p-8 rounded-[24px] overflow-hidden relative border ${alertStyle.container}`}
              role={block.alert.type === 'critical' ? 'alert' : 'note'}
            >
              <div className="flex gap-5 items-start relative z-10">
                <div className={`p-3 rounded-xl shrink-0 ${alertStyle.icon}`}>
                  <alertStyle.IconComponent size={24} aria-hidden />
                </div>
                <div>
                  <h2
                    className={`font-black text-[12px] uppercase tracking-widest mb-1.5 ${alertStyle.title}`}
                  >
                    <HighlightText text={block.alert.title} highlight={searchQuery} />
                  </h2>
                  <p className="text-[#0a0a0a] text-[17px] leading-relaxed">
                    <HighlightText text={block.alert.text} highlight={searchQuery} />
                  </p>
                </div>
              </div>
            </div>
          );
        })()}

      {block.steps && (
        <section aria-labelledby="workflow-steps-heading">
          <h2 id="workflow-steps-heading" className="sr-only">
            Workflow steps
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-10">
            {block.steps.map((step, sIdx) => (
              <div
                key={sIdx}
                className="p-6 bg-white border border-slate-200 shadow-sm rounded-[24px] hover:border-[#2563eb]/40 transition-colors group"
              >
                <div className="text-[11px] font-black text-slate-400 group-hover:text-[#2563eb] uppercase tracking-widest mb-3 flex items-center justify-between transition-colors">
                  <span>Step {sIdx + 1}</span>
                  <CheckCircle2
                    size={16}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    aria-hidden
                  />
                </div>
                <h3 className="text-[#0a0a0a] text-[17px] font-bold mb-2">
                  <HighlightText text={step.label} highlight={searchQuery} />
                </h3>
                <p className="text-slate-500 text-[15px] leading-relaxed">
                  <HighlightText text={step.desc} highlight={searchQuery} />
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {block.code &&
        !(activeCategory.id === 'api' && getEndpointById(activeSection.id)) && (
        <pre className="my-8 rounded-[24px] overflow-hidden border border-slate-200 bg-slate-900 shadow-xl relative group">
          <div className="px-5 py-3 bg-white/5 border-b border-white/10 flex items-center justify-between">
            <div className="flex gap-1.5" aria-hidden>
              <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
            </div>
            <div className="flex items-center gap-2 text-white/40 text-[10px] font-black uppercase tracking-widest">
              <Terminal size={12} aria-hidden /> API Snippet
            </div>
          </div>
          <code className="block p-6 text-[14px] font-mono text-slate-300 overflow-x-auto leading-relaxed custom-scrollbar">
            <HighlightText text={block.code} highlight={searchQuery} />
          </code>
        </pre>
      )}

      {showTrustMeta ? <DocTrustMeta showReviewer={activeCategory.id === 'ai-accuracy'} /> : null}
    </article>
  );

  return (
    <div className="bg-[#fbfbf9] min-h-screen selection:bg-[#2563eb]/20 text-[#0a0a0a] flex flex-col">
      <SEO title={docSeo.title} description={docSeo.description} />
      <LandingNavbar />

      <main className="flex-1 flex flex-col">
        <div className="pt-32 px-3 lg:px-5 mx-auto w-full">
          <div className="mb-6">
            <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-slate-500 text-sm font-bold uppercase tracking-wider mb-4 flex-wrap">
              <Link to="/" className="hover:text-[#2563eb] flex items-center gap-1 transition-colors no-underline">
                <ArrowLeft size={14} aria-hidden /> Home
              </Link>
              <ChevronRight size={14} aria-hidden />
              <Link to={docSectionPath(activeCategory.id, activeSection.id)} className="text-[#0a0a0a] no-underline">
                Documentation
              </Link>
              <ChevronRight size={14} aria-hidden />
              <span className="text-slate-600">{activeCategory.title}</span>
              <ChevronRight size={14} aria-hidden />
              <span className="text-[#2563eb]">{activeSection.title}</span>
            </nav>
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  className="lg:hidden p-3 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm"
                  onClick={() => setIsMobileDrawerOpen(true)}
                  aria-label="Open documentation menu"
                >
                  <Menu size={24} className="text-[#0a0a0a]" />
                </button>
                <p className="font-serif text-2xl sm:text-3xl text-[#0a0a0a] tracking-tight leading-[0.95]">
                  Knowledge <span className="italic text-[#2563eb]">Base</span>
                </p>
              </div>

              <div className="relative group w-full lg:w-auto">
                <Search
                  className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-[#2563eb] transition-colors"
                  size={20}
                  aria-hidden
                />
                <input
                  type="search"
                  aria-label="Search documentation"
                  placeholder="Search guides, APIs, specs..."
                  className="w-full lg:min-w-[400px] pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-[24px] focus:outline-none focus:ring-4 focus:ring-[#2563eb]/10 focus:border-[#2563eb] transition-all text-[#0a0a0a] font-medium text-base shadow-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex-1 flex flex-col lg:flex-row px-4 mx-auto w-full min-h-0">
          <aside
            className="hidden lg:block w-72 xl:w-80 shrink-0 overflow-y-auto custom-scrollbar pr-4 border-r border-slate-100"
            style={{ maxHeight: 'calc(100vh - 220px)' }}
          >
            {renderSidebarContent()}
          </aside>

          <AnimatePresence>
            {isMobileDrawerOpen && (
              <>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 lg:hidden"
                  onClick={() => setIsMobileDrawerOpen(false)}
                />
                <motion.div
                  initial={{ x: '-100%' }}
                  animate={{ x: 0 }}
                  exit={{ x: '-100%' }}
                  transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                  className="fixed top-0 left-0 bottom-0 w-4/5 max-w-sm bg-white z-50 border-r border-slate-200 shadow-2xl flex flex-col"
                  role="dialog"
                  aria-label="Documentation navigation"
                >
                  <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-white/80 backdrop-blur-xl">
                    <div className="font-serif text-2xl tracking-tight">Menu</div>
                    <button
                      type="button"
                      onClick={() => setIsMobileDrawerOpen(false)}
                      className="p-2 hover:bg-slate-100 rounded-full transition-colors"
                      aria-label="Close menu"
                    >
                      <X size={20} className="text-slate-500" />
                    </button>
                  </div>
                  <div className="p-4 overflow-y-auto flex-1">{renderSidebarContent()}</div>
                </motion.div>
              </>
            )}
          </AnimatePresence>

          <div
            ref={contentRef}
            className="flex-1 lg:pl-10 xl:pl-16 overflow-y-auto custom-scrollbar pb-20"
            style={{ maxHeight: 'calc(100vh - 220px)' }}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={`${activeCategory.id}-${activeSection.id}`}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              >
                {renderSectionBody()}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </main>

      <LandingFooter />

      <style
        dangerouslySetInnerHTML={{
          __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 6px; height: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.1); border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.2); }
      `,
        }}
      />
    </div>
  );
}
