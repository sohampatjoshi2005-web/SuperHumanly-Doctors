import LandingNavbar from '../components/landing/LandingNavbar';
import LandingFooter from '../components/landing/LandingFooter';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, HelpCircle, MessageSquare, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';

const faqs = [
  {
    category: "Technical Sovereignty",
    questions: [
      {
        q: "What is 'Institutional Medical Sovereignty'?",
        a: "It is the principle that a healthcare institution should have absolute technical control over its medical data and the AI infrastructure that processes it. Unlike public AI tools, we provide isolated kernels where your data is never used to train global models."
      },
      {
        q: "Are the AI models HIPAA compliant?",
        a: "Yes. Our models run within HIPAA-compliant, SOC-2 verified environments. All clinical data processing occurs within encrypted, per-user nodes to ensure zero leakage between different medical entities."
      }
    ]
  },
  {
    category: "Clinical Workflow",
    questions: [
      {
        q: "How accurate is the 'AI Intake Engine'?",
        a: "Our engine uses a medical-tuned transcription pipeline with high-accuracy ASR, clinician-oriented prompting, and terminology correction. In benchmarked quiet clinical environments, the target operating point is 98.4% transcription accuracy, with final verification kept in the doctor workflow."
      },
      {
        q: "Does the platform integrate with my existing EHR?",
        a: "Yes. Our Enterprise tier supports full FHIR-based bidirectional syncing with major EHR systems like Epic and Cerner. Standard users can utilize our 'Intelligence Export' to move documentation into their existing registries."
      }
    ]
  },
  {
    category: "Privacy & Security",
    questions: [
      {
        q: "Who owns the clinical documentation generated?",
        a: "You do. Superhumanly Doctors acts as a technical custodian. The institution or individual practitioner maintains 100% legal ownership of all records, notes, and patient data."
      },
      {
        q: "Can I delete my data permanently?",
        a: "Absolutely. Our platform supports 'Instant Purge' protocols. When you delete a record or an account, the associated data is scrubbed across our primary and backup nodes."
      }
    ]
  }
];

export default function FAQPage() {
  const [openIdx, setOpenIdx] = useState(null);

  return (
    <div className="bg-white min-h-screen">
      <SEO
        title="Protocol Support & FAQ"
        description="Institutional knowledge base for clinical documentation automation, EHR synchronization, and data sovereignty protocols."
        faqs={faqs.flatMap((cat) => cat.questions)}
      />
      <LandingNavbar />
      
      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl font-serif text-text mb-6">Medical Support <span className="italic text-accent">FAQ.</span></h1>
            <p className="text-lg text-text2/60 font-medium">
               Answering the most critical questions about clinical intelligence and data sovereignty.
            </p>
          </motion.div>

          <div className="space-y-16">
             {faqs.map((cat, catIdx) => (
                <div key={catIdx}>
                   <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-accent-vibrant mb-8 border-b border-border pb-4">{cat.category}</h3>
                   <div className="space-y-2">
                      {cat.questions.map((faq, qIdx) => {
                         const idx = `${catIdx}-${qIdx}`;
                         const isOpen = openIdx === idx;
                         return (
                            <div key={idx} className={`rounded-3xl border transition-all duration-300 ${isOpen ? 'border-text/20 bg-accent/5' : 'border-border bg-white hover:bg-off'}`}>
                               <button 
                                 onClick={() => setOpenIdx(isOpen ? null : idx)}
                                 className="w-full text-left p-6 flex justify-between items-center"
                               >
                                  <span className="text-lg font-bold text-text pr-4 leading-tight">{faq.q}</span>
                                  <ChevronDown className={`shrink-0 transition-transform duration-300 text-text/30 ${isOpen ? 'rotate-180' : ''}`} size={20} />
                               </button>
                               <AnimatePresence>
                                  {isOpen && (
                                     <motion.div
                                        initial={{ height: 0, opacity: 0 }}
                                        animate={{ height: 'auto', opacity: 1 }}
                                        exit={{ height: 0, opacity: 0 }}
                                        transition={{ duration: 0.3 }}
                                        className="overflow-hidden"
                                     >
                                        <div className="px-6 pb-6 text-text2/70 font-medium leading-relaxed">
                                           {faq.a}
                                        </div>
                                     </motion.div>
                                  )}
                               </AnimatePresence>
                            </div>
                         );
                      })}
                   </div>
                </div>
             ))}
          </div>

          {/* Call to action */}
          <div className="mt-20 grid grid-cols-1 sm:grid-cols-2 gap-6">
             <Link to="/contact" className="p-8 rounded-[32px] bg-text text-white group hover:bg-black transition-all no-underline">
                <MessageSquare className="text-accent-vibrant mb-6" size={32} />
                <h4 className="text-xl font-serif mb-2 italic">Still have questions?</h4>
                <p className="text-white/50 text-sm font-medium">Consult with our Medical Engineering team for institutional deployments.</p>
             </Link>
             <Link to="/documentation/getting-started/overview" className="p-8 rounded-[32px] bg-off border border-border group hover:bg-white hover:shadow-2xl transition-all no-underline">
                <BookOpen className="text-accent mb-6" size={32} />
                <h4 className="text-xl font-serif mb-2 italic">Technical Documentation</h4>
                <p className="text-text2/50 text-sm font-medium">Full SDK and API reference for clinical integration.</p>
             </Link>
          </div>
        </div>
      </main>

      <LandingFooter />
    </div>
  );
}
