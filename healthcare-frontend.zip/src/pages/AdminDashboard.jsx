import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { 
  Shield, Activity, Users, Clock, CheckCircle2, 
  XCircle, Filter, Search, MoreHorizontal, 
  ArrowUpRight, Download, RefreshCw, LogOut,
  Building, Terminal, Zap, Globe, Cpu, ChevronRight,
  TrendingUp, BarChart3, PieChart as PieChartIcon, 
  ZapOff, AlertTriangle, Database
} from 'lucide-react';
import { 
  LineChart, Line, AreaChart, Area, XAxis, YAxis, 
  CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, BarChart, Bar 
} from 'recharts';
import { fetchAdminStats, fetchTrialRequests, updateTrialStatus, fetchHealthTelemetry } from '../lib/doctorApi';
import SEO from '../components/SEO';
import AdminSidebar from '../components/admin/AdminSidebar';
import TrialLedgerTab from '../components/admin/TrialLedgerTab';
import AuditVaultTab from '../components/admin/AuditVaultTab';
import UserDirectoryTab from '../components/admin/UserDirectoryTab';
import ClinicRegistryTab from '../components/admin/ClinicRegistryTab';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [viewMode, setViewMode] = useState('feed'); // 'feed' or 'analytics'
  const [stats, setStats] = useState(null);
  const [trials, setTrials] = useState([]);
  const [telemetry, setTelemetry] = useState({ cpu_usage: 0, memory_percent: 0, disk_percent: 0, latency_ms: 0 });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedTrial, setSelectedTrial] = useState(null);
  const navigate = useNavigate();

  const loadData = async (isSilent = false) => {
    if (!isSilent) setLoading(true);
    else setRefreshing(true);
    try {
      const [statsData, trialsData] = await Promise.all([
        fetchAdminStats(),
        fetchTrialRequests()
      ]);
      setStats(statsData);
      setTrials(trialsData);
    } catch (err) {
      console.error('Failed to load admin data:', err);
      if (err.message?.includes('Session expired')) navigate('/admin/login');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const loadTelemetry = async () => {
    try {
      const data = await fetchHealthTelemetry();
      setTelemetry(data);
    } catch (err) {
      console.error('Failed to load telemetry:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (activeTab === 'health') {
      loadTelemetry();
      const interval = setInterval(loadTelemetry, 10000);
      return () => clearInterval(interval);
    }
  }, [activeTab]);

  // Process data for charts
  const chartData = useMemo(() => {
    return stats?.trial_growth || [];
  }, [stats]);

  const roleDistribution = useMemo(() => {
    return stats?.role_distribution || [];
  }, [stats]);

  const COLORS = ['#004EB3', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

  const handleStatusUpdate = async (trialId, newStatus) => {
    try {
      await updateTrialStatus(trialId, newStatus);
      setTrials(prev => prev.map(t => t._id === trialId ? { ...t, status: newStatus } : t));
      loadData(true);
    } catch (err) {
      alert('Failed to transition trial status.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('doc_token');
    localStorage.removeItem('doc_user');
    navigate('/admin/login');
  };

  if (loading) {
    return (
      <div className="h-screen bg-bg flex items-center justify-center overflow-hidden">
        <div className="flex flex-col items-center gap-6">
          <div className="relative">
             <div className="w-16 h-16 border-4 border-accent/5 border-t-accent rounded-full animate-spin" />
             <div className="absolute inset-0 flex items-center justify-center">
                <Terminal size={18} className="text-accent animate-pulse" />
             </div>
          </div>
          <div className="text-muted font-black uppercase tracking-[0.4em] text-[9px]">Synchronizing Terminal...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-bg text-text flex overflow-hidden selection:bg-accent/10">
      <SEO title="Admin Command Center" description="Superhumanly Doctors Institutional Administration Ledger." />
      
      <AdminSidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={handleLogout} />

      <div className="flex-1 flex flex-col relative overflow-hidden">
        {/* Immersive Grid Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:40px_40px] [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-[0.15]"></div>
          <div className="absolute top-0 right-0 w-[800px] h-[600px] bg-accent/5 blur-[150px] rounded-full opacity-40" />
          <div className="absolute bottom-0 left-0 w-[600px] h-[400px] bg-emerald-500/5 blur-[120px] rounded-full opacity-30" />
        </div>

        {/* Top Header - Precision Control Strip */}
        <header className="h-14 border-b border-border/50 flex items-center justify-between px-8 relative z-50 bg-white/40 backdrop-blur-2xl">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-2.5 py-1 rounded-lg bg-emerald-500/5 border border-emerald-500/10">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-emerald-700">Sovereign Node</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {refreshing && (
              <motion.div 
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-border/40 bg-white/50"
              >
                 <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                 <span className="text-[10px] font-black uppercase tracking-widest text-muted/40">Synchronizing</span>
              </motion.div>
            )}
            
            <button 
              onClick={() => loadData(true)}
              className={`w-8 h-8 rounded-lg border border-border/40 bg-white hover:bg-off flex items-center justify-center transition-all active:scale-95 group ${refreshing ? 'animate-spin' : ''}`}
            >
              <RefreshCw size={12} className="text-muted group-hover:text-text transition-colors" />
            </button>

            <div className="w-px h-4 bg-border/40" />

            <div className="flex items-center gap-3 pl-2">
              <div className="text-right">
                <div className="text-[11px] font-bold text-text tracking-tight leading-none mb-0.5">
                  {JSON.parse(localStorage.getItem('doc_user') || '{}')?.full_name || 'Administrator'}
                </div>
                <div className="text-[8px] font-black uppercase tracking-widest text-muted/30">Master Root</div>
              </div>
              <div className="w-8 h-8 rounded-lg bg-text text-white flex items-center justify-center text-[10px] font-black shadow-lg shadow-text/5 border border-text relative group/profile uppercase">
                {(JSON.parse(localStorage.getItem('doc_user') || '{}')?.full_name || 'A').charAt(0)}
                <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full shadow-sm" />
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto relative z-10 px-8 py-6 custom-scrollbar">
          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="space-y-12"
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-muted/30 mb-1">
                       <span>Admin</span>
                       <ChevronRight size={10} className="text-muted/20" />
                       <span className="text-accent">{activeTab === 'dashboard' ? 'Platform Preview' : activeTab}</span>
                    </div>
                    <h1 className="text-5xl lg:text-6xl font-serif tracking-tight text-text leading-tight relative">
                      Platform <span className="italic text-accent">Intelligence.</span>
                    </h1>
                    <div className="flex items-center gap-4">
                      <p className="text-[15px] text-muted/60 font-medium max-w-xl leading-relaxed">
                        Real-time clinical telemetry and institutional registry oversight.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center p-1 bg-off border border-border/40 rounded-2xl shadow-inner group/toggle">
                     <button 
                        onClick={() => setViewMode('feed')}
                        className={`px-5 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all ${
                          viewMode === 'feed' 
                            ? 'bg-white shadow-[0_4px_12px_rgba(0,0,0,0.05)] text-text border border-border/60' 
                            : 'text-muted/40 hover:text-muted/60'
                        }`}
                      >
                        Live Feed
                     </button>
                     <button 
                        onClick={() => setViewMode('analytics')}
                        className={`px-5 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all ${
                          viewMode === 'analytics' 
                            ? 'bg-white shadow-[0_4px_12px_rgba(0,0,0,0.05)] text-text border border-border/60' 
                            : 'text-muted/40 hover:text-muted/60'
                        }`}
                      >
                        Analytical View
                     </button>
                  </div>
                </div>

                <AnimatePresence mode="wait">
                  {viewMode === 'feed' ? (
                    <motion.div
                      key="feed"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      className="space-y-12"
                    >
                      {/* KPI Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                        {[
                          { label: 'Pending Requests', val: stats?.pending_trials || 0, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100', desc: 'Awaiting MD verification' },
                          { label: 'Active Doctors', val: stats?.total_doctors || 0, icon: Users, color: 'text-accent', bg: 'bg-accent-light', border: 'border-accent/10', desc: 'Authenticated clinical nodes' },
                          { label: 'Platform Approval', val: stats?.approved_trials || 0, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100', desc: 'Sovereign access granted' },
                          { label: 'Total Footprint', val: stats?.total_trials || 0, icon: Shield, color: 'text-text/60', bg: 'bg-off', border: 'border-border', desc: 'Institutional reach' }
                        ].map((s, i) => (
                          <div key={i} className="bg-white border border-border/60 rounded-[28px] p-6 hover:shadow-xl hover:shadow-black/[0.02] transition-all group relative overflow-hidden shadow-sm">
                            <div className="absolute top-0 right-0 p-6 opacity-0 group-hover:opacity-[0.03] transition-opacity translate-x-4 group-hover:translate-x-0 transition-transform duration-500">
                               <s.icon size={64} />
                            </div>
                            <div className="flex items-center justify-between mb-6 relative z-10">
                              <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${s.bg} ${s.color} border ${s.border} shadow-sm transition-transform group-hover:scale-110 duration-300`}>
                                <s.icon size={18} />
                              </div>
                              <div className="w-8 h-8 rounded-lg bg-off flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                 <ArrowUpRight size={14} className="text-muted/40" />
                              </div>
                            </div>
                            <div className="text-4xl font-bold mb-1.5 tracking-tighter text-text relative z-10">{s.val}</div>
                            <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted mb-1 relative z-10">{s.label}</div>
                            <div className="text-[10px] font-medium text-muted/40 relative z-10">{s.desc}</div>
                          </div>
                        ))}
                      </div>

                      {/* Recent Activity Ledger */}
                      <div className="bg-white border border-border/60 rounded-[32px] p-8 shadow-sm relative overflow-hidden flex flex-col min-h-[400px]">
                        <div className="flex items-center justify-between mb-8">
                           <div className="space-y-1">
                             <h3 className="text-xl font-serif tracking-tight text-text">Recent <span className="italic text-accent">Activity Ledger.</span></h3>
                             <p className="text-[12px] text-muted/40 font-medium tracking-tight">Direct institutional oversight of pending clinical access requests.</p>
                           </div>
                           <button 
                             onClick={() => setActiveTab('trials')}
                             className="flex items-center gap-2 px-4 py-2 rounded-xl text-[11px] font-black uppercase tracking-widest text-accent bg-accent-light border border-accent/10 hover:bg-accent hover:text-white transition-all shadow-sm active:scale-95"
                           >
                             View Full Ledger <ChevronRight size={14} />
                           </button>
                        </div>

                        <div className="flex-1 overflow-x-auto">
                          <table className="w-full text-left border-separate border-spacing-0">
                            <thead>
                              <tr>
                                <th className="px-4 py-4 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Requester Node</th>
                                <th className="px-4 py-4 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Institutional Entity</th>
                                <th className="px-4 py-4 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Status</th>
                                <th className="px-4 py-4 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30 text-right">Protocol Action</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-border/20">
                              {trials.slice(0, 5).map((trial) => (
                                <tr key={trial._id} className="group hover:bg-off/50 transition-colors cursor-pointer" onClick={() => setSelectedTrial(trial)}>
                                  <td className="px-4 py-4">
                                    <div className="flex items-center gap-3">
                                      <div className="w-8 h-8 rounded-lg bg-text text-white flex items-center justify-center text-[10px] font-black shadow-lg shadow-text/10">
                                        {trial.full_name.charAt(0)}
                                      </div>
                                      <div>
                                        <div className="text-[13px] font-bold text-text tracking-tight">{trial.full_name}</div>
                                        <div className="text-[10px] text-muted/50 font-medium truncate max-w-[150px]">{trial.email}</div>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="px-4 py-4">
                                    <div className="flex items-center gap-2 text-[12px] font-medium text-text/70">
                                       <Building size={12} className="text-muted/30" />
                                       {trial.institution}
                                    </div>
                                  </td>
                                  <td className="px-4 py-4">
                                    <div className={`inline-flex items-center px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${
                                      trial.status === 'pending' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                                      trial.status === 'approved' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                                      'bg-red-50 text-red-600 border-red-100'
                                    }`}>
                                       {trial.status}
                                    </div>
                                  </td>
                                  <td className="px-4 py-4 text-right">
                                    <div className="p-2 inline-flex rounded-lg hover:bg-white hover:shadow-sm border border-transparent hover:border-border/60 transition-all text-muted/40 hover:text-text">
                                      <ArrowUpRight size={16} />
                                    </div>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="analytics"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className="space-y-8"
                    >
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Request Volume Chart */}
                        <div className="lg:col-span-2 bg-white border border-border/60 rounded-[32px] p-8 shadow-sm">
                           <div className="flex items-center justify-between mb-8">
                              <div>
                                <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-muted/40 mb-1">Growth Telemetry</h4>
                                <h3 className="text-lg font-bold text-text">Sovereign Request Volume</h3>
                              </div>
                              <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-emerald-500">
                                 <TrendingUp size={14} /> +12.5% this week
                              </div>
                           </div>
                           <div className="h-[300px] w-full">
                              <ResponsiveContainer width="100%" height="100%">
                                 <AreaChart data={chartData}>
                                    <defs>
                                      <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#004EB3" stopOpacity={0.1}/>
                                        <stop offset="95%" stopColor="#004EB3" stopOpacity={0}/>
                                      </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                                    <XAxis 
                                      dataKey="name" 
                                      axisLine={false} 
                                      tickLine={false} 
                                      tick={{fontSize: 10, fill: '#9ca3af', fontWeight: 600}} 
                                      dy={10}
                                    />
                                    <YAxis 
                                      axisLine={false} 
                                      tickLine={false} 
                                      tick={{fontSize: 10, fill: '#9ca3af', fontWeight: 600}} 
                                    />
                                    <Tooltip 
                                      contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.05)', fontSize: '12px'}}
                                    />
                                    <Area type="monotone" dataKey="requests" stroke="#004EB3" strokeWidth={3} fillOpacity={1} fill="url(#colorRequests)" />
                                 </AreaChart>
                              </ResponsiveContainer>
                           </div>
                        </div>

                        {/* Role Distribution */}
                        <div className="bg-white border border-border/60 rounded-[32px] p-8 shadow-sm flex flex-col">
                           <div className="mb-8">
                              <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-muted/40 mb-1">Clinical Demographics</h4>
                              <h3 className="text-lg font-bold text-text">Sovereign Mandates</h3>
                           </div>
                           <div className="flex-1 min-h-[250px]">
                              <ResponsiveContainer width="100%" height="100%">
                                 <PieChart>
                                    <Pie
                                      data={roleDistribution}
                                      cx="50%"
                                      cy="50%"
                                      innerRadius={60}
                                      outerRadius={80}
                                      paddingAngle={5}
                                      dataKey="value"
                                    >
                                      {roleDistribution.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                      ))}
                                    </Pie>
                                    <Tooltip />
                                 </PieChart>
                              </ResponsiveContainer>
                           </div>
                           <div className="mt-4 grid grid-cols-2 gap-2">
                              {roleDistribution.map((role, idx) => (
                                <div key={idx} className="flex items-center gap-2">
                                   <div className="w-2 h-2 rounded-full" style={{backgroundColor: COLORS[idx % COLORS.length]}} />
                                   <span className="text-[10px] font-bold text-muted/60 truncate">{role.name}</span>
                                </div>
                              ))}
                           </div>
                        </div>
                      </div>

                      {/* Technical Performance Strip */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {[
                          { label: 'Avg Latency', val: '240ms', icon: Activity, sub: 'Processing throughput' },
                          { label: 'Security Score', val: '100%', icon: Shield, sub: 'Zero-trust verified' },
                          { label: 'Node Health', val: 'Nominal', icon: Zap, sub: 'US-EAST-GTY-01' }
                        ].map((p, i) => (
                          <div key={i} className="bg-white border border-border/60 rounded-3xl p-6 shadow-sm flex items-center gap-5">
                             <div className="w-12 h-12 rounded-2xl bg-off border border-border/40 flex items-center justify-center text-muted/30">
                                <p.icon size={20} />
                             </div>
                             <div>
                                <div className="text-[10px] font-black uppercase tracking-widest text-muted/40 mb-0.5">{p.label}</div>
                                <div className="text-xl font-bold text-text">{p.val}</div>
                                <div className="text-[10px] font-medium text-muted/50">{p.sub}</div>
                             </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}

            {activeTab === 'trials' && (
              <TrialLedgerTab 
                trials={trials}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                filterStatus={filterStatus}
                setFilterStatus={setFilterStatus}
                onSelectTrial={setSelectedTrial}
              />
            )}

            {activeTab === 'users' && (
              <UserDirectoryTab />
            )}

            {activeTab === 'audit' && (
              <AuditVaultTab />
            )}

            {activeTab === 'health' && (
              <motion.div
                key="health"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="space-y-10"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-muted/30 mb-1">
                     <span>Infrastructure</span>
                     <ChevronRight size={10} className="text-muted/20" />
                     <span className="text-accent">System Health</span>
                  </div>
                  <h1 className="text-5xl lg:text-6xl font-serif tracking-tight text-text leading-tight">
                    Sovereign <span className="italic text-accent">Integrity.</span>
                  </h1>
                  <p className="text-[15px] text-muted/60 font-medium max-w-xl leading-relaxed">
                    Institutional-grade oversight of infrastructure topology and neural throughput.
                  </p>
                </div>

                {/* Service Status Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { name: 'Core API Gateway', status: 'Nominal', sub: 'FastAPI v0.110', icon: Zap, color: 'text-emerald-500', bg: 'bg-emerald-50' },
                    { name: 'Persistence Layer', status: 'Stable', sub: 'PostgreSQL 16', icon: Database, color: 'text-accent', bg: 'bg-accent-light' },
                    { name: 'Audit Worker Cluster', status: 'Active', sub: 'Celery / Redis', icon: Cpu, color: 'text-amber-500', bg: 'bg-amber-50' },
                    { name: 'Neural AI Engine', status: 'Online', sub: 'LangGraph Protocol', icon: Activity, color: 'text-emerald-500', bg: 'bg-emerald-50' }
                  ].map((s, i) => (
                    <div key={i} className="bg-white border border-border/60 rounded-[28px] p-6 shadow-sm group hover:shadow-md transition-all">
                       <div className="flex items-center justify-between mb-6">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${s.bg} ${s.color} border border-black/[0.03]`}>
                             <s.icon size={18} />
                          </div>
                          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-off border border-border/40 text-[9px] font-black uppercase tracking-widest text-muted/40">
                             v2.4.0
                          </div>
                       </div>
                       <div className="text-[14px] font-bold text-text tracking-tight mb-1">{s.name}</div>
                       <div className="flex items-center gap-2 mb-3">
                          <div className={`w-1.5 h-1.5 rounded-full ${s.status === 'Nominal' || s.status === 'Online' ? 'bg-emerald-500' : 'bg-amber-500'} animate-pulse`} />
                          <span className={`text-[11px] font-black uppercase tracking-widest ${s.status === 'Nominal' || s.status === 'Online' ? 'text-emerald-600' : 'text-amber-600'}`}>{s.status}</span>
                       </div>
                       <div className="text-[10px] font-medium text-muted/40">{s.sub}</div>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Neural Latency Telemetry */}
                  <div className="lg:col-span-2 bg-white border border-border/60 rounded-[32px] p-8 shadow-sm">
                    <div className="flex items-center justify-between mb-8">
                       <h3 className="text-lg font-bold text-text">Neural Throughput Latency</h3>
                       <div className="flex items-center gap-4">
                          <div className="flex items-center gap-2 text-[10px] font-bold text-muted/40 uppercase tracking-widest">
                             <div className="w-2 h-2 rounded-full bg-accent" /> API Gateway
                          </div>
                          <div className="flex items-center gap-2 text-[10px] font-bold text-muted/40 uppercase tracking-widest">
                             <div className="w-2 h-2 rounded-full bg-emerald-500" /> AI Reasoning
                          </div>
                       </div>
                    </div>
                    <div className="h-[320px] w-full">
                       <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={[
                            { name: '12:00', api: 45, ai: 1200 },
                            { name: '13:00', api: 52, ai: 1450 },
                            { name: '14:00', api: 48, ai: 1100 },
                            { name: '15:00', api: 61, ai: 1600 },
                            { name: '16:00', api: 55, ai: 1300 },
                            { name: '17:00', api: 42, ai: 1250 },
                            { name: '18:00', api: 49, ai: 1400 }
                          ]}>
                             <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                             <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#9ca3af'}} />
                             <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#9ca3af'}} />
                             <Tooltip contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.05)'}} />
                             <Line type="monotone" dataKey="api" stroke="#004EB3" strokeWidth={3} dot={false} />
                             <Line type="monotone" dataKey="ai" stroke="#10B981" strokeWidth={3} dot={false} />
                          </LineChart>
                       </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Resource Matrix */}
                  <div className="bg-white border border-border/60 rounded-[32px] p-8 shadow-sm flex flex-col">
                    <h3 className="text-lg font-bold text-text mb-8">Resource Matrix</h3>
                    <div className="space-y-8 flex-1">
                       {[
                         { label: 'CPU Utilization', val: telemetry.cpu_usage, color: 'bg-accent' },
                         { label: 'Memory Persistence', val: telemetry.memory_percent, color: 'bg-emerald-500' },
                         { label: 'Network Ingress', val: 24, color: 'bg-amber-500' },
                         { label: 'Storage Cluster', val: telemetry.disk_percent, color: 'bg-text' }
                       ].map((r, i) => (
                         <div key={i} className="space-y-2">
                            <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-muted/60">
                               <span>{r.label}</span>
                               <span className="text-text">{r.val}%</span>
                            </div>
                            <div className="h-2 w-full bg-off rounded-full overflow-hidden">
                               <motion.div 
                                 initial={{ width: 0 }}
                                 animate={{ width: `${r.val}%` }}
                                 transition={{ duration: 1 }}
                                 className={`h-full ${r.color} rounded-full`}
                               />
                            </div>
                         </div>
                       ))}
                    </div>
                    <div className="mt-8 pt-6 border-t border-border/40">
                       <div className="flex items-center justify-between p-4 bg-off rounded-2xl border border-border/60">
                          <div className="flex items-center gap-3">
                             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                             <span className="text-[10px] font-black uppercase tracking-widest text-text">Cluster Optimized</span>
                          </div>
                          <ChevronRight size={14} className="text-muted/40" />
                       </div>
                    </div>
                  </div>
                </div>

                {/* System Event Log */}
                <div className="bg-white border border-border/60 rounded-[32px] p-8 shadow-sm relative overflow-hidden">
                   <div className="flex items-center justify-between mb-8">
                      <h3 className="text-lg font-bold text-text">System Infrastructure Ledger</h3>
                      <button className="text-[10px] font-black uppercase tracking-widest text-accent hover:underline">Export Logs</button>
                   </div>
                   <div className="space-y-4 font-mono">
                      {[
                        { time: '18:42:01', level: 'INFO', msg: 'Audit queue flushed successfully [342 objects]', color: 'text-emerald-600' },
                        { time: '18:40:12', level: 'SYSTEM', msg: 'Neural reasoning pipeline handshake verified', color: 'text-accent' },
                        { time: '18:35:55', level: 'Nominal', msg: 'PostgreSQL connection pool synchronized [ID: 882]', color: 'text-muted/60' },
                        { time: '18:30:22', level: 'INFO', msg: 'Master Administrator login detected [IP: 192.168.1.1]', color: 'text-amber-600' }
                      ].map((l, i) => (
                        <div key={i} className="flex gap-4 text-[12px] p-2 rounded-lg hover:bg-off transition-colors">
                           <span className="text-muted/40 shrink-0">{l.time}</span>
                           <span className={`font-black uppercase tracking-tighter shrink-0 w-16 ${l.color}`}>{l.level}</span>
                           <span className="text-text/70 truncate">{l.msg}</span>
                        </div>
                      ))}
                   </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'clinics' && (
              <ClinicRegistryTab />
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Trial Detail Drawer (Hardened) */}
      <AnimatePresence>
        {selectedTrial && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedTrial(null)}
              className="fixed inset-0 bg-text/40 backdrop-blur-sm z-[1000]"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 w-full max-w-[540px] h-full bg-white border-l border-border/60 z-[1001] shadow-[0_32px_100px_rgba(0,0,0,0.15)] flex flex-col overflow-hidden"
            >
              <div className="p-8 border-b border-border/60 flex items-center justify-between bg-off/50 backdrop-blur-md">
                <div className="flex items-center gap-5">
                  <div className="w-12 h-12 rounded-2xl bg-text text-white flex items-center justify-center text-xl font-black shadow-lg shadow-text/10 border border-text">
                    {selectedTrial.full_name.charAt(0)}
                  </div>
                  <div>
                    <h2 className="text-xl font-bold tracking-tight text-text mb-0.5 leading-none">{selectedTrial.full_name}</h2>
                    <p className="text-[13px] text-muted font-medium">{selectedTrial.email}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedTrial(null)}
                  className="w-10 h-10 rounded-xl hover:bg-white border border-transparent hover:border-border/60 transition-all text-muted/40 hover:text-text flex items-center justify-center"
                >
                  <XCircle size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-10 space-y-12 custom-scrollbar">
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-off/50 border border-border/40 rounded-3xl p-6">
                    <div className="text-[9px] font-black uppercase tracking-[0.2em] text-muted/40 mb-3">Institutional Entity</div>
                    <div className="font-bold flex items-center gap-3 text-text text-[15px]">
                      <Building size={16} className="text-accent" /> {selectedTrial.institution}
                    </div>
                  </div>
                  <div className="bg-off/50 border border-border/40 rounded-3xl p-6">
                    <div className="text-[9px] font-black uppercase tracking-[0.2em] text-muted/40 mb-3">Clinical Mandate</div>
                    <div className="font-bold flex items-center gap-3 text-text text-[15px]">
                      <Terminal size={16} className="text-accent" /> {selectedTrial.professional_role}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-muted/30 mb-4 px-2">Use Case Architecture</h4>
                  <div className="bg-white border border-border/60 rounded-[32px] p-8 font-serif text-xl leading-relaxed text-text italic shadow-sm relative">
                    <span className="absolute top-4 left-6 text-4xl text-accent/10 font-serif">"</span>
                    <div className="relative z-10 pl-4">{selectedTrial.use_case}</div>
                    <span className="absolute bottom-2 right-6 text-4xl text-accent/10 font-serif rotate-180">"</span>
                  </div>
                </div>

                <div className="space-y-4">
                   <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-muted/30 mb-4 px-2">Protocol Metadata</h4>
                   <div className="space-y-px rounded-[24px] border border-border/60 overflow-hidden shadow-sm">
                      <div className="flex items-center justify-between text-[13px] px-6 py-4 bg-off/30 border-b border-border/40">
                        <span className="text-muted font-medium">Transmission Timestamp</span>
                        <span className="font-mono text-text/60">{new Date(selectedTrial.created_at).toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between text-[13px] px-6 py-4 bg-off/30 border-b border-border/40">
                        <span className="text-muted font-medium">Security Clearance</span>
                        <span className="font-mono text-emerald-600 font-bold">Verified HIPAA/SOC2-II</span>
                      </div>
                      <div className="flex items-center justify-between text-[13px] px-6 py-4 bg-off/30">
                         <span className="text-muted font-medium">Network Node</span>
                         <span className="font-mono text-text/60 tracking-tighter">US-EAST-GTY-PROD-04</span>
                      </div>
                   </div>
                </div>
              </div>

              <div className="p-8 border-t border-border/60 bg-off/50 flex items-center gap-4">
                  {selectedTrial.status === 'pending' ? (
                    <>
                      <button 
                        onClick={() => handleStatusUpdate(selectedTrial._id, 'approved')}
                        className="flex-1 h-14 bg-text text-white rounded-2xl font-black uppercase tracking-widest text-[12px] hover:bg-accent transition-all flex items-center justify-center gap-3 shadow-xl shadow-text/10 border border-text hover:border-accent"
                      >
                         <CheckCircle2 size={18} /> Authorize Clinical Access
                      </button>
                      <button 
                        onClick={() => handleStatusUpdate(selectedTrial._id, 'rejected')}
                        className="flex-1 h-14 bg-white border border-border/60 text-text hover:bg-red-50 hover:border-red-200 hover:text-red-600 rounded-2xl font-black uppercase tracking-widest text-[12px] transition-all flex items-center justify-center gap-3"
                      >
                         <XCircle size={18} /> Rescind Protocol
                      </button>
                    </>
                  ) : (
                    <div className="w-full text-center py-5 bg-white rounded-2xl border border-border/60 text-[10px] font-black uppercase tracking-[0.25em] text-muted/40">
                      Protocol Processed on {new Date(selectedTrial.processed_at).toLocaleDateString()}
                    </div>
                  )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.05); border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.1); }
      `}} />
    </div>
  );
}
