import { 
  Book, Workflow, Users, Terminal, Shield, Brain, HelpCircle, Lock 
} from 'lucide-react';

export const docCategories = [
  {
    id: 'getting-started',
    title: 'Getting Started',
    icon: Book,
    subcategories: [
      { 
        id: 'overview', 
        title: 'Product Overview',
        content: {
          title: 'What is this product?',
          text: 'Superhumanly Doctors is a B2B AI-powered clinical intelligence platform. It converts raw clinical conversations into accurate, actionable medical summaries and structured prescriptions in real time, helping physicians focus more on patient care and less on paperwork.',
          alert: {
            type: 'info',
            title: 'Mission-Critical Reliability',
            text: 'Superhumanly is architected for 99.99% availability, utilizing zero-trust data isolation protocols designed to meet the rigorous demands of trauma centers and high-volume clinics.'
          }
        }
      },
      {
        id: 'how-it-works',
        title: 'How It Works',
        content: {
          title: '3-Step Core Workflow',
          text: 'The platform is built around a streamlined, friction-free ingestion engine:',
          customComponent: 'AcousticFlowDiagram',
          steps: [
            { label: 'Phase 01: Speak', desc: 'Secure acoustic capture during the patient encounter.' },
            { label: 'Phase 02: Transcribe', desc: 'High-fidelity audio is converted via clinical NLP models.' },
            { label: 'Phase 03: Generate', desc: 'Structured SOAP notes and medical prescriptions are instantly synthesized.' }
          ]
        }
      },
      {
        id: 'quickstart',
        title: 'Quick Start Guide',
        content: {
          title: 'First Prescription in 5 Minutes',
          text: 'To initialize your first session, navigate to the "Patients" registry on your dashboard, select an active node, and click "Initialize Encounter". Ensure your microphone is positioned correctly. The system will begin immediate audio analysis.',
          commandStrip: 'trial-key-activate --node=hospital-1',
          list: [
            'Log into the clinical portal using your institutional credentials.',
            'Grant microphone and local caching permissions in your browser.',
            'Select a patient profile (or create a new ad-hoc encounter).',
            'Press the ambient capture button and begin your consultation.',
            'Review the generated synthesis, edit as necessary, and sign to commit.'
          ]
        }
      },
      {
        id: 'sysreqs',
        title: 'System Requirements',
        content: {
          title: 'Hardware & Browser Support',
          text: 'Superhumanly requires a modern web environment for high-speed edge processing.',
          list: [
            'Browsers: Google Chrome v115+ or Microsoft Edge v115+ (Safari and Firefox are partially supported but not recommended for edge audio streaming).',
            'Permissions: Persistent Microphone access is strictly required.',
            'Hardware: A dedicated USB boundary microphone or premium headset is highly recommended for noisy clinical environments.',
            'Internet: Minimum 10Mbps stable upstream for real-time cloud sync.'
          ]
        }
      }
    ]
  },
  {
    id: 'doctors',
    title: 'For Doctors',
    icon: Workflow,
    subcategories: [
      {
        id: 'recording',
        title: 'Consultation Recording',
        content: {
          title: 'How to Record a Consultation',
          text: 'Ensure the acoustic environment is optimal. Beamforming technology attempts to isolate the physician\'s voice from background noise, but clear dictation of medical entities (dosages, anatomical locations) improves accuracy.',
          steps: [
            { label: 'Step 01: Setup Mic', desc: 'Ensure your USB boundary microphone or headset is connected and selected in your browser settings.' },
            { label: 'Step 02: Start Encounter', desc: 'Click "Initialize Encounter" on the patient dashboard to open the acoustic workspace.' },
            { label: 'Step 03: Dictate', desc: 'Press the microphone icon and begin your consultation naturally. The AI will extract clinical entities automatically.' }
          ],
          alert: {
            type: 'warning',
            title: 'Encryption Key Rotation',
            text: 'Ambient sessions are encrypted with session-bound keys. If a recording is interrupted, you may need to re-verify your identity.'
          }
        }
      },
      {
        id: 'languages',
        title: 'Languages & Accents',
        content: {
          title: 'Supported Languages & Accents',
          text: 'Our Clinical Grammar Engine is trained on diverse, multicultural medical corpora. It seamlessly adapts to various linguistic patterns without requiring manual toggle adjustments.',
          list: [
            'Standard American & British English: Native parsing with high accuracy on complex pharmacological terminology.',
            'Indian-Accented English: Fine-tuned to understand regional inflections and common medical abbreviations used in APAC.',
            'Hinglish (Hindi-English Mixing): Capable of extracting structured clinical intent even when sentences blend Hindi and English words.',
            'Acoustic Adaptation: The model automatically calibrates to the speaker\'s voice profile within the first 10 seconds of the encounter.'
          ]
        }
      },
      {
        id: 'review-edit',
        title: 'Review & Edit Guidelines',
        content: {
          title: 'Reviewing Generated Notes',
          text: 'Always review the AI-generated SOAP notes and prescriptions before signing. You can click into any text block to manually correct misinterpreted terms or adjust dosages before finalizing.'
        }
      },
      {
        id: 'approve-sign',
        title: 'Approve, Sign & Send',
        content: {
          title: 'Signature & Export Synchronization',
          text: 'The final step of the ambient workflow is reviewing and signing the structured output. This process ensures that the finalized document is accurately mapped and securely transmitted.',
          steps: [
            { label: 'Step 01: Final Review', desc: 'Verify all extracted ICD-10 codes, dosages, and clinical instructions in the workspace editor.' },
            { label: 'Step 02: Digital Signature', desc: 'Click "Sign & Export" to cryptographically sign the document using your session token.' },
            { label: 'Step 03: EHR Sync', desc: 'The system automatically transmits the signed PDF and structured JSON payload to your connected EHR system.' }
          ]
        }
      },
      {
        id: 'profiles',
        title: 'Patient Profile Mapping',
        content: {
          title: 'Managing Patient Profiles',
          text: 'Encounter histories are mapped longitudinally. Ensure you have the correct patient record active before recording. You can view previous medications and chronic conditions from the right-hand panel during a session.'
        }
      }
    ]
  },
  {
    id: 'admins',
    title: 'For Clinic Admins',
    icon: Users,
    subcategories: [
      {
        id: 'setup',
        title: 'Clinic Account Setup',
        content: {
          title: 'Institutional Configuration',
          text: 'Set up your clinic\'s global defaults, including letterheads for PDF prescriptions, default currency for billing, and timezone settings under the Admin Settings panel.'
        }
      },
      {
        id: 'seats',
        title: 'Managing Doctors',
        content: {
          title: 'Adding & Removing Seats',
          text: 'Admin users can invite new physicians via email. You can manage Role-Based Access Control (RBAC) to restrict nurses or front-desk staff from signing prescriptions while allowing them to initiate recordings.',
          list: [
            'Global Admin: Full access to billing, audit logs, clinic settings, and user management. Cannot sign prescriptions unless also granted Physician role.',
            'Physician: Can create patients, initiate ambient recordings, edit SOAP notes, and cryptographically sign prescriptions for EHR export.',
            'Nurse / Assistant: Can create patient records and initiate ambient recordings, but cannot finalize or sign prescriptions.',
            'Auditor (Read-Only): Has access to view the Immutable Audit Ledger and generate compliance reports, but cannot access raw audio or PII.'
          ]
        }
      },
      {
        id: 'governance',
        title: 'Data Governance & Audits',
        content: {
          title: 'Records & Compliance Reports',
          text: 'Superhumanly maintains an Immutable Audit Ledger. Every sync event, edit, and export is recorded. Admins can generate SOC2/HIPAA compliance reports detailing exactly who accessed which patient record and when.',
          list: [
            'Generating Reports: Navigate to the Admin Dashboard > Governance > Audit Logs. Select a date range and click "Export to CSV" for a full compliance trace.',
            'Ledger Visibility: The immutable ledger tracks timestamp, user ID, IP address, and the exact action performed (e.g., "Signed Prescription for Patient X").',
            'Suspicious Activity Alerts: Configure webhook notifications to alert your IT team if multiple failed login attempts or unauthorized EHR syncs occur.'
          ],
          alert: {
            type: 'info',
            title: 'Audit Batching',
            text: 'Audit logs are batched via Redis and flushed to MongoDB every 5 seconds for high-throughput tracking without UI degradation.'
          }
        }
      },
      {
        id: 'billing',
        title: 'Billing & Subscriptions',
        content: {
          title: 'Subscription Management',
          text: 'View active usage limits, process audio minute quotas, and upgrade institutional plans from the Billing portal. Invoices are generated at the end of the calendar month.',
          steps: [
            { label: 'Step 1: Access Billing', desc: 'Log in as a Global Admin and navigate to the "Billing & Usage" tab in the Admin Settings.' },
            { label: 'Step 2: Select Tier', desc: 'Click "Upgrade Plan" and choose between Individual, Clinic, or Enterprise tiers based on your seat requirements.' },
            { label: 'Step 3: Payment Provision', desc: 'Enter the institutional corporate card details. Your account limits will scale instantly upon verification.' }
          ]
        }
      }
    ]
  },
  {
    id: 'api',
    title: 'API Reference',
    icon: Terminal,
    subcategories: [
      {
        id: 'overview',
        title: 'Overview',
        content: {
          title: 'REST API Reference',
          text: 'Programmatic access to ambient transcription, structured prescription generation, and encounter retrieval. All endpoints use HTTPS and Bearer authentication unless noted.',
          customComponent: 'ApiReferenceHub',
        },
      },
      {
        id: 'auth',
        title: 'Authentication',
        content: {
          title: 'API Keys & OAuth',
          text: 'All non-public endpoints require a Bearer token in the Authorization header. Admin accounts can generate long-lived API keys from the Developer Dashboard.',
        }
      },
      {
        id: 'transcribe',
        title: 'POST /process-audio',
        content: {
          title: 'Transcribe Audio Stream',
          text: 'The primary entry point for ambient extraction. Accepts a multipart form upload containing an audio file and an optional customer ID.',
        }
      },
      {
        id: 'generate-rx',
        title: 'POST /generate-prescription',
        content: {
          title: 'Generate Structured Prescription',
          text: 'Generates a structured JSON prescription from cleaned text. Extracted entities are mapped to standard medical ontologies.'
        }
      },
      {
        id: 'get-rx',
        title: 'GET /prescriptions/{id}',
        content: {
          title: 'Retrieve Clinical Encounters',
          text: 'Fetches the full JSON representation of a finalized encounter, including the SOAP note and medication array.'
        }
      }
    ]
  },
  {
    id: 'security',
    title: 'Security & Compliance',
    icon: Shield,
    subcategories: [
      {
        id: 'encryption',
        title: 'Cryptographic Specs',
        content: {
          title: 'AES-256-GCM / TLS-1.3',
          text: 'We utilize NIST-standard protocols. Data at rest is secured via AES-256-GCM. Data in transit operates exclusively over TLS 1.3 with Perfect Forward Secrecy.',
          badges: [
            { label: 'AES-256-GCM', color: 'blue' },
            { label: 'TLS 1.3 PFS', color: 'green' },
            { label: 'Session-Bound Tokens', color: 'indigo' },
            { label: 'Air-Gap Ready', color: 'slate' }
          ]
        }
      },
      {
        id: 'compliance',
        title: 'HIPAA & DPDP Mapping',
        content: {
          title: 'Regulatory Compliance',
          text: 'The platform exceeds US HIPAA and India\'s DPDP Act requirements. Zero-Trust architecture ensures no entity is trusted by default without multi-dimensional identity handshakes.',
          customComponent: 'ComplianceTable'
        }
      },
      {
        id: 'retention',
        title: 'Data Retention & Deletion',
        content: {
          title: 'Lifecycle Management',
          text: 'Institutional admins can configure custom data retention policies (e.g., auto-delete audio post-transcription). Manual data deletion requests are honored strictly within regulatory SLAs.'
        }
      }
    ]
  },
  {
    id: 'ai-accuracy',
    title: 'AI & Accuracy',
    icon: Brain,
    subcategories: [
      {
        id: 'safety-banner',
        title: 'Clinical Validation Warning',
        content: {
          title: 'MANDATORY SAFETY WARNING',
          text: 'Superhumanly AI is an assistive technology, NOT an autonomous diagnostic tool. The AI may hallucinate, misinterpret audio, or omit crucial details. The attending physician bears 100% responsibility for the accuracy, clinical validity, and safety of the final signed prescription.',
          alert: {
            type: 'critical',
            title: 'Physician Sovereign Review — Non-Negotiable',
            text: 'You MUST manually verify all generated dosages, drug names, and clinical instructions prior to approval. Under no circumstances should AI-generated output be signed without physician review. The AI assists; the doctor decides. Failure to review constitutes a clinical safety violation.'
          }
        }
      },
      {
        id: 'review-protocol',
        title: 'Mandatory Review Protocol',
        content: {
          title: 'Pre-Signature Validation Checklist',
          text: 'Before signing any AI-generated output, the attending clinician must complete the following verification steps without exception:',
          steps: [
            { label: 'Step 01: Drug Verification', desc: 'Confirm every medication name, dosage, frequency, and route of administration matches the clinical intent.' },
            { label: 'Step 02: Allergy Cross-Check', desc: 'Verify the prescription does not conflict with the patient\'s known allergies or existing medication regimen.' },
            { label: 'Step 03: Clinical Sign-Off', desc: 'Apply your digital signature only after full review. This constitutes legal attestation of accuracy.' }
          ]
        }
      },
      {
        id: 'nlp',
        title: 'Deep NLP & Vocabulary',
        content: {
          title: 'Medical Ontologies & Dictionary Boundaries',
          text: 'The AI uses specialized NLP trained on complex medical literature, enabling it to distinguish between incidental conversational noise and actionable clinical data.',
          list: [
            'Supported Ontologies: ICD-10-CM, SNOMED-CT, RxNorm, and LOINC are actively used for entity resolution.',
            'Vocabulary Size: The clinical grammar engine covers over 250,000 medical terms, drug names, and procedural codes.',
            'Known Limitations: Rare orphan drug names, newly approved biologics, and highly specialized surgical terminology may require manual correction.',
            'Continuous Learning: The system improves from structured corrections made by physicians during the review phase.'
          ]
        }
      },
      {
        id: 'corrections',
        title: 'Correcting Misheard Words',
        content: {
          title: 'Handling AI Mistakes',
          text: 'If the AI mishears a drug name (e.g., confusing "Zyrtec" with "Zantac"), click the medication block in the prescription editor to manually type the correct name. The system will learn from these structural corrections.',
          list: [
            'Click any highlighted medication block to enter edit mode and type the correct drug name or dosage.',
            'Use the "Flag for Review" button to mark ambiguous extractions for secondary physician verification.',
            'Corrections are stored anonymously to improve the clinical grammar engine for future encounters.',
            'If the same error recurs across multiple sessions, contact support to request a vocabulary patch.'
          ]
        }
      }
    ]
  },
  {
    id: 'troubleshooting',
    title: 'FAQs & Troubleshooting',
    icon: HelpCircle,
    subcategories: [
      {
        id: 'mic-permissions',
        title: 'Microphone Permissions',
        content: {
          title: 'Cannot Access Microphone',
          text: 'If the microphone indicator remains grey, click the lock icon in your browser URL bar and ensure "Microphone" is set to "Allow". Refresh the page to re-initialize the audio driver.'
        }
      },
      {
        id: 'offline',
        title: 'Network Drops & Offline Mode',
        content: {
          title: 'Handling Intermittent Connectivity',
          text: 'If your internet connection drops, the application will attempt to cache the audio locally in the browser (up to 10 minutes). Do not close the tab; the system will auto-upload the payload once connectivity is restored.'
        }
      }
    ]
  },
  {
    id: 'legal',
    title: 'Legal & Disclaimer',
    icon: Lock,
    subcategories: [
      {
        id: 'disclaimer',
        title: 'Medical Disclaimer',
        content: {
          title: 'Not Medical Advice',
          text: 'The software services provided by Superhumanly do not constitute the practice of medicine. The platform acts solely as an administrative record-keeping system.'
        }
      },
      {
        id: 'terms',
        title: 'Terms of Service',
        content: {
          title: 'Usage Agreements',
          text: 'By accessing the institutional node, you agree to our comprehensive Master Service Agreement. Unauthorized distribution of patient data constitutes a severe violation of these terms.'
        }
      },
      {
        id: 'privacy',
        title: 'Privacy Policy',
        content: {
          title: 'Data Privacy',
          text: 'We do not sell, rent, or monetize clinical data. Data used for model fine-tuning is strictly aggregated, completely de-identified, and requires explicit institutional opt-in.'
        }
      }
    ]
  }
];
