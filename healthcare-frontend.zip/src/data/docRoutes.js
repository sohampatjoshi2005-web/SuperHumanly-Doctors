import { docCategories } from './docCategories.js';

/** ISO date for YMYL trust signals — bump when clinical copy changes materially. */
export const DOC_CONTENT_LAST_MODIFIED = '2026-05-23';

export const DOC_MEDICAL_REVIEWER =
  'Superhumanly Clinical Safety Board — licensed physician reviewers';

const MEDICAL_WEB_PAGE_CATEGORIES = new Set([
  'getting-started',
  'doctors',
  'security',
  'ai-accuracy',
]);

export function docSectionPath(categoryId, sectionId) {
  return `/documentation/${categoryId}/${sectionId}`;
}

export function listAllDocSectionPaths() {
  const paths = [];
  for (const category of docCategories) {
    for (const section of category.subcategories) {
      paths.push(docSectionPath(category.id, section.id));
    }
  }
  return paths;
}

export function findDocSection(categorySlug, sectionSlug) {
  const category = docCategories.find((c) => c.id === categorySlug);
  if (!category) return null;
  const section = category.subcategories.find((s) => s.id === sectionSlug);
  if (!section) return null;
  return { category, section };
}

export function getDefaultDocLocation() {
  const first = docCategories[0];
  const section = first.subcategories[0];
  return { categorySlug: first.id, sectionSlug: section.id };
}

export function resolveDocSeo({ category, section }) {
  const path = docSectionPath(category.id, section.id);
  const title = section.content?.title || section.title;
  const description =
    section.content?.text?.slice(0, 155) ||
    `${section.title} — ${category.title} documentation for licensed clinicians.`;
  return { path, title, description };
}

export function isMedicalDocumentationSection(categoryId) {
  return MEDICAL_WEB_PAGE_CATEGORIES.has(categoryId);
}

export function isHowToSection(categoryId, sectionId) {
  return categoryId === 'getting-started' && sectionId === 'how-it-works';
}
