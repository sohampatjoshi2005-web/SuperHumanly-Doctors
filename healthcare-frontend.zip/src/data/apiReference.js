/** Public API reference catalog — mirrors docCategories `api` section ids. */

const API_ORIGIN = (
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_API_BASE_URL) ||
  'https://api.superhumanly.io/v1'
).replace(/\/$/, '');

const TOKEN_PLACEHOLDER = '$TOKEN';
const RX_ID_PLACEHOLDER = '{prescription_id}';

/** @typedef {'curl' | 'fetch' | 'python'} ApiSnippetLanguage */

/**
 * @typedef {object} ApiEndpoint
 * @property {string} id
 * @property {string} method
 * @property {string} path
 * @property {string} title
 * @property {string} group
 * @property {'auth' | 'multipart' | 'json' | 'read'} kind
 */

/** @type {ApiEndpoint[]} */
export const API_ENDPOINTS = [
  {
    id: 'auth',
    method: 'Bearer',
    path: 'Authorization',
    title: 'API Keys & OAuth',
    group: 'Authentication',
    kind: 'auth',
  },
  {
    id: 'transcribe',
    method: 'POST',
    path: '/process-audio',
    title: 'Transcribe Audio Stream',
    group: 'Clinical capture',
    kind: 'multipart',
  },
  {
    id: 'generate-rx',
    method: 'POST',
    path: '/generate-prescription',
    title: 'Generate Structured Prescription',
    group: 'Clinical capture',
    kind: 'json',
  },
  {
    id: 'get-rx',
    method: 'GET',
    path: '/prescriptions/{id}',
    title: 'Retrieve Clinical Encounters',
    group: 'Records',
    kind: 'read',
  },
];

export const API_SNIPPET_LANGUAGES = /** @type {const} */ (['curl', 'fetch', 'python']);

export function getApiOrigin() {
  return API_ORIGIN;
}

export function getEndpointById(endpointId) {
  return API_ENDPOINTS.find((e) => e.id === endpointId) ?? null;
}

export function listApiEndpointGroups() {
  const groups = new Map();
  for (const endpoint of API_ENDPOINTS) {
    if (!groups.has(endpoint.group)) {
      groups.set(endpoint.group, []);
    }
    groups.get(endpoint.group).push(endpoint);
  }
  return [...groups.entries()];
}

/**
 * @param {ApiSnippetLanguage} lang
 * @param {string} endpointId
 */
export function buildApiSnippet(lang, endpointId) {
  const endpoint = getEndpointById(endpointId);
  if (!endpoint) return '';

  const url = `${API_ORIGIN}${endpoint.path.replace('{id}', RX_ID_PLACEHOLDER)}`;

  if (endpoint.kind === 'auth') {
    if (lang === 'curl') {
      return `curl "${API_ORIGIN}/health" \\\n  -H "Authorization: Bearer ${TOKEN_PLACEHOLDER}"`;
    }
    if (lang === 'fetch') {
      return `const response = await fetch("${API_ORIGIN}/health", {\n  headers: {\n    Authorization: \`Bearer \${process.env.SUPERHUMANLY_TOKEN}\`,\n  },\n});\n\nconst data = await response.json();`;
    }
    return `import os\nimport requests\n\nheaders = {\n    "Authorization": f"Bearer {os.environ['SUPERHUMANLY_TOKEN']}",\n}\n\nresponse = requests.get("${API_ORIGIN}/health", headers=headers, timeout=30)\nresponse.raise_for_status()\nprint(response.json())`;
  }

  if (endpoint.kind === 'multipart') {
    if (lang === 'curl') {
      return `curl -X POST "${API_ORIGIN}/process-audio" \\\n  -H "Authorization: Bearer ${TOKEN_PLACEHOLDER}" \\\n  -F "audio=@recording.wav" \\\n  -F "customer_id=optional-clinic-id"`;
    }
    if (lang === 'fetch') {
      return `const form = new FormData();\nform.append("audio", audioFile);\nform.append("customer_id", clinicId);\n\nconst response = await fetch("${API_ORIGIN}/process-audio", {\n  method: "POST",\n  headers: { Authorization: \`Bearer \${token}\` },\n  body: form,\n});\n\nconst data = await response.json();`;
    }
    return `import requests\n\nheaders = {"Authorization": f"Bearer {TOKEN_PLACEHOLDER}"}\nfiles = {"audio": open("recording.wav", "rb")}\ndata = {"customer_id": "optional-clinic-id"}\n\nresponse = requests.post(\n    "${API_ORIGIN}/process-audio",\n    headers=headers,\n    files=files,\n    data=data,\n    timeout=120,\n)\nresponse.raise_for_status()\nprint(response.json())`;
  }

  if (endpoint.kind === 'json') {
    const body = `{\n  "transcript": "Patient presents with...",\n  "patient_id": "pt_123",\n  "encounter_id": "enc_456"\n}`;
    if (lang === 'curl') {
      return `curl -X POST "${API_ORIGIN}/generate-prescription" \\\n  -H "Authorization: Bearer ${TOKEN_PLACEHOLDER}" \\\n  -H "Content-Type: application/json" \\\n  -d '${body.replace(/\n/g, '\\n')}'`;
    }
    if (lang === 'fetch') {
      return `const response = await fetch("${API_ORIGIN}/generate-prescription", {\n  method: "POST",\n  headers: {\n    Authorization: \`Bearer \${token}\`,\n    "Content-Type": "application/json",\n  },\n  body: JSON.stringify({\n    transcript: "Patient presents with...",\n    patient_id: "pt_123",\n    encounter_id: "enc_456",\n  }),\n});\n\nconst data = await response.json();`;
    }
    return `import requests\n\nheaders = {\n    "Authorization": f"Bearer {TOKEN_PLACEHOLDER}",\n    "Content-Type": "application/json",\n}\npayload = {\n    "transcript": "Patient presents with...",\n    "patient_id": "pt_123",\n    "encounter_id": "enc_456",\n}\n\nresponse = requests.post(\n    "${API_ORIGIN}/generate-prescription",\n    headers=headers,\n    json=payload,\n    timeout=60,\n)\nresponse.raise_for_status()\nprint(response.json())`;
  }

  // read
  if (lang === 'curl') {
    return `curl "${url}" \\\n  -H "Authorization: Bearer ${TOKEN_PLACEHOLDER}"`;
  }
  if (lang === 'fetch') {
    return `const prescriptionId = "${RX_ID_PLACEHOLDER}";\n\nconst response = await fetch(\n  \`${API_ORIGIN}/prescriptions/\${prescriptionId}\`,\n  { headers: { Authorization: \`Bearer \${token}\` } },\n);\n\nconst data = await response.json();`;
  }
  return `import requests\n\nprescription_id = "${RX_ID_PLACEHOLDER}"\nheaders = {"Authorization": f"Bearer {TOKEN_PLACEHOLDER}"}\n\nresponse = requests.get(\n    f"${API_ORIGIN}/prescriptions/{prescription_id}",\n    headers=headers,\n    timeout=30,\n)\nresponse.raise_for_status()\nprint(response.json())`;
}

export function getTryItRequestUrl(endpointId) {
  const endpoint = getEndpointById(endpointId);
  if (!endpoint || endpoint.kind === 'auth') {
    return API_ORIGIN;
  }
  return `${API_ORIGIN}${endpoint.path.replace('{id}', RX_ID_PLACEHOLDER)}`;
}
