import { lazy, Suspense, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import ProtectedRoute from './components/auth/ProtectedRoute';
import AuthRoute from './components/auth/AuthRoute';
import PageLoader from './components/PageLoader';
import './index.css';

// Lazy load all pages for better performance
const LandingPage = lazy(() => import('./pages/LandingPage'));
const DoctorSupportPage = lazy(() => import('./pages/DoctorSupportPage'));
const DoctorAuthPage = lazy(() => import('./pages/DoctorAuthPage'));
const RequestTrialPage = lazy(() => import('./pages/RequestTrialPage'));
const DocumentationPage = lazy(() => import('./pages/DocumentationPage'));
const PricingPage = lazy(() => import('./pages/PricingPage'));
const AboutPage = lazy(() => import('./pages/AboutPage'));
const PrivacyPolicyPage = lazy(() => import('./pages/PrivacyPolicyPage'));
const TermsOfServicePage = lazy(() => import('./pages/TermsOfServicePage'));
const FAQPage = lazy(() => import('./pages/FAQPage'));
const ContactPage = lazy(() => import('./pages/ContactPage'));
const NotFoundPage = lazy(() => import('./pages/NotFoundPage'));
const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));
const AdminLoginPage = lazy(() => import('./pages/AdminLoginPage'));
const AdminRoute = lazy(() => import('./components/auth/AdminRoute'));

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white selection:bg-accent/10">
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route 
              path="/auth" 
              element={
                <AuthRoute>
                  <DoctorAuthPage />
                </AuthRoute>
              } 
            />
            <Route path="/admin/login" element={<AdminLoginPage />} />
            <Route 
              path="/admin/dashboard" 
              element={
                <AdminRoute>
                  <AdminDashboard />
                </AdminRoute>
              } 
            />
            <Route path="/request-trial" element={<RequestTrialPage />} />
            <Route path="/documentation" element={<DocumentationPage />} />
            <Route path="/documentation/:categorySlug/:sectionSlug" element={<DocumentationPage />} />
            <Route
              path="/developers"
              element={<Navigate to="/documentation/api/overview" replace />}
            />
            <Route path="/pricing" element={<PricingPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsOfServicePage />} />
            <Route path="/faq" element={<FAQPage />} />
            <Route path="/contact" element={<ContactPage />} />
            
            <Route 
              path="/portal" 
              element={
                <ProtectedRoute>
                  <DoctorSupportPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/doctor-support" 
              element={
                <ProtectedRoute>
                  <DoctorSupportPage />
                </ProtectedRoute>
              } 
            />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </Suspense>
      </div>
    </Router>
  );
}

export default App;
