import { useEffect } from 'react';

/**
 * Signals prerender / crawlers that Helmet head + route body are ready (CRWL-05).
 */
export function SeoReadyMarker({ readyKey }) {
  useEffect(() => {
    document.documentElement.setAttribute('data-seo-ready', 'true');
    return () => {
      document.documentElement.removeAttribute('data-seo-ready');
    };
  }, [readyKey]);

  return null;
}
