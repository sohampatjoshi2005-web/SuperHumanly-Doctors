import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { listAllDocSectionPaths } from '../data/docRoutes.js';
import {
  PUBLIC_ROUTE_PATHS,
  isAdminPath,
  isAuthPath,
  isDocumentationSectionPath,
  isPortalPath,
  isPublicMarketingPath,
  listDocumentationSectionPaths,
  listPublicPathsForSitemap,
  shouldNoindex,
} from './routes.js';

const APP_PUBLIC_ROUTES = [
  '/',
  '/request-trial',
  '/documentation',
  '/pricing',
  '/about',
  '/privacy',
  '/terms',
  '/faq',
  '/contact',
];

const APP_PRIVATE_ROUTES = [
  '/auth',
  '/admin/login',
  '/admin/dashboard',
  '/portal',
  '/doctor-support',
];

describe('routes registry', () => {
  it('includes YMYL legal pages in public registry', () => {
    assert.ok(PUBLIC_ROUTE_PATHS.includes('/privacy'));
    assert.ok(PUBLIC_ROUTE_PATHS.includes('/terms'));
  });

  it('marks all App.jsx marketing routes as public', () => {
    for (const path of APP_PUBLIC_ROUTES) {
      assert.ok(isPublicMarketingPath(path), `${path} should be public`);
      assert.equal(shouldNoindex(path), false, `${path} should not noindex`);
    }
  });

  it('marks private routes as noindex', () => {
    for (const path of APP_PRIVATE_ROUTES) {
      assert.equal(shouldNoindex(path), true, `${path} should noindex`);
      assert.equal(isPublicMarketingPath(path), false, `${path} should not be public`);
    }
  });

  it('classifies portal and admin helpers', () => {
    assert.ok(isPortalPath('/portal'));
    assert.ok(isPortalPath('/doctor-support'));
    assert.ok(isAuthPath('/auth'));
    assert.ok(isAdminPath('/admin/dashboard'));
  });

  it('listPublicPathsForSitemap includes documentation deep links', () => {
    const sitemap = listPublicPathsForSitemap();
    const docPaths = listDocumentationSectionPaths();
    assert.equal(docPaths.length, listAllDocSectionPaths().length);
    assert.ok(docPaths.length >= 20);
    for (const path of docPaths) {
      assert.ok(sitemap.includes(path), `${path} missing from sitemap list`);
      assert.ok(isDocumentationSectionPath(path));
      assert.equal(shouldNoindex(path), false);
    }
  });

  it('listPublicPathsForSitemap includes all top-level marketing paths', () => {
    const sitemap = listPublicPathsForSitemap();
    for (const path of PUBLIC_ROUTE_PATHS) {
      assert.ok(sitemap.includes(path), `${path} missing from sitemap`);
    }
  });
});
