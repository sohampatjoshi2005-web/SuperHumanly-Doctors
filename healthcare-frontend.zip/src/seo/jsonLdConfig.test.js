import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { setSiteOrigin } from './siteUrl.js';
import { resolvePageJsonLd } from './jsonLdConfig.js';

describe('resolvePageJsonLd', () => {
  it('home includes WebSite and Organization', () => {
    setSiteOrigin('https://example.com');
    const graph = resolvePageJsonLd({ pathname: '/' });
    const types = graph.map((n) => n['@type']);
    assert.ok(types.includes('WebSite'));
    assert.ok(types.includes('Organization'));
    assert.equal(graph.filter((n) => n['@context']).length, 0);
  });

  it('pricing includes SoftwareApplication', () => {
    setSiteOrigin('https://example.com');
    const graph = resolvePageJsonLd({ pathname: '/pricing' });
    assert.ok(graph.some((n) => n['@type'] === 'SoftwareApplication'));
    assert.ok(graph.some((n) => n['@type'] === 'BreadcrumbList'));
  });

  it('documentation uses MedicalWebPage with professional audience', () => {
    setSiteOrigin('https://example.com');
    const graph = resolvePageJsonLd({ pathname: '/documentation' });
    const medical = graph.find((n) => n['@type'] === 'MedicalWebPage');
    assert.ok(medical);
    assert.equal(medical.medicalAudience.audienceType, 'https://schema.org/Clinician');
  });

  it('faq FAQPage matches provided questions', () => {
    setSiteOrigin('https://example.com');
    const faqs = [{ q: 'Test Q?', a: 'Test A.' }];
    const graph = resolvePageJsonLd({ pathname: '/faq', faqs });
    const faqPage = graph.find((n) => n['@type'] === 'FAQPage');
    assert.equal(faqPage.mainEntity.length, 1);
    assert.equal(faqPage.mainEntity[0].name, 'Test Q?');
  });

  it('portal returns empty graph', () => {
    setSiteOrigin('https://example.com');
    assert.deepEqual(resolvePageJsonLd({ pathname: '/portal' }), []);
  });

  it('how-it-works includes HowTo schema', () => {
    setSiteOrigin('https://example.com');
    const graph = resolvePageJsonLd({ pathname: '/documentation/getting-started/how-it-works' });
    assert.ok(graph.some((n) => n['@type'] === 'HowTo'));
    assert.ok(graph.some((n) => n['@type'] === 'MedicalWebPage'));
  });

  it('doc deep link breadcrumb has four items', () => {
    setSiteOrigin('https://example.com');
    const graph = resolvePageJsonLd({ pathname: '/documentation/security/encryption' });
    const crumbs = graph.find((n) => n['@type'] === 'BreadcrumbList');
    assert.equal(crumbs.itemListElement.length, 4);
  });
});
