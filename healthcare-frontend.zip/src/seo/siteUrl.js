let siteOrigin = '';

export function setSiteOrigin(url) {
  siteOrigin = String(url).replace(/\/+$/, '');
}

export function getSiteOrigin() {
  return siteOrigin;
}

export function readSiteOriginFromEnv() {
  const raw = import.meta.env.VITE_SITE_URL;
  if (raw && String(raw).trim()) {
    setSiteOrigin(String(raw).trim());
  }
  return getSiteOrigin();
}

export function absoluteUrl(path) {
  if (!siteOrigin) {
    return path;
  }
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return `${siteOrigin}${normalizedPath}`;
}
