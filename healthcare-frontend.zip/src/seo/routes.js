import { listAllDocSectionPaths } from '../data/docRoutes.js';

/** Top-level marketing paths — must mirror src/App.jsx Route paths (indexable). */
export const PUBLIC_ROUTE_PATHS = [
  '/',
  '/pricing',
  '/about',
  '/documentation',
  '/faq',
  '/contact',
  '/privacy',
  '/terms',
  '/request-trial',
];

const DOC_SECTION_PATHS = listAllDocSectionPaths();

const DOC_PATH_PATTERN = /^\/documentation\/[a-z0-9-]+\/[a-z0-9-]+$/;

/** YMYL-04: /privacy and /terms must remain in PUBLIC_ROUTE_PATHS for dynamic sitemap. */

export const NOINDEX_PREFIXES = ['/auth', '/admin', '/portal', '/doctor-support'];

function normalizePathname(pathname) {
  if (!pathname) return '/';
  const path = pathname.split('?')[0].split('#')[0];
  if (path !== '/' && path.endsWith('/')) {
    return path.slice(0, -1);
  }
  return path || '/';
}

export function isAuthPath(pathname) {
  const p = normalizePathname(pathname);
  return p === '/auth' || p.startsWith('/auth/');
}

export function isAdminPath(pathname) {
  const p = normalizePathname(pathname);
  return p === '/admin' || p.startsWith('/admin/');
}

export function isPortalPath(pathname) {
  const p = normalizePathname(pathname);
  return p === '/portal' || p === '/doctor-support' || p.startsWith('/portal/');
}

export function isDocumentationSectionPath(pathname) {
  const p = normalizePathname(pathname);
  return DOC_PATH_PATTERN.test(p) && DOC_SECTION_PATHS.includes(p);
}

export function isPublicMarketingPath(pathname) {
  const p = normalizePathname(pathname);
  if (PUBLIC_ROUTE_PATHS.includes(p)) return true;
  return isDocumentationSectionPath(p);
}

export function shouldNoindex(pathname) {
  const p = normalizePathname(pathname);
  if (isAuthPath(p) || isAdminPath(p) || isPortalPath(p)) {
    return true;
  }
  return !isPublicMarketingPath(p);
}

export function listPublicPathsForSitemap() {
  return [...PUBLIC_ROUTE_PATHS, ...DOC_SECTION_PATHS];
}

export function listDocumentationSectionPaths() {
  return [...DOC_SECTION_PATHS];
}

export function listNoindexPrefixes() {
  return [...NOINDEX_PREFIXES];
}
