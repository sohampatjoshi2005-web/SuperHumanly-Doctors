import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { setSiteOrigin } from './siteUrl.js';
import { resolvePageSeo, isIndexablePath } from './seoConfig.js';

describe('resolvePageSeo', () => {
  it('uses absolute canonical and og urls', () => {
    setSiteOrigin('https://example.com');
    const seo = resolvePageSeo({ pathname: '/pricing' });
    assert.equal(seo.canonical, 'https://example.com/pricing');
    assert.equal(seo.ogUrl, 'https://example.com/pricing');
    assert.ok(seo.ogImage.startsWith('https://example.com/'));
  });

  it('noindex on portal and auth', () => {
    setSiteOrigin('https://example.com');
    assert.equal(resolvePageSeo({ pathname: '/portal' }).robots, 'noindex,nofollow');
    assert.equal(resolvePageSeo({ pathname: '/auth' }).robots, 'noindex,nofollow');
    assert.equal(resolvePageSeo({ pathname: '/admin/dashboard' }).robots, 'noindex,nofollow');
  });

  it('indexable marketing paths have no robots meta', () => {
    setSiteOrigin('https://example.com');
    const seo = resolvePageSeo({ pathname: '/privacy' });
    assert.equal(seo.robots, undefined);
    assert.ok(seo.title.includes('Privacy'));
  });

  it('isIndexablePath matches public routes', () => {
    assert.equal(isIndexablePath('/faq'), true);
    assert.equal(isIndexablePath('/portal'), false);
  });
});
