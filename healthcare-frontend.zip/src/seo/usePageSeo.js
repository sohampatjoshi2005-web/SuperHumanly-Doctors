import { useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { resolvePageSeo } from './seoConfig.js';

export function usePageSeo(overrides = {}) {
  const { pathname } = useLocation();
  return useMemo(
    () => resolvePageSeo({ pathname, overrides }),
    [pathname, overrides],
  );
}
