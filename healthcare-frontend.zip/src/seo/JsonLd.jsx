import { Helmet } from 'react-helmet-async';

export function JsonLd({ graph }) {
  if (!graph?.length) return null;

  const payload = {
    '@context': 'https://schema.org',
    '@graph': graph,
  };

  return (
    <Helmet>
      <script type="application/ld+json">{JSON.stringify(payload)}</script>
    </Helmet>
  );
}
