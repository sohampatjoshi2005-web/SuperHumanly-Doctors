import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { listPublicPathsForSitemap } from './routes.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const BACKEND_MANIFEST = resolve(
  __dirname,
  '../../../healthcare-backend/app/data/seo/doc_manifest.json',
);

/** Mirrors healthcare-backend crawl_policy STATIC_MARKETING_PATHS */
const BACKEND_STATIC_PATHS = [
  '/',
  '/pricing',
  '/about',
  '/documentation',
  '/faq',
  '/contact',
  '/privacy',
  '/terms',
  '/request-trial',
];

function loadBackendIndexablePaths() {
  const manifest = JSON.parse(readFileSync(BACKEND_MANIFEST, 'utf8'));
  const docPaths = manifest.documentation_paths || [];
  return [...new Set([...BACKEND_STATIC_PATHS, ...docPaths])].sort();
}

describe('backend crawl contract parity', () => {
  it('frontend sitemap paths match backend indexable allowlist', () => {
    const frontend = listPublicPathsForSitemap().sort();
    const backend = loadBackendIndexablePaths();
    assert.deepEqual(frontend, backend);
  });
});
