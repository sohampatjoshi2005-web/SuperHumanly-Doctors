import { absoluteUrl } from './siteUrl.js';
import { SITE_NAME } from './seoConfig.js';
import { shouldNoindex } from './routes.js';
import {
  findDocSection,
  isHowToSection,
  isMedicalDocumentationSection,
  DOC_CONTENT_LAST_MODIFIED,
} from '../data/docRoutes.js';

function entityId(path, fragment) {
  return `${absoluteUrl(path)}${fragment}`;
}

export function buildOrganizationNode() {
  return {
    '@type': 'Organization',
    '@id': entityId('/', '#organization'),
    name: SITE_NAME,
    url: absoluteUrl('/'),
    logo: absoluteUrl('/favicon.svg'),
    description:
      'B2B clinical documentation platform for licensed clinicians and health systems.',
    sameAs: [
      'https://twitter.com/superhumanlyai',
      'https://www.linkedin.com/company/superhumanlyai',
    ],
  };
}

export function buildWebSiteNode() {
  return {
    '@type': 'WebSite',
    '@id': entityId('/', '#website'),
    name: SITE_NAME,
    url: absoluteUrl('/'),
    publisher: { '@id': entityId('/', '#organization') },
    description:
      'Clinical documentation for licensed clinicians — AI-assisted transcription and structured prescriptions.',
  };
}

export function buildBreadcrumbNode(items) {
  return {
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: absoluteUrl(item.path),
    })),
  };
}

export function buildMedicalWebPageNode({ name, description, path, dateModified }) {
  return {
    '@type': 'MedicalWebPage',
    '@id': absoluteUrl(path),
    name,
    description,
    url: absoluteUrl(path),
    dateModified: dateModified || DOC_CONTENT_LAST_MODIFIED,
    isPartOf: { '@id': entityId('/', '#website') },
    publisher: { '@id': entityId('/', '#organization') },
    medicalAudience: {
      '@type': 'MedicalAudience',
      audienceType: 'https://schema.org/Clinician',
    },
  };
}

export function buildHowToNode({ name, description, path, steps }) {
  if (!steps?.length) return null;
  return {
    '@type': 'HowTo',
    '@id': `${absoluteUrl(path)}#howto`,
    name,
    description,
    step: steps.map((step, index) => ({
      '@type': 'HowToStep',
      position: index + 1,
      name: step.label,
      text: step.desc,
    })),
  };
}

function parseDocumentationPath(pathname) {
  const match = pathname.match(/^\/documentation\/([^/]+)\/([^/]+)$/);
  if (!match) return null;
  return findDocSection(match[1], match[2]);
}

export function buildSoftwareApplicationNode() {
  return {
    '@type': 'SoftwareApplication',
    name: SITE_NAME,
    applicationCategory: 'BusinessApplication',
    operatingSystem: 'Web',
    url: absoluteUrl('/pricing'),
    offers: [
      {
        '@type': 'Offer',
        name: 'Standard Node',
        price: '299',
        priceCurrency: 'USD',
        url: absoluteUrl('/pricing'),
      },
      {
        '@type': 'Offer',
        name: 'Research & Intelligence',
        price: '599',
        priceCurrency: 'USD',
        url: absoluteUrl('/pricing'),
      },
    ],
  };
}

/** FAQ items: { q, a }[] — must match visible on-page Q&A */
export function buildFAQPageNode(faqs) {
  if (!faqs?.length) return null;
  return {
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.q,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.a,
      },
    })),
  };
}

export function buildWebPageNode({ name, description, path }) {
  return {
    '@type': 'WebPage',
    '@id': absoluteUrl(path),
    name,
    description,
    url: absoluteUrl(path),
    isPartOf: { '@id': entityId('/', '#website') },
  };
}

const ROUTE_LABELS = {
  '/': 'Home',
  '/pricing': 'Pricing',
  '/about': 'About',
  '/documentation': 'Documentation',
  '/faq': 'FAQ',
  '/contact': 'Contact',
  '/privacy': 'Privacy',
  '/terms': 'Terms',
  '/request-trial': 'Request a Trial',
};

function breadcrumbForPath(pathname) {
  if (pathname === '/') return null;

  const doc = parseDocumentationPath(pathname);
  if (doc) {
    return buildBreadcrumbNode([
      { name: 'Home', path: '/' },
      { name: 'Documentation', path: `/documentation/${doc.category.id}/${doc.section.id}` },
      { name: doc.category.title, path: `/documentation/${doc.category.id}/${doc.section.id}` },
      { name: doc.section.title, path: pathname },
    ]);
  }

  const label = ROUTE_LABELS[pathname];
  if (!label) return null;
  return buildBreadcrumbNode([
    { name: 'Home', path: '/' },
    { name: label, path: pathname },
  ]);
}

/**
 * Resolve JSON-LD graph nodes for a route (no @context — JsonLd adds it).
 * @param {{ pathname: string, faqs?: { q: string, a: string }[], pageTitle?: string, pageDescription?: string }} input
 */
export function resolvePageJsonLd({ pathname, faqs, pageTitle, pageDescription }) {
  if (shouldNoindex(pathname)) {
    return [];
  }

  const graph = [];
  const crumbs = breadcrumbForPath(pathname);
  if (crumbs) graph.push(crumbs);

  if (pathname === '/') {
    graph.push(buildWebSiteNode(), buildOrganizationNode());
    return graph;
  }

  graph.push(buildOrganizationNode());

  if (pathname === '/pricing') {
    graph.push(
      buildSoftwareApplicationNode(),
      buildWebPageNode({
        name: pageTitle || 'Institutional Pricing',
        description: pageDescription,
        path: '/pricing',
      }),
    );
    return graph;
  }

  const doc = parseDocumentationPath(pathname);
  if (doc) {
    const { category, section } = doc;
    const pageName = pageTitle || section.content?.title || section.title;
    const pageDesc = pageDescription || section.content?.text?.slice(0, 200);

    if (isMedicalDocumentationSection(category.id)) {
      graph.push(
        buildMedicalWebPageNode({
          name: pageName,
          description: pageDesc,
          path: pathname,
        }),
      );
    } else {
      graph.push(
        buildWebPageNode({
          name: pageName,
          description: pageDesc,
          path: pathname,
        }),
      );
    }

    if (isHowToSection(category.id, section.id) && section.content?.steps) {
      const howTo = buildHowToNode({
        name: section.content.title,
        description: section.content.text,
        path: pathname,
        steps: section.content.steps,
      });
      if (howTo) graph.push(howTo);
    }

    return graph;
  }

  if (pathname === '/documentation') {
    graph.push(
      buildMedicalWebPageNode({
        name: pageTitle || 'Clinical Documentation',
        description:
          pageDescription ||
          'Product guides, security, and workflows for licensed clinical teams.',
        path: '/documentation',
      }),
    );
    return graph;
  }

  if (pathname === '/faq') {
    const faqNode = buildFAQPageNode(faqs);
    if (faqNode) graph.push(faqNode);
    graph.push(
      buildWebPageNode({
        name: pageTitle || 'FAQ',
        description: pageDescription,
        path: '/faq',
      }),
    );
    return graph;
  }

  const label = ROUTE_LABELS[pathname];
  if (label) {
    graph.push(
      buildWebPageNode({
        name: pageTitle || label,
        description: pageDescription,
        path: pathname,
      }),
    );
  }

  return graph;
}

/** @deprecated Use resolvePageJsonLd — legacy helpers for gradual migration */
export function getOrganizationSchema() {
  return { '@context': 'https://schema.org', ...buildOrganizationNode() };
}

export function getMedicalWebPageSchema(title, description) {
  return {
    '@context': 'https://schema.org',
    ...buildMedicalWebPageNode({
      name: title,
      description,
      path: '/documentation',
    }),
  };
}

export function getFAQSchema(faqs) {
  return {
    '@context': 'https://schema.org',
    ...buildFAQPageNode(faqs),
  };
}
