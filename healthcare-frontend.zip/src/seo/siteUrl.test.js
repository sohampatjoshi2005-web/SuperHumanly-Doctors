import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { absoluteUrl, getSiteOrigin, setSiteOrigin } from './siteUrl.js';

describe('siteUrl', () => {
  it('setSiteOrigin strips trailing slashes', () => {
    setSiteOrigin('https://example.com/');
    assert.equal(getSiteOrigin(), 'https://example.com');
  });

  it('absoluteUrl joins origin and path', () => {
    setSiteOrigin('https://example.com');
    assert.equal(absoluteUrl('/pricing'), 'https://example.com/pricing');
    assert.equal(absoluteUrl('/'), 'https://example.com/');
  });

  it('absoluteUrl returns path when origin unset', () => {
    setSiteOrigin('');
    assert.equal(absoluteUrl('/faq'), '/faq');
  });
});
