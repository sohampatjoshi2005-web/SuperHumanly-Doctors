import { absoluteUrl } from './siteUrl.js';
import {
  isPublicMarketingPath,
  shouldNoindex,
} from './routes.js';
import { findDocSection, resolveDocSeo } from '../data/docRoutes.js';

export const SITE_NAME = 'Superhumanly Doctors';
const DEFAULT_OG_IMAGE = '/og-preview.png';
const DEFAULT_DESCRIPTION =
  'Professional clinical documentation for licensed clinicians. Built for physicians who value technical sovereignty and high-fidelity continuity.';

/** Per-route defaults — keys must match PUBLIC_ROUTE_PATHS where applicable */
export const ROUTE_SEO = {
  '/': {
    title: 'AI-Powered Clinical Intelligence',
    description:
      'Clinical documentation for licensed clinicians. Built for physicians who demand accuracy, data sovereignty, and clinical velocity.',
  },
  '/pricing': {
    title: 'Institutional Pricing',
    description:
      'Transparent pricing for licensed clinicians and health systems adopting AI-assisted clinical documentation.',
  },
  '/about': {
    title: 'About Superhumanly Doctors',
    description:
      'B2B clinical intelligence for licensed physicians — technical sovereignty, structured prescriptions, and institutional workflows.',
  },
  '/documentation': {
    title: 'Documentation',
    description:
      'Product guides, security, and API reference for clinical teams implementing Superhumanly Doctors.',
  },
  '/faq': {
    title: 'Frequently Asked Questions',
    description: 'Answers for clinicians and clinic administrators evaluating clinical documentation automation.',
  },
  '/contact': {
    title: 'Contact',
    description: 'Reach the Superhumanly Doctors team for demos, institutional onboarding, and technical support.',
  },
  '/privacy': {
    title: 'Privacy Policy',
    description: 'How Superhumanly Doctors processes and protects clinical and account data.',
  },
  '/terms': {
    title: 'Terms of Service',
    description: 'Terms governing use of the Superhumanly Doctors platform by licensed clinical professionals.',
  },
  '/request-trial': {
    title: 'Request a Trial',
    description: 'Request trial access to Superhumanly Doctors for your clinical practice or institution.',
  },
  '/auth': {
    title: 'Clinician Sign In',
    description: 'Secure sign-in for licensed clinicians.',
    noindex: true,
  },
  '/portal': {
    title: 'Clinical Portal',
    description: 'Authenticated clinician workspace.',
    noindex: true,
  },
  '/doctor-support': {
    title: 'Clinical Portal',
    description: 'Authenticated clinician workspace.',
    noindex: true,
  },
};

export function normalizeCanonicalPath(pathname) {
  if (!pathname) return '/';
  const path = pathname.split('?')[0].split('#')[0];
  if (path !== '/' && path.endsWith('/')) {
    return path.slice(0, -1);
  }
  return path || '/';
}

export function resolveImageUrl(imagePath = DEFAULT_OG_IMAGE) {
  return absoluteUrl(imagePath.startsWith('/') ? imagePath : `/${imagePath}`);
}

function formatTitle(title) {
  if (!title) return SITE_NAME;
  if (title.includes(SITE_NAME)) return title;
  return `${title} | ${SITE_NAME}`;
}

/**
 * @param {{ pathname: string, overrides?: { title?: string, description?: string, canonical?: string, ogType?: string, ogImage?: string, robots?: string }, schema?: object }} input
 */
export function resolvePageSeo({ pathname, overrides = {} }) {
  const normalizedPath = normalizeCanonicalPath(pathname);

  const docMatch = normalizedPath.match(/^\/documentation\/([^/]+)\/([^/]+)$/);
  let docDefaults = null;
  if (docMatch) {
    const resolved = findDocSection(docMatch[1], docMatch[2]);
    if (resolved) {
      docDefaults = resolveDocSeo(resolved);
    }
  }

  const routeDefaults = docDefaults || ROUTE_SEO[normalizedPath] || {};
  const prefixMatch = normalizedPath.startsWith('/admin')
    ? { title: 'Admin', description: 'Administration console.', noindex: true }
  : null;

  const noindex =
    overrides.robots?.includes('noindex') ||
    routeDefaults.noindex ||
    prefixMatch?.noindex ||
    shouldNoindex(normalizedPath);

  const title = formatTitle(
    overrides.title ?? docDefaults?.title ?? routeDefaults.title ?? prefixMatch?.title,
  );
  const description =
    overrides.description ??
    docDefaults?.description ??
    routeDefaults.description ??
    prefixMatch?.description ??
    DEFAULT_DESCRIPTION;

  const canonical = overrides.canonical?.startsWith('http')
    ? overrides.canonical.replace(/\/+$/, '') || overrides.canonical
    : absoluteUrl(normalizedPath);

  const ogImage = resolveImageUrl(overrides.ogImage);
  const ogUrl = canonical;

  const gscToken = import.meta.env?.VITE_GOOGLE_SITE_VERIFICATION?.trim();

  return {
    title,
    description,
    canonical,
    ogType: overrides.ogType || 'website',
    ogImage,
    ogUrl,
    ogSiteName: SITE_NAME,
    ogLocale: 'en_US',
    twitterSite: import.meta.env?.VITE_TWITTER_SITE?.trim() || undefined,
    robots: noindex ? 'noindex,nofollow' : undefined,
    googleSiteVerification: noindex ? undefined : gscToken || undefined,
  };
}

export function isIndexablePath(pathname) {
  return isPublicMarketingPath(pathname) && !shouldNoindex(pathname);
}
