import { useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { resolvePageJsonLd } from './jsonLdConfig.js';

export function usePageJsonLd(options = {}) {
  const { pathname } = useLocation();
  const { faqs, pageTitle, pageDescription } = options;

  return useMemo(
    () => resolvePageJsonLd({ pathname, faqs, pageTitle, pageDescription }),
    [pathname, faqs, pageTitle, pageDescription],
  );
}
