import { DOC_CONTENT_LAST_MODIFIED, DOC_MEDICAL_REVIEWER } from '../../data/docRoutes.js';

/** Visible YMYL trust signals for clinical documentation pages. */
export default function DocTrustMeta({ showReviewer = true }) {
  return (
    <footer className="mt-12 pt-6 border-t border-slate-200 text-sm text-slate-500">
      <p>
        <time dateTime={DOC_CONTENT_LAST_MODIFIED}>
          Last updated:{' '}
          {new Date(`${DOC_CONTENT_LAST_MODIFIED}T12:00:00Z`).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })}
        </time>
      </p>
      {showReviewer ? (
        <p className="mt-2">
          Medical content reviewed by: <span className="text-slate-700">{DOC_MEDICAL_REVIEWER}</span>
        </p>
      ) : null}
    </footer>
  );
}
