import { motion } from 'framer-motion';
import { Mic, Cpu, FileText, ArrowRight } from 'lucide-react';

export default function AcousticFlowDiagram() {
  const steps = [
    {
      id: 'speak',
      title: 'Speak',
      desc: 'High-fidelity acoustic capture at the edge.',
      icon: Mic,
      color: 'bg-blue-100 text-blue-600 border-blue-200'
    },
    {
      id: 'transcribe',
      title: 'Transcribe',
      desc: 'Zero-latency neural NLP models process audio.',
      icon: Cpu,
      color: 'bg-indigo-100 text-indigo-600 border-indigo-200'
    },
    {
      id: 'generate',
      title: 'Generate',
      desc: 'Structured medical prescriptions are synthesized.',
      icon: FileText,
      color: 'bg-green-100 text-green-600 border-green-200'
    }
  ];

  return (
    <div className="w-full my-12 p-8 sm:p-12 bg-white rounded-[24px] border border-slate-200 shadow-sm relative overflow-hidden group">
      {/* Subtle background gradient pulse */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-50/50 via-transparent to-green-50/50 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
      
      <div className="relative z-10">
        <h3 className="font-serif text-2xl text-[#0a0a0a] mb-8 text-center tracking-tight">The Acoustic Modality Pipeline</h3>
        
        <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8">
          {steps.map((step, idx) => (
            <div key={step.id} className="flex flex-col md:flex-row items-center gap-4 md:gap-8">
              
              <motion.div 
                whileHover={{ scale: 1.05, y: -5 }}
                className="flex flex-col items-center text-center max-w-[200px]"
              >
                <div className={`w-20 h-20 rounded-2xl flex items-center justify-center border shadow-sm mb-4 relative ${step.color}`}>
                  <step.icon size={32} />
                  {/* Glowing ping effect */}
                  <motion.div 
                    className="absolute inset-0 rounded-2xl border-2 border-current opacity-20"
                    animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0, 0.2] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut", delay: idx * 0.5 }}
                  />
                </div>
                <div className="font-bold text-[17px] text-[#0a0a0a] mb-1">{step.title}</div>
                <div className="text-sm text-slate-500 leading-relaxed">{step.desc}</div>
              </motion.div>

              {idx < steps.length - 1 && (
                <div className="hidden md:flex items-center justify-center h-20 text-slate-300">
                  <ArrowRight size={24} />
                </div>
              )}
              {idx < steps.length - 1 && (
                <div className="flex md:hidden text-slate-300 rotate-90 my-2">
                  <ArrowRight size={24} />
                </div>
              )}

            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
