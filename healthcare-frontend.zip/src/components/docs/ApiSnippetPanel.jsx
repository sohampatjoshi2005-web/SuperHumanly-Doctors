import { useState } from 'react';
import { CheckCircle2, Copy, Terminal } from 'lucide-react';
import {
  API_SNIPPET_LANGUAGES,
  buildApiSnippet,
  getEndpointById,
  getTryItRequestUrl,
} from '../../data/apiReference';

const LANG_LABELS = {
  curl: 'cURL',
  fetch: 'JavaScript',
  python: 'Python',
};

export default function ApiSnippetPanel({ endpointId }) {
  const endpoint = getEndpointById(endpointId);
  const [lang, setLang] = useState('curl');
  const [copied, setCopied] = useState(false);
  const [bearerToken, setBearerToken] = useState('');

  if (!endpoint) return null;

  const snippet = buildApiSnippet(lang, endpointId);
  const tryItUrl = getTryItRequestUrl(endpointId);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(snippet);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      /* clipboard unavailable */
    }
  };

  return (
    <div className="my-8 space-y-6" data-api-snippet-panel>
      <div className="flex flex-wrap items-center gap-2" role="tablist" aria-label="Code snippet language">
        {API_SNIPPET_LANGUAGES.map((key) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={lang === key}
            onClick={() => setLang(key)}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest border transition-colors ${
              lang === key
                ? 'bg-[#2563eb] text-white border-[#2563eb]'
                : 'bg-white text-slate-500 border-slate-200 hover:border-[#2563eb]/40'
            }`}
          >
            {LANG_LABELS[key]}
          </button>
        ))}
        <span className="ml-auto inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 text-slate-600 text-[10px] font-black uppercase tracking-widest">
          {endpoint.method}
          <span className="font-mono normal-case tracking-normal text-slate-800">{endpoint.path}</span>
        </span>
      </div>

      <pre className="rounded-[24px] overflow-hidden border border-slate-200 bg-slate-900 shadow-xl relative group">
        <div className="px-5 py-3 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex gap-1.5" aria-hidden>
            <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
            <div className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
          </div>
          <div className="flex items-center gap-2 text-white/40 text-[10px] font-black uppercase tracking-widest">
            <Terminal size={12} aria-hidden />
            {LANG_LABELS[lang]}
          </div>
          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 text-white/80 hover:bg-white/20 text-[10px] font-bold uppercase tracking-wider transition-colors"
            aria-label="Copy snippet to clipboard"
          >
            {copied ? <CheckCircle2 size={14} className="text-green-400" /> : <Copy size={14} />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
        <code className="block p-6 text-[13px] font-mono text-slate-300 overflow-x-auto leading-relaxed custom-scrollbar whitespace-pre">
          {snippet}
        </code>
      </pre>

      <section
        className="rounded-[24px] border border-dashed border-slate-300 bg-slate-50/80 p-6"
        aria-labelledby={`try-it-${endpointId}`}
      >
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <h2 id={`try-it-${endpointId}`} className="text-sm font-black uppercase tracking-widest text-slate-600">
            Try it
          </h2>
          <span className="text-[10px] font-bold uppercase tracking-widest text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-full">
            Sandbox coming soon
          </span>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1.5 block">
              Authorization
            </span>
            <input
              type="password"
              autoComplete="off"
              value={bearerToken}
              onChange={(e) => setBearerToken(e.target.value)}
              placeholder="Bearer token (not sent — preview only)"
              className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-mono text-slate-800"
              aria-describedby={`try-it-hint-${endpointId}`}
            />
          </label>
          <label className="block sm:col-span-1">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1.5 block">
              Request URL
            </span>
            <input
              type="text"
              readOnly
              value={tryItUrl}
              className="w-full rounded-xl border border-slate-200 bg-slate-100 px-4 py-2.5 text-sm font-mono text-slate-600"
            />
          </label>
        </div>
        <p id={`try-it-hint-${endpointId}`} className="mt-3 text-sm text-slate-500">
          Live requests from the browser are disabled until the hosted API sandbox ships. Use the snippets above
          from your secure server or CLI.
        </p>
        <button
          type="button"
          disabled
          title="API sandbox coming soon"
          className="mt-4 px-5 py-2.5 rounded-xl bg-slate-200 text-slate-500 text-sm font-bold cursor-not-allowed"
        >
          Send request
        </button>
      </section>
    </div>
  );
}
