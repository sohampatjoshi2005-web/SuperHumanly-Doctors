import { Shield, CheckCircle2 } from 'lucide-react';

const complianceData = [
  {
    requirement: 'Data Encryption at Rest',
    hipaa: 'Required — AES-256 or equivalent',
    dpdp: 'Reasonable security safeguards (Section 8)',
    status: 'verified'
  },
  {
    requirement: 'Data Encryption in Transit',
    hipaa: 'Required — TLS 1.2+ mandatory',
    dpdp: 'Implied under "reasonable safeguards"',
    status: 'verified'
  },
  {
    requirement: 'User Consent for Data Processing',
    hipaa: 'Authorization required for non-TPO use',
    dpdp: 'Explicit, informed, free consent required (Section 6)',
    status: 'verified'
  },
  {
    requirement: 'Role-Based Access Control (RBAC)',
    hipaa: 'Minimum necessary standard (§164.502)',
    dpdp: 'Purpose limitation — access only for stated purpose',
    status: 'verified'
  },
  {
    requirement: 'Data Retention Limits',
    hipaa: '6 years from date of creation',
    dpdp: 'Only as long as purpose requires (Section 8(7))',
    status: 'verified'
  },
  {
    requirement: 'Right to Deletion',
    hipaa: 'Amendment rights (§164.526)',
    dpdp: 'Right to erasure upon consent withdrawal (Section 12)',
    status: 'verified'
  },
  {
    requirement: 'Breach Notification',
    hipaa: 'Within 60 days of discovery',
    dpdp: 'Without unreasonable delay to DPB (Section 8(6))',
    status: 'verified'
  },
  {
    requirement: 'Audit Trail / Logging',
    hipaa: 'Required — access logs for 6 years',
    dpdp: 'Implied via accountability obligation',
    status: 'verified'
  }
];

export default function ComplianceTable() {
  return (
    <div className="w-full my-10 overflow-hidden rounded-2xl border border-slate-200 shadow-sm bg-white">
      {/* Table Header */}
      <div className="flex items-center gap-3 px-6 py-4 bg-blue-50/60 border-b border-slate-200">
        <Shield size={20} className="text-[#2563eb]" />
        <span className="font-black text-[12px] uppercase tracking-widest text-[#2563eb]">
          Regulatory Compliance Matrix
        </span>
      </div>

      {/* Responsive Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[640px]">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/50">
              <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest text-slate-500 w-[28%]">
                Requirement
              </th>
              <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest text-slate-500 w-[30%]">
                US HIPAA
              </th>
              <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest text-slate-500 w-[30%]">
                India DPDP Act
              </th>
              <th className="px-6 py-4 text-[11px] font-black uppercase tracking-widest text-slate-500 w-[12%] text-center">
                Status
              </th>
            </tr>
          </thead>
          <tbody>
            {complianceData.map((row, idx) => (
              <tr
                key={idx}
                className={`border-b border-slate-100 last:border-b-0 hover:bg-blue-50/30 transition-colors ${
                  idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/30'
                }`}
              >
                <td className="px-6 py-4 text-[14px] font-bold text-[#0a0a0a]">
                  {row.requirement}
                </td>
                <td className="px-6 py-4 text-[14px] text-slate-600 leading-relaxed">
                  {row.hipaa}
                </td>
                <td className="px-6 py-4 text-[14px] text-slate-600 leading-relaxed">
                  {row.dpdp}
                </td>
                <td className="px-6 py-4 text-center">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-green-50 text-green-700 border border-green-200">
                    <CheckCircle2 size={12} />
                    Verified
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="px-6 py-3 bg-slate-50/50 border-t border-slate-200 text-[12px] text-slate-400 font-medium">
        Last audited: May 2026 · Superhumanly exceeds both HIPAA and DPDP baseline requirements.
      </div>
    </div>
  );
}
