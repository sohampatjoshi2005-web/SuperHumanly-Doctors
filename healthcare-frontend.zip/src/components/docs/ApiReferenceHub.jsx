import { Link } from 'react-router-dom';
import { ArrowRight, Terminal } from 'lucide-react';
import { docSectionPath } from '../../data/docRoutes';
import { listApiEndpointGroups } from '../../data/apiReference';

export default function ApiReferenceHub() {
  const groups = listApiEndpointGroups();

  return (
    <section className="my-10" aria-labelledby="api-hub-heading">
      <h2 id="api-hub-heading" className="sr-only">
        API endpoint groups
      </h2>
      <p className="text-sm text-slate-500 mb-8 max-w-2xl">
        Integrate ambient capture and structured prescriptions into your EHR or internal tools. Select an
        endpoint for multi-language snippets and a try-it preview.
      </p>
      <div className="space-y-10">
        {groups.map(([groupName, endpoints]) => (
          <div key={groupName}>
            <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-400 mb-4">
              {groupName}
            </h3>
            <ul className="grid gap-4 sm:grid-cols-2">
              {endpoints.map((endpoint) => (
                <li key={endpoint.id}>
                  <Link
                    to={docSectionPath('api', endpoint.id)}
                    className="group flex flex-col h-full p-6 bg-white border border-slate-200 rounded-[24px] shadow-sm hover:border-[#2563eb]/50 hover:shadow-md transition-all no-underline"
                  >
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 text-[10px] font-black uppercase tracking-widest text-slate-600">
                        <Terminal size={12} aria-hidden />
                        {endpoint.method}
                      </span>
                      <ArrowRight
                        size={18}
                        className="text-slate-300 group-hover:text-[#2563eb] shrink-0 transition-colors"
                        aria-hidden
                      />
                    </div>
                    <span className="font-mono text-sm text-[#2563eb] mb-2">{endpoint.path}</span>
                    <span className="text-[#0a0a0a] font-bold text-base">{endpoint.title}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}
