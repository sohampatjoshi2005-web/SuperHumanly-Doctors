import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, Search, Filter, Shield, 
  MoreHorizontal, UserCheck, UserX,
  Mail, Calendar, Building, RefreshCw,
  ChevronRight, ArrowUpRight, Terminal,
  ShieldCheck, Globe, Cpu, Zap
} from 'lucide-react';
import { fetchAllUsers, promoteAdmin } from '../../lib/doctorApi';

export default function UserDirectoryTab() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await fetchAllUsers();
      setUsers(data);
    } catch (err) {
      console.error('Failed to load users:', err);
    } finally {
      setLoading(false);
    }
  };

  const handlePromote = async (username) => {
    if (!window.confirm(`Elevate ${username} to administrative status?`)) return;
    try {
      await promoteAdmin(username);
      loadUsers();
    } catch (err) {
      alert(err.message);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const filteredUsers = users.filter(u => {
    const matchesSearch = (u.full_name || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
                         u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         u.username.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const roleCounts = {
    all: users.length,
    doctor: users.filter(u => u.role === 'doctor').length,
    admin: users.filter(u => u.role === 'admin').length,
    clinic_admin: users.filter(u => u.role === 'clinic_admin').length
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-muted/30 mb-1">
             <span>Directory</span>
             <ChevronRight size={10} className="text-muted/20" />
             <span className="text-accent">User Infrastructure</span>
          </div>
          <h2 className="text-5xl lg:text-6xl font-serif tracking-tight text-text leading-tight">
            User <span className="italic text-accent">Infrastructure.</span>
          </h2>
          <p className="text-[15px] text-muted/60 font-medium max-w-xl leading-relaxed">
            Manage administrative clearance, platform access, and institutional associations for all clinical nodes.
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="bg-white border border-border/60 rounded-2xl px-6 py-4 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow group">
            <div className="w-10 h-10 rounded-xl bg-accent-light text-accent flex items-center justify-center group-hover:scale-110 transition-transform">
               <Users size={20} />
            </div>
            <div>
               <div className="text-2xl font-bold text-text tracking-tighter leading-none">{users.length}</div>
               <div className="text-[9px] font-black uppercase tracking-widest text-muted/40">Total Nodes</div>
            </div>
          </div>
          <button 
            onClick={loadUsers}
            className="w-12 h-14 bg-white border border-border/60 rounded-2xl flex items-center justify-center text-muted/40 hover:text-text hover:shadow-sm active:scale-95 transition-all"
          >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      <div className="bg-white border border-border/60 rounded-[32px] overflow-hidden shadow-sm flex flex-col min-h-[600px]">
        {/* Advanced Toolbar */}
        <div className="px-8 py-8 border-b border-border/40 flex flex-col xl:flex-row xl:items-center justify-between gap-8 bg-off/30">
          <div className="flex flex-wrap items-center gap-3">
            {[
              { id: 'all', label: 'All Identities' },
              { id: 'doctor', label: 'Doctors' },
              { id: 'admin', label: 'Administrators' },
              { id: 'clinic_admin', label: 'Clinic Admins' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setRoleFilter(tab.id)}
                className={`px-5 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all relative ${
                  roleFilter === tab.id 
                    ? 'text-text' 
                    : 'text-muted/40 hover:text-muted/60'
                }`}
              >
                <span className="relative z-10 flex items-center gap-2">
                  {tab.label}
                  <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold ${
                    roleFilter === tab.id ? 'bg-text text-white' : 'bg-muted/10 text-muted/40'
                  }`}>
                    {roleCounts[tab.id]}
                  </span>
                </span>
                {roleFilter === tab.id && (
                  <motion.div 
                    layoutId="activeRoleTab"
                    className="absolute inset-0 bg-white border border-border/60 rounded-xl shadow-sm" 
                  />
                )}
              </button>
            ))}
          </div>

          <div className="relative w-full xl:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted/30" size={16} />
            <input 
              type="text" 
              placeholder="Search by name, username or mail..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-border/60 rounded-2xl pl-12 pr-5 py-3.5 text-[14px] focus:outline-none focus:border-accent/40 focus:ring-4 focus:ring-accent/5 transition-all font-medium text-text shadow-sm"
            />
          </div>
        </div>

        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left border-separate border-spacing-0">
            <thead>
              <tr className="bg-off/20">
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">User Identity</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Role / Clearance</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Institutional Association</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Registration</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30 text-right">Node Protocol</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/20">
              <AnimatePresence mode="popLayout">
                {filteredUsers.map((u) => (
                  <motion.tr 
                    key={u.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="group hover:bg-off/40 transition-colors"
                  >
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className={`w-11 h-11 rounded-xl flex items-center justify-center font-black text-[12px] border transition-transform group-hover:scale-110 ${
                          u.role === 'admin' ? 'bg-text text-white border-text' : 'bg-off border-border text-muted/60'
                        }`}>
                          {(u.full_name || u.username).charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-bold text-[14px] text-text mb-0.5 flex items-center gap-2">
                            {u.full_name || u.username}
                            {!u.is_active && (
                              <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-red-50 text-red-600 text-[8px] font-black uppercase tracking-widest border border-red-100">
                                <UserX size={8} /> Inactive
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-muted/50 font-medium flex items-center gap-1.5 leading-none">
                            <Mail size={10} className="text-muted/30" /> {u.email}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border shadow-sm ${
                        u.role === 'admin' ? 'bg-purple-50 border-purple-100 text-purple-600' : 
                        u.role === 'clinic_admin' ? 'bg-blue-50 border-blue-100 text-blue-600' :
                        'bg-emerald-50 border-emerald-100 text-emerald-600'
                      }`}>
                        {u.role === 'admin' ? <Shield size={10} /> : <Zap size={10} />}
                        {u.role.replace('_', ' ')}
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-2 text-[13px] font-bold text-text/80">
                        <Building size={14} className="text-muted/30" /> 
                        <span className={u.institution ? 'text-text' : 'text-muted/40 italic'}>
                          {u.institution || 'Independent Node'}
                        </span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-2 text-[12px] font-bold text-text/60">
                        <Calendar size={13} className="text-muted/30" />
                        {new Date(u.created_at).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                       {u.role !== 'admin' && (
                         <button 
                           onClick={() => handlePromote(u.username)}
                           className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border/60 bg-white text-[10px] font-black uppercase tracking-widest text-muted/40 hover:text-text hover:border-text transition-all hover:shadow-sm"
                         >
                           Manage Node <ArrowUpRight size={12} />
                         </button>
                       )}
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
          
          {loading && (
            <div className="py-32 flex flex-col items-center justify-center text-center">
              <div className="relative">
                <RefreshCw className="w-12 h-12 text-accent animate-spin opacity-20" />
                <div className="absolute inset-0 flex items-center justify-center">
                   <Terminal size={16} className="text-accent animate-pulse" />
                </div>
              </div>
              <p className="mt-6 text-[11px] font-black uppercase tracking-[0.3em] text-muted/40">Synchronizing User Node Registry...</p>
            </div>
          )}

          {!loading && filteredUsers.length === 0 && (
            <div className="py-32 flex flex-col items-center justify-center text-center px-8">
              <div className="w-20 h-20 bg-off rounded-3xl flex items-center justify-center mb-8 border border-border/40 relative group">
                <Users size={32} className="text-muted/10 group-hover:text-accent/20 transition-colors" />
                <div className="absolute inset-0 bg-accent/5 rounded-3xl scale-0 group-hover:scale-100 transition-transform duration-500" />
              </div>
              <h3 className="text-2xl font-serif tracking-tight text-text mb-3">No <span className="italic text-accent">identities</span> found in directory.</h3>
              <p className="text-muted/60 font-medium max-w-sm leading-relaxed text-[15px]">Refine your search parameters or select a different clinical role.</p>
              <button 
                onClick={() => {setSearchQuery(''); setRoleFilter('all');}}
                className="mt-8 text-[11px] font-black uppercase tracking-widest text-accent hover:underline"
              >
                Reset directory filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
