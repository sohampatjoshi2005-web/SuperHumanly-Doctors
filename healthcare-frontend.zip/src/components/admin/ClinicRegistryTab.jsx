import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Building2, Search, Filter, Shield, 
  MoreHorizontal, Plus, Building, 
  Globe, Mail, Phone, Calendar,
  ChevronRight, ArrowUpRight, Activity,
  Database, Zap, CheckCircle2, ShieldCheck,
  Building as BuildingIcon, RefreshCw
} from 'lucide-react';
import { fetchClinics, createClinic } from '../../lib/doctorApi';

export default function ClinicRegistryTab() {
  const [clinics, setClinics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [newClinic, setNewClinic] = useState({ name: '', address: '', contact_email: '', phone: '' });
  const [submitting, setSubmitting] = useState(false);

  const loadClinics = async () => {
    setLoading(true);
    try {
      const data = await fetchClinics();
      setClinics(data);
    } catch (err) {
      console.error('Failed to load institutional registry:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await createClinic(newClinic);
      setShowRegisterModal(false);
      setNewClinic({ name: '', address: '', contact_email: '', phone: '' });
      loadClinics();
    } catch (err) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  useEffect(() => {
    loadClinics();
  }, []);

  const filteredClinics = clinics.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         (c.contact_email || '').toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || 
                         (statusFilter === 'active' ? c.is_active : !c.is_active);
    return matchesSearch && matchesStatus;
  });

  const statusCounts = {
    all: clinics.length,
    active: clinics.filter(c => c.is_active).length,
    inactive: clinics.filter(c => !c.is_active).length
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-muted/30 mb-1">
             <span>Governance</span>
             <ChevronRight size={10} className="text-muted/20" />
             <span className="text-accent">Clinic Registry</span>
          </div>
          <h2 className="text-5xl lg:text-6xl font-serif tracking-tight text-text leading-tight">
            Institutional <span className="italic text-accent">Registry.</span>
          </h2>
          <p className="text-[15px] text-muted/60 font-medium max-w-xl leading-relaxed">
            Monitor and manage the global distribution of clinical entities within the sovereign platform network.
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="bg-white border border-border/60 rounded-2xl px-6 py-4 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow group">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
               <Building2 size={20} />
            </div>
            <div>
               <div className="text-2xl font-bold text-text tracking-tighter leading-none">{clinics.length}</div>
               <div className="text-[9px] font-black uppercase tracking-widest text-muted/40">Entities Registered</div>
            </div>
          </div>
          <button 
            onClick={() => setShowRegisterModal(true)}
            className="h-14 px-6 bg-text text-white rounded-2xl font-black uppercase tracking-widest text-[11px] flex items-center gap-3 hover:bg-accent transition-all shadow-xl shadow-text/10 active:scale-95"
          >
            <Plus size={16} /> Register Entity
          </button>
        </div>
      </div>

      {/* Register Modal */}
      <AnimatePresence>
        {showRegisterModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowRegisterModal(false)}
              className="absolute inset-0 bg-text/20 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white border border-border/60 rounded-[40px] w-full max-w-xl p-10 shadow-2xl relative z-10"
            >
              <div className="space-y-8">
                <div>
                  <h3 className="text-3xl font-serif tracking-tight text-text mb-2">Register <span className="italic text-accent">Entity.</span></h3>
                  <p className="text-muted/60 text-sm font-medium">Onboard a new institutional clinical node to the sovereign network.</p>
                </div>

                <form onSubmit={handleRegister} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-muted/40 ml-1">Entity Nomenclature</label>
                    <input 
                      required
                      value={newClinic.name}
                      onChange={e => setNewClinic({...newClinic, name: e.target.value})}
                      placeholder="e.g. Mayo Clinic Hub"
                      className="w-full bg-off border border-border/60 rounded-2xl px-5 py-3.5 text-sm font-bold focus:outline-none focus:border-accent/40 focus:ring-4 focus:ring-accent/5 transition-all"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-muted/40 ml-1">Contact Email</label>
                      <input 
                        type="email"
                        value={newClinic.contact_email}
                        onChange={e => setNewClinic({...newClinic, contact_email: e.target.value})}
                        placeholder="registry@clinic.io"
                        className="w-full bg-off border border-border/60 rounded-2xl px-5 py-3.5 text-sm font-bold focus:outline-none focus:border-accent/40 focus:ring-4 focus:ring-accent/5 transition-all"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-muted/40 ml-1">Node Phone</label>
                      <input 
                        value={newClinic.phone}
                        onChange={e => setNewClinic({...newClinic, phone: e.target.value})}
                        placeholder="+1 (555) 000-0000"
                        className="w-full bg-off border border-border/60 rounded-2xl px-5 py-3.5 text-sm font-bold focus:outline-none focus:border-accent/40 focus:ring-4 focus:ring-accent/5 transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-muted/40 ml-1">Geospatial Address</label>
                    <textarea 
                      value={newClinic.address}
                      onChange={e => setNewClinic({...newClinic, address: e.target.value})}
                      placeholder="Full institutional address..."
                      className="w-full bg-off border border-border/60 rounded-2xl px-5 py-3.5 text-sm font-bold focus:outline-none focus:border-accent/40 focus:ring-4 focus:ring-accent/5 transition-all h-24 resize-none"
                    />
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button 
                      type="button"
                      onClick={() => setShowRegisterModal(false)}
                      className="flex-1 px-6 py-4 rounded-2xl border border-border/60 text-[11px] font-black uppercase tracking-widest text-muted/40 hover:bg-off transition-all"
                    >
                      Cancel
                    </button>
                    <button 
                      disabled={submitting}
                      className="flex-1 px-6 py-4 bg-text text-white rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-accent transition-all shadow-xl shadow-text/10 disabled:opacity-50"
                    >
                      {submitting ? 'Synchronizing...' : 'Confirm Registration'}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="bg-white border border-border/60 rounded-[32px] overflow-hidden shadow-sm flex flex-col min-h-[600px]">
        {/* Advanced Toolbar */}
        <div className="px-8 py-8 border-b border-border/40 flex flex-col xl:flex-row xl:items-center justify-between gap-8 bg-off/30">
          <div className="flex flex-wrap items-center gap-3">
            {[
              { id: 'all', label: 'All Entities' },
              { id: 'active', label: 'Active Clusters' },
              { id: 'inactive', label: 'Standby / Offline' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id)}
                className={`px-5 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all relative ${
                  statusFilter === tab.id 
                    ? 'text-text' 
                    : 'text-muted/40 hover:text-muted/60'
                }`}
              >
                <span className="relative z-10 flex items-center gap-2">
                  {tab.label}
                  <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold ${
                    statusFilter === tab.id ? 'bg-text text-white' : 'bg-muted/10 text-muted/40'
                  }`}>
                    {statusCounts[tab.id]}
                  </span>
                </span>
                {statusFilter === tab.id && (
                  <motion.div 
                    layoutId="activeClinicTab"
                    className="absolute inset-0 bg-white border border-border/60 rounded-xl shadow-sm" 
                  />
                )}
              </button>
            ))}
          </div>

          <div className="relative w-full xl:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted/30" size={16} />
            <input 
              type="text" 
              placeholder="Search by entity name or mail..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-border/60 rounded-2xl pl-12 pr-5 py-3.5 text-[14px] focus:outline-none focus:border-accent/40 focus:ring-4 focus:ring-accent/5 transition-all font-medium text-text shadow-sm"
            />
          </div>
        </div>

        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left border-separate border-spacing-0">
            <thead>
              <tr className="bg-off/20">
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Clinical Entity</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Node Status</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Contact Metadata</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Registration</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/20">
              <AnimatePresence mode="popLayout">
                {filteredClinics.map((c) => (
                  <motion.tr 
                    key={c.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="group hover:bg-off/40 transition-colors"
                  >
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className={`w-11 h-11 rounded-xl flex items-center justify-center font-black text-[12px] border transition-transform group-hover:scale-110 bg-off border-border text-muted/60`}>
                          <BuildingIcon size={18} className="text-accent" />
                        </div>
                        <div>
                          <div className="font-bold text-[14px] text-text mb-0.5">{c.name}</div>
                          <div className="text-[10px] font-black uppercase tracking-widest text-muted/30 flex items-center gap-2">
                             <Globe size={10} /> Sovereign Node Registry
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border shadow-sm ${
                        c.is_active ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 'bg-off border-border text-muted/40'
                      }`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${c.is_active ? 'bg-emerald-500 animate-pulse' : 'bg-muted/20'}`} />
                        {c.is_active ? 'Operational' : 'Standby'}
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 text-[12px] font-bold text-text/60">
                          <Mail size={12} className="text-muted/30" /> {c.contact_email || 'N/A'}
                        </div>
                        <div className="flex items-center gap-2 text-[12px] font-bold text-text/60">
                          <Phone size={12} className="text-muted/30" /> {c.phone || 'N/A'}
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-2 text-[12px] font-bold text-text/60">
                        <Calendar size={13} className="text-muted/30" />
                        {new Date(c.created_at).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                       <button className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border/60 bg-white text-[10px] font-black uppercase tracking-widest text-muted/40 hover:text-text hover:border-text transition-all hover:shadow-sm">
                         Entity Ledger <ArrowUpRight size={12} />
                       </button>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
          
          {loading && (
            <div className="py-32 flex flex-col items-center justify-center text-center">
              <div className="relative">
                <RefreshCw className="w-12 h-12 text-accent animate-spin opacity-20" />
                <div className="absolute inset-0 flex items-center justify-center">
                   <ShieldCheck size={16} className="text-accent animate-pulse" />
                </div>
              </div>
              <p className="mt-6 text-[11px] font-black uppercase tracking-[0.3em] text-muted/40">Synchronizing Institutional Registry...</p>
            </div>
          )}

          {!loading && filteredClinics.length === 0 && (
            <div className="py-32 flex flex-col items-center justify-center text-center px-8">
              <div className="w-20 h-20 bg-off rounded-3xl flex items-center justify-center mb-8 border border-border/40 relative group">
                <Building2 size={32} className="text-muted/10 group-hover:text-accent/20 transition-colors" />
                <div className="absolute inset-0 bg-accent/5 rounded-3xl scale-0 group-hover:scale-100 transition-transform duration-500" />
              </div>
              <h3 className="text-2xl font-serif tracking-tight text-text mb-3">No <span className="italic text-accent">entities</span> found in registry.</h3>
              <p className="text-muted/60 font-medium max-w-sm leading-relaxed text-[15px]">Refine your search parameters or check regional standby nodes.</p>
              <button 
                onClick={() => {setSearchQuery(''); setStatusFilter('all');}}
                className="mt-8 text-[11px] font-black uppercase tracking-widest text-accent hover:underline"
              >
                Clear registry filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
