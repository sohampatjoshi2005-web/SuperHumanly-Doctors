import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ShieldCheck, ShieldAlert, RefreshCw, 
  Search, Lock, CheckCircle2, AlertTriangle,
  Fingerprint, Database, Zap, ChevronRight,
  Terminal, Globe, Cpu, Activity, ArrowUpRight,
  User, Shield, Hash
} from 'lucide-react';
import { fetchAdminAuditLogs, verifyAuditVault } from '../../lib/doctorApi';

export default function AuditVaultTab() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState(null);
  const [error, setError] = useState(null);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const data = await fetchAdminAuditLogs();
      setLogs(data);
    } catch (err) {
      console.error('Failed to load audit ledger:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setVerifying(true);
    setError(null);
    try {
      const data = await verifyAuditVault();
      setVerificationResult(data);
    } catch (err) {
      console.error('Audit verification error:', err);
      setError(err.message);
    } finally {
      setVerifying(false);
    }
  };

  useEffect(() => {
    loadLogs();
    handleVerify();
  }, []);

  return (
    <div className="space-y-10">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-muted/30 mb-1">
             <span>Governance</span>
             <ChevronRight size={10} className="text-muted/20" />
             <span className="text-accent">Audit Vault</span>
          </div>
          <h2 className="text-5xl lg:text-6xl font-serif tracking-tight text-text leading-tight">
            Sovereign <span className="italic text-accent">Vault.</span>
          </h2>
          <p className="text-[15px] text-muted/60 font-medium max-w-xl leading-relaxed">
            Cryptographic verification of the clinical audit chain. Ensures zero-tamper integrity for institutional compliance and platform non-repudiability.
          </p>
        </div>
        
        <button 
          onClick={handleVerify}
          disabled={verifying}
          className="flex items-center gap-3 px-6 py-3.5 bg-text text-white rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-accent transition-all shadow-xl shadow-text/10 disabled:opacity-50 group active:scale-95"
        >
          <RefreshCw size={14} className={verifying ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'} /> 
          {verifying ? 'Verifying Integrity...' : 'Re-verify Chain Integrity'}
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Verification Intelligence Card */}
        <div className="xl:col-span-2 bg-white border border-border/60 rounded-[40px] p-10 relative overflow-hidden shadow-sm">
          <div className="absolute top-0 right-0 p-10 opacity-[0.03] text-accent">
            <ShieldCheck size={240} />
          </div>

          <div className="relative z-10">
            <div className="flex items-center gap-6 mb-10">
              <div className={`w-20 h-20 rounded-[28px] flex items-center justify-center border-2 shadow-sm ${
                error ? 'bg-red-50 border-red-100 text-red-500' : 
                verificationResult ? 'bg-emerald-50 border-emerald-100 text-emerald-500' : 
                'bg-off border-border text-muted/40'
              }`}>
                {error ? <ShieldAlert size={40} /> : <ShieldCheck size={40} />}
              </div>
              <div>
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-muted/30 mb-2">
                   <Activity size={10} /> Real-time Integrity Status
                </div>
                <h3 className="text-3xl font-serif tracking-tight text-text italic">
                  {error ? 'Chain Compromised.' : 
                   verificationResult ? 'Integrity Confirmed.' : 
                   'Initializing Sequence...'}
                </h3>
              </div>
            </div>

            {verificationResult && !error && (
              <div className="space-y-10">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                   {[
                     { label: 'Hashed Artifacts', val: verificationResult.count, sub: 'Verified Log Entries', icon: Database, color: 'text-text' },
                     { label: 'Integrity Score', val: `${(verificationResult.integrity_score * 100).toFixed(0)}%`, sub: 'Non-Repudiation Verified', icon: Shield, color: 'text-emerald-600' },
                     { label: 'Protocol', val: 'SHA-256', sub: 'Merkle Chain Architecture', icon: Hash, color: 'text-accent' }
                   ].map((stat, i) => (
                     <div key={i} className="bg-off/50 border border-border/40 rounded-[28px] p-6 hover:bg-white transition-colors group">
                        <div className={`w-8 h-8 rounded-lg bg-white border border-border/60 flex items-center justify-center mb-4 ${stat.color} shadow-sm group-hover:scale-110 transition-transform`}>
                           <stat.icon size={16} />
                        </div>
                        <div className="text-[10px] font-black uppercase tracking-widest text-muted/40 mb-1">{stat.label}</div>
                        <div className={`text-2xl font-bold tracking-tighter ${stat.color}`}>{stat.val}</div>
                        <div className="text-[10px] font-medium text-muted/40 mt-1">{stat.sub}</div>
                     </div>
                   ))}
                </div>

                <div className="bg-off/30 rounded-[32px] p-8 border border-border/60 relative group">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Fingerprint size={16} className="text-accent" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-muted/40">Master Sovereign Fingerprint</span>
                    </div>
                    <div className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-700 text-[8px] font-black uppercase tracking-widest">Signed</div>
                  </div>
                  <div className="font-mono text-[11px] break-all text-text/50 bg-white p-5 rounded-2xl border border-border/40 shadow-inner group-hover:text-text transition-colors">
                    {verificationResult.last_hash}
                  </div>
                </div>

                <div className="flex items-center gap-3 text-emerald-600 px-6 py-4 bg-emerald-50 rounded-2xl border border-emerald-100/50">
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                   <span className="text-[12px] font-bold tracking-tight">{verificationResult.message}</span>
                </div>
              </div>
            )}

            {error && (
              <div className="bg-red-50 border border-red-100 rounded-[32px] p-10 space-y-6">
                <div className="flex items-center gap-4 text-red-600">
                  <AlertTriangle size={32} />
                  <div>
                    <h4 className="text-xl font-bold tracking-tight">Security Protocol Violation</h4>
                    <p className="text-red-600/60 text-sm font-medium">Chain mismatch detected during recursive audit.</p>
                  </div>
                </div>
                <p className="text-red-900/70 text-[15px] leading-relaxed">
                  The audit chain verification process failed. This indicates a cryptographic mismatch in the event log, signifying potential unauthorized database manipulation or data corruption.
                </p>
                <div className="text-[11px] font-mono text-red-900/60 bg-white/50 p-5 rounded-2xl border border-red-200 shadow-inner">
                   <span className="font-black">REASON:</span> {error}
                </div>
                <button className="px-6 py-3 bg-red-600 text-white rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg shadow-red-200">
                   Initiate Lock Protocol
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Global Audit Ledger */}
        <div className="bg-white border border-border/60 rounded-[40px] p-8 shadow-sm flex flex-col h-[680px]">
           <div className="flex items-center justify-between mb-8">
              <div>
                 <h3 className="text-lg font-bold text-text">Live Ledger</h3>
                 <p className="text-[11px] text-muted/40 font-medium tracking-tight">Recent platform-wide actions</p>
              </div>
              <button 
                onClick={loadLogs}
                className="p-2 rounded-xl hover:bg-off transition-all text-muted/20 hover:text-text active:scale-95"
              >
                <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
              </button>
           </div>

           <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-3">
              <AnimatePresence mode="popLayout">
                {logs.map((log, i) => (
                  <motion.div 
                    key={log.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="p-4 rounded-2xl bg-off/30 border border-border/40 hover:bg-white hover:border-border hover:shadow-md transition-all group"
                  >
                     <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                           <div className="w-8 h-8 rounded-lg bg-white border border-border/60 flex items-center justify-center text-muted/40 group-hover:text-accent transition-colors shadow-sm">
                              <User size={14} />
                           </div>
                           <div>
                              <div className="text-[12px] font-bold text-text mb-0.5">{log.actor}</div>
                              <div className="text-[10px] font-medium text-muted/40">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</div>
                           </div>
                        </div>
                        <div className="px-2 py-0.5 rounded bg-white border border-border/60 text-[8px] font-black uppercase tracking-widest text-muted/40 group-hover:text-text group-hover:border-text transition-colors shadow-sm">
                           {log.action}
                        </div>
                     </div>
                     <div className="flex items-center gap-2 mb-3">
                        <Terminal size={10} className="text-accent" />
                        <span className="text-[11px] font-bold text-text/60 truncate">{log.resource_type}: {log.resource_id}</span>
                     </div>
                     <div className="flex items-center justify-between pt-3 border-t border-border/40">
                        <div className="flex items-center gap-2 text-[10px] font-bold text-muted/30">
                           <Globe size={10} /> {log.ip_address || 'Internal'}
                        </div>
                        <div className="flex items-center gap-1.5 text-[9px] font-mono text-muted/20 group-hover:text-muted/40 transition-colors">
                           <Fingerprint size={10} /> {log.event_hash?.slice(0, 12)}...
                        </div>
                     </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {logs.length === 0 && !loading && (
                <div className="py-20 text-center opacity-40">
                   <Shield size={40} className="mx-auto mb-4" />
                   <p className="text-[11px] font-black uppercase tracking-widest">No active ledger entries.</p>
                </div>
              )}
           </div>
           
           <div className="mt-8 pt-6 border-t border-border/40 text-center">
              <button className="text-[10px] font-black uppercase tracking-widest text-accent hover:underline flex items-center gap-2 mx-auto">
                 Export Comprehensive Audit Bundle <ArrowUpRight size={12} />
              </button>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
         <div className="bg-white border border-border/60 rounded-[32px] p-8 shadow-sm group hover:shadow-md transition-all">
            <div className="w-12 h-12 rounded-2xl bg-accent-light text-accent flex items-center justify-center mb-6 shadow-sm group-hover:scale-110 transition-transform">
               <Database size={24} />
            </div>
            <h4 className="text-xl font-bold mb-3 text-text">Immutable Merkle Chain</h4>
            <p className="text-muted/60 text-[14px] leading-relaxed font-medium">
               Every administrative and clinical action is hashed and cryptographically chained to the previous entry. Superhumanly uses a proprietary Merkle-root architecture to guarantee that no record can be deleted or modified without triggering a global integrity mismatch.
            </p>
         </div>

         <div className="bg-white border border-border/60 rounded-[32px] p-8 shadow-sm group hover:shadow-md transition-all">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-6 shadow-sm group-hover:scale-110 transition-transform">
               <Zap size={24} />
            </div>
            <h4 className="text-xl font-bold mb-3 text-text">Automatic Compliance Trigger</h4>
            <p className="text-muted/60 text-[14px] leading-relaxed font-medium">
               System-wide verification runs automatically upon every platform mutation. In the event of an integrity mismatch, the Administrative Sovereign is notified instantly, and all clinical write-operations are frozen to protect the sanctity of the institutional data layer.
            </p>
         </div>
      </div>
    </div>
  );
}
