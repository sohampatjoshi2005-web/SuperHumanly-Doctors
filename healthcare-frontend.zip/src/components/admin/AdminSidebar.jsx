import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Building2, 
  ShieldCheck, 
  Activity, 
  ClipboardList,
  LogOut,
  Terminal,
  ShieldAlert,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Zap,
  Globe,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function AdminSidebar({ activeTab, setActiveTab, onLogout }) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const sections = [
    {
      title: 'Operations',
      items: [
        { id: 'dashboard', label: 'Platform Preview', icon: LayoutDashboard },
        { id: 'health', label: 'System Health', icon: Activity },
      ]
    },
    {
      title: 'Directory',
      items: [
        { id: 'trials', label: 'Trial Ledger', icon: ClipboardList },
        { id: 'users', label: 'User Directory', icon: Users },
      ]
    },
    {
      title: 'Governance',
      items: [
        { id: 'clinics', label: 'Clinic Registry', icon: Building2 },
        { id: 'audit', label: 'Audit Vault', icon: ShieldCheck },
      ]
    }
  ];

  return (
    <motion.div 
      initial={false}
      animate={{ width: isCollapsed ? 80 : 320 }}
      transition={{ type: 'spring', stiffness: 400, damping: 40, mass: 1 }}
      className="bg-off border-r border-border flex flex-col h-screen shrink-0 relative overflow-visible group/sidebar z-[101]"
    >
      {/* Tactile Latch (Collapse Toggle) */}
      <motion.button 
        whileHover={{ scale: 1.05, x: 2 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsCollapsed(!isCollapsed)}
        className={`absolute -right-3 top-24 w-6 h-12 bg-white border border-border rounded-full flex flex-col items-center justify-center shadow-[0_4px_12px_rgba(0,0,0,0.08)] z-[150] transition-opacity duration-300 ${isCollapsed ? 'opacity-100' : 'opacity-0 group-hover/sidebar:opacity-100'} hover:bg-text hover:text-white cursor-pointer group/latch`}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={isCollapsed ? 'collapsed' : 'expanded'}
            initial={{ opacity: 0, rotate: -180 }}
            animate={{ opacity: 1, rotate: 0 }}
            exit={{ opacity: 0, rotate: 180 }}
            transition={{ duration: 0.3 }}
          >
            {isCollapsed ? <ChevronsRight size={14} /> : <ChevronsLeft size={14} />}
          </motion.div>
        </AnimatePresence>
      </motion.button>

      {/* Decorative gradient corner */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-20 -left-20 w-40 h-40 bg-accent/5 blur-[80px] rounded-full"></div>
      </div>

      {/* ═══ EXPANDED VIEW ═══ */}
      <div className={`h-full flex flex-col p-4 shrink-0 transition-opacity duration-200 overflow-hidden ${isCollapsed ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
        <div className="p-2 pt-4 pb-8">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-9 h-9 bg-text rounded-xl flex items-center justify-center shadow-lg shadow-text/10 relative shrink-0">
               <Terminal size={18} className="text-white" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-serif text-[22px] tracking-tight leading-none text-text">Superhumanly</span>
              <span className="text-[9px] font-black uppercase tracking-[0.25em] text-accent mt-1">Admin Terminal</span>
            </div>
          </div>

          <div className="space-y-6">
            {sections.map((section, idx) => (
              <div key={idx} className="space-y-1">
                <div className="text-[10px] font-black text-muted/30 uppercase tracking-[0.25em] mb-3 px-3">
                  {section.title}
                </div>
                <nav className="space-y-0.5">
                  {section.items.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-300 group relative ${
                        activeTab === item.id 
                          ? 'bg-white text-text shadow-[0_4px_12px_rgba(0,0,0,0.03)]' 
                          : 'text-muted/60 hover:text-text hover:bg-white/40 hover:pl-5'
                      }`}
                    >
                      <item.icon size={16} className={`${activeTab === item.id ? 'text-accent' : 'text-muted/40 group-hover:text-muted/60'} transition-colors`} />
                      <span className="text-[13.5px] font-bold tracking-tight">{item.label}</span>
                      
                      {activeTab === item.id && (
                        <motion.div 
                          layoutId="activeTabGlowHardened"
                          className="absolute left-[-12px] w-1 h-5 bg-accent rounded-r-full shadow-[0_0_10px_rgba(0,78,179,0.4)]" 
                        />
                      )}
                    </button>
                  ))}
                </nav>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-auto p-2">

          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-muted/60 hover:text-red-500 hover:bg-red-50 transition-all duration-300 group"
          >
            <div className="w-8 h-8 rounded-lg bg-off border border-border flex items-center justify-center group-hover:bg-red-100/50 group-hover:border-red-200 transition-all">
              <LogOut size={16} />
            </div>
            <span className="text-[13px] font-bold tracking-tight">Exit Terminal</span>
          </button>
        </div>
      </div>

      {/* ═══ COLLAPSED VIEW ═══ */}
      <AnimatePresence>
        {isCollapsed && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute top-0 left-0 w-20 bottom-0 flex flex-col items-center py-8 z-20"
          >
            <div className="w-10 h-10 bg-text rounded-xl flex items-center justify-center shadow-lg shadow-text/10 mb-10">
               <Terminal size={20} className="text-white" />
            </div>

            <div className="flex-1 flex flex-col items-center gap-3">
              {sections.map(s => s.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all duration-300 relative ${
                    activeTab === item.id 
                      ? 'bg-white text-accent shadow-md border border-border' 
                      : 'text-muted/40 hover:text-text hover:bg-white/50'
                  }`}
                  title={item.label}
                >
                  <item.icon size={18} />
                  {activeTab === item.id && (
                    <motion.div 
                      layoutId="collapsedGlowHardened"
                      className="absolute left-[-18px] w-1 h-5 bg-accent rounded-r-full" 
                    />
                  )}
                </button>
              )))}
            </div>

            <button 
              onClick={onLogout}
              className="w-11 h-11 rounded-xl flex items-center justify-center text-muted/40 hover:text-red-500 hover:bg-red-50 transition-all mt-auto"
              title="Exit Terminal"
            >
              <LogOut size={18} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
