import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Clock, CheckCircle2, XCircle, Search, Filter, 
  Download, Building, Stethoscope, ChevronRight,
  ArrowUpRight, Users, Shield, Terminal
} from 'lucide-react';

export default function TrialLedgerTab({ 
  trials, 
  searchQuery, 
  setSearchQuery, 
  filterStatus, 
  setFilterStatus, 
  onSelectTrial 
}) {
  const filteredTrials = trials.filter(t => {
    const matchesSearch = t.full_name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         t.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         t.institution.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || t.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const statusCounts = {
    all: trials.length,
    pending: trials.filter(t => t.status === 'pending').length,
    approved: trials.filter(t => t.status === 'approved').length,
    rejected: trials.filter(t => t.status === 'rejected').length
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.3em] text-muted/30 mb-1">
             <span>Registry</span>
             <ChevronRight size={10} className="text-muted/20" />
             <span className="text-accent">Trial Ledger</span>
          </div>
          <h2 className="text-5xl lg:text-6xl font-serif tracking-tight text-text leading-tight">
            Institutional <span className="italic text-accent">Registry.</span>
          </h2>
          <p className="text-[15px] text-muted/60 font-medium max-w-xl leading-relaxed">
            Monitor and authorize clinical access requests within the Superhumanly documentation ecosystem.
          </p>
        </div>
        
        <button className="flex items-center gap-2 px-6 py-3.5 bg-text text-white rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-accent transition-all shadow-xl shadow-text/10 active:scale-95 group">
          <Download size={14} className="group-hover:-translate-y-0.5 transition-transform" /> Export Master Ledger
        </button>
      </div>

      <div className="bg-white border border-border/60 rounded-[32px] overflow-hidden shadow-sm flex flex-col min-h-[600px]">
        {/* Advanced Filter Toolbar */}
        <div className="px-8 py-8 border-b border-border/40 flex flex-col xl:flex-row xl:items-center justify-between gap-8 bg-off/30">
          <div className="flex flex-wrap items-center gap-3">
            {[
              { id: 'all', label: 'All Requests' },
              { id: 'pending', label: 'Pending' },
              { id: 'approved', label: 'Authorized' },
              { id: 'rejected', label: 'Rescinded' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setFilterStatus(tab.id)}
                className={`px-5 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all relative ${
                  filterStatus === tab.id 
                    ? 'text-text' 
                    : 'text-muted/40 hover:text-muted/60'
                }`}
              >
                <span className="relative z-10 flex items-center gap-2">
                  {tab.label}
                  <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold ${
                    filterStatus === tab.id ? 'bg-text text-white' : 'bg-muted/10 text-muted/40'
                  }`}>
                    {statusCounts[tab.id]}
                  </span>
                </span>
                {filterStatus === tab.id && (
                  <motion.div 
                    layoutId="activeFilterTab"
                    className="absolute inset-0 bg-white border border-border/60 rounded-xl shadow-sm" 
                  />
                )}
              </button>
            ))}
          </div>

          <div className="relative w-full xl:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted/30" size={16} />
            <input 
              type="text" 
              placeholder="Search by identity or institution..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-border/60 rounded-2xl pl-12 pr-5 py-3.5 text-[14px] focus:outline-none focus:border-accent/40 focus:ring-4 focus:ring-accent/5 transition-all font-medium text-text shadow-sm"
            />
          </div>
        </div>

        <div className="flex-1 overflow-x-auto">
          <table className="w-full text-left border-separate border-spacing-0">
            <thead>
              <tr className="bg-off/20">
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Clinician Identity</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Institutional Entity</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30 text-center">Status</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30">Transmission</th>
                <th className="px-8 py-5 border-b border-border/40 text-[10px] font-black uppercase tracking-widest text-muted/30 text-right">Protocol</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/20">
              <AnimatePresence mode="popLayout">
                {filteredTrials.map((t) => (
                  <motion.tr 
                    key={t._id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="group hover:bg-off/40 transition-colors cursor-pointer"
                    onClick={() => onSelectTrial(t)}
                  >
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-text text-white flex items-center justify-center text-[11px] font-black shadow-lg shadow-text/5 group-hover:scale-110 transition-transform">
                          {t.full_name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-[14px] text-text mb-0.5">{t.full_name}</div>
                          <div className="text-[11px] text-muted/50 font-medium tracking-tight leading-none">{t.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 text-[13px] font-bold text-text/80">
                          <Building size={13} className="text-muted/30" /> {t.institution}
                        </div>
                        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-muted/30">
                          <Terminal size={11} className="text-muted/20" /> {t.professional_role}
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-center">
                      <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border shadow-sm
                        ${t.status === 'approved' ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 
                          t.status === 'rejected' ? 'bg-red-50 border-red-100 text-red-600' : 
                          'bg-amber-50 border-amber-100 text-amber-600'}`}>
                        {t.status === 'pending' && <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />}
                        {t.status === 'approved' && <CheckCircle2 size={10} />}
                        {t.status === 'rejected' && <XCircle size={10} />}
                        {t.status}
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="text-[12px] font-bold text-text/60 mb-0.5">{new Date(t.created_at).toLocaleDateString()}</div>
                      <div className="text-[10px] font-medium text-muted/30">{new Date(t.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                    </td>
                    <td className="px-8 py-6 text-right">
                       <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border/60 bg-white text-[10px] font-black uppercase tracking-widest text-muted/40 group-hover:text-text group-hover:border-text transition-all group-hover:shadow-sm">
                         View Protocol <ArrowUpRight size={12} />
                       </div>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
          
          {filteredTrials.length === 0 && (
            <div className="py-32 flex flex-col items-center justify-center text-center px-8">
              <div className="w-20 h-20 bg-off rounded-3xl flex items-center justify-center mb-8 border border-border/40 relative group">
                <Search size={32} className="text-muted/10 group-hover:text-accent/20 transition-colors" />
                <div className="absolute inset-0 bg-accent/5 rounded-3xl scale-0 group-hover:scale-100 transition-transform duration-500" />
              </div>
              <h3 className="text-2xl font-serif tracking-tight text-text mb-3">No <span className="italic text-accent">matches</span> found in registry.</h3>
              <p className="text-muted/60 font-medium max-w-sm leading-relaxed text-[15px]">Refine your search parameters or filter by institutional status.</p>
              <button 
                onClick={() => {setSearchQuery(''); setFilterStatus('all');}}
                className="mt-8 text-[11px] font-black uppercase tracking-widest text-accent hover:underline"
              >
                Clear all filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
