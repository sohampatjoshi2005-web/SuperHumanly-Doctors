import { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { fetchCustomers, createCustomer, fetchEncounters } from '../../lib/doctorApi';
import { 
  Rocket, Clock, Zap, User, ChevronDown, 
  Search, Check, Plus, X, ArrowRight, History, 
  ChevronRight, ChevronsLeft, ChevronsRight 
} from 'lucide-react';

export default function Sidebar({ 
  selectedCustomer, 
  setSelectedCustomer, 
  onLoadEncounter,
  isCollapsed,
  setIsCollapsed,
  isOpenMobile,
  onCloseMobile,
  trialData,
  onUpgradeClick
}) {
  const [customers, setCustomers] = useState([]);
  const [encounters, setEncounters] = useState([]);
  const [recentPatients, setRecentPatients] = useState([]);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [loadingCustomers, setLoadingCustomers] = useState(true);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownTriggerRef = useRef(null);
  const dropdownRef = useRef(null);

  // Persistence for Recent Patients
  useEffect(() => {
    const saved = localStorage.getItem('recent_patients');
    if (saved) setRecentPatients(JSON.parse(saved));
  }, []);

  useEffect(() => {
    if (selectedCustomer && selectedCustomer.id !== 'TUT-001') {
      const updated = [selectedCustomer, ...recentPatients.filter(p => p.id !== selectedCustomer.id)].slice(0, 3);
      setRecentPatients(updated);
      localStorage.setItem('recent_patients', JSON.stringify(updated));
    }
  }, [selectedCustomer]);

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target) && 
          dropdownTriggerRef.current && !dropdownTriggerRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    loadCustomers();

    const handleClear = () => {
      setRecentPatients(prev => {
        const filtered = prev.filter(p => p.id !== 'TUT-001');
        localStorage.setItem('recent_patients', JSON.stringify(filtered));
        return filtered;
      });
    };

    const handleRefresh = (e) => {
      if (selectedCustomer && e.detail?.customerId === selectedCustomer.id) {
        loadEncounters(selectedCustomer.id);
      }
    };

    window.addEventListener('superhumanly-tutorial-clear', handleClear);
    window.addEventListener('superhumanly-encounter-created', handleRefresh);

    return () => {
      window.removeEventListener('superhumanly-tutorial-clear', handleClear);
      window.removeEventListener('superhumanly-encounter-created', handleRefresh);
    };
  }, []);

  useEffect(() => {
    if (selectedCustomer) {
      loadEncounters(selectedCustomer.id);
    } else {
      setEncounters([]);
    }
  }, [selectedCustomer]);

  const handleToggleDropdown = () => {
    setDropdownOpen(prev => !prev);
  };

  const loadCustomers = async () => {
    setLoadingCustomers(true);
    try {
      const data = await fetchCustomers();
      setCustomers(data);
      const validIds = new Set(data.map((c) => c.id));
      // Functional update avoids stale closure clearing a patient just created/selected.
      setSelectedCustomer((current) => {
        if (current && !validIds.has(current.id)) return null;
        return current;
      });
      setRecentPatients((prev) => {
        const pruned = prev.filter((p) => validIds.has(p.id));
        if (pruned.length !== prev.length) {
          localStorage.setItem('recent_patients', JSON.stringify(pruned));
        }
        return pruned;
      });
    } catch (e) {
      console.error(e);
      setCustomers([]);
    } finally {
      setLoadingCustomers(false);
    }
  };

  const mockEncounters = [
    { 
      id: 'mock-1', 
      created_at: new Date(Date.now() - 86400000 * 2).toISOString(), 
      patient_summary: "Patient presented with mild hypertension and requested a renewal of their maintenance medication. Vitals stable.",
      rx_summary: "Lisinopril 10mg - 1 tablet daily. Follow up in 3 months.",
      rx_json: { medication: "Lisinopril", dosage: "10mg", frequency: "Daily" }
    },
    { 
      id: 'mock-2', 
      created_at: new Date(Date.now() - 86400000 * 5).toISOString(), 
      patient_summary: "Routine check-up. Patient reporting improved sleep quality following lifestyle adjustments. No new clinical concerns.",
      rx_summary: "No new prescriptions. Continue current regimen.",
      rx_json: {}
    }
  ];

  const isMockActive = window.superhumanly_mock_active === 'sidebar' || (selectedCustomer?.id === 'TUT-001');
  const displayedEncounters = isMockActive && encounters.length === 0 ? mockEncounters : encounters;

  const loadEncounters = async (id) => {
    try {
      const data = await fetchEncounters(id);
      setEncounters(data);
    } catch (e) {
      console.error(e);
      setEncounters([]);
    }
  };

  const handleCreateCustomer = async () => {
    const name = newCustomerName.trim();
    if (!name) return;
    setIsCreating(true);
    try {
      const data = await createCustomer(name);
      setCustomers((prev) => {
        if (prev.some((c) => c.id === data.id)) return prev;
        return [data, ...prev];
      });
      setSelectedCustomer(data);
      setNewCustomerName('');
      setSearchQuery('');
      setDropdownOpen(false);
    } catch (e) {
      console.error(e);
      alert(e.message || 'Failed to create patient. Check you are signed in and try again.');
    } finally {
      setIsCreating(false);
    }
  };

  const validCustomers = useMemo(
    () => customers.filter((c) => c?.id && typeof c.name === 'string' && c.name.trim()),
    [customers],
  );

  const filteredCustomers = useMemo(() => {
    if (!searchQuery.trim()) return validCustomers;
    const q = searchQuery.toLowerCase();
    return validCustomers.filter((c) => c.name.toLowerCase().includes(q));
  }, [validCustomers, searchQuery]);

  const getInitials = (name) => {
    if (!name) return '??';
    const parts = name.split(' ');
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return parts[0].substring(0, 2).toUpperCase();
  };

  const formatDate = (dateStr) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const renderSidebarShell = (mobile = false) => (
      <motion.div 
        initial={mobile ? { x: -340 } : false}
        animate={{ 
          width: mobile ? 320 : (isCollapsed ? 80 : 320),
          x: 0,
        }}
        exit={mobile ? { x: -340 } : undefined}
        transition={{
          type: 'spring',
          stiffness: 400,
          damping: 40,
          mass: 1
        }}
        className={`bg-off border-r border-border p-0 flex flex-col shrink-0 relative overflow-visible group/sidebar h-full ${mobile ? 'absolute top-0 left-0 bottom-0 w-full max-w-[320px] shadow-[-10px_0_40px_rgba(0,0,0,0.08)] z-[1001] pointer-events-auto' : 'hidden lg:flex z-[101]'}`}
      >
        {/* Tactile Latch (Collapse Toggle) */}
        {!mobile && (
          <motion.button 
            whileHover={{ scale: 1.05, x: 2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsCollapsed(!isCollapsed)}
            className={`absolute -right-3 top-32 w-6 h-12 bg-white border border-border rounded-full flex flex-col items-center justify-center shadow-[0_4px_12px_rgba(0,0,0,0.08)] z-[150] transition-opacity duration-300 ${isCollapsed ? 'opacity-100' : 'opacity-0 group-hover/sidebar:opacity-100'} hover:bg-text hover:text-white cursor-pointer group/latch`}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={isCollapsed ? 'collapsed' : 'expanded'}
                initial={{ opacity: 0, rotate: -180 }}
                animate={{ opacity: 1, rotate: 0 }}
                exit={{ opacity: 0, rotate: 180 }}
                transition={{ duration: 0.3 }}
              >
                {isCollapsed ? <ChevronsRight size={14} /> : <ChevronsLeft size={14} />}
              </motion.div>
            </AnimatePresence>
            
            {/* Subtle side glow on hover */}
            <div className="absolute inset-0 rounded-full opacity-0 group-hover/latch:opacity-20 bg-accent blur-md -z-10 transition-opacity" />
          </motion.button>
        )}

        {/* Decorative gradient corner */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-l-[24px]">
          <div className="absolute -top-20 -left-20 w-40 h-40 bg-accent/5 blur-[80px] rounded-full"></div>
        </div>

        {/* ═══ EXPANDED VIEW WRAPPER ═══ */}
        <div className={`w-[320px] h-full flex flex-col p-4 shrink-0 transition-opacity duration-200 overflow-hidden ${(isCollapsed && !mobile) ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
          {/* Mobile Close Button */}
          {mobile && (
            <div className="flex items-center justify-between px-3 pt-2 pb-5 lg:hidden">
              <div>
                <div className="text-[11px] font-black uppercase tracking-[0.18em] text-muted mb-1">Patient Registry</div>
                <div className="text-[24px] font-serif text-text leading-none">Clinical Continuity</div>
              </div>
              <button 
                onClick={onCloseMobile}
                className="p-2 text-muted hover:text-text"
              >
                <X size={20} />
              </button>
            </div>
          )}

          <div className="relative z-10 flex flex-col h-full min-h-0 overflow-hidden">
            <AnimatePresence mode="wait">
              {(!isCollapsed || mobile) && (
                <motion.div 
                  key="content"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.2 }}
                  className="flex flex-col h-full min-h-0"
                >
                  {/* RECENT PATIENTS - Continuity Strip */}
                  {recentPatients.length > 0 && (
                    <div className="mb-5 overflow-hidden shrink-0">
                      <div className="text-[10px] font-black text-muted uppercase tracking-[0.2em] mb-3 px-1">Recent Continuity</div>
                      <div className="flex gap-2.5 h-11">
                        {recentPatients.map(p => (
                          <button 
                            key={p.id}
                            onClick={() => setSelectedCustomer(p)}
                            className={`w-10 h-10 rounded-2xl flex items-center justify-center text-[11px] font-black transition-all border ${
                              selectedCustomer?.id === p.id 
                                ? 'bg-accent text-white border-accent shadow-md shadow-accent/10' 
                                : 'bg-white text-muted border-border hover:border-accent hover:text-accent shadow-sm'
                            }`}
                            title={p.name}
                          >
                            {getInitials(p.name)}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between mb-3 px-1 shrink-0">
                    <h2 className="text-[11px] font-black text-muted uppercase tracking-[0.2em] flex items-center gap-2">
                      <User size={12} className="text-accent" /> Active Subject
                    </h2>
                  </div>
                  
                  <div id="tutorial-sidebar-patients" className="relative flex flex-col gap-3 mb-6 shrink-0 z-20">
                    {/* Precision Context Strip */}
                    <button
                      ref={dropdownTriggerRef}
                      className={`w-full group relative overflow-hidden transition-all duration-300 rounded-2xl border-2 border-dashed h-[52px] ${
                        selectedCustomer 
                          ? 'bg-white px-2 border-border/80 shadow-sm hover:border-accent/40 border-solid' 
                          : 'bg-off/40 px-2 border-border/40 hover:bg-white hover:border-accent/20'
                      }`}
                      onClick={handleToggleDropdown}
                    >
                      {selectedCustomer ? (
                        <div className="flex items-center gap-3 text-left relative z-10 h-full">
                          <div className="w-9 h-9 bg-accent/5 text-accent rounded-xl flex items-center justify-center text-sm font-black border border-accent/10 shrink-0">
                            {getInitials(selectedCustomer.name)}
                          </div>
                          <div className="flex flex-col min-w-0">
                            <div className="text-[15px] font-bold text-text truncate leading-none">{selectedCustomer.name}</div>
                          </div>
                          <ChevronDown size={16} className={`ml-auto text-muted/30 transition-transform duration-300 ${dropdownOpen ? 'rotate-180' : ''}`} />
                        </div>
                      ) : (
                        <div className="flex items-center gap-3 text-muted/60 h-full relative">
                          <div className="w-9 h-9 rounded-xl border border-dashed border-border/60 flex items-center justify-center shrink-0 group-hover:border-accent/40 group-hover:text-accent transition-colors">
                            <Plus size={16} />
                          </div>
                          <span className="text-[14px] font-bold tracking-tight">Select Active Subject...</span>
                          <ChevronDown size={16} className="ml-auto opacity-30 group-hover:opacity-100 transition-opacity" />
                        </div>
                      )}
                    </button>
                    
                    <AnimatePresence>
                      {dropdownOpen && (
                        <motion.div
                          ref={dropdownRef}
                          initial={{ opacity: 0, y: -8, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: -8, scale: 0.95 }}
                          transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                          className="absolute left-0 right-0 top-[calc(100%+12px)] bg-white/95 backdrop-blur-xl border border-border/60 rounded-[24px] shadow-[0_32px_64px_rgba(0,0,0,0.15)] overflow-hidden z-[200]"
                        >
                          {/* Portal Header & Search */}
                          <div className="p-1 border-b border-border/40">
                            <div className="relative">
                              <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted/40">
                                <Search size={16} />
                              </div>
                              <input 
                                autoFocus
                                type="text" 
                                placeholder="Search clinical database..."
                                className="w-full bg-off/60 border-none rounded-xl pl-10 pr-4 py-2.5 text-[13px] font-semibold outline-none focus:bg-white transition-all placeholder:text-muted/60"
                                value={searchQuery}
                                onChange={e => setSearchQuery(e.target.value)}
                              />
                            </div>
                          </div>

                          <div className="max-h-[320px] overflow-y-auto p-1.5 custom-scrollbar">
                            {filteredCustomers.length === 0 ? (
                              <div className="p-8 text-center">
                                <div className="text-[12px] font-bold text-muted/40 uppercase tracking-widest mb-1">No Results</div>
                                <div className="text-[11px] text-muted italic">Check the database spelling...</div>
                              </div>
                            ) : (
                              <div className="space-y-1">
                                {/* System Reset */}
                                <button
                                  key="reset-workspace-context"
                                  type="button"
                                  className={`w-full px-0 py-1 rounded-xl flex items-center text-[11px] font-black uppercase tracking-widest cursor-pointer hover:bg-off flex items-center gap-3 transition-all text-accent`}
                                  onClick={() => { setSelectedCustomer(null); setDropdownOpen(false); setSearchQuery(''); }}
                                >
                                  <div className="w-7 h-7 rounded-lg flex items-center justify-center text-accent">
                                    <X size={16} />
                                  </div>
                                  Reset Workspace Context
                                </button>

                                {filteredCustomers.map(c => (
                                  <button 
                                    key={c.id}
                                    className={`w-full px-1.5 py-2.5 rounded-xl text-[14px] font-bold cursor-pointer transition-all flex items-center justify-between group ${selectedCustomer?.id === c.id ? 'bg-accent/5 text-accent' : 'text-text hover:bg-off hover:pl-4'}`}
                                    onClick={() => { setSelectedCustomer(c); setDropdownOpen(false); setSearchQuery(''); }}
                                  >
                                    <div className="flex items-center gap-3">
                                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-black transition-all ${selectedCustomer?.id === c.id ? 'bg-accent text-white shadow-md shadow-accent/20' : 'bg-off text-muted/70 group-hover:bg-white group-hover:shadow-sm'}`}>
                                        {getInitials(c.name)}
                                      </div>
                                      <span className="truncate">{c.name}</span>
                                    </div>
                                    {selectedCustomer?.id === c.id && (
                                      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                                        <Check size={16} className="text-accent" />
                                      </motion.div>
                                    )}
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                    
                    <div className="relative group flex items-center">
                       <div className="absolute left-4 z-10 pointer-events-none">
                          <Plus size={16} className={`transition-colors ${newCustomerName ? 'text-accent' : 'text-muted'}`} />
                       </div>
                       <input 
                         type="text" 
                         placeholder="Create new patient profile..." 
                         className="w-full h-[52px] border border-border/80 rounded-2xl pl-11 pr-12 text-[14px] font-bold outline-none focus:border-accent/30 focus:bg-white transition-all placeholder:text-muted placeholder:font-medium shadow-sm"
                         value={newCustomerName}
                         onChange={e => setNewCustomerName(e.target.value)}
                         onKeyDown={e => e.key === 'Enter' && handleCreateCustomer()}
                       />
                       <div className="absolute right-2 flex items-center gap-1">
                         {newCustomerName && (
                           <button 
                             onClick={() => setNewCustomerName('')}
                             className="p-1 text-muted hover:text-[#d94040] transition-colors"
                           >
                             <X size={15} />
                           </button>
                         )}
                         <button 
                           className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-300 shrink-0 disabled:opacity-0 ${isCreating ? 'bg-accent/10' : 'bg-text text-white hover:bg-black active:scale-[0.9] shadow-md'}`}
                           onClick={handleCreateCustomer}
                           disabled={isCreating || !newCustomerName.trim()}
                         >
                           {isCreating ? <div className="typing-dot relative pt-1"><span></span><span></span><span></span></div> : <ArrowRight size={18} />}
                         </button>
                       </div>
                    </div>
                  </div>

                  {/* TIMELINE SECTION */}
                  <div id="tutorial-sidebar-timeline" className="flex-1 flex flex-col min-h-0">
                    <div className="flex items-center gap-2 text-muted mb-5 px-1 shrink-0">
                      <History size={18} className="text-accent" />
                      <h2 className="text-lg font-bold text-black">Patient Timeline</h2>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto custom-scrollbar min-h-0">
                      {!selectedCustomer ? (
                        <div className="flex flex-col items-center justify-center py-24 px-6 text-center">
                          <div className="relative mb-8">
                            {/* Double-Ring Effect */}
                            <div className="absolute inset-[-12px] rounded-full border border-dashed border-border/20 animate-[spin_20s_linear_infinite]" />
                            <div className="w-20 h-20 bg-off/40 rounded-[32px] border border-dashed border-border/60 flex items-center justify-center text-muted/20 shadow-sm relative z-10">
                              <History size={32} />
                            </div>
                          </div>
                          <h3 className="text-[16px] font-bold text-text/60 mb-2">Registry Continuity</h3>
                          <p className="text-[13px] font-medium text-muted/50 leading-relaxed max-w-[200px]">Select a subject profile to audit clinical history.</p>
                        </div>
                      ) : displayedEncounters.length === 0 ? (
                        <div className="py-24 px-6 text-center">
                          <div className="relative mb-8 flex justify-center">
                             {/* Double-Ring Effect */}
                            <div className="absolute inset-[-12px] w-[104px] h-[104px] rounded-full border border-dashed border-border/20 animate-[spin_25s_linear_infinite_reverse]" />
                            <div className="w-20 h-20 bg-off/40 rounded-[32px] border border-dashed border-border/60 flex items-center justify-center text-muted/20 shadow-sm relative z-10">
                              <Zap size={32} />
                            </div>
                          </div>
                          <h3 className="text-[16px] font-bold text-text/60 mb-2">Pristine Record</h3>
                          <p className="text-[13px] font-medium text-muted/50 leading-relaxed max-w-[200px]">No past encounters recorded for this subject.</p>
                        </div>
                      ) : (
                        <div className="flex flex-col relative pl-4 pb-8">
                          <div className="absolute left-[3px] top-4 bottom-4 w-px bg-border/40" aria-hidden="true" />
                          <div className="flex flex-col space-y-3">
                          {displayedEncounters.map((enc, idx) => (
                            <motion.div 
                              key={enc.id ?? `encounter-${idx}`} 
                              initial={{ opacity: 0, y: 5 }} 
                              animate={{ opacity: 1, y: 0 }} 
                              transition={{ delay: idx * 0.05 }}
                              className="relative group"
                            >
                              <div className="absolute left-[-16px] top-4 w-2 h-2 rounded-full border-2 border-off bg-border/80 transition-all z-10" />
                              <div 
                                className="p-3.5 bg-white border border-border/80 rounded-xl cursor-pointer hover:border-accent/40 hover:shadow-sm transition-all duration-200 relative overflow-hidden group/card"
                                onClick={() => onLoadEncounter(enc)}
                              >
                                <div className="flex justify-between items-start mb-1.5">
                                  <span className="text-[10px] font-black text-accent uppercase tracking-widest">{formatDate(enc.created_at)}</span>
                                  <ChevronRight size={14} className="text-muted/40 group-hover/card:text-accent transition-colors" />
                                </div>
                                <div className="text-[14px] font-bold text-text mb-1 leading-tight">Clinical Encounter</div>
                                <div className="text-[12px] font-medium text-muted/70 line-clamp-2 leading-relaxed">
                                  {enc.patient_summary || 'No summary recorded.'}
                                </div>
                              </div>
                            </motion.div>
                          ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* TRIAL STATUS INDICATOR */}
                  {!trialData?.is_unlimited && trialData && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-auto pt-6 border-t border-border/60"
                    >
                      <div className="bg-white/40 border border-border/80 rounded-2xl p-4 shadow-sm relative overflow-hidden group/trial">
                        <div className="absolute top-0 right-0 p-2 opacity-5 group-hover/trial:opacity-20 transition-opacity">
                           <Zap size={40} className="text-accent" />
                        </div>
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                             <Rocket size={14} className="text-accent" />
                             <span className="text-[11px] font-black uppercase tracking-widest text-muted">Trial Status</span>
                          </div>
                          {trialData.is_expired && (
                            <span className="bg-red-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full uppercase">Expired</span>
                          )}
                        </div>
                        
                        <div className="flex justify-between mb-2">
                           <div className="flex flex-col">
                              <span className="text-[18px] font-serif text-text leading-none">{Math.max(0, 10 - trialData.usage_count)}</span>
                              <span className="text-[10px] font-bold text-muted uppercase">Uses Left</span>
                           </div>
                           <div className="flex flex-col items-end">
                              <span className="text-[18px] font-serif text-text leading-none">{trialData.days_left}</span>
                              <span className="text-[10px] font-bold text-muted uppercase">Days Left</span>
                           </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full h-1.5 bg-off rounded-full mb-4 overflow-hidden border border-border/30">
                           <motion.div 
                             initial={{ width: 0 }}
                             animate={{ width: `${Math.min(100, (trialData.usage_count / 10) * 100)}%` }}
                             className={`h-full ${trialData.is_expired ? 'bg-red-400' : 'bg-accent'}`}
                           />
                        </div>

                        <button 
                          onClick={onUpgradeClick}
                          className={`w-full py-2.5 rounded-xl text-[12px] font-black uppercase tracking-wider transition-all shadow-sm ${trialData.is_expired ? 'bg-text text-white hover:bg-black' : 'bg-accent/10 text-accent hover:bg-accent hover:text-white'}`}
                        >
                          {trialData.is_expired ? 'Upgrade for Access' : 'Request Full Access'}
                        </button>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* ═══ COLLAPSED VIEW WRAPPER ═══ */}
        <AnimatePresence>
          {isCollapsed && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute top-0 left-0 w-[80px] bottom-0 flex flex-col items-center gap-8 py-24 z-20 pointer-events-auto"
            >
              <motion.div layout layoutId="selected-patient" className={`w-11 h-11 rounded-2xl flex items-center justify-center border shadow-sm transition-all ${selectedCustomer ? 'bg-accent/10 border-accent/30 text-accent font-black shadow-lg shadow-accent/5' : 'bg-white border-border text-muted/20'}`}>
                {selectedCustomer ? getInitials(selectedCustomer.name) : <User size={20} />}
              </motion.div>
              
              <div className="w-10 h-px bg-border/60" />
              
              <div className="flex flex-col gap-4">
                {recentPatients.map(p => (
                  <button 
                    key={p.id}
                    onClick={() => setSelectedCustomer(p)}
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center text-[11px] font-black shadow-sm transition-all border ${selectedCustomer?.id === p.id ? 'bg-accent text-white border-accent' : 'bg-white text-muted/40 border-border hover:border-accent hover:text-accent'}`}
                  >
                    {getInitials(p.name)}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <style dangerouslySetInnerHTML={{ __html: `
          .custom-scrollbar::-webkit-scrollbar { width: 4px; }
          .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
          .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.04); border-radius: 10px; }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.08); }
        `}} />
      </motion.div>
  );

  return (
    <>
      {isOpenMobile && (
        <div className="fixed inset-0 z-[1000] lg:hidden">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={onCloseMobile}
            className="absolute inset-0 bg-black/20 backdrop-blur-sm"
          />
          {renderSidebarShell(true)}
        </div>
      )}

      {renderSidebarShell(false)}
    </>
  );
}
