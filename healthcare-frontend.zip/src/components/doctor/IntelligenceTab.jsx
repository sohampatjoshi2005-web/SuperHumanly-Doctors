import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Database, TrendingUp, Activity, PieChart, BarChart3, Search, Sparkles, Wand2, Lightbulb, Map, MousePointer2, Loader2, Info, Copy, ThumbsUp, ThumbsDown, RotateCcw, Edit2, Check, PanelLeftClose, PanelLeftOpen, MoreHorizontal, Trash2, Pencil, Shield } from 'lucide-react';
import { queryIntelligence, fetchIntelligenceStats, fetchSessions, fetchSessionMessages, renameSession, deleteSession } from '../../lib/doctorApi';
import {
  PortalChartSkeleton,
  PortalInsightCardSkeleton,
  PortalSessionListSkeleton,
} from '../portal/PortalSkeleton';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip as ReTooltip, CartesianGrid, BarChart, Bar, Cell, LineChart, Line, PieChart as RePieChart, Pie } from 'recharts';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

const Tooltip = ({ text, children }) => (
  <div className="relative inline-block group/tooltip">
    {children}
    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-56 p-3 bg-text text-white text-[11px] font-medium rounded-lg opacity-0 invisible group-hover/tooltip:opacity-100 group-hover/tooltip:visible transition-all duration-150 shadow-xl z-50 pointer-events-none">
       {text}
       <div className="absolute top-full left-1/2 -translate-x-1/2 border-6 border-transparent border-t-text" />
    </div>
  </div>
);

const InsightCard = ({ title, value, label, trend, icon: Icon, color, loading, description }) => {
  if (loading) return <PortalInsightCardSkeleton />;

  return (
  <div className="bg-white border border-border/90 p-5 rounded-2xl hover:bg-off/40 transition-all duration-200 relative flex flex-col justify-between h-full shadow-sm">
    <div className="flex items-start justify-between mb-4">
      <div className="flex flex-col">
        <span className="portal-label">{title}</span>
        <div className="flex items-center gap-1.5 mt-2">
           <h4 className="text-[24px] font-bold text-text tracking-tight">{value}</h4>
           <span className={`text-[11px] font-black ${
             trend?.startsWith('+') ? 'text-green-700' : 'text-red-600'
           }`}>
             {trend}
           </span>
        </div>
      </div>
      <Tooltip text={description}>
        <div className="w-6 h-6 rounded-full border border-border/80 flex items-center justify-center text-muted hover:text-accent hover:border-accent hover:bg-white transition-all cursor-help shadow-sm">
           <span className="text-[11px] font-black italic">i</span>
        </div>
      </Tooltip>
    </div>
    
    <div className="flex items-center gap-2">
       <div className={`w-1.5 h-1.5 rounded-full ${
         color === 'blue' ? 'bg-blue-500' :
         color === 'teal' ? 'bg-teal-500' :
         color === 'purple' ? 'bg-purple-500' :
         'bg-accent'
       }`} />
       <p className="text-[12px] font-bold text-text2 uppercase tracking-wide">
          {label}
       </p>
    </div>
  </div>
  );
};

// [NEW] Clinical Data Table Component for Chat
const ClinicalDataTable = ({ data }) => {
  if (!data || !data.headers || !data.rows) return null;
  return (
    <div className="overflow-x-auto my-5 border border-border/60 rounded-2xl bg-white shadow-sm">
      <table className="w-full text-left text-[13px] border-collapse">
        <thead>
          <tr className="bg-off/50">
            {data.headers.map((h, i) => (
              <th key={i} className="px-4 py-3 font-black text-muted uppercase tracking-widest border-b border-border/60">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.rows.map((row, idx) => (
            <motion.tr 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: idx * 0.05 }}
              key={idx} 
              className="hover:bg-off/30 transition-colors"
            >
              {row.map((cell, i) => (
                <td key={i} className="px-4 py-3 border-b border-border/40 font-medium text-text">{cell}</td>
              ))}
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

// [NEW] Risk Profile Card Component
const RiskProfileCard = ({ profile }) => (
  <motion.div 
    initial={{ opacity: 0, scale: 0.98 }}
    animate={{ opacity: 1, scale: 1 }}
    className="my-5 p-6 bg-white border-2 border-accent/10 rounded-[28px] shadow-lg shadow-accent/5 relative overflow-hidden group"
  >
     <div className="absolute top-0 right-0 w-32 h-32 bg-accent/5 blur-3xl rounded-full -mr-16 -mt-16 group-hover:bg-accent/10 transition-all" />
     <div className="flex items-start justify-between mb-6 relative z-10">
        <div className="flex items-center gap-3">
           <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
             profile.severity === 'High' ? 'bg-red-50 text-red-600' : 'bg-orange-50 text-orange-600'
           }`}>
             <Shield className={profile.severity === 'High' ? 'animate-pulse' : ''} size={24} />
           </div>
           <div>
              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted mb-1">Critical Insight</div>
              <h4 className="text-[20px] font-bold text-text">{profile.name}</h4>
           </div>
        </div>
        <div className={`px-4 py-1.5 rounded-full text-[11px] font-black uppercase tracking-widest ${
          profile.severity === 'High' ? 'bg-red-600 text-white' : 'bg-orange-500 text-white'
        }`}>
          {profile.severity} Priority
        </div>
     </div>
     
     <div className="space-y-4 relative z-10">
        <div className="p-4 bg-off/50 rounded-2xl border border-border/40">
           <div className="text-[11px] font-black text-muted uppercase mb-2">Severity Analysis</div>
           <p className="text-[14px] font-medium leading-relaxed text-text">{profile.reason}</p>
        </div>
        
        {profile.vitals && (
           <div className="flex gap-4">
              {Object.entries(profile.vitals).map(([k, v]) => (
                <div key={k} className="flex-1 p-3 bg-white border border-border/60 rounded-xl flex flex-col items-center">
                   <span className="text-[10px] font-black text-muted uppercase">{k}</span>
                   <span className="text-[16px] font-bold text-text">{v}</span>
                </div>
              ))}
           </div>
        )}
     </div>
  </motion.div>
);

// [NEW] Comparison Metric Block
const ComparisonMetric = ({ comparison }) => (
  <div className="my-5 p-4 bg-off/40 border border-border/60 rounded-2xl grid grid-cols-3 gap-4">
     <div className="flex flex-col items-center justify-center p-3">
        <span className="text-[10px] font-black text-muted uppercase mb-1">Baseline</span>
        <span className="text-[15px] font-bold text-text">{comparison.baseline}</span>
     </div>
     <div className="flex flex-col items-center justify-center p-3 bg-white rounded-xl shadow-sm border border-border/60">
        <span className="text-[10px] font-black text-accent uppercase mb-1">Current</span>
        <span className="text-[18px] font-black text-text">{comparison.current}</span>
     </div>
     <div className="flex flex-col items-center justify-center p-3">
        <span className="text-[10px] font-black text-muted uppercase mb-1">Variance</span>
        <span className={`text-[15px] font-black ${comparison.variance.startsWith('+') ? 'text-red-500' : 'text-green-600'}`}>{comparison.variance}</span>
     </div>
  </div>
);

// [NEW] Clinical Bar Chart (for LLM directives)
const ClinicalBarChart = ({ data }) => {
  if (!data || !data.labels || !data.values) return null;
  
  const chartData = data.labels.map((label, i) => ({
    name: label,
    value: data.values[i] || 0
  }));

  return (
    <div className="my-6 p-6 bg-white border border-border/60 rounded-[28px] shadow-sm">
       <div className="flex items-center gap-2 mb-6">
          <div className="w-1.5 h-6 bg-accent rounded-full" />
          <span className="text-[11px] font-black uppercase tracking-widest text-muted">Clinical Distribution</span>
       </div>
       <div className="h-64 w-full min-h-[16rem] min-w-0">
         <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={200}>
           <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
             <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" opacity={0.5} />
             <XAxis 
               dataKey="name" 
               axisLine={false} 
               tickLine={false} 
               tick={{ fontSize: 10, fontWeight: 700, fill: '#666' }}
               dy={10}
             />
             <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#999' }} />
             <ReTooltip 
               cursor={{ fill: 'rgba(0,0,0,0.02)' }}
               content={({ active, payload }) => {
                 if (active && payload && payload.length) {
                   return (
                     <div className="bg-text text-white p-3 rounded-xl shadow-xl border border-white/10">
                       <div className="text-[10px] font-black uppercase tracking-widest opacity-50">{payload[0].payload.name}</div>
                       <div className="text-[18px] font-bold">{payload[0].value} <span className="text-[10px] opacity-60 uppercase">Records</span></div>
                     </div>
                   );
                 }
                 return null;
               }}
             />
             <Bar dataKey="value" radius={[6, 6, 0, 0]}>
               {chartData.map((entry, index) => (
                 <Cell key={`cell-${index}`} fill={index % 2 === 0 ? 'var(--color-accent)' : 'rgba(0,82,204,0.4)'} />
               ))}
             </Bar>
           </BarChart>
         </ResponsiveContainer>
       </div>
    </div>
  );
};

// [NEW] Clinical Trend Chart (001-B)
const TrendChart = ({ data, loading }) => {
  if (loading || !data || !data.labels || !data.current || !data.baseline) {
    return <PortalChartSkeleton label="Calibrating velocity" />;
  }

  const chartData = data.labels.map((label, i) => ({
    name: label,
    current: data.current[i] || 0,
    baseline: data.baseline[i] || 0
  }));

  return (
    <div className="h-64 w-full min-h-[16rem] min-w-0">
      <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={200}>
        <AreaChart data={chartData} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="colorCurrent" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="var(--color-accent)" stopOpacity={0.1}/>
              <stop offset="95%" stopColor="var(--color-accent)" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" opacity={0.5} />
          <XAxis 
            dataKey="name" 
            axisLine={false} 
            tickLine={false} 
            tick={{ fontSize: 9, fontWeight: 900, fill: '#505050' }}
            dy={10}
          />
          <YAxis hide />
          <ReTooltip 
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                return (
                  <div className="bg-text text-white p-3 rounded-xl shadow-xl border border-white/10 backdrop-blur-md">
                    <div className="text-[10px] font-black uppercase tracking-widest mb-1 opacity-50">{payload[0].payload.name}</div>
                    <div className="flex items-center gap-4">
                       <div>
                         <div className="text-[9px] font-black uppercase text-accent mb-0.5">Current</div>
                         <div className="text-[16px] font-bold">{payload[0].value} <span className="text-[10px] opacity-60">enc</span></div>
                       </div>
                       <div className="w-px h-6 bg-white/10" />
                       <div>
                         <div className="text-[9px] font-black uppercase text-muted mb-0.5">Baseline</div>
                         <div className="text-[14px] font-bold opacity-60">{payload[1].value}</div>
                       </div>
                    </div>
                  </div>
                );
              }
              return null;
            }}
          />
          <Area 
            dataKey="baseline" 
            stroke="#707070" 
            fill="transparent" 
            strokeDasharray="5 5" 
            strokeWidth={1.5}
            dot={false}
            activeDot={false}
          />
          <Area 
            type="monotone" 
            dataKey="current" 
            stroke="var(--color-accent)" 
            fillOpacity={1} 
            fill="url(#colorCurrent)" 
            strokeWidth={3}
            dot={{ r: 4, fill: 'var(--color-accent)', strokeWidth: 2, stroke: '#fff' }}
            activeDot={{ r: 6, strokeWidth: 0 }}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

// [NEW] Institutional Heatmap (001-C)
const DutyHeatmap = ({ data, loading }) => {
  if (loading || !data || !Array.isArray(data) || data.length === 0) {
    return <PortalChartSkeleton label="Mapping institutional load" />;
  }

  const days = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
  const maxVal = Math.max(...data.flat(), 1);

  return (
    <div className="flex flex-col gap-1.5">
       <div className="flex justify-between mb-2">
          <div className="flex gap-4">
             {['00', '06', '12', '18', '23'].map(h => (
               <span key={h} className="text-[9px] font-black text-muted">{h}:00</span>
             ))}
          </div>
       </div>
       {data.map((hours, dIdx) => (
         <div key={dIdx} className="flex gap-1.5 items-center">
           <span className="w-8 text-[9px] font-black text-muted tracking-tighter">{days[dIdx]}</span>
           <div className="flex-1 flex gap-1">
             {hours.map((val, hIdx) => {
               const opacity = val === 0 ? 0.05 : 0.1 + (val / maxVal) * 0.9;
               return (
                 <div 
                   key={hIdx} 
                   className="flex-1 aspect-square rounded-[3px] transition-all hover:ring-2 hover:ring-accent/20 cursor-help"
                   style={{ 
                     backgroundColor: val === 0 ? '#111111' : 'var(--color-accent)',
                     opacity: opacity
                   }}
                   title={`${days[dIdx]} ${hIdx}:00 - ${val} encounters`}
                 />
               );
             })}
           </div>
         </div>
       ))}
    </div>
  );
};


// [NEW] Actionable Intelligence Buttons
const ActionGroup = ({ actions }) => {
  if (!actions) return null;
  return (
    <div className="flex flex-wrap gap-3 my-4">
       {actions.map((action, i) => (
         <button 
           key={i}
           onClick={() => alert(`Action: ${action.type}\nPayload: ${JSON.stringify(action.payload)}`)}
           className="px-5 py-2.5 bg-accent/5 border border-accent/20 rounded-xl text-[12px] font-bold text-accent hover:bg-accent hover:text-white transition-all flex items-center gap-2 shadow-sm"
         >
           {action.label} <TrendingUp size={14} />
         </button>
       ))}
    </div>
  );
};

// [NEW] Agent Tool Steps — shows tool_start/tool_end events in real-time
const AgentToolSteps = ({ steps }) => {
  if (!steps || steps.length === 0) return null;
  return (
    <div className="flex flex-col gap-1.5 mb-3">
      {steps.map((step, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-2.5 pl-1"
        >
          {step.status === 'running' ? (
            <Loader2 size={13} className="text-accent animate-spin flex-shrink-0" />
          ) : (
            <div className="w-[13px] h-[13px] rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
              <Check size={9} className="text-green-600" />
            </div>
          )}
          <span className="text-[11px] font-black uppercase tracking-[0.12em] text-muted">
            {step.label}
          </span>
        </motion.div>
      ))}
    </div>
  );
};

// [NEW] Agent Chart — renders __chart__ JSON from the generate_chart tool
const AgentChart = ({ chartJson }) => {
  if (!chartJson || !chartJson.__chart__) return null;

  const { chart_type, title, data, xKey, yKey, colors } = chartJson;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="my-6 p-6 bg-white border border-border/60 rounded-[28px] shadow-sm"
    >
      <div className="flex items-center gap-2 mb-6">
        <div className="w-1.5 h-6 bg-accent rounded-full" />
        <span className="text-[11px] font-black uppercase tracking-widest text-muted">{title}</span>
      </div>
      <div className="h-72 w-full min-h-[18rem] min-w-0">
        <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={240}>
          {chart_type === 'bar' ? (
            <BarChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" opacity={0.5} />
              <XAxis dataKey={xKey} axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700, fill: '#666' }} dy={10} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#999' }} />
              <ReTooltip cursor={{ fill: 'rgba(0,0,0,0.02)' }} content={({ active, payload }) => active && payload?.length ? (
                <div className="bg-text text-white p-3 rounded-xl shadow-xl"><div className="text-[10px] font-black uppercase tracking-widest opacity-50">{payload[0].payload[xKey]}</div><div className="text-[18px] font-bold">{payload[0].value}</div></div>
              ) : null} />
              <Bar dataKey={yKey} radius={[6, 6, 0, 0]}>
                {data.map((_, i) => <Cell key={i} fill={colors?.[i] || '#6366f1'} />)}
              </Bar>
            </BarChart>
          ) : chart_type === 'line' ? (
            <LineChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" opacity={0.5} />
              <XAxis dataKey={xKey} axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 700, fill: '#666' }} dy={10} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#999' }} />
              <ReTooltip />
              <Line type="monotone" dataKey={yKey} stroke="#6366f1" strokeWidth={3} dot={{ r: 4, fill: '#6366f1', strokeWidth: 2, stroke: '#fff' }} />
            </LineChart>
          ) : chart_type === 'pie' ? (
            <RePieChart>
              <Pie data={data} dataKey={yKey} nameKey={xKey} cx="50%" cy="50%" outerRadius={100} label={({ name, value }) => `${name}: ${value}`}>
                {data.map((_, i) => <Cell key={i} fill={colors?.[i] || '#6366f1'} />)}
              </Pie>
              <ReTooltip />
            </RePieChart>
          ) : null}
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
};

// [NEW] Multi-step Thinking Telemetry
const ThinkingTelemetry = ({ agentSteps }) => {
  const defaultSteps = [
    "Isolating longitudinal variances...",
    "Establishing multi-node frequency baseline...",
    "Calibrating institutional duty cycles...",
    "Correlating verified ICD-10/CPT clusters...",
    "Finalizing Superhumanly reasoning model..."
  ];
  const [currentStep, setCurrentStep] = React.useState(0);

  React.useEffect(() => {
    if (agentSteps && agentSteps.length > 0) return; // Don't cycle if we have real steps
    const timer = setInterval(() => {
      setCurrentStep(prev => (prev + 1) % defaultSteps.length);
    }, 1500);
    return () => clearInterval(timer);
  }, [agentSteps]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col gap-3 py-4"
    >
       <div className="flex items-center gap-3">
          <Loader2 size={16} className="text-accent animate-spin" />
          <span className="text-[13px] font-bold text-text">Synthesizing clinical evidence...</span>
       </div>
       {agentSteps && agentSteps.length > 0 ? (
         <div className="pl-7"><AgentToolSteps steps={agentSteps} /></div>
       ) : (
         <div className="pl-7 flex flex-col gap-1.5 overflow-hidden">
            <AnimatePresence mode="wait">
               <motion.div 
                 key={currentStep}
                 initial={{ opacity: 0, y: 10 }}
                 animate={{ opacity: 1, y: 0 }}
                 exit={{ opacity: 0, y: -10 }}
                 className="text-[11px] font-black text-muted uppercase tracking-widest italic"
               >
                  {defaultSteps[currentStep]}
               </motion.div>
            </AnimatePresence>
         </div>
       )}
    </motion.div>
  );
};

// [NEW] Main Intelligence Response Resolver
const IntelligenceResponse = ({ content }) => {
  let data = null;
  let isJson = false;
  let chartJsons = [];
  
  // Detect __chart__ JSON blocks embedded in content by the agent
  const chartRegex = /\{[^{}]*"__chart__"\s*:\s*true[^{}]*\}/g;
  let cleanedContent = content;
  const chartMatches = content.match(chartRegex);
  if (chartMatches) {
    for (const match of chartMatches) {
      try {
        const parsed = JSON.parse(match);
        if (parsed.__chart__) {
          chartJsons.push(parsed);
          cleanedContent = cleanedContent.replace(match, '');
        }
      } catch (e) { /* skip */ }
    }
  }

  // Also try deeper nested chart JSON
  try {
    const deepChartRegex = /```json\s*(\{[\s\S]*?"__chart__"[\s\S]*?\})\s*```/g;
    let deepMatch;
    while ((deepMatch = deepChartRegex.exec(content)) !== null) {
      try {
        const parsed = JSON.parse(deepMatch[1]);
        if (parsed.__chart__) {
          chartJsons.push(parsed);
          cleanedContent = cleanedContent.replace(deepMatch[0], '');
        }
      } catch (e) { /* skip */ }
    }
  } catch (e) { /* skip */ }

  try {
    // Attempt to find JSON block if AI wrapped it in markdown or returned mixed content
    const jsonMatch = cleanedContent.match(/\{[\s\S]*\}/);
    const targetContent = jsonMatch ? jsonMatch[0] : cleanedContent;
    
    const parsed = JSON.parse(targetContent);
    if (parsed && (parsed.narrative || parsed.directives)) {
      data = parsed;
      isJson = true;
    }
  } catch (e) {
    // Not valid JSON, or not the schema we expect
  }

  if (!isJson) {
    return (
      <div className="w-full">
        <ReactMarkdown 
          remarkPlugins={[remarkGfm]}
          components={MarkdownComponents}
        >
          {cleanedContent}
        </ReactMarkdown>
        {chartJsons.map((cj, i) => <AgentChart key={i} chartJson={cj} />)}
      </div>
    );
  }

  return (
    <div className="w-full">
      {data.narrative && (
        <ReactMarkdown 
          remarkPlugins={[remarkGfm]}
          components={MarkdownComponents}
        >
          {data.narrative}
        </ReactMarkdown>
      )}
      
      <div className="space-y-4">
        {data.directives?.includes('TABLE') && data.data?.table && (
          <ClinicalDataTable data={data.data.table} />
        )}
        
        {data.directives?.includes('CHART') && data.data?.chart && (
          <ClinicalBarChart data={data.data.chart} />
        )}

        {data.directives?.includes('RISK_PROFILE') && data.data?.risk_profiles && Array.isArray(data.data.risk_profiles) && data.data.risk_profiles.map((p, idx) => (
          <RiskProfileCard key={idx} profile={p} />
        ))}
        
        {data.directives?.includes('COMPARISON') && data.data?.comparison && (
          <ComparisonMetric comparison={data.data.comparison} />
        )}

        {data.directives?.includes('ACTIONS') && data.data?.actions && Array.isArray(data.data.actions) && (
          <ActionGroup actions={data.data.actions} />
        )}

        {chartJsons.map((cj, i) => <AgentChart key={`agent-chart-${i}`} chartJson={cj} />)}
      </div>
      
      {!data.narrative && isJson && chartJsons.length === 0 && (
         <div className="p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 text-[12px] font-medium">
            Intelligence engine returned structured data without narrative. Directives: {data.directives?.join(', ')}
         </div>
      )}
    </div>
  );
};

const MarkdownComponents = {
  p: ({node, ...props}) => <p className="mb-4 last:mb-0" {...props} />,
  h3: ({node, ...props}) => <h3 className="text-[15px] font-bold mt-6 mb-3 text-[#111111]" {...props} />,
  h4: ({node, ...props}) => <h4 className="text-[14px] font-bold mt-5 mb-2 text-[#111111]" {...props} />,
  strong: ({node, ...props}) => <strong className="font-bold text-[#111111]" {...props} />,
  ul: ({node, ...props}) => <ul className="list-disc pl-5 mb-4 space-y-1.5" {...props} />,
  ol: ({node, ...props}) => <ol className="list-decimal pl-5 mb-4 space-y-1.5" {...props} />,
  li: ({node, ...props}) => <li className="" {...props} />,
  table: ({node, ...props}) => <div className="overflow-x-auto mb-5 border border-border/60 rounded-xl overflow-hidden"><table className="w-full text-left text-[14px]" {...props} /></div>,
  th: ({node, ...props}) => <th className="bg-off/80 px-4 py-3 font-bold border-b border-border/60 text-muted uppercase tracking-widest text-[11px]" {...props} />,
  td: ({node, ...props}) => <td className="px-4 py-3 border-b border-border/40 font-medium" {...props} />,
};

export default function IntelligenceTab() {
  const [query, setQuery] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [loadingStats, setLoadingStats] = useState(true);
  const [loadingSessions, setLoadingSessions] = useState(true);
  const [agentSteps, setAgentSteps] = useState([]);
  const [streamingContent, setStreamingContent] = useState('');
  
  // Chat Interface States
  const [chatMode, setChatMode] = useState(false);
  const [messages, setMessages] = useState([]);
  const [copiedIndex, setCopiedIndex] = useState(null);
  const [messageFeedback, setMessageFeedback] = useState({});
  const [editingIndex, setEditingIndex] = useState(null);
  const [editValue, setEditValue] = useState('');
  
  // Real Sessions
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [sessions, setSessions] = useState([]);
  const [currentSessionId, setCurrentSessionId] = useState(null);
  
  // Session Management UI States
  const [sessionMenuId, setSessionMenuId] = useState(null);
  const [renamingSessionId, setRenamingSessionId] = useState(null);
  const [renamingValue, setRenamingValue] = useState('');
  
  const [stats, setStats] = useState({
    predictive_risk: { value: '...', trend: '...', label: 'Analyzing population...' },
    clinical_velocity: { value: '...', trend: '...', label: 'Measuring efficiency...' },
    revenue_integrity: { value: '...', trend: '...', label: 'Calculating integrity...' },
    selection_bias: [
      { label: "Initializing...", value: 0, variance: "0%" },
      { label: "Initializing...", value: 0, variance: "0%" },
      { label: "Initializing...", value: 0, variance: "0%" }
    ],
    heatmap: Array(24).fill(0)
  });

  const maxHeatmapCount = Math.max(...stats.heatmap, 1);

  useEffect(() => {
    loadStats();
    loadSessions();
  }, []);

  const loadSessions = async () => {
    setLoadingSessions(true);
    try {
      const data = await fetchSessions();
      setSessions(data);
    } catch (e) {
      console.error('Failed to load sessions', e);
    } finally {
      setLoadingSessions(false);
    }
  };

  const loadStats = async () => {
    setLoadingStats(true);
    try {
      const data = await fetchIntelligenceStats();
      setStats(data);
    } catch (e) {
      console.error('Failed to load intelligence telemetry', e);
    } finally {
      setLoadingStats(false);
    }
  };

  const submitQuery = async (textToSubmit, historyTruncateIdx = null) => {
    if (!textToSubmit.trim()) return;
    
    // Switch to chat mode if not already
    if (!chatMode) {
      setChatMode(true);
      if (!isSidebarOpen) setIsSidebarOpen(true);
    }
    
    setIsThinking(true);
    setAgentSteps([]);
    setStreamingContent('');

    let updatedMessages = [...messages];
    if (historyTruncateIdx !== null) {
      updatedMessages = updatedMessages.slice(0, historyTruncateIdx);
    }
    
    const userMsg = { role: 'user', content: textToSubmit };
    updatedMessages.push(userMsg);
    setMessages(updatedMessages);

    try {
      const toolNameMap = {
        search_patients: 'Searching patients',
        get_patient_history: 'Fetching patient history',
        get_recent_encounters: 'Loading recent encounters',
        aggregate_clinical_data: 'Aggregating clinical data',
        generate_chart: 'Generating visualization',
      };

      const data = await queryIntelligence(textToSubmit, currentSessionId, (event) => {
        if (event.type === 'tool_start') {
          const label = toolNameMap[event.tool] || `Running ${event.tool}`;
          setAgentSteps(prev => [...prev, { label, status: 'running' }]);
        } else if (event.type === 'tool_end') {
          setAgentSteps(prev => prev.map((s, i) => i === prev.length - 1 ? { ...s, status: 'done' } : s));
        } else if (event.type === 'content') {
          setStreamingContent(prev => prev + event.content);
        }
      });
      
      const assistantMsg = { role: 'assistant', content: data.insight };
      setMessages(prev => [...prev.slice(0, updatedMessages.length), assistantMsg]);
      setStreamingContent('');
      setAgentSteps([]);
      
      if (!currentSessionId && data.session_id) {
         setCurrentSessionId(data.session_id);
         loadSessions();
      }
    } catch (error) {
       console.error("Intelligence Query Error:", error);
       const errorMsg = { 
         role: 'assistant', 
         content: "System Error: The Superhumanly reasoning core is currently unreachable or timed out. Please verify your connection and try again." 
       };
       setMessages(prev => [...prev, errorMsg]);
       setStreamingContent('');
       setAgentSteps([]);
    } finally {
      setIsThinking(false);
    }
  };

  const handleQuery = (e) => {
    e.preventDefault();
    const currentQuery = query;
    setQuery('');
    submitQuery(currentQuery);
  };
  
  const handleCopy = (text, idx) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleFeedback = (idx, type) => {
    setMessageFeedback(prev => ({ ...prev, [idx]: prev[idx] === type ? null : type }));
  };

  const handleRetry = (idx, role) => {
    if (role === 'user') {
      submitQuery(messages[idx].content, idx);
    } else if (role === 'assistant') {
      const targetQueryIdx = idx - 1;
      if (targetQueryIdx >= 0 && messages[targetQueryIdx]) {
         submitQuery(messages[targetQueryIdx].content, targetQueryIdx);
      }
    }
  };

  const handleEditSubmit = (idx) => {
    if (!editValue.trim()) return;
    setEditingIndex(null);
    submitQuery(editValue, idx);
  };

  const handleSessionClick = async (sessionId) => {
    setCurrentSessionId(sessionId);
    setChatMode(true);
    setMessages([]);
    try {
       const msgs = await fetchSessionMessages(sessionId);
       setMessages(msgs);
    } catch (e) {
       console.error("Failed to load session messages", e);
    }
  };

  const resetToDashboard = () => {
    setChatMode(false);
    setMessages([]);
    setQuery('');
    setCurrentSessionId(null);
    loadStats(); // Ensure dashboard has fresh telemetry
  };

  const handleRename = async (sessionId) => {
    if (!renamingValue.trim()) return;
    try {
      await renameSession(sessionId, renamingValue);
      setSessions(prev => prev.map(s => s.id === sessionId ? { ...s, title: renamingValue } : s));
      setRenamingSessionId(null);
    } catch (e) {
      console.error(e);
    }
  };

  const handleDelete = async (sessionId) => {
    try {
      await deleteSession(sessionId);
      setSessions(prev => prev.filter(s => s.id !== sessionId));
      if (currentSessionId === sessionId) {
        resetToDashboard();
      }
      setSessionMenuId(null);
    } catch (e) {
      console.error(e);
    }
  };

  return (
      <div className="h-full flex overflow-hidden bg-white">
        {/* Collapsible Sidebar */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div 
               initial={{ width: 0, opacity: 0 }}
               animate={{ width: 256, opacity: 1 }}
               exit={{ width: 0, opacity: 0 }}
               transition={{ duration: 0.3, ease: 'easeInOut' }}
               className="bg-off/30 border-r border-border/40 flex flex-col flex-shrink-0 whitespace-nowrap overflow-hidden"
            >
              <div className="p-4 border-b border-border/40 min-w-[256px]">
                <button 
                  onClick={resetToDashboard}
                  className="w-full py-2.5 px-4 bg-white border border-[#e2e2e2] hover:border-accent hover:text-accent hover:shadow-[0_2px_10px_rgba(0,102,204,0.06)] rounded-xl text-[13px] font-bold text-[#333333] transition-all flex items-center justify-center gap-2 group/new-btn"
                >
                  <Sparkles size={14} className="text-accent group-hover/new-btn:scale-110 transition-transform duration-200" /> New Analysis
                </button>
              </div>
              <div className="flex-1 overflow-y-auto py-2 min-w-[256px] custom-scrollbar">
                 <div className="portal-label my-2 px-4">Recents</div>
                 {loadingSessions ? (
                   <PortalSessionListSkeleton />
                 ) : sessions.length === 0 ? (
                   <div className="mx-3 px-4 py-6 rounded-2xl border border-dashed border-border/60 bg-white/60 text-center">
                     <MessageSquare size={20} className="mx-auto text-muted/40 mb-2" aria-hidden />
                     <p className="text-[13px] font-bold text-text2">No analyses yet</p>
                     <p className="text-[12px] text-muted/70 mt-1 leading-relaxed">
                       Run your first query from the dashboard to start a session.
                     </p>
                   </div>
                 ) : (
                 <div className="flex flex-col gap-0.5">
                    {sessions.map((session) => {
                      const isActive = session.id === currentSessionId;
                      const isMenuOpen = sessionMenuId === session.id;
                      const isRenaming = renamingSessionId === session.id;
                      
                      return (
                        <div key={session.id} className="relative group px-1">
                          {isRenaming ? (
                            <div className="px-3 py-2 flex items-center gap-2 bg-white border border-accent/20 rounded-xl shadow-sm w-full">
                               <input 
                                 autoFocus
                                 className="w-full bg-transparent text-[15px] font-medium outline-none text-text"
                                 value={renamingValue}
                                 onChange={(e) => setRenamingValue(e.target.value)}
                                 onKeyDown={(e) => {
                                   if (e.key === 'Enter') handleRename(session.id);
                                   if (e.key === 'Escape') setRenamingSessionId(null);
                                 }}
                                 onBlur={() => handleRename(session.id)}
                               />
                            </div>
                          ) : (
                            <div 
                              className={`w-full group/item px-3 py-2 rounded-xl transition-all flex items-center justify-between cursor-pointer border-l-2 ${
                                isActive 
                                  ? 'bg-accent/[0.04] text-accent border-accent font-bold pl-2.5 rounded-r-xl rounded-l-none' 
                                  : 'hover:bg-black/[0.02] text-[#4a4a4a] hover:text-[#111111] border-transparent'
                              }`}
                              onClick={() => handleSessionClick(session.id)}
                            >
                               <div className="flex flex-col flex-1 min-w-0 pr-1.5 overflow-hidden pointer-events-none">
                                  <div 
                                    className="text-[15px] font-medium whitespace-nowrap"
                                    style={{ 
                                      WebkitMaskImage: 'linear-gradient(to right, black 96%, transparent 100%)',
                                      maskImage: 'linear-gradient(to right, black 96%, transparent 100%)'
                                    }}
                                  >
                                    {session.title}
                                  </div>
                               </div>

                               <button 
                                 onClick={(e) => {
                                   e.stopPropagation();
                                   setSessionMenuId(isMenuOpen ? null : session.id);
                                 }}
                                 className={`p-1.5 rounded-md hover:bg-black/5 transition-opacity shrink-0 ${isActive || isMenuOpen ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}
                               >
                                  <MoreHorizontal size={16} className={isActive ? 'text-accent' : 'text-[#888888] hover:text-[#111111]'} />
                               </button>
                            </div>
                          )}

                          {/* Dropdown Menu */}
                          <AnimatePresence>
                            {isMenuOpen && (
                              <>
                                <div className="fixed inset-0 z-[100]" onClick={() => setSessionMenuId(null)} />
                                <motion.div 
                                  initial={{ opacity: 0, scale: 0.95, y: -10 }}
                                  animate={{ opacity: 1, scale: 1, y: 0 }}
                                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                                  className="absolute right-2 top-11 p-1 bg-white border border-border/80 rounded-xl shadow-xl z-[101] min-w-[140px]"
                                >
                                   <button 
                                     onClick={(e) => {
                                       e.stopPropagation();
                                       setRenamingSessionId(session.id);
                                       setRenamingValue(session.title);
                                       setSessionMenuId(null);
                                     }}
                                     className="w-full flex items-center gap-2.5 px-3 py-2.5 text-[13px] font-bold text-muted hover:bg-off rounded-lg transition-all"
                                   >
                                      <Pencil size={15} /> Rename
                                   </button>
                                   <button 
                                     onClick={(e) => {
                                       e.stopPropagation();
                                       handleDelete(session.id);
                                     }}
                                     className="w-full flex items-center gap-2.5 px-3 py-2.5 text-[13px] font-bold text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                   >
                                      <Trash2 size={15} /> Delete
                                   </button>
                                </motion.div>
                              </>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })}
                 </div>
                 )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col relative h-full">
           
           {/* Sidebar Toggle Button */}
           <div className="absolute top-4 left-4 z-50">
              <button 
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="p-2.5 bg-white border border-border/80 rounded-xl text-muted hover:text-text shadow-sm hover:shadow-md transition-all flex items-center justify-center backdrop-blur-md"
                title={isSidebarOpen ? "Close sidebar" : "Open sidebar"}
              >
                 {isSidebarOpen ? <PanelLeftClose size={16} /> : <PanelLeftOpen size={16} />}
              </button>
           </div>

           {/* Conditional Main Content */}
           {chatMode ? (
             <>
               {/* Messages Thread */}
               <div className="flex-1 overflow-y-auto custom-scrollbar p-6 md:p-10 pt-20">
              <div className="max-w-5xl mx-auto flex flex-col space-y-8 min-h-full">
                 {messages.length === 0 && !isThinking && (
                   <div className="flex-1 flex flex-col items-center justify-center text-center py-16 px-6">
                     <div className="w-14 h-14 rounded-2xl bg-accent/5 border border-accent/10 flex items-center justify-center mb-5">
                       <Sparkles size={24} className="text-accent" aria-hidden />
                     </div>
                     <h2 className="portal-section-title mb-2">Start this analysis</h2>
                     <p className="portal-body max-w-md text-muted/80">
                       Ask about workload variance, coding integrity, or patient cohort trends. Answers stream here with citations.
                     </p>
                   </div>
                 )}
                 <AnimatePresence initial={false}>
                   {messages.map((msg, idx) => (
                     <motion.div 
                        key={idx}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                     >
                        <div className={`relative group ${
                          msg.role === 'user' 
                            ? 'max-w-[85%] bg-[#f4f4f4] text-[#111111] px-5 py-3.5 rounded-[20px] rounded-br-sm' 
                            : 'w-full text-text py-2'
                        }`}>
                           <div className={`text-[15px] leading-relaxed ${msg.role === 'user' ? 'font-medium' : ''}`}>
                             {editingIndex === idx ? (
                               <div className="w-full flex flex-col gap-3">
                                  <textarea 
                                    className="w-full min-w-[300px] bg-white border border-border/80 rounded-xl p-3 text-[14px] text-[#111111] outline-none focus:border-accent/40 focus:ring-2 focus:ring-accent/10 resize-none"
                                    rows={3}
                                    value={editValue}
                                    onChange={(e) => setEditValue(e.target.value)}
                                    autoFocus
                                  />
                                  <div className="flex justify-end gap-2">
                                     <button onClick={() => setEditingIndex(null)} className="px-4 py-2 rounded-lg text-[12px] font-bold text-muted hover:bg-black/5 transition-all">Cancel</button>
                                     <button onClick={() => handleEditSubmit(idx)} className="px-4 py-2 rounded-lg text-[12px] font-bold bg-accent/90 text-white hover:bg-accent transition-all">Save & Submit</button>
                                  </div>
                               </div>
                             ) : msg.role === 'assistant' ? (
                               <IntelligenceResponse content={msg.content} />
                             ) : (
                               msg.content
                             )}
                           </div>

                           {/* Assistant Action Bar */}
                           {msg.role === 'assistant' && (
                             <div className="flex items-center gap-1 mt-5 text-muted">
                               <button onClick={() => handleCopy(msg.content, idx)} className="p-1.5 rounded-lg hover:bg-off hover:text-text transition-all duration-200">
                                 {copiedIndex === idx ? <Check size={16} className="text-green-600" /> : <Copy size={16} />}
                               </button>
                               <button onClick={() => handleFeedback(idx, 'like')} className={`p-1.5 rounded-lg hover:bg-off transition-all duration-200 ${messageFeedback[idx] === 'like' ? 'text-accent bg-accent/10' : 'hover:text-text'}`}><ThumbsUp size={16} /></button>
                               <button onClick={() => handleFeedback(idx, 'dislike')} className={`p-1.5 rounded-lg hover:bg-off transition-all duration-200 ${messageFeedback[idx] === 'dislike' ? 'text-red-500 bg-red-50' : 'hover:text-text'}`}><ThumbsDown size={16} /></button>
                               <button onClick={() => handleRetry(idx, 'assistant')} className="p-1.5 rounded-lg hover:bg-off hover:text-text transition-all duration-200 flex items-center gap-1.5 ml-1"><RotateCcw size={16} /><span className="text-[11px] font-bold uppercase tracking-wider">Retry</span></button>
                             </div>
                           )}

                           {/* User Action Bar (Hover only) */}
                           {msg.role === 'user' && editingIndex !== idx && (
                             <div className="absolute -bottom-7 right-0 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center gap-1 text-muted">
                               <span className="text-[10px] font-bold uppercase mr-2 opacity-60">Just Now</span>
                               <button onClick={() => handleRetry(idx, 'user')} className="p-1.5 rounded-lg hover:bg-[#e0e0e0] hover:text-text transition-all duration-200"><RotateCcw size={14} /></button>
                               <button onClick={() => { setEditingIndex(idx); setEditValue(msg.content); }} className="p-1.5 rounded-lg hover:bg-[#e0e0e0] hover:text-text transition-all duration-200"><Edit2 size={14} /></button>
                               <button onClick={() => handleCopy(msg.content, idx)} className="p-1.5 rounded-lg hover:bg-[#e0e0e0] hover:text-text transition-all duration-200">
                                 {copiedIndex === idx ? <Check size={14} className="text-green-600" /> : <Copy size={14} />}
                               </button>
                             </div>
                           )}
                        </div>
                     </motion.div>
                   ))}
                   
                   {isThinking && (
                     <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex justify-start w-full"
                     >
                        <div className="w-full text-text py-2">
                           <ThinkingTelemetry agentSteps={agentSteps} />
                        </div>
                     </motion.div>
                   )}
                 </AnimatePresence>
                 
                 {/* Explicit spacer block to push content above fixed input area */}
                 <div className="h-24 shrink-0 w-full" aria-hidden="true" />
              </div>
           </div>

           {/* Input anchored at bottom */}
           <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-white via-white to-transparent pt-12 pb-6 px-6 z-50 pointer-events-none">
              <div className="max-w-3xl mx-auto pointer-events-auto">
                 <form onSubmit={handleQuery} className="relative shadow-2xl shadow-black/[0.04] rounded-[24px]">
                    <input 
                      type="text" 
                      placeholder="Ask a follow-up question..."
                      className="w-full h-[64px] bg-white border border-border/80 rounded-[24px] pl-6 pr-32 text-[15px] font-medium text-text outline-none focus:border-accent/40 focus:ring-4 focus:ring-accent/5 transition-all"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                    />
                    <button 
                      type="submit"
                      disabled={isThinking || !query.trim()}
                      className="absolute right-2 top-2 bottom-2 px-6 bg-text text-white rounded-[18px] text-[13px] font-bold hover:bg-black transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      Send <MessageSquare size={14} />
                    </button>
                 </form>
                  <div className="text-center mt-2">
                     <span className="text-[12px] text-muted/80 font-medium">Metrics calculated via Superhumanly Thoughts™️. AI can make mistakes. Verify clinical data.</span>
                  </div>
               </div>
            </div>
          </>
        ) : (
          <div className="flex-1 h-full flex flex-col p-6 pt-16 overflow-y-auto custom-scrollbar">
            <div className="w-full pt-4">
              {/* Header & Input Section - Restricted to max-w-6xl */}
              <div className="max-w-6xl mx-auto mb-14">
                <div className="text-center mb-10">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/5 border border-accent/10 mb-6">
                    <Sparkles size={14} className="text-accent" />
                    <span className="text-[11px] font-black uppercase tracking-[0.2em] text-accent">Institutional Duty Cycle Active</span>
                  </div>
                  <h1 className="portal-display text-[48px] lg:text-[56px] tracking-tight leading-none mb-6">
                    Ask your dataset <br/>
                    <span className="italic text-accent">in plain English.</span>
                  </h1>
                  <p className="portal-body text-[17px] text-muted/70 max-w-4xl mx-auto">
                    Bimodal peak detection and selection-bias monitoring for high-velocity clinical environments.
                  </p>
                </div>

                <div className="relative">
                  <form onSubmit={handleQuery} className="relative z-10">
                    <input 
                      type="text" 
                      placeholder="e.g., 'What is the current workload variance compared to the 30-day baseline?'"
                      className="w-full h-[72px] bg-white border border-border/80 rounded-[24px] pl-16 pr-32 text-[16px] font-medium text-text outline-none shadow-xl shadow-black/[0.03] focus:border-accent/40 focus:ring-4 focus:ring-accent/5 transition-all"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                    />
                    <div className="absolute left-6 top-1/2 -translate-y-1/2 text-[#999999]">
                       <MessageSquare size={24} />
                    </div>
                    <button 
                      type="submit"
                      disabled={!query.trim()}
                      className="absolute right-2.5 top-2.5 bottom-2.5 px-8 bg-text text-white rounded-[16px] text-[14px] font-bold hover:bg-black transition-all"
                    >
                      Analyze
                    </button>
                  </form>
                </div>
              </div>

              {/* Cards Container - Wider width */}
              <div className="max-w-[1400px] mx-auto w-full">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
                    <div className="bg-white border border-border/90 p-8 rounded-[32px] shadow-sm hover:shadow-md transition-all">
                        <div className="flex items-center justify-between mb-8">
                           <div>
                              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted/40 mb-1">Performance Baseline</div>
                              <h3 className="text-[20px] font-bold text-text">Duty Cycle Velocity</h3>
                           </div>
                           <div className="flex items-center gap-2 px-3 py-1 bg-green-50 text-green-700 rounded-full text-[11px] font-black uppercase tracking-wider">
                              <TrendingUp size={14} /> +12.5% Target
                           </div>
                        </div>
                        <TrendChart data={stats.duty_cycle_velocity} loading={loadingStats} />
                        <div className="mt-6 pt-6 border-t border-border/40 flex justify-between items-center">
                           <p className="text-[12px] font-medium text-muted/60">Longitudinal variance tracking (14d rolling window)</p>
                           <button className="text-[11px] font-black text-accent uppercase tracking-widest hover:underline">View Analytics</button>
                        </div>
                    </div>

                    <div className="bg-white border border-border/90 p-8 rounded-[32px] shadow-sm hover:shadow-md transition-all">
                        <div className="flex items-center justify-between mb-8">
                           <div>
                              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted/40 mb-1">Density Mapping</div>
                              <h3 className="text-[20px] font-bold text-text">Institutional Load</h3>
                           </div>
                           <div className="flex gap-2">
                              <div className="w-8 h-8 rounded-full border border-border/60 flex items-center justify-center text-muted/40 hover:text-text cursor-pointer transition-all"><Info size={14} /></div>
                           </div>
                        </div>
                        <DutyHeatmap data={stats.temporal_heatmap} loading={loadingStats} />
                        <div className="mt-6 flex items-center justify-between">
                           <div className="flex items-center gap-4">
                              <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-[2px] bg-accent/10" /><span className="text-[9px] font-bold text-muted/40 uppercase">Idle</span></div>
                              <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-[2px] bg-accent/60" /><span className="text-[9px] font-bold text-muted/40 uppercase">Peak</span></div>
                              <div className="flex items-center gap-1.5"><div className="w-2 h-2 rounded-[2px] bg-accent" /><span className="text-[9px] font-bold text-muted/40 uppercase">Saturation</span></div>
                           </div>
                           <span className="text-[11px] font-black text-muted/30 uppercase italic">Bimodal Peak Detected</span>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
                    <InsightCard 
                      loading={loadingStats}
                      title="Predictive Risk" 
                      value={stats.predictive_risk.value}
                      label={stats.predictive_risk.label}
                      trend={stats.predictive_risk.trend}
                      description="Longitudinal variance tracking for identifying early warning signs of clinical crisis."
                      icon={Activity} 
                      color="blue"
                    />
                    <InsightCard 
                      loading={loadingStats}
                      title="Clinical Velocity" 
                      value={stats.clinical_velocity.value}
                      label={stats.clinical_velocity.label}
                      trend={stats.clinical_velocity.trend}
                      description="Real-time efficiency mapping based on average encounter duration and documentation speed."
                      icon={TrendingUp} 
                      color="teal"
                    />
                    <InsightCard 
                      loading={loadingStats}
                      title="Revenue Integrity" 
                      value={stats.revenue_integrity.value}
                      label={stats.revenue_integrity.label}
                      trend={stats.revenue_integrity.trend}
                      description="Compliance and billing accuracy score based on ICD-10/CPT coding alignment with clinical transcript."
                      icon={PieChart} 
                      color="purple"
                    />
                </div>

                <div className="bg-off/30 border border-border/60 rounded-[32px] p-8 mb-10">
                   <div className="flex items-center justify-between mb-8">
                      <div className="flex items-center gap-3">
                         <div className="w-10 h-10 rounded-2xl bg-white border border-border/80 flex items-center justify-center text-accent shadow-sm"><BarChart3 size={20} /></div>
                         <div>
                            <h3 className="text-[18px] font-bold text-text">Complexity Distribution</h3>
                            <p className="text-[12px] font-medium text-muted/60">Institutional selection-bias monitoring</p>
                         </div>
                      </div>
                   </div>
                   
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {loadingStats
                        ? Array.from({ length: 3 }).map((_, idx) => (
                            <PortalInsightCardSkeleton key={idx} />
                          ))
                        : stats.selection_bias.map((item, idx) => (
                        <div key={idx} className="bg-white p-5 rounded-2xl border border-border/40 shadow-sm relative overflow-hidden group">
                           <div className="absolute top-0 right-0 w-24 h-24 bg-accent/5 blur-3xl -mr-12 -mt-12 group-hover:bg-accent/10 transition-all" />
                           <div className="flex items-center justify-between relative z-10">
                              <span className="text-[10px] font-black uppercase tracking-widest text-muted/40">{item.label}</span>
                              <span className="text-[12px] font-black text-accent">{item.variance}</span>
                           </div>
                           <div className="mt-2 text-[24px] font-bold text-text relative z-10">{item.value} <span className="text-[12px] text-muted/40 font-medium tracking-normal">Encounters</span></div>
                           <div className="mt-4 h-1 w-full bg-off rounded-full overflow-hidden relative z-10">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: item.variance }}
                                className="h-full bg-accent"
                              />
                           </div>
                        </div>
                      ))}
                   </div>
                </div>
              </div>

              {/* Methodology Footer - Centered in max-w-6xl */}
              <div className="max-w-6xl mx-auto text-center pb-12 mt-4">
                 <div className="inline-flex flex-col items-center gap-2">
                    <p className="text-[12px] text-muted/40 font-medium">
                       All metrics calculated via <span className="text-accent/60 font-black italic">Superhumanly Thoughts™️</span> reasoning engine.
                    </p>
                    <div className="flex gap-4 mt-2">
                       <button className="text-[10px] font-black uppercase tracking-[0.2em] text-muted/40 hover:text-accent transition-colors">Methodology Paper</button>
                       <span className="text-muted/20 text-[10px]">•</span>
                       <button className="text-[10px] font-black uppercase tracking-[0.2em] text-muted/40 hover:text-accent transition-colors">System Integrity Report</button>
                       <span className="text-muted/20 text-[10px]">•</span>
                       <button className="text-[10px] font-black uppercase tracking-[0.2em] text-muted/40 hover:text-accent transition-colors">HIPAA Compliance</button>
                    </div>
                 </div>
              </div>
            </div>
            <style dangerouslySetInnerHTML={{ __html: `
              .custom-scrollbar::-webkit-scrollbar { width: 4px; }
              .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
              .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.04); border-radius: 10px; }
              .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.08); }
            `}} />
          </div>
        )}
      </div>
    </div>
  );
}
