import { motion, AnimatePresence } from 'framer-motion';
import {
  Mic,
  Square,
  Zap,
  ClipboardList,
  CheckCircle2,
} from 'lucide-react';
import {
  NeuralOrb,
  CaptureStatus,
  SignalMeter,
  ClinicalWaveform,
} from '../ui/IntakeVisuals';
import ClinicalAudioPlayer from '../ui/ClinicalAudioPlayer';

function formatDuration(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

/**
 * Phase 65 — premium Record tab: ambient shell, live stream + standard capture, responsive layout.
 */
export default function RecordCapturePanel({
  streamMode,
  onStreamModeChange,
  isLiveRecording,
  isLiveConnecting,
  isRecording,
  liveTranscript,
  onStartStreaming,
  onStopStreaming,
  onStartRecording,
  onStopRecording,
  onClearAudio,
  onReRecord,
  selectedCustomer,
  audioFile,
  recordingDuration,
}) {
  const modeIdle = !isLiveRecording && !isRecording && !audioFile;
  const liveLevel = isLiveRecording ? 88 + Math.min(12, Math.floor(liveTranscript.length / 40)) : 0;

  return (
    <motion.div
      key="record"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="h-full min-h-[380px] lg:min-h-0 w-full flex items-center justify-center p-2 sm:p-4"
      role="region"
      aria-label="Ambient encounter capture"
    >
      <div className="w-full h-full flex flex-col relative overflow-hidden justify-between rounded-[28px] border border-border/30 bg-gradient-to-b from-white via-white to-off/40 shadow-[0_8px_40px_rgba(0,0,0,0.04)]">
        {/* Ambient mesh — transform/opacity only for 120Hz */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-[28px]" aria-hidden>
          <div className="absolute -top-[40%] left-1/2 h-[80%] w-[90%] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(0,78,179,0.08),transparent_70%)]" />
          <div className="absolute bottom-0 right-0 h-40 w-40 translate-x-1/4 translate-y-1/4 rounded-full bg-accent/[0.06] blur-3xl" />
          <div
            className="absolute inset-0 opacity-[0.35]"
            style={{
              backgroundImage:
                'radial-gradient(circle at 1px 1px, rgba(0,78,179,0.06) 1px, transparent 0)',
              backgroundSize: '20px 20px',
            }}
          />
        </div>

        <div className="relative z-10 flex flex-col flex-1 p-4 sm:p-5">
          <div className="w-full flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
            <div className="flex flex-col gap-1.5 min-w-0">
              <div className="flex items-center gap-2">
                <div
                  className={`w-2.5 h-2.5 rounded-full shrink-0 ${isLiveRecording || isRecording ? 'bg-green animate-ping' : 'bg-muted/40'}`}
                />
                <span className="text-[11px] font-black uppercase tracking-widest text-text truncate">
                  {isLiveRecording
                    ? 'Ambient ingestion active'
                    : isRecording
                      ? 'Local capture active'
                      : 'Ambient encounter capture'}
                </span>
              </div>
              <div className="h-[14px]">
                <span
                  className={`text-[10px] text-accent font-bold block transition-opacity duration-300 ${isLiveConnecting ? 'opacity-100 animate-pulse' : 'opacity-0'}`}
                >
                  Connecting secure proxy tunnel…
                </span>
              </div>
            </div>

            <div
              className={`flex items-center p-1 bg-off/80 rounded-[14px] shadow-inner border border-border/20 self-start sm:self-auto transition-opacity duration-300 ${modeIdle ? 'opacity-100' : 'opacity-0 pointer-events-none absolute sm:static'}`}
              role="tablist"
              aria-label="Capture mode"
            >
              <button
                type="button"
                role="tab"
                aria-selected={streamMode === 'streaming'}
                onClick={() => onStreamModeChange('streaming')}
                className={`px-3 sm:px-4 py-1.5 rounded-[10px] text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 ${streamMode === 'streaming' ? 'bg-white text-accent shadow-sm ring-1 ring-border/30' : 'text-muted/50 hover:text-text'}`}
              >
                <Zap size={12} className={streamMode === 'streaming' ? 'fill-accent/20' : ''} />
                Live stream
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={streamMode === 'file'}
                onClick={() => onStreamModeChange('file')}
                className={`px-3 sm:px-4 py-1.5 rounded-[10px] text-[10px] sm:text-[11px] font-bold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 ${streamMode === 'file' ? 'bg-white text-accent shadow-sm ring-1 ring-border/30' : 'text-muted/50 hover:text-text'}`}
              >
                <ClipboardList size={12} />
                Standard
              </button>
            </div>
          </div>

          {streamMode === 'streaming' ? (
            <div className="w-full flex flex-col flex-1 min-h-0">
              <div className="w-full flex-1 min-h-[160px] bg-white/90 backdrop-blur-sm rounded-[24px] p-4 sm:p-6 shadow-sm border border-border/30 relative mb-4 sm:mb-6 flex flex-col">
                <div className="absolute top-4 right-4 flex items-center gap-2">
                  {isLiveRecording ? (
                    <div className="flex items-center gap-1.5 bg-red-500/10 px-2.5 py-1 rounded-full">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                      <span className="text-[10px] font-bold uppercase tracking-wider text-red-500">
                        Live
                      </span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5 bg-off px-2.5 py-1 rounded-full border border-border/40">
                      <Mic size={10} className="text-muted" />
                      <span className="text-[10px] font-bold uppercase tracking-wider text-muted">
                        Ready
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex-1 overflow-y-auto mt-8 sm:mt-6 pr-2 scrollbar-thin flex flex-col text-[15px] leading-relaxed font-medium text-text min-h-[120px]">
                  {liveTranscript ? (
                    <p>
                      {liveTranscript}
                      {isLiveRecording && (
                        <span
                          className="inline-block w-1.5 h-4 ml-1 bg-accent/80 animate-pulse rounded-full align-middle"
                          aria-hidden
                        />
                      )}
                    </p>
                  ) : (
                    <div className="flex flex-col sm:flex-row items-center justify-center h-full gap-6 py-4">
                      <NeuralOrb progress={isLiveRecording ? 72 : 18} isProcessing={isLiveRecording} />
                      <div className="text-center sm:text-left max-w-xs">
                        <p className="text-[13px] font-bold text-text mb-1">
                          {isLiveRecording ? 'Listening…' : 'Real-time clinical dictation'}
                        </p>
                        <p className="text-[12px] text-muted leading-relaxed">
                          {isLiveRecording
                            ? 'Speak clearly. Transcript streams over the secure proxy.'
                            : 'Start capture when the patient chart is open and microphone access is granted.'}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-4 mt-auto">
                <div className="flex items-center gap-4 w-full sm:w-auto justify-center sm:justify-start">
                  <CaptureStatus isActive={isLiveRecording} />
                  <SignalMeter level={liveLevel} />
                </div>

                <div className="flex items-center justify-center relative">
                  {isLiveRecording ? (
                    <div className="relative">
                      <div className="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-30" aria-hidden />
                      <motion.button
                        type="button"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={onStopStreaming}
                        aria-label="Stop live dictation"
                        className="w-16 h-16 relative z-10 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-[0_8px_24px_rgba(239,68,68,0.3)] cursor-pointer border-4 border-white"
                      >
                        <Square size={20} fill="white" />
                      </motion.button>
                    </div>
                  ) : (
                    <motion.button
                      type="button"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={onStartStreaming}
                      disabled={isLiveConnecting || !selectedCustomer}
                      aria-label="Start live dictation"
                      className="w-16 h-16 bg-accent hover:bg-accent/90 text-white rounded-full flex items-center justify-center shadow-[0_8px_24px_rgba(0,78,179,0.25)] cursor-pointer transition-all disabled:opacity-40 disabled:cursor-not-allowed border-4 border-white ring-1 ring-border/20"
                    >
                      <Mic size={24} />
                    </motion.button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="w-full flex flex-col flex-1 justify-center min-h-[280px]">
              <AnimatePresence mode="wait">
                {isRecording ? (
                  <motion.div
                    key="recording"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 1.02 }}
                    className="flex flex-col items-center w-full min-h-[280px] justify-center bg-white/90 backdrop-blur-sm rounded-[24px] shadow-sm border border-border/30 p-6 sm:p-8"
                  >
                    <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-6 mb-10 sm:mb-16">
                      <div className="flex flex-col gap-4 items-center sm:items-start">
                        <CaptureStatus isActive />
                        <SignalMeter level={92} />
                      </div>
                      <div className="flex flex-col items-center sm:items-end gap-1">
                        <span className="text-[10px] font-bold text-red-500 uppercase tracking-[0.2em] animate-pulse">
                          Live capture
                        </span>
                        <div
                          className="text-[32px] font-mono font-black text-text tracking-tight leading-none tabular-nums"
                          aria-live="polite"
                        >
                          {formatDuration(recordingDuration)}
                        </div>
                      </div>
                    </div>

                    <div className="w-full mb-10 sm:mb-12">
                      <ClinicalWaveform isActive color="accent" />
                    </div>

                    <div className="flex flex-col items-center gap-6 relative">
                      <div className="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-20" aria-hidden />
                      <motion.button
                        type="button"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={onStopRecording}
                        aria-label="Stop recording"
                        className="w-20 h-20 relative z-10 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-[0_12px_32px_rgba(239,68,68,0.3)] cursor-pointer border-4 border-white"
                      >
                        <Square size={24} fill="white" />
                      </motion.button>
                    </div>
                  </motion.div>
                ) : audioFile?.name === 'live_recording.wav' ? (
                  <motion.div
                    key="captured"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-full min-h-[280px] flex flex-col justify-center bg-white/90 backdrop-blur-sm rounded-[24px] shadow-sm border border-border/30 p-6 sm:p-8 relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none" aria-hidden>
                      <CheckCircle2 size={120} />
                    </div>
                    <div className="flex flex-col gap-6 relative z-10">
                      <div className="flex flex-col sm:flex-row items-center gap-5">
                        <div className="w-16 h-16 bg-green/10 text-green rounded-[20px] flex items-center justify-center border border-green/20 shrink-0">
                          <Mic size={28} />
                        </div>
                        <div className="text-center sm:text-left min-w-0">
                          <div className="text-[18px] font-black text-text uppercase tracking-tight">
                            Audio captured
                          </div>
                          <div className="text-[12px] font-mono font-medium text-muted mt-1 truncate max-w-[240px]">
                            {audioFile.name}
                          </div>
                        </div>
                      </div>

                      {audioFile.preview && (
                        <div className="w-full bg-off/50 rounded-2xl p-4 border border-border/20">
                          <ClinicalAudioPlayer src={audioFile.preview} />
                        </div>
                      )}

                      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-border/30">
                        <button
                          type="button"
                          onClick={onClearAudio}
                          className="w-full sm:w-auto px-4 py-2 rounded-xl text-[11px] font-bold text-muted/80 uppercase tracking-wider hover:text-red-500 hover:bg-red-500/5 transition-colors"
                        >
                          Discard file
                        </button>
                        <button
                          type="button"
                          onClick={onReRecord}
                          className="w-full sm:w-auto px-4 py-2 bg-white border border-border/20 rounded-xl text-[10px] font-black text-muted/60 uppercase tracking-wider"
                        >
                          Re-record
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="idle"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex flex-col items-center justify-center px-4 py-8 w-full min-h-[280px]"
                  >
                    <NeuralOrb progress={24} isProcessing={false} />
                    <h3 className="text-[20px] sm:text-[22px] font-black text-text mt-6 mb-2 tracking-tight text-center">
                      Standard session capture
                    </h3>
                    <p className="text-[14px] font-medium text-muted text-center leading-relaxed mb-8 max-w-sm">
                      Record locally, then submit for structured prescription synthesis.
                    </p>
                    <motion.button
                      type="button"
                      whileHover={{ scale: 1.04 }}
                      whileTap={{ scale: 0.96 }}
                      onClick={onStartRecording}
                      disabled={!selectedCustomer}
                      aria-label="Start standard recording"
                      className="w-[72px] h-[72px] bg-text text-white rounded-full flex items-center justify-center shadow-[0_20px_50px_rgba(0,0,0,0.15)] hover:bg-black cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed border-4 border-white"
                    >
                      <Mic size={26} />
                    </motion.button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
