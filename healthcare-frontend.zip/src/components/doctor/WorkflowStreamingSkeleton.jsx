import { motion } from 'framer-motion';
import { Activity, ClipboardList, Database, Sparkles, Stethoscope, User } from 'lucide-react';

export function SkeletonShimmer({ className = '' }) {
  return (
    <div
      className={`relative overflow-hidden bg-off/50 border border-border/30 ${className}`}
      aria-hidden
    >
      <motion.div
        className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/80 to-transparent"
        animate={{ x: ['-120%', '280%'] }}
        transition={{ duration: 1.6, repeat: Infinity, ease: 'linear' }}
      />
    </div>
  );
}

export function StreamingStatusStrip({ progress = 0, message = '', node = '' }) {
  const nodeLabel = node
    ? node.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
    : 'Initializing';

  return (
    <div className="mb-5 rounded-2xl border border-accent/15 bg-accent/[0.04] px-4 py-3 flex flex-col sm:flex-row sm:items-center gap-3">
      <div className="flex items-center gap-2.5 min-w-0">
        <span className="relative flex h-2.5 w-2.5 shrink-0">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent/40 opacity-75" />
          <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-accent" />
        </span>
        <span className="text-[10px] font-black uppercase tracking-[0.22em] text-accent truncate">
          Live stream · {nodeLabel}
        </span>
      </div>
      <p className="text-[12px] font-medium text-muted/70 flex-1 truncate sm:text-right">
        {message || 'Streaming clinical artifacts as each pipeline stage completes…'}
      </p>
      <div className="flex items-center gap-2 shrink-0 sm:min-w-[88px] sm:justify-end">
        <span className="text-[13px] font-black font-mono text-accent tabular-nums">{Math.round(progress)}%</span>
        <div className="w-16 h-1 rounded-full bg-border/40 overflow-hidden">
          <motion.div
            className="h-full bg-accent rounded-full"
            animate={{ width: `${Math.min(100, progress)}%` }}
            transition={{ type: 'spring', stiffness: 80, damping: 18 }}
          />
        </div>
      </div>
    </div>
  );
}

export function ClinicalNarrativeSkeleton({ active = false }) {
  return (
    <div
      className={`mb-6 rounded-2xl border p-4 transition-colors duration-500 ${
        active ? 'border-accent/25 bg-accent/[0.03]' : 'border-border/40 bg-off/20'
      }`}
      aria-busy="true"
      aria-label="Loading clinical narrative"
    >
      <div className="flex items-center gap-2 mb-4">
        <SkeletonShimmer className="h-3.5 w-3.5 rounded-md" />
        <SkeletonShimmer className="h-2.5 w-28 rounded-full" />
        <div className="h-px flex-1 bg-border/30" />
      </div>
      <div className="space-y-2.5 pl-1 border-l-2 border-border/30">
        <SkeletonShimmer className="h-4 w-[92%] rounded-md" />
        <SkeletonShimmer className="h-4 w-[78%] rounded-md" />
        <SkeletonShimmer className="h-4 w-[64%] rounded-md" />
      </div>
    </div>
  );
}

const SOAP_META = {
  Subjective: { icon: User, color: '#0052cc' },
  Objective: { icon: Activity, color: '#111111' },
  Assessment: { icon: Stethoscope, color: '#7c3aed' },
  Plan: { icon: ClipboardList, color: '#16a34a' },
};

export function SoapSectionSkeleton({ title, active = false, lines = 3 }) {
  const meta = SOAP_META[title] || SOAP_META.Subjective;
  const Icon = meta.icon;

  return (
    <div
      className={`flex flex-col gap-4 rounded-2xl border px-1 py-1 transition-all duration-500 ${
        active ? 'border-accent/20 bg-accent/[0.02]' : 'border-transparent'
      }`}
      aria-busy="true"
      aria-label={`Loading ${title}`}
    >
      <div className="flex items-center gap-4">
        <div
          className={`w-10 h-10 rounded-[14px] border flex items-center justify-center ${
            active ? 'border-accent/30 bg-accent/5 text-accent' : 'border-border/40 bg-white text-muted/30'
          }`}
          style={{ color: active ? meta.color : undefined }}
        >
          <Icon size={20} className={active ? 'animate-pulse' : ''} />
        </div>
        <SkeletonShimmer className="h-3 w-24 rounded-full" />
        {active && (
          <span className="ml-auto text-[9px] font-black uppercase tracking-[0.2em] text-accent animate-pulse">
            Extracting
          </span>
        )}
      </div>
      <div className="pl-12 space-y-2.5 relative">
        <div className="absolute left-[19px] top-0 bottom-2 w-[1.5px] bg-border/25 rounded-full" />
        {Array.from({ length: lines }).map((_, i) => (
          <SkeletonShimmer key={i} className={`h-3.5 rounded-md ${i === lines - 1 ? 'w-[55%]' : 'w-full'}`} />
        ))}
      </div>
    </div>
  );
}

export function TranscriptPreviewCard({ text }) {
  if (!text?.trim()) return null;
  const preview = text.length > 420 ? `${text.slice(0, 420)}…` : text;

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className="mt-6 rounded-2xl border border-border/50 bg-off/30 p-4"
    >
      <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted/50 mb-2">
        Source transcript (live)
      </div>
      <p className="text-[13px] leading-relaxed text-text/70 font-medium">{preview}</p>
    </motion.div>
  );
}

export function RxPanelSkeleton({ active = false }) {
  return (
    <div className="flex flex-col flex-1 min-h-0 p-1" aria-busy="true" aria-label="Loading prescription">
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-2">
          <SkeletonShimmer className="h-9 w-24 rounded-xl" />
          <SkeletonShimmer className="h-9 w-28 rounded-xl" />
        </div>
        <div className="flex gap-2">
          {[1, 2, 3].map((i) => (
            <SkeletonShimmer key={i} className="h-9 w-9 rounded-xl" />
          ))}
        </div>
      </div>
      <div
        className={`rounded-2xl border p-5 space-y-4 flex-1 ${
          active ? 'border-accent/20 bg-accent/[0.02]' : 'border-border/40 bg-white'
        }`}
      >
        <SkeletonShimmer className="h-3 w-32 rounded-full" />
        <SkeletonShimmer className="h-7 w-3/4 rounded-lg" />
        <div className="grid grid-cols-4 gap-2 pt-2 border-t border-border/30">
          {['Drug', 'Dose', 'Freq', 'Duration'].map((h) => (
            <SkeletonShimmer key={h} className="h-2.5 w-full rounded-full opacity-60" />
          ))}
        </div>
        {[0, 1, 2].map((row) => (
          <div key={row} className="grid grid-cols-4 gap-2">
            <SkeletonShimmer className="h-10 col-span-1 rounded-xl" />
            <SkeletonShimmer className="h-10 col-span-1 rounded-xl" />
            <SkeletonShimmer className="h-10 col-span-1 rounded-xl" />
            <SkeletonShimmer className="h-10 col-span-1 rounded-xl" />
          </div>
        ))}
        <div className="pt-4 space-y-2 border-t border-border/20">
          <SkeletonShimmer className="h-3 w-full rounded-md" />
          <SkeletonShimmer className="h-3 w-[85%] rounded-md" />
        </div>
      </div>
    </div>
  );
}

export function BillingPanelSkeleton({ active = false }) {
  return (
    <div className="flex flex-col flex-1 p-1" aria-busy="true" aria-label="Loading billing codes">
      <div className="flex items-center gap-2 mb-5">
        <Database size={18} className={active ? 'text-accent animate-pulse' : 'text-muted/30'} />
        <SkeletonShimmer className="h-3 w-36 rounded-full" />
      </div>
      <div className="space-y-3">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className={`flex items-center gap-3 p-4 rounded-2xl border ${
              active && i === 0 ? 'border-accent/20 bg-accent/[0.03]' : 'border-border/40 bg-off/20'
            }`}
          >
            <SkeletonShimmer className="h-10 w-16 rounded-lg shrink-0" />
            <div className="flex-1 space-y-2">
              <SkeletonShimmer className="h-3 w-[70%] rounded-md" />
              <SkeletonShimmer className="h-2.5 w-full rounded-md" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function PartialDiagnosisChip({ diagnosis }) {
  if (!diagnosis) return null;
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      className="mb-4 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/10 border border-accent/20"
    >
      <Sparkles size={12} className="text-accent" />
      <span className="text-[11px] font-black uppercase tracking-wider text-accent">Primary dx</span>
      <span className="text-[12px] font-bold text-text">{diagnosis}</span>
    </motion.div>
  );
}

export function StreamingRightPane({ partial, streamNode, progress }) {
  const hasRx = Boolean(partial?.rx_text || partial?.diagnosis);
  const hasBilling = Boolean(partial?.billing_codes?.length);
  const rxActive = ['intelligence', 'validation', 'formatting'].includes(streamNode) && !hasRx;
  const billingActive = streamNode === 'intelligence' && !hasBilling;

  return (
    <div className="flex flex-col flex-1 min-h-0">
      <div className="flex flex-col gap-2 mb-6 shrink-0">
        <div className="text-[10px] font-black text-accent tracking-[0.3em] uppercase">
          Phase · Artifact assembly
        </div>
        <h3 className="text-[22px] font-black text-text tracking-tight">Rx &amp; Billing Ledger</h3>
      </div>

      <PartialDiagnosisChip diagnosis={partial?.diagnosis} />

      {hasRx ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-2xl border border-border/50 bg-off/20 p-4 mb-4"
        >
          <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted/50 mb-2">Rx preview</div>
          <pre className="text-[12px] font-mono text-text/80 whitespace-pre-wrap leading-relaxed max-h-40 overflow-y-auto custom-scrollbar">
            {partial.rx_text || `Diagnosis: ${partial.diagnosis}`}
          </pre>
        </motion.div>
      ) : (
        <RxPanelSkeleton active={rxActive} />
      )}

      <div className="mt-6 pt-6 border-t border-border/30 flex-1 min-h-0">
        {hasBilling ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2">
            <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted/50 mb-3">
              Codes detected
            </div>
            {partial.billing_codes.slice(0, 4).map((code, idx) => (
              <div
                key={idx}
                className="flex items-center gap-3 p-3 rounded-xl border border-border/40 bg-white text-[12px]"
              >
                <span className="font-mono font-black text-accent">
                  {code.code || code.icd10 || '—'}
                </span>
                <span className="text-muted/70 truncate">{code.description || code.justification || ''}</span>
              </div>
            ))}
          </motion.div>
        ) : (
          <BillingPanelSkeleton active={billingActive} />
        )}
      </div>

      <div className="mt-auto pt-4">
        <StreamingStatusStrip progress={progress} node={streamNode} message="Rx and billing populate after clinical intelligence." />
      </div>
    </div>
  );
}
