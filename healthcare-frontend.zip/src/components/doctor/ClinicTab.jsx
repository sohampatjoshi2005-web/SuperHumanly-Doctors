import { useState, useEffect } from 'react';
import { Users, UserPlus, Shield, Activity, TrendingUp, CheckCircle, Clock, AlertCircle, Search, Mail, Key, FileDown, Stethoscope, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import { fetchClinicMembers, addClinicDoctor, fetchClinicStats, downloadClinicReport } from '../../lib/doctorApi';

export default function ClinicTab() {
  const [members, setMembers] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({ username: '', email: '', password: '', full_name: '' });
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [membersData, statsData] = await Promise.all([
        fetchClinicMembers(),
        fetchClinicStats()
      ]);
      setMembers(membersData);
      setStats(statsData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      setIsExporting(true);
      setError(null);
      await downloadClinicReport();
    } catch (err) {
      setError('Export failed. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleAddDoctor = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    try {
      await addClinicDoctor(formData);
      setSuccess('Doctor onboarded successfully!');
      setFormData({ username: '', email: '', password: '', full_name: '' });
      setShowAddModal(false);
      loadData();
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-accent border-t-transparent rounded-full animate-spin"></div>
          <p className="text-muted font-bold animate-pulse">Syncing Clinic Registry...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col overflow-y-auto custom-scrollbar bg-white">
      <div className="w-full mx-auto p-12">
        {/* ═══ INSTITUTIONAL HEADER ═══ */}
        <div className="flex justify-between items-start mb-16 border-b border-border/10">
          <div>
             <div className="flex items-center gap-3 mb-3 text-[11px] font-black uppercase tracking-[0.3em] text-accent">
                <Shield size={14} />
                Clinical Governance Node
             </div>
             <h1 className="font-serif text-[56px] tracking-tighter text-text leading-none">
               Clinic <span className="italic text-accent">Management</span>
             </h1>
             <p className="text-muted font-medium mt-6 text-[16px] max-w-xl">
               Administrative oversight for <span className="text-text font-bold">{stats?.clinic_name || 'Autonomous Clinical Institution'}</span>. Unified registry and performance intelligence.
             </p>
          </div>
          
          <div className="flex flex-col items-end gap-8">
            {/* Ultra-Compact Metric Status Bar */}
            <div className="flex items-center gap-8 px-6 py-3 bg-off/50 border border-border/10 rounded-2xl">
               <div className="flex items-center gap-3">
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted">Staff</span>
                  <span className="text-[18px] font-black text-text">{stats?.team_size || 0}</span>
               </div>
               <div className="w-px h-4 bg-border/20" />
               <div className="flex items-center gap-3">
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted">Encounters</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-[18px] font-black text-text">{stats?.total_encounters || 0}</span>
                    <span className="text-[9px] font-bold text-green-600">↑</span>
                  </div>
               </div>
               <div className="w-px h-4 bg-border/20" />
               <div className="flex items-center gap-3">
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted">Registry</span>
                  <span className="text-[18px] font-black text-text">{stats?.total_patients || 0}</span>
               </div>
            </div>

            <div className="flex items-center gap-4">
              <button 
                onClick={handleExport}
                disabled={isExporting}
                className="group flex items-center gap-3 px-8 py-4 bg-off hover:bg-white text-text rounded-2xl font-bold border border-border/40 transition-all hover:shadow-xl hover:shadow-black/5 active:scale-[0.98]"
              >
                {isExporting ? <div className="w-4 h-4 border-2 border-text border-t-transparent rounded-full animate-spin" /> : <FileDown size={18} className="text-accent group-hover:scale-110 transition-transform" />}
                <span>{isExporting ? 'Exporting...' : 'Export Audit'}</span>
              </button>
              
              <button 
                onClick={() => setShowAddModal(true)}
                className="group flex items-center gap-3 px-8 py-4 bg-text text-white rounded-2xl font-bold shadow-2xl shadow-text/20 hover:bg-accent transition-all active:scale-[0.98]"
              >
                <UserPlus size={18} className="group-hover:scale-110 transition-transform" />
                <span>Onboard Physician</span>
              </button>
            </div>
          </div>
        </div>

        {/* ═══ ANALYTICS GRID ═══ */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
          {/* Clinical Focus */}
          <div className="space-y-8">
            <div className="flex items-center justify-between border-b border-border/10">
               <h3 className="text-[12px] font-black uppercase tracking-[0.3em] text-muted flex items-center gap-3">
                 <Stethoscope size={16} className="text-accent" />
                 Institutional Focus
               </h3>
               <span className="text-[10px] font-black text-accent uppercase tracking-widest bg-accent/5 px-3 py-1 rounded-full">Top Diagnoses</span>
            </div>
            
            <div className="space-y-6">
              {stats?.top_diagnoses?.length > 0 ? (
                stats.top_diagnoses.map((diag, idx) => (
                  <div key={idx} className="group">
                    <div className="flex justify-between items-end mb-2 px-1">
                      <span className="text-[14px] font-bold text-text group-hover:text-accent transition-colors">{diag.name}</span>
                      <span className="text-[11px] font-black text-text2 uppercase">{diag.count} Cases</span>
                    </div>
                    <div className="h-2 w-full bg-off rounded-full overflow-hidden border border-border/10">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(diag.count / stats.total_encounters) * 100}%` }}
                        transition={{ duration: 1, ease: "circOut", delay: idx * 0.1 }}
                        className="h-full bg-text rounded-full"
                      />
                    </div>
                  </div>
                ))
              ) : (
                <div className="py-10 border-2 border-dashed border-border/20 rounded-[32px] text-center">
                   <Activity size={32} className="text-muted/20 mx-auto mb-3" />
                   <p className="text-[11px] font-black text-muted uppercase tracking-widest">Awaiting Aggregate Data</p>
                </div>
              )}
            </div>
          </div>

          {/* Efficiency Ledger */}
          <div className="space-y-8">
            <div className="flex items-center justify-between border-b border-border/10">
               <h3 className="text-[12px] font-black uppercase tracking-[0.3em] text-muted flex items-center gap-3">
                 <TrendingUp size={16} className="text-accent" />
                 Physician Velocity
               </h3>
               <span className="text-[10px] font-black text-accent uppercase tracking-widest bg-accent/5 px-3 py-1 rounded-full">Live Performance</span>
            </div>
            
            <div className="grid grid-cols-1 gap-3">
               {stats?.staff_performance?.map((staff, idx) => (
                  <div key={idx} className="group flex items-center justify-between p-4 bg-off/20 hover:bg-off transition-all rounded-2xl border border-border/10">
                     <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-white border border-border/20 flex items-center justify-center text-accent font-black text-xs group-hover:bg-accent group-hover:text-white transition-all">
                          {staff.name[0]}
                        </div>
                        <span className="text-[15px] font-bold text-text">{staff.name}</span>
                     </div>
                     <div className="text-right">
                        <span className="text-[18px] font-black text-text block leading-none">{staff.encounters}</span>
                        <span className="text-[9px] font-bold text-muted uppercase tracking-widest">Encounters</span>
                     </div>
                  </div>
               ))}
            </div>
          </div>
        </div>

        {/* ═══ PHYSICIAN REGISTRY ═══ */}
        <div className="space-y-10 pb-20">
           <div className="flex items-center justify-between">
              <div>
                <h2 className="text-[28px] font-serif tracking-tight text-text">
                  Physician <span className="italic text-accent">Registry</span>
                </h2>
                <p className="text-[13px] font-medium text-muted mt-1">Validated institutional identity nodes across all clinics</p>
              </div>
              
              <div className="flex items-center gap-4">
                 <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={16} />
                    <input 
                      type="text" 
                      placeholder="Search registry..." 
                      className="h-12 pl-12 pr-6 bg-off/50 border border-border/20 focus:border-accent/40 rounded-2xl text-sm font-bold text-text outline-none w-80 transition-all" 
                    />
                 </div>
                 <div className="h-12 px-5 bg-off rounded-2xl flex items-center gap-3 border border-border/20">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    <span className="text-[11px] font-black uppercase tracking-widest text-text2">Registry Online</span>
                 </div>
              </div>
           </div>

           <div className="border border-border/30 rounded-[40px] overflow-hidden bg-white shadow-2xl shadow-black/5">
             <table className="w-full text-left border-collapse">
               <thead>
                 <tr className="bg-off/30">
                   <th className="px-10 py-6 text-[11px] font-black uppercase tracking-[0.25em] text-muted border-b border-border/10">Provider Node</th>
                   <th className="px-10 py-6 text-[11px] font-black uppercase tracking-[0.25em] text-muted border-b border-border/10">Access Level</th>
                   <th className="px-10 py-6 text-[11px] font-black uppercase tracking-[0.25em] text-muted border-b border-border/10 text-center">Status</th>
                   <th className="px-10 py-6 text-[11px] font-black uppercase tracking-[0.25em] text-muted border-b border-border/10 text-right">Settings</th>
                 </tr>
               </thead>
               <tbody>
                 {members.map((member, idx) => (
                   <tr key={member.id} className="group hover:bg-off/20 transition-all">
                     <td className="px-10 py-6 border-b border-border/10">
                       <div className="flex items-center gap-5">
                          <div className="w-12 h-12 rounded-2xl bg-text flex items-center justify-center text-white font-black text-sm group-hover:scale-110 transition-transform shadow-lg shadow-text/10">
                            {member.full_name?.split(' ').map(n=>n[0]).join('') || member.username[0].toUpperCase()}
                          </div>
                          <div>
                            <p className="font-black text-[16px] text-text tracking-tight group-hover:text-accent transition-colors">{member.full_name || member.username}</p>
                            <p className="text-[12px] text-muted font-bold lowercase tracking-tight">{member.email}</p>
                          </div>
                       </div>
                     </td>
                     <td className="px-10 py-6 border-b border-border/10">
                       <span className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border ${
                         member.role === 'clinic_admin' ? 'bg-purple-50 text-purple-600 border-purple-100' : 'bg-accent/5 text-accent border-accent/10'
                       }`}>
                         {member.role.replace('_', ' ')}
                       </span>
                     </td>
                     <td className="px-10 py-6 border-b border-border/10">
                        <div className="flex items-center justify-center gap-2 text-[10px] font-black text-green-600 uppercase tracking-widest">
                          <div className="w-1.5 h-1.5 rounded-full bg-green-500" /> Active
                        </div>
                     </td>
                     <td className="px-10 py-6 border-b border-border/10 text-right">
                       <button className="p-3 text-muted hover:text-accent hover:bg-white rounded-xl transition-all">
                         <Settings size={20} />
                       </button>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[2000] flex items-center justify-center p-6">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] w-full max-w-[500px] overflow-hidden shadow-2xl border border-border"
          >
            <div className="p-10">
              <div className="flex justify-between items-start mb-8">
                <div className="w-14 h-14 rounded-2xl bg-accent/5 flex items-center justify-center text-accent">
                  <UserPlus size={28} />
                </div>
                <button onClick={() => setShowAddModal(false)} className="p-2 text-muted hover:text-text transition-transform hover:rotate-90">
                  <Clock className="rotate-45" size={24} />
                </button>
              </div>

              <h2 className="font-serif text-[32px] tracking-tight text-text mb-2">Onboard <span className="italic text-accent">New Physician</span></h2>
              <p className="text-muted font-medium mb-8">Assign credentials and provision access to the clinic registry.</p>

              <form onSubmit={handleAddDoctor} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-muted ml-1">Full Professional Name</label>
                  <div className="relative">
                    <Users className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                    <input 
                      type="text" required placeholder="Dr. Jane Smith"
                      value={formData.full_name} onChange={e => setFormData({...formData, full_name: e.target.value})}
                      className="w-full h-14 pl-12 pr-4 bg-off border-none rounded-2xl text-text font-bold placeholder:text-muted/20 outline-none focus:ring-2 ring-accent/20 transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2">
                    <label className="text-[11px] font-black uppercase tracking-widest text-muted ml-1">Username</label>
                    <div className="relative">
                      <Activity className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                      <input 
                        type="text" required placeholder="jsmith"
                        value={formData.username} onChange={e => setFormData({...formData, username: e.target.value})}
                        className="w-full h-14 pl-12 pr-4 bg-off border-none rounded-2xl text-text font-bold placeholder:text-muted/40 outline-none focus:ring-2 ring-accent/20 transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[11px] font-black uppercase tracking-widest text-muted ml-1">Temporary PW</label>
                    <div className="relative">
                      <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                      <input 
                        type="password" required placeholder="••••••••"
                        value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})}
                        className="w-full h-14 pl-12 pr-4 bg-off border-none rounded-2xl text-text font-bold placeholder:text-muted/40 outline-none focus:ring-2 ring-accent/20 transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-muted ml-1">Professional Email</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                    <input 
                      type="email" required placeholder="jane.smith@hospital.org"
                      value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})}
                      className="w-full h-14 pl-12 pr-4 bg-off border-none rounded-2xl text-text font-bold placeholder:text-muted/20 outline-none focus:ring-2 ring-accent/20 transition-all"
                    />
                  </div>
                </div>

                {error && (
                  <div className="p-4 bg-red-50 rounded-2xl border border-red-100 flex items-center gap-3 text-red-600 text-sm font-bold">
                    <AlertCircle size={18} /> {error}
                  </div>
                )}

                <button 
                  type="submit"
                  className="w-full h-16 bg-text text-white rounded-full font-black text-lg shadow-xl shadow-text/10 hover:bg-accent transition-all active:scale-[0.98] mt-6"
                >
                  Confirm Onboarding
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
