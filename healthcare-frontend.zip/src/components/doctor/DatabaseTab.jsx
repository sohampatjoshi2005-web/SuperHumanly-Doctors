import { useState, useEffect, useMemo } from 'react';
import { Database, User, Calendar, Activity, Search, Filter, ArrowRight, Clock, ChevronDown, CheckCircle2, History, Trash2, ExternalLink, Mic, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { fetchCustomers, fetchEncounters } from '../../lib/doctorApi';

export default function DatabaseTab({ setActiveTab, setSelectedCustomer }) {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedCustomerId, setExpandedCustomerId] = useState(null);
  const [encounters, setEncounters] = useState({});
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState('all'); // 'all', 'recent', 'active'

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    setLoading(true);
    try {
      const data = await fetchCustomers();
      setCustomers(data);
    } catch (e) {
      console.error(e);
      setCustomers([]);
    } finally {
      setLoading(false);
    }
  };

  const mockCustomers = [
    { id: 'TUT-001', name: 'Alexander Thompson (Test)', created_at: new Date().toISOString() },
    { id: 'TUT-002', name: 'Elena Rodriguez (Test)', created_at: new Date().toISOString() },
    { id: 'TUT-003', name: 'Marcus Chen (Test)', created_at: new Date().toISOString() }
  ];

  const displayedCustomers = window.superhumanly_mock_active === 'database' ? mockCustomers : customers;
  const isMockActive = window.superhumanly_mock_active === 'database';

  const toggleCustomer = async (id) => {
    if (expandedCustomerId === id) {
      setExpandedCustomerId(null);
      return;
    }
    setExpandedCustomerId(id);
    if (!encounters[id] && !isMockActive) {
      try {
        const data = await fetchEncounters(id);
        setEncounters(prev => ({ ...prev, [id]: data }));
      } catch (e) {
        console.error(e);
      }
    }
  };

  const handleStartEncounter = (customer) => {
    setSelectedCustomer(customer);
    setActiveTab('workflow');
  };

  const filteredCustomers = useMemo(() => {
    let result = displayedCustomers;
    
    // Apply Filter
    if (filter === 'recent') {
      const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
      result = result.filter(c => new Date(c.created_at).getTime() > sevenDaysAgo);
    } else if (filter === 'active') {
      // Filter for customers that have at least one encounter
      result = result.filter(c => encounters[c.id]?.length > 0 || isMockActive);
    }

    // Apply Search
    return result.filter(c => 
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.id.toString().includes(searchQuery)
    );
  }, [displayedCustomers, searchQuery, filter, encounters, isMockActive]);

  const stats = useMemo(() => ({
    total: displayedCustomers.length,
    recent: displayedCustomers.filter(c => Date.now() - new Date(c.created_at).getTime() < 7 * 24 * 60 * 60 * 1000).length,
  }), [displayedCustomers]);

  if (loading && !isMockActive) {
    return (
      <div className="flex-1 p-10 flex items-center justify-center bg-white">
        <div className="typing-dot"><span></span><span></span><span></span></div>
      </div>
    );
  }

  return (
    <div className="flex-1 h-full flex flex-col bg-white overflow-hidden font-sans">
      
      {/* Studio Header: Precise & Minimal */}
      <div id="tutorial-database-header" className="px-8 pt-6 pb-8 shrink-0 border-b border-border/60">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div>
            <h1 className="text-[28px] lg:text-[34px] font-black text-text tracking-tight flex items-baseline gap-2">
              Customer Directory <span className="text-muted font-medium">/</span> <span className="text-muted text-[20px] font-semibold">Encounters</span>
            </h1>
          </div>

          <div className="flex items-center gap-10">
            <div className="flex flex-col items-end">
              <span className="text-[11px] font-bold text-muted uppercase tracking-widest leading-none mb-1.5">Total Identity Registry</span>
              <span className="text-[24px] font-black text-text leading-none">{stats.total} <span className="text-[14px] text-muted font-bold ml-1">Patients</span></span>
            </div>
            <div className="h-10 w-px bg-border/60" />
            <div className="flex flex-col items-end">
              <span className="text-[11px] font-bold text-accent uppercase tracking-widest leading-none mb-1.5">Intake Seven Days</span>
              <span className="text-[24px] font-black text-accent leading-none">+{stats.recent} <span className="text-[14px] text-accent font-bold ml-1">New</span></span>
            </div>
          </div>
        </div>

        {/* Integrated High-Contrast Command Bar */}
        <div className="mt-12 flex items-center gap-4">
          <div className="relative flex-1 group max-w-[700px]">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
            <input 
              type="text" 
              placeholder="Search registry identities by name, ID, or clinical identifier..." 
              className="w-full bg-off/80 border border-border/80 rounded-full pl-12 pr-4 py-3.5 text-[15px] font-bold text-text outline-none focus:border-accent/60 focus:bg-white transition-all placeholder:text-muted placeholder:font-medium shadow-sm"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            {[
              { id: 'all', label: 'All Records', icon: Database },
              { id: 'recent', label: 'Recently Registered', icon: Clock },
              { id: 'active', label: 'Active Documentation', icon: Activity }
            ].map(f => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={`h-[52px] px-6 rounded-full border text-[14px] font-black transition-all flex items-center gap-2 ${
                  filter === f.id 
                    ? 'bg-text text-white border-text shadow-md' 
                    : 'bg-white border-border text-muted hover:bg-off hover:text-text'
                }`}
              >
                <f.icon size={16} className={filter === f.id ? 'text-white' : 'text-accent'} />
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Registry Table Header */}
      <div className="bg-off/30 border-b border-border/60 shrink-0 px-6">
        <div className="flex items-center py-3 text-md font-black text-muted/90">
          <div className="w-[80px] shrink-0"># Index</div>
          <div className="flex-[2.5] min-w-0">Patient Identity</div>
          <div className="hidden lg:block flex-1 ml-12">Registration Date</div>
          <div className="hidden lg:block flex-1 ml-12">Encounters</div>
          <div className="flex-1 text-right">Registry Operations</div>
        </div>
      </div>

      {/* Registry Data Rows */}
      <div className="flex-1 overflow-y-auto custom-scrollbar-minimal">
        <div className="mx-auto pb-20">
          <AnimatePresence mode="popLayout">
            <div className="flex flex-col">
              {filteredCustomers.length === 0 ? (
                <div className="py-24 text-center">
                  <span className="text-[16px] font-bold text-muted italic">No historical identities found in active registry.</span>
                </div>
              ) : (
                filteredCustomers.map((c, idx) => (
                  <motion.div 
                    key={c.id} 
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={`group/row transition-all border-b border-border/40 px-6 ${
                      expandedCustomerId === c.id ? 'bg-[#f8faff]' : 'hover:bg-off/50'
                    }`}
                  >
                    <div className="flex items-center py-4 relative w-full">
                      {/* Selection Indicator */}
                      <div className={`absolute -left-12 top-0 bottom-0 w-1.5 transition-all duration-300 ${
                        expandedCustomerId === c.id ? 'bg-accent' : 'bg-transparent'
                      }`} />

                      <div className="w-[80px] shrink-0 text-[13px] font-black text-muted group-hover/row:text-text transition-colors">
                        {String(idx + 1).padStart(3, '0')}
                      </div>

                      <div 
                        className="flex-[2.5] flex items-center gap-4 cursor-pointer min-w-0"
                        onClick={() => toggleCustomer(c.id)}
                      >
                         <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-all shrink-0 ${
                            expandedCustomerId === c.id ? 'bg-accent text-white shadow-sm' : 'bg-bg text-muted group-hover/row:bg-accent/10 group-hover/row:text-accent'
                         }`}>
                            <User size={18} />
                         </div>
                          <div className="flex flex-col min-w-0">
                             <h3 className="text-[16px] font-bold text-text truncate">{c.name}</h3>
                             <div className="flex items-center gap-2 mt-0.5">
                                <span className={`text-[9px] font-black uppercase tracking-tighter px-1.5 py-0.5 rounded ${
                                   idx % 3 === 0 ? 'bg-[#f0fdf4] text-[#15803d]' :
                                   idx % 3 === 1 ? 'bg-[#f0f9ff] text-[#0369a1]' :
                                   'bg-[#fef2f2] text-[#991b1b]'
                                }`}>
                                   {idx % 3 === 0 ? 'Stable' : idx % 3 === 1 ? 'Pending Review' : 'Critical Follow-up'}
                                </span>
                             </div>
                          </div>
                      </div>

                      <div className="hidden lg:flex items-center flex-1 ml-12 text-[14px] font-semibold text-muted/90 tracking-tight whitespace-nowrap">
                        <Calendar size={18} className="text-accent mr-2" /> {new Date(c.created_at).toLocaleDateString(undefined, { dateStyle: 'medium' })}
                      </div>

                      <div className="hidden lg:flex items-center flex-1 ml-12 text-[14px] font-semibold text-muted/90 tracking-tight whitespace-nowrap">
                        <Activity size={18} className="text-accent mr-2" /> {encounters[c.id]?.length || 0} Professional Records
                      </div>

                       <div className="flex-1 flex items-center justify-end gap-2 lg:gap-3">
                          {/* QUICK CONTINUITY ACTIONS */}
                          <div className="flex items-center gap-1 opacity-0 group-hover/row:opacity-100 transition-all">
                             <button 
                                onClick={(e) => { e.stopPropagation(); handleStartEncounter(c); }}
                                className="w-8 h-8 rounded-full bg-off text-muted hover:bg-accent hover:text-white transition-all flex items-center justify-center shadow-sm"
                                title="Init Audio Session"
                             >
                                <Mic size={14} />
                             </button>
                             <button 
                                onClick={(e) => { e.stopPropagation(); handleStartEncounter(c); }}
                                className="w-8 h-8 rounded-full bg-off text-muted hover:bg-accent hover:text-white transition-all flex items-center justify-center shadow-sm"
                                title="Quick Documentation"
                             >
                                <FileText size={14} />
                             </button>
                          </div>
                          <button 
                             className="h-[36px] px-5 bg-text text-white rounded-full text-[13px] font-black hover:bg-black transition-all active:scale-95 flex items-center gap-2 shadow-sm"
                             onClick={(e) => { e.stopPropagation(); handleStartEncounter(c); }}
                          >
                             Encounter <ArrowRight size={16} />
                          </button>
                         <button 
                           onClick={() => toggleCustomer(c.id)}
                           className={`h-[36px] w-[36px] rounded-full transition-all flex items-center justify-center border ${expandedCustomerId === c.id ? 'bg-text text-white border-text' : 'text-muted border-transparent hover:bg-off hover:text-text hover:border-border'}`}
                         >
                           <ChevronDown size={20} className={`transition-transform duration-300 ${expandedCustomerId === c.id ? 'rotate-180' : ''}`} />
                         </button>
                      </div>
                    </div>

                    <AnimatePresence>
                      {expandedCustomerId === c.id && (
                        <motion.div 
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="border-t border-border/10 overflow-hidden"
                        >
                          <div className="p-4 bg-[#fffdff] rounded-2xl mb-4">
                             <div className="flex items-center gap-3 mb-6">
                                <span className="text-[11px] font-black text-accent uppercase tracking-widest">Encounter Timeline</span>
                                <div className="flex-1 h-[1px] bg-accent/10" />
                             </div>

                             {!encounters[c.id] ? (
                                <div className="py-8 flex justify-start">
                                  <div className="typing-dot"><span></span><span></span><span></span></div>
                                </div>
                             ) : encounters[c.id].length === 0 ? (
                                <div className="py-4 text-[12px] font-bold text-muted italic">No documentation history.</div>
                             ) : (
                                <div className="flex flex-col gap-6 relative">
                                   <div className="absolute left-[7px] top-2 bottom-2 w-[1px] bg-border/40" />
                                   {encounters[c.id].map((enc, eIdx) => (
                                      <div key={enc.id} className="relative pl-8 group/item">
                                         <div className="absolute left-0 top-1.5 w-[15px] h-[15px] rounded-full bg-white border border-border/80 group-hover/item:border-accent transition-colors z-10" />
                                         
                                         <div className="flex flex-col gap-4">
                                            <div className="flex items-center gap-4">
                                               <span className="text-[13px] font-black text-text">{new Date(enc.created_at).toLocaleDateString(undefined, { dateStyle: 'medium' })}</span>
                                               <span className="text-[11px] font-bold text-muted">{new Date(enc.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                               <div className="px-2 py-0.5 bg-green/5 text-green rounded text-[9px] font-black border border-green/10 uppercase tracking-tighter">Verified</div>
                                            </div>

                                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-6 border-b border-border/10">
                                               <div>
                                                  <div className="text-[10px] font-black text-muted uppercase tracking-tight mb-2">Clinical AI</div>
                                                  <p className="text-[13px] font-medium text-text2 leading-relaxed">{enc.patient_summary}</p>
                                               </div>
                                               <div className="lg:pl-6 lg:border-l border-border/10">
                                                  <div className="text-[10px] font-black text-muted uppercase tracking-tight mb-2">Documentation</div>
                                                  <p className="text-[13px] font-bold text-text2 leading-relaxed whitespace-pre-wrap">{enc.rx_summary}</p>
                                               </div>
                                            </div>
                                         </div>
                                      </div>
                                   ))}
                                </div>
                             )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                ))
              )}
            </div>
          </AnimatePresence>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar-minimal::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar-minimal::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar-minimal::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.05); border-radius: 10px; }
        .custom-scrollbar-minimal::-webkit-scrollbar-thumb:hover { background: rgba(0,0,0,0.1); }
      `}} />
    </div>
  );
}
