import { motion } from 'framer-motion';
import { Activity } from 'lucide-react';

export default function PageLoader() {
  return (
    <main
      id="main-content"
      role="status"
      aria-live="polite"
      aria-busy="true"
      aria-label="Loading application"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-white"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col items-center"
      >
        <div className="relative mb-6" aria-hidden="true">
          <div className="w-20 h-20 rounded-full border-4 border-accent/10 flex items-center justify-center">
            <Activity className="text-accent" size={40} />
          </div>
          <motion.div
            className="absolute inset-0 rounded-full border-4 border-transparent border-t-accent"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
        </div>
        <h1 className="font-serif text-2xl text-text tracking-tight m-0">
          Initializing <span className="italic text-accent2">Clinical Context…</span>
        </h1>
        <p className="mt-4 text-[10px] font-black uppercase tracking-[0.3em] text-text2/80 m-0">
          Sovereignty Kernel v4.2
        </p>
      </motion.div>
    </main>
  );
}
