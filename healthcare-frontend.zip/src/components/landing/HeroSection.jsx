import { motion } from 'framer-motion';
import { User, Activity, ClipboardList, Database, ArrowRight, Play } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function HeroSection() {
  return (
    <section className="px-5 sm:px-6 lg:px-12 pt-[104px] sm:pt-[120px] lg:pt-[140px] pb-10 sm:pb-16 text-center relative overflow-hidden bg-white">
      {/* Subtle background decoration */}
      <div className="absolute top-0 right-1/4 w-[200px] sm:w-[300px] h-[200px] sm:h-[300px] bg-accent/3 rounded-full blur-[80px] -z-10"></div>
      <div className="absolute bottom-0 left-0 w-[250px] h-[250px] bg-accent/[0.02] rounded-full blur-[100px] -z-10"></div>
      
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="inline-flex items-center gap-[7px] border border-border/80 rounded-full px-3 sm:px-[12px] py-[5px] text-[9px] sm:text-[10px] font-black uppercase tracking-[0.12em] sm:tracking-widest text-text2 mb-6 sm:mb-8 bg-white shadow-[0_2px_8px_rgba(0,0,0,0.04)]"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-green/80 animate-pulse"></span> Clinical AI v2.0 Platform
      </motion.div>

      <motion.h1
        initial={{ opacity: 1, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.05 }}
        className="font-serif text-[44px] sm:text-[42px] md:text-[52px] lg:text-[72px] font-normal leading-[1.08] sm:leading-[1.05] tracking-[-0.02em] text-text mb-4 sm:mb-[24px]"
      >
        Clinical documentation for <br />
        <em className="italic text-accent font-medium">elite medicine.</em>
      </motion.h1>

      <motion.p 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="text-[15.5px] sm:text-[17px] lg:text-[19px] text-text2 font-medium max-w-[480px] sm:max-w-[580px] mx-auto mb-7 sm:mb-10 leading-[1.6]"
      >
        Built for licensed clinicians and physicians who demand accuracy, data sovereignty, and clinical velocity.
      </motion.p>

      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="flex flex-row gap-3 sm:gap-4 justify-center items-center mb-10 sm:mb-[80px] max-w-[420px] sm:max-w-none mx-auto"
      >
        <Link 
          to="/auth"
          className="flex-1 sm:flex-none px-6 sm:px-8 py-3.5 sm:py-4 bg-text text-white rounded-full text-[14px] sm:text-[16px] font-bold hover:bg-black transition-all shadow-[0_4px_20px_rgba(0,0,0,0.15)] active:scale-95 flex items-center justify-center gap-2 group no-underline whitespace-nowrap"
        >
          Enter Portal <ArrowRight size={16} className="group-hover:translate-x-0.5 transition-transform" />
        </Link>
        <Link 
          to="/request-trial"
          className="flex-1 sm:flex-none px-5 sm:px-7 py-3.5 sm:py-3.5 border border-black/15 rounded-full text-[14px] sm:text-[15px] font-bold cursor-pointer font-sans text-text bg-white transition-all hover:border-text hover:text-text active:scale-95 flex items-center justify-center gap-2 no-underline whitespace-nowrap shadow-[0_2px_8px_rgba(0,0,0,0.04)]"
        >
          Request Trial
        </Link>
      </motion.div>

      {/* High-Fidelity Dashboard Preview */}
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.4 }}
        className="bg-gradient-to-b from-white to-[#fafbfc] border border-border/50 rounded-[20px] sm:rounded-[32px] p-4 sm:p-6 lg:p-10 max-w-[960px] mx-auto shadow-[0_8px_30px_rgba(0,0,0,0.06),0_1px_3px_rgba(0,0,0,0.04)] sm:shadow-[0_24px_80px_rgba(0,0,0,0.06)] relative text-left overflow-hidden"
      >
        {/* Subtle inner glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[80%] h-[1px] bg-gradient-to-r from-transparent via-accent/20 to-transparent"></div>

        {/* Tab Pills */}
        <div className="flex gap-1.5 sm:gap-2 mb-4 sm:mb-8 overflow-x-auto pb-1 no-scrollbar">
          <div className="px-3 sm:px-4 py-1.5 rounded-full text-[10px] sm:text-[11px] font-bold transition-all border border-text text-text shadow-sm bg-white shrink-0 whitespace-nowrap">Clinical Assistant</div>
          <div className="px-3 sm:px-4 py-1.5 rounded-full text-[10px] sm:text-[11px] font-bold transition-all border border-transparent text-muted shrink-0 whitespace-nowrap">Documentation Engine</div>
          <div className="px-3 sm:px-4 py-1.5 rounded-full text-[10px] sm:text-[11px] font-bold transition-all border border-transparent text-muted shrink-0 whitespace-nowrap">Registry Hub</div>
        </div>

        {/* Chat Conversation */}
        <div className="flex flex-col gap-3.5 sm:gap-6">
          {/* User message */}
          <div className="flex items-start gap-2 sm:gap-3 flex-row-reverse">
            <div className="w-7 h-7 sm:w-[32px] sm:h-[32px] rounded-[10px] flex items-center justify-center text-xs shrink-0 bg-off border border-border/40 shadow-sm">
              <User size={13} className="text-text" />
            </div>
            <div className="px-3.5 sm:px-5 py-2.5 sm:py-3 text-[12.5px] sm:text-[14px] leading-[1.55] sm:leading-relaxed bg-text/[0.06] text-text font-medium rounded-[16px] rounded-tr-[4px] sm:rounded-2xl sm:rounded-tr-none max-w-[calc(100%-44px)] sm:max-w-[85%]">
              Dr. Sarah: Requesting protocol adjustment for RX-7722. Patient reports edema on Amlodipine 10mg. 
            </div>
          </div>

          {/* AI response */}
          <div className="flex items-start gap-2 sm:gap-3">
            <div className="w-7 h-7 sm:w-[32px] sm:h-[32px] rounded-[10px] flex items-center justify-center shrink-0 bg-accent text-white font-black text-[9px] sm:text-[10px] shadow-[0_2px_8px_rgba(0,82,204,0.3)]">S</div>
            <div className="px-3.5 sm:px-5 py-2.5 sm:py-3 text-[12.5px] sm:text-[14px] leading-[1.55] sm:leading-relaxed bg-white border border-border/50 rounded-[16px] rounded-tl-[4px] sm:rounded-2xl sm:rounded-tl-none text-text max-w-[calc(100%-44px)] sm:max-w-[85%] shadow-[0_2px_8px_rgba(0,0,0,0.03)]">
              <div className="flex items-center gap-1.5 text-accent font-black text-[8px] sm:text-[9px] uppercase tracking-[0.12em] sm:tracking-widest mb-2 sm:mb-3">
                 <Activity size={10} className="opacity-70" />
                 Clinical Signal Identified
              </div>
              Adjustment Recommendation: Reduce Amlodipine to 5mg. Introduce 25mg Losartan daily. Follow-up BP screening in 14 days. Clinical integrity verified.
            </div>
          </div>
        </div>

        {/* Dense Metrics Grid */}
        <div className="grid grid-cols-3 gap-2 sm:gap-4 mt-5 sm:mt-10 lg:mt-12 bg-off/60 p-3 sm:p-6 rounded-[14px] sm:rounded-[24px] border border-border/40">
          {[
            { value: '98.4%', label: 'Accuracy Factor', sub: 'Medical transcription pipeline active' },
            { value: 'Sub-2s', label: 'Latency Node', sub: 'Triage priority v1' },
            { value: 'Sovereign', label: 'Security Tier', sub: 'Zero-knowledge' }
          ].map((metric, i) => (
            <div key={i} className="text-left">
              <div className="font-serif text-[17px] sm:text-[24px] tracking-tight text-text">{metric.value}</div>
              <div className="text-[7.5px] sm:text-[10px] font-bold text-text2 uppercase tracking-[0.1em] sm:tracking-widest mt-0.5 sm:mt-1 mb-0.5 sm:mb-1 leading-tight">{metric.label}</div>
              <div className="text-[9px] sm:text-[11px] text-accent font-bold hidden sm:block">{metric.sub}</div>
              {/* Mobile accent dot indicator */}
              <div className="flex items-center gap-1 mt-1 sm:hidden">
                <div className="w-1 h-1 rounded-full bg-accent"></div>
                <span className="text-[7px] font-black text-accent uppercase tracking-wider">Active</span>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
