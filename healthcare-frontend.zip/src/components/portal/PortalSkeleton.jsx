/** Shared loading placeholders for portal surfaces (Intelligence, Workflow). */

export function PortalSkeletonBar({ className = '' }) {
  return <div className={`rounded-lg bg-border/50 animate-pulse ${className}`} aria-hidden />;
}

export function PortalInsightCardSkeleton() {
  return (
    <div
      className="bg-white border border-border/90 p-5 rounded-2xl h-full shadow-sm"
      aria-busy="true"
      aria-label="Loading insight"
    >
      <PortalSkeletonBar className="h-2.5 w-24 mb-4" />
      <PortalSkeletonBar className="h-8 w-32 mb-6" />
      <PortalSkeletonBar className="h-2 w-20" />
    </div>
  );
}

export function PortalSessionListSkeleton({ rows = 4 }) {
  return (
    <div className="flex flex-col gap-2 px-3" aria-busy="true" aria-label="Loading sessions">
      {Array.from({ length: rows }).map((_, i) => (
        <PortalSkeletonBar key={i} className="h-10 w-full rounded-xl" />
      ))}
    </div>
  );
}

export function PortalChartSkeleton({ label = 'Loading chart' }) {
  return (
    <div
      className="h-48 flex flex-col items-center justify-center gap-3 bg-off/30 rounded-2xl border border-border/40"
      aria-busy="true"
      aria-label={label}
    >
      <div className="w-full max-w-xs space-y-2 px-6">
        <PortalSkeletonBar className="h-2 w-full" />
        <PortalSkeletonBar className="h-2 w-[80%]" />
        <PortalSkeletonBar className="h-24 w-full rounded-xl mt-2" />
      </div>
      <span className="portal-label text-muted/60 normal-case tracking-normal font-bold text-[11px]">
        {label}
      </span>
    </div>
  );
}
