import { useLocation } from 'react-router-dom';
import { SeoHead } from '../seo/SeoHead.jsx';
import { JsonLd } from '../seo/JsonLd.jsx';
import { SeoReadyMarker } from '../seo/SeoReadyMarker.jsx';
import { resolvePageSeo } from '../seo/seoConfig.js';
import { resolvePageJsonLd } from '../seo/jsonLdConfig.js';

/**
 * Backward-compatible SEO wrapper — SeoHead + unified @graph JSON-LD.
 * Pass `faqs` on FAQ page; `schema` prop is deprecated (ignored when graph resolves).
 */
export default function SEO({
  title,
  description,
  type,
  schema: _legacySchema,
  canonical,
  robots,
  faqs,
}) {
  const { pathname } = useLocation();
  const seo = resolvePageSeo({
    pathname,
    overrides: {
      title,
      description,
      ogType: type,
      canonical,
      robots,
    },
  });

  const graph = resolvePageJsonLd({
    pathname,
    faqs,
    pageTitle: title,
    pageDescription: description,
  });

  return (
    <>
      <SeoHead seo={seo} />
      <JsonLd graph={graph} />
      <SeoReadyMarker readyKey={`${pathname}:${seo.title}`} />
    </>
  );
}
