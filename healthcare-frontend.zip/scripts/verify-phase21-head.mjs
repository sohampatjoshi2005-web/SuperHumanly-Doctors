/**
 * Phase 21 — head meta smoke checks (static + optional live).
 */
import { readFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { resolvePageSeo } from '../src/seo/seoConfig.js';
import { setSiteOrigin } from '../src/seo/siteUrl.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');

setSiteOrigin(process.env.VITE_SITE_URL || 'https://superhumanlymedical.io');

let failed = 0;
function pass(msg) {
  console.log(`✅ ${msg}`);
}
function fail(msg) {
  console.log(`❌ ${msg}`);
  failed += 1;
}

const indexHtml = readFileSync(resolve(repoRoot, 'index.html'), 'utf8');
if (indexHtml.includes('rel="canonical"')) {
  fail('index.html should not contain shell canonical');
} else {
  pass('index.html has no duplicate canonical');
}
if (indexHtml.includes('og:image')) {
  fail('index.html should not contain shell og:image');
} else {
  pass('index.html has no duplicate og:image');
}

const pricing = resolvePageSeo({ pathname: '/pricing' });
if (!pricing.ogImage.startsWith('https://')) {
  fail('pricing og:image must be absolute');
} else {
  pass('absolute og:image on /pricing');
}
if (!pricing.canonical.startsWith('https://')) {
  fail('pricing canonical must be absolute');
} else {
  pass('absolute canonical on /pricing');
}

const portal = resolvePageSeo({ pathname: '/portal' });
if (portal.robots !== 'noindex,nofollow') {
  fail('portal must be noindex');
} else {
  pass('portal noindex');
}

if (!existsSync(resolve(repoRoot, 'src/seo/SeoHead.jsx'))) {
  fail('SeoHead.jsx missing');
} else {
  pass('SeoHead.jsx exists');
}

process.exit(failed ? 1 : 0);
