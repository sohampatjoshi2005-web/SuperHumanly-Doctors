/**
 * Phase 23 — documentation deep links & crawlable nav.
 */
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { listAllDocSectionPaths } from '../src/data/docRoutes.js';
import { listDocumentationSectionPaths } from '../src/seo/routes.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');

let failed = 0;
function pass(msg) {
  console.log(`✅ ${msg}`);
}
function fail(msg) {
  console.log(`❌ ${msg}`);
  failed += 1;
}

const docPaths = listAllDocSectionPaths();
const registryPaths = listDocumentationSectionPaths();

if (docPaths.length < 20) {
  fail(`expected 20+ doc paths, got ${docPaths.length}`);
} else {
  pass(`${docPaths.length} documentation section URLs registered`);
}

if (JSON.stringify(docPaths.sort()) !== JSON.stringify(registryPaths.sort())) {
  fail('docRoutes paths must match routes registry');
} else {
  pass('docRoutes ↔ routes registry parity');
}

const docPage = readFileSync(resolve(repoRoot, 'src/pages/DocumentationPage.jsx'), 'utf8');
if (!docPage.includes('<Link') || docPage.includes('onClick={() => handleSubcategoryClick')) {
  fail('sidebar must use Link hrefs, not button-only navigation');
} else {
  pass('documentation sidebar uses crawlable Link elements');
}

if (!docPage.includes('<main') || !docPage.includes('<article') || !docPage.includes('<nav ')) {
  fail('documentation page must use semantic landmarks');
} else {
  pass('semantic main/nav/article landmarks present');
}

if (!docPage.includes('DocTrustMeta')) {
  fail('medical documentation must include trust meta footer');
} else {
  pass('YMYL trust meta component wired');
}

const app = readFileSync(resolve(repoRoot, 'src/App.jsx'), 'utf8');
if (!app.includes('/documentation/:categorySlug/:sectionSlug')) {
  fail('App.jsx missing documentation deep-link route');
} else {
  pass('deep-link route registered in App.jsx');
}

process.exit(failed ? 1 : 0);
