/**
 * Dev-only SEO API stub when healthcare-backend Phase 66 is not running.
 * NOT for production.
 */
import http from 'node:http';
import { listPublicPathsForSitemap } from '../src/seo/routes.js';
import { absoluteUrl, setSiteOrigin } from '../src/seo/siteUrl.js';

const port = Number(process.env.SEO_MOCK_PORT || 8799);
const origin = (process.env.VITE_SITE_URL || 'http://localhost:5173').replace(/\/+$/, '');
setSiteOrigin(origin);

function buildSitemapXml() {
  const paths = listPublicPathsForSitemap();
  const urls = paths
    .map(
      (path) =>
        `  <url><loc>${absoluteUrl(path)}</loc><lastmod>2026-05-23</lastmod></url>`,
    )
    .join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}

function buildRobotsTxt() {
  return [
    'User-agent: *',
    'Allow: /',
    '',
    'Disallow: /auth',
    'Disallow: /admin',
    'Disallow: /portal',
    'Disallow: /doctor-support',
    '',
    `Sitemap: ${origin}/sitemap.xml`,
    '',
  ].join('\n');
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${port}`);

  if (url.pathname === '/sitemap.xml') {
    res.writeHead(200, {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, max-age=3600',
    });
    res.end(buildSitemapXml());
    return;
  }

  if (url.pathname === '/robots.txt') {
    res.writeHead(200, {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'public, max-age=3600',
    });
    res.end(buildRobotsTxt());
    return;
  }

  if (url.pathname === '/v1/seo/prerender-paths') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ paths: listPublicPathsForSitemap() }));
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

server.listen(port, () => {
  console.log(`[seo-dev-mock] listening on http://127.0.0.1:${port} (origin ${origin})`);
});
