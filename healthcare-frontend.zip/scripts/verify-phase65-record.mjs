/**
 * v3.2 Phase 65 — Record tab UI refinement smoke checks.
 */
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
let failed = 0;
const pass = (m) => console.log(`✅ ${m}`);
const fail = (m) => {
  console.log(`❌ ${m}`);
  failed += 1;
};

const panel = readFileSync(resolve(root, 'src/components/doctor/RecordCapturePanel.jsx'), 'utf8');
const workflow = readFileSync(resolve(root, 'src/components/doctor/WorkflowTab.jsx'), 'utf8');

if (!workflow.includes('RecordCapturePanel')) fail('WorkflowTab must use RecordCapturePanel');
else pass('WorkflowTab delegates to RecordCapturePanel');

if (!panel.includes('NeuralOrb')) fail('Record panel missing NeuralOrb ambient visual');
else pass('NeuralOrb ambient visual');

if (!panel.includes('aria-label="Ambient encounter capture"')) fail('missing region aria-label');
else pass('accessibility region label');

if (!panel.includes('radial-gradient')) fail('missing ambient gradient shell');
else pass('ambient gradient shell');

if (!panel.includes('Live stream')) fail('missing stream mode toggle');
else pass('live stream / standard modes');

process.exit(failed ? 1 : 0);
