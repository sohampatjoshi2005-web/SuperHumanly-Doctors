/**
 * MEAS-03 — frontend registry ≡ backend prerender-paths ≡ sitemap locs.
 */
import { readFileSync } from 'node:fs';
import { existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { listPublicPathsForSitemap } from '../src/seo/routes.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');
const distDir = resolve(repoRoot, 'dist');
const API_BASE = (process.env.PRERENDER_API_URL || 'http://localhost:8000').replace(/\/$/, '');
const BACKEND_MANIFEST = resolve(
  repoRoot,
  '../healthcare-backend/app/data/seo/doc_manifest.json',
);

let failed = 0;
function pass(msg) {
  console.log(`✅ ${msg}`);
}
function fail(msg) {
  console.log(`❌ ${msg}`);
  failed += 1;
}

const STATIC = [
  '/',
  '/pricing',
  '/about',
  '/documentation',
  '/faq',
  '/contact',
  '/privacy',
  '/terms',
  '/request-trial',
];

function loadBackendPaths() {
  const manifest = JSON.parse(readFileSync(BACKEND_MANIFEST, 'utf8'));
  return [...new Set([...STATIC, ...(manifest.documentation_paths || [])])].sort();
}

async function fetchApiPaths() {
  const res = await fetch(`${API_BASE}/v1/seo/prerender-paths`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  return data.paths.sort();
}

function parseSitemapPaths(xml) {
  const locs = [...xml.matchAll(/<loc>([^<]+)<\/loc>/g)].map((m) => {
    try {
      return new URL(m[1]).pathname.replace(/\/$/, '') || '/';
    } catch {
      return m[1];
    }
  });
  return [...new Set(locs)].sort();
}

function assertEqual(label, a, b) {
  if (JSON.stringify(a) === JSON.stringify(b)) {
    pass(`${label} (${a.length} paths)`);
    return true;
  }
  const onlyA = a.filter((p) => !b.includes(p));
  const onlyB = b.filter((p) => !a.includes(p));
  fail(`${label}: mismatch (+${onlyA.length} / -${onlyB.length})`);
  if (onlyA.length) console.log('  only in A:', onlyA.slice(0, 5).join(', '), onlyA.length > 5 ? '…' : '');
  if (onlyB.length) console.log('  only in B:', onlyB.slice(0, 5).join(', '), onlyB.length > 5 ? '…' : '');
  return false;
}

async function main() {
  const frontend = listPublicPathsForSitemap().sort();
  const manifest = loadBackendPaths();

  assertEqual('frontend ↔ backend manifest', frontend, manifest);

  try {
    const api = await fetchApiPaths();
    assertEqual('frontend ↔ API prerender-paths', frontend, api);
  } catch (err) {
    console.warn(`⚠️  API prerender-paths skipped (${err.message})`);
  }

  const sitemapFile = resolve(distDir, 'sitemap.xml');
  if (existsSync(sitemapFile)) {
    const xml = readFileSync(sitemapFile, 'utf8');
    assertEqual('frontend ↔ dist/sitemap.xml', frontend, parseSitemapPaths(xml));
  } else {
    try {
      const res = await fetch(`${API_BASE}/sitemap.xml`);
      if (res.ok) {
        const xml = await res.text();
        assertEqual('frontend ↔ live sitemap.xml', frontend, parseSitemapPaths(xml));
      }
    } catch {
      console.warn('⚠️  sitemap.xml check skipped (no dist file, API down)');
    }
  }

  process.exit(failed ? 1 : 0);
}

main();
