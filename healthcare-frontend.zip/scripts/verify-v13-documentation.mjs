/**
 * v1.3 Documentation Center — smoke checks against shipped implementation.
 */
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, '..');

let failed = 0;
function pass(msg) {
  console.log(`✅ ${msg}`);
}
function fail(msg) {
  console.log(`❌ ${msg}`);
  failed += 1;
}

const read = (rel) => readFileSync(resolve(root, rel), 'utf8');

const docPage = read('src/pages/DocumentationPage.jsx');
const docData = read('src/data/docCategories.js');
const faqPage = read('src/pages/FAQPage.jsx');

if (!/<Link[\s\S]*docSectionPath|to=\{docSectionPath/.test(docPage) && !/<Link[^>]+to=\{href\}/.test(docPage)) {
  if (!/<Link[^>]+to=\{href\}/.test(docPage)) fail('Documentation sidebar must use Link hrefs');
} else {
  pass('crawlable sidebar links');
}

if (!docData.includes('AcousticFlowDiagram') || !docPage.includes('AcousticFlowDiagram')) {
  fail('missing AcousticFlowDiagram (phase 14)');
} else {
  pass('acoustic flow diagram wired');
}

if (!docData.includes('ComplianceTable') || !read('src/components/docs/ComplianceTable.jsx')) {
  fail('missing ComplianceTable (phase 17)');
} else {
  pass('compliance table present');
}

if (!docData.includes("type: 'critical'") || !docPage.includes("case 'critical'")) {
  fail('missing critical safety alert (phase 18)');
} else {
  pass('critical clinical safety alert');
}

if (!faqPage.includes('accordion') && !faqPage.includes('faqs.map')) {
  fail('FAQ page missing interactive Q&A');
} else {
  pass('FAQ console present');
}

if (docData.includes('doctors') && docData.includes('admins')) {
  pass('doctor and admin guide sections');
} else {
  fail('missing clinical/admin doc categories');
}

process.exit(failed ? 1 : 0);
