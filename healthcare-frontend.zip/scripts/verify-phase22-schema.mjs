/**
 * Phase 22 — JSON-LD @graph smoke checks.
 */
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { resolvePageJsonLd } from '../src/seo/jsonLdConfig.js';
import { setSiteOrigin } from '../src/seo/siteUrl.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');

setSiteOrigin(process.env.VITE_SITE_URL || 'https://superhumanlymedical.io');

let failed = 0;
function pass(msg) {
  console.log(`✅ ${msg}`);
}
function fail(msg) {
  console.log(`❌ ${msg}`);
  failed += 1;
}

const jsonLdSrc = readFileSync(resolve(repoRoot, 'src/seo/JsonLd.jsx'), 'utf8');
if (!jsonLdSrc.includes('@graph')) {
  fail('JsonLd.jsx must emit @graph');
} else {
  pass('JsonLd.jsx uses @graph');
}

const home = resolvePageJsonLd({ pathname: '/' });
const payload = { '@context': 'https://schema.org', '@graph': home };
const serialized = JSON.stringify(payload);
if ((serialized.match(/"@context"/g) || []).length !== 1) {
  fail('single @context at root only');
} else {
  pass('single @context in serialized graph');
}

if (!home.some((n) => n['@type'] === 'Organization')) {
  fail('home missing Organization');
} else {
  pass('home has Organization');
}

const pricing = resolvePageJsonLd({ pathname: '/pricing' });
if (!pricing.some((n) => n['@type'] === 'SoftwareApplication')) {
  fail('pricing missing SoftwareApplication');
} else {
  pass('pricing has SoftwareApplication');
}

const portal = resolvePageJsonLd({ pathname: '/portal' });
if (portal.length !== 0) {
  fail('portal must have empty graph');
} else {
  pass('portal has no JSON-LD');
}

const legacy = readFileSync(resolve(repoRoot, 'src/lib/StructuredData.js'), 'utf8');
if (legacy.includes('"@context": "https://schema.org"') && legacy.includes('export {')) {
  pass('StructuredData.js re-exports from jsonLdConfig');
}

process.exit(failed ? 1 : 0);
