/**
 * MEAS-02 — assert baked SEO in dist/ for all indexable paths (post-prerender).
 */
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { listPublicPathsForSitemap } from '../src/seo/routes.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');
const distDir = resolve(repoRoot, 'dist');

let failed = 0;
function pass(msg) {
  console.log(`✅ ${msg}`);
}
function fail(msg) {
  console.log(`❌ ${msg}`);
  failed += 1;
}

function distFileForPath(routePath) {
  if (routePath === '/') return resolve(distDir, 'index.html');
  return resolve(distDir, routePath.replace(/^\/+/, ''), 'index.html');
}

function countCanonicals(html) {
  const matches = html.match(/<link[^>]+rel=["']canonical["']/gi);
  return matches?.length ?? 0;
}

function assertBakedSeo(html, path) {
  const canonicalCount = countCanonicals(html);
  if (canonicalCount !== 1) {
    fail(`${path}: expected 1 canonical, found ${canonicalCount}`);
    return false;
  }

  const title = html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim();
  if (!title || title.length < 4) {
    fail(`${path}: missing title`);
    return false;
  }

  const desc =
    html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i) ||
    html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']description["']/i);
  if (!desc?.[1]?.trim()) {
    fail(`${path}: missing meta description`);
    return false;
  }

  if (html.includes('Initializing Clinical Context')) {
    fail(`${path}: PageLoader shell in baked HTML`);
    return false;
  }

  const isPrivate = path.startsWith('/portal') || path.startsWith('/auth') || path.startsWith('/admin');
  if (!isPrivate && !html.includes('application/ld+json') && !path.startsWith('/contact')) {
    fail(`${path}: missing JSON-LD`);
    return false;
  }

  if (path.startsWith('/documentation/') && !/<h1[^>]*>/i.test(html)) {
    fail(`${path}: documentation missing h1`);
    return false;
  }

  return true;
}

async function main() {
  if (!existsSync(distDir)) {
    fail('dist/ missing — run npm run build:prerender');
    process.exit(1);
  }

  const paths = listPublicPathsForSitemap();
  let checked = 0;
  let missing = 0;

  for (const path of paths) {
    const file = distFileForPath(path);
    if (!existsSync(file)) {
      missing += 1;
      fail(`${path}: missing ${file.replace(`${repoRoot}/`, '')}`);
      continue;
    }
    const html = await readFile(file, 'utf8');
    if (assertBakedSeo(html, path)) {
      checked += 1;
    }
  }

  if (missing === 0 && checked === paths.length) {
    pass(`baked SEO verified for ${checked} prerendered routes`);
  }

  process.exit(failed ? 1 : 0);
}

main();
