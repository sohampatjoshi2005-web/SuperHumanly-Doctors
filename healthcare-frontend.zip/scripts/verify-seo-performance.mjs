/**
 * PERF-01–04 — static performance SEO checks (source + optional Lighthouse).
 */
import { readFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');

let failed = 0;
function pass(msg) {
  console.log(`✅ ${msg}`);
}
function fail(msg) {
  console.log(`❌ ${msg}`);
  failed += 1;
}

const read = (rel) => readFileSync(resolve(repoRoot, rel), 'utf8');

const hero = read('src/components/landing/HeroSection.jsx');
const css = read('src/index.css');
const main = read('src/main.jsx');
const indexHtml = read('index.html');

const h1Block = hero.match(/<motion\.h1[\s\S]*?<\/motion\.h1>/)?.[0] ?? '';
if (/opacity:\s*0/.test(h1Block)) {
  fail('Hero h1 must not use opacity:0 on first paint (LCP)');
} else {
  pass('Hero h1 avoids opacity-zero LCP pattern');
}

if (!/display=swap/.test(css)) {
  fail('index.css Google Fonts import must include display=swap');
} else {
  pass('fonts use font-display: swap');
}

if (!/initWebVitalsReporting/.test(main)) {
  fail('main.jsx must call initWebVitalsReporting');
} else {
  pass('web-vitals reporting wired in main.jsx');
}

if (!/preconnect/.test(indexHtml) || !/fonts\.googleapis/.test(indexHtml)) {
  fail('index.html should preconnect to Google Fonts');
} else {
  pass('font preconnect hints in index.html');
}

const about = read('src/pages/AboutPage.jsx');
const imgTags = about.match(/<img[^>]*>/g) || [];
for (const tag of imgTags) {
  if (!/loading=/.test(tag)) {
    fail('AboutPage images should declare loading= attribute');
    break;
  }
}
if (imgTags.length && !failed) {
  pass('below-fold About images declare loading strategy');
}

if (process.env.RUN_LIGHTHOUSE === '1') {
  console.log('\n[lighthouse] RUN_LIGHTHOUSE=1 — run: npm run lighthouse:ci');
} else {
  console.log('\nℹ️  Optional lab budgets: RUN_LIGHTHOUSE=1 npm run lighthouse:ci');
  console.log('   Thresholds (p75): LCP ≤2500ms, INP ≤200ms, CLS ≤0.1');
}

process.exit(failed ? 1 : 0);
