#!/usr/bin/env node
/**
 * Phase 27 — Interactive API Reference Hub verification.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let failed = 0;

function ok(msg) {
  console.log(`  ✓ ${msg}`);
}
function fail(msg) {
  console.error(`  ✗ ${msg}`);
  failed += 1;
}

function read(rel) {
  return fs.readFileSync(path.join(root, rel), 'utf8');
}

console.log('Phase 27 — API Reference Hub\n');

const requiredFiles = [
  'src/data/apiReference.js',
  'src/components/docs/ApiSnippetPanel.jsx',
  'src/components/docs/ApiReferenceHub.jsx',
];

for (const f of requiredFiles) {
  if (fs.existsSync(path.join(root, f))) ok(`exists ${f}`);
  else fail(`missing ${f}`);
}

const apiRef = read('src/data/apiReference.js');
for (const fn of ['buildApiSnippet', 'getEndpointById', 'listApiEndpointGroups']) {
  if (apiRef.includes(`export function ${fn}`)) ok(`exports ${fn}`);
  else fail(`missing export ${fn}`);
}

for (const id of ['auth', 'transcribe', 'generate-rx', 'get-rx']) {
  if (apiRef.includes(`id: '${id}'`)) ok(`endpoint catalog includes ${id}`);
  else fail(`endpoint catalog missing ${id}`);
}

for (const lang of ['curl', 'fetch', 'python']) {
  const snippet = await import(path.join(root, 'src/data/apiReference.js')).then((m) =>
    m.buildApiSnippet(lang, 'transcribe'),
  );
  if (snippet && snippet.length > 20) ok(`snippet ${lang} for transcribe`);
  else fail(`empty snippet ${lang}`);
}

const panel = read('src/components/docs/ApiSnippetPanel.jsx');
if (panel.includes('API_SNIPPET_LANGUAGES') && panel.includes('clipboard')) {
  ok('snippet panel has language tabs and copy');
} else fail('snippet panel incomplete');

if (panel.includes('disabled') && panel.includes('Sandbox coming soon')) {
  ok('try-it console stub present');
} else fail('try-it stub missing');

const hub = read('src/components/docs/ApiReferenceHub.jsx');
if (hub.includes('listApiEndpointGroups') && hub.includes('docSectionPath')) {
  ok('hub links to doc sections');
} else fail('hub incomplete');

const docs = read('src/data/docCategories.js');
if (docs.includes("id: 'overview'") && docs.includes('ApiReferenceHub')) {
  ok('api overview section in docCategories');
} else fail('api overview missing');

const app = read('src/App.jsx');
if (app.includes('path="/developers"') && app.includes('/documentation/api/overview')) {
  ok('/developers redirects to api overview');
} else fail('/developers route missing');

const docPage = read('src/pages/DocumentationPage.jsx');
if (docPage.includes('ApiSnippetPanel') && docPage.includes('ApiReferenceHub')) {
  ok('DocumentationPage wires API components');
} else fail('DocumentationPage not wired');

const manifestPath = path.join(
  root,
  '../healthcare-backend/app/data/seo/doc_manifest.json',
);
if (fs.existsSync(manifestPath)) {
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (manifest.documentation_paths?.includes('/documentation/api/overview')) {
    ok('backend doc_manifest includes api overview');
  } else {
    fail('backend doc_manifest missing /documentation/api/overview');
  }
} else {
  fail('backend doc_manifest not found');
}

console.log(failed ? `\n${failed} check(s) failed.\n` : '\nAll Phase 27 checks passed.\n');
process.exit(failed ? 1 : 0);
