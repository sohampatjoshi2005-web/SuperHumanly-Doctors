#!/usr/bin/env node
/**
 * Phase 28 — Portal UX polish verification.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let failed = 0;

function ok(msg) {
  console.log(`  ✓ ${msg}`);
}
function fail(msg) {
  console.error(`  ✗ ${msg}`);
  failed += 1;
}

function read(rel) {
  return fs.readFileSync(path.join(root, rel), 'utf8');
}

console.log('Phase 28 — Portal UX polish\n');

const required = [
  'src/components/portal/PortalSkeleton.jsx',
  'src/index.css',
  'src/components/doctor/WorkflowTab.jsx',
  'src/components/doctor/IntelligenceTab.jsx',
  'src/pages/DoctorSupportPage.jsx',
];

for (const f of required) {
  if (fs.existsSync(path.join(root, f))) ok(`exists ${f}`);
  else fail(`missing ${f}`);
}

const css = read('src/index.css');
for (const cls of ['portal-shell', 'portal-display', 'portal-title', 'portal-label', 'portal-body']) {
  if (css.includes(`.${cls}`)) ok(`typography token .${cls}`);
  else fail(`missing .${cls}`);
}

const workflow = read('src/components/doctor/WorkflowTab.jsx');
if (workflow.includes('handleReviewMobileTabChange')) ok('mobile review tab handler');
else fail('missing handleReviewMobileTabChange');

if (
  workflow.includes("reviewMobileTab === 'prescription' || reviewMobileTab === 'billing'") &&
  workflow.includes("id: 'billing', label: 'Codes'")
) {
  ok('mobile shows Rx and Codes tabs with billing pane');
} else fail('mobile review tab parity incomplete');

if (workflow.includes('hidden lg:flex items-end gap-1.5')) {
  ok('desktop-only inner Rx/Billing tabs');
} else fail('inner tabs not hidden on mobile');

const intel = read('src/components/doctor/IntelligenceTab.jsx');
if (intel.includes('PortalInsightCardSkeleton') && intel.includes('loading')) {
  ok('Intelligence insight skeletons');
} else fail('insight skeletons missing');

if (intel.includes('No analyses yet') && intel.includes('PortalSessionListSkeleton')) {
  ok('session list empty + loading states');
} else fail('session states missing');

if (intel.includes('Start this analysis')) ok('chat empty state');
else fail('chat empty state missing');

const portal = read('src/pages/DoctorSupportPage.jsx');
if (portal.includes('portal-shell')) ok('portal-shell on DoctorSupportPage');
else fail('portal-shell not applied');

console.log(failed ? `\n${failed} check(s) failed.\n` : '\nAll Phase 28 checks passed.\n');
process.exit(failed ? 1 : 0);
