/**
 * Post-build prerender — bakes Helmet head + route HTML into dist per route (CRWL-04, CRWL-05).
 *
 * Prerequisites:
 *   1. `npm run build` completed (dist/ exists, VITE_SITE_URL set for production)
 *   2. healthcare-backend running OR PRERENDER_SKIP=1 / local routes fallback
 *
 * Env:
 *   PRERENDER_API_URL — backend origin (default http://localhost:8000)
 *   PRERENDER_PREVIEW_PORT — vite preview port (default 4173)
 *   PRERENDER_SKIP — set to 1 to no-op (Docker layer without Chromium)
 */
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { copyFile, mkdir, unlink, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import puppeteer from 'puppeteer';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');
const distDir = resolve(repoRoot, 'dist');
const shellFile = resolve(distDir, '.prerender-shell.html');

const API_URL = (process.env.PRERENDER_API_URL || 'http://localhost:8000').replace(/\/$/, '');
const PREVIEW_PORT = Number(process.env.PRERENDER_PREVIEW_PORT || 4173);
const PREVIEW_URL = `http://127.0.0.1:${PREVIEW_PORT}`;

function distFileForPath(routePath) {
  const normalized = routePath === '/' ? '/' : `/${routePath.replace(/^\/+|\/+$/g, '')}`;
  if (normalized === '/') return resolve(distDir, 'index.html');
  return resolve(distDir, normalized.slice(1), 'index.html');
}

async function fetchPrerenderPathsFromApi() {
  const res = await fetch(`${API_URL}/v1/seo/prerender-paths`);
  if (!res.ok) throw new Error(`prerender-paths HTTP ${res.status}`);
  const data = await res.json();
  if (!Array.isArray(data.paths)) throw new Error('invalid prerender-paths payload');
  return data.paths;
}

async function fetchPrerenderPaths() {
  try {
    return await fetchPrerenderPathsFromApi();
  } catch (err) {
    console.warn('[prerender] API fetch failed, using frontend registry:', err.message);
    const { listPublicPathsForSitemap } = await import('../src/seo/routes.js');
    return listPublicPathsForSitemap();
  }
}

function waitForPreviewReady(url, timeoutMs = 60000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const tick = async () => {
      try {
        const res = await fetch(url);
        if (res.ok || res.status === 404) return resolve();
      } catch {
        /* retry */
      }
      if (Date.now() - start > timeoutMs) {
        reject(new Error(`Preview server not ready at ${url}`));
        return;
      }
      setTimeout(tick, 300);
    };
    tick();
  });
}

function startPreview() {
  return new Promise((resolve, reject) => {
    const child = spawn(
      'npx',
      ['vite', 'preview', '--host', '127.0.0.1', '--port', String(PREVIEW_PORT), '--strictPort'],
      { cwd: repoRoot, stdio: ['ignore', 'pipe', 'pipe'], env: { ...process.env } },
    );
    let settled = false;
    child.stderr?.on('data', (chunk) => {
      const text = chunk.toString();
      if (text.includes('EADDRINUSE') && !settled) {
        settled = true;
        reject(new Error(text));
      }
    });
    waitForPreviewReady(PREVIEW_URL)
      .then(() => {
        if (!settled) {
          settled = true;
          resolve(child);
        }
      })
      .catch((err) => {
        child.kill();
        reject(err);
      });
  });
}

async function ensureSpaShellBackup() {
  if (!existsSync(shellFile)) {
    await copyFile(resolve(distDir, 'index.html'), shellFile);
  }
}

async function restoreSpaShell() {
  await copyFile(shellFile, resolve(distDir, 'index.html'));
}

async function prepareDistForPath(routePath) {
  const segments = routePath.split('/').filter(Boolean);
  for (let i = 1; i < segments.length; i++) {
    const parentPath = `/${segments.slice(0, i).join('/')}`;
    const parentFile = distFileForPath(parentPath);
    if (existsSync(parentFile)) await unlink(parentFile);
  }
  if (routePath !== '/') {
    const outFile = distFileForPath(routePath);
    if (existsSync(outFile)) await unlink(outFile);
  }
  await restoreSpaShell();
}

async function prerenderPath(page, path) {
  await prepareDistForPath(path);
  const url = `${PREVIEW_URL}${path === '/' ? '/' : path}`;
  await page.goto(url, { waitUntil: 'networkidle0', timeout: 90000 });

  await page.waitForFunction(
    (expectedPath) => {
      if (document.documentElement.getAttribute('data-seo-ready') !== 'true') return false;

      const title = document.title?.trim() || '';
      const canonical = document.querySelector('link[rel="canonical"]')?.getAttribute('href') || '';
      const ogTitle = document.querySelector('meta[property="og:title"]')?.getAttribute('content') || '';
      const hostTitle = title === window.location.host || title === '127.0.0.1';
      if (title.length < 4 || hostTitle || !ogTitle || ogTitle.length < 4) return false;

      const loaderText = document.body?.innerText?.includes('Initializing Clinical Context');
      if (loaderText) return false;

      if (expectedPath.startsWith('/documentation/')) {
        const h1 = document.querySelector('main article h1, main h1');
        if (!h1?.textContent?.trim()) return false;
      }

      if (expectedPath !== '/') {
        return (
          canonical.includes(expectedPath) || window.location.pathname === expectedPath
        );
      }
      return canonical.length > 0;
    },
    { timeout: 90000 },
    path,
  );

  const html = await page.content();
  const outFile = distFileForPath(path);
  await mkdir(dirname(outFile), { recursive: true });
  await writeFile(outFile, html, 'utf8');
  return outFile;
}

async function main() {
  if (process.env.PRERENDER_SKIP === '1') {
    console.log('[prerender] PRERENDER_SKIP=1 — skipping');
    return;
  }

  if (!existsSync(distDir)) {
    throw new Error('dist/ missing — run `npm run build` first');
  }

  console.log('[prerender] Fetching paths from', API_URL);
  const paths = await fetchPrerenderPaths();

  const forbidden = ['/portal', '/doctor-support', '/auth', '/admin'];
  for (const path of paths) {
    if (forbidden.some((f) => path === f || path.startsWith(`${f}/`))) {
      throw new Error(`refusing to prerender private path ${path}`);
    }
  }

  paths.sort((a, b) => b.split('/').filter(Boolean).length - a.split('/').filter(Boolean).length);
  console.log('[prerender] Paths:', paths.length);

  await ensureSpaShellBackup();
  console.log('[prerender] Starting vite preview on', PREVIEW_URL);
  const preview = await startPreview();
  const browser = await puppeteer.launch({ headless: true });

  try {
    for (const path of paths) {
      const page = await browser.newPage();
      const out = await prerenderPath(page, path);
      await page.close();
      console.log(`[prerender] ${path} → ${out.replace(`${repoRoot}/`, '')}`);
    }
  } finally {
    await browser.close();
    preview.kill('SIGTERM');
  }

  console.log('[prerender] Done', paths.length, 'routes');
}

main().catch((err) => {
  console.error('[prerender] Failed:', err.message);
  process.exit(1);
});
