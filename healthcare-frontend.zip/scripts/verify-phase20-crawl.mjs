/**
 * Phase 20 — crawl infrastructure smoke checks.
 * Prerequisite: backend on :8000 or `npm run seo:mock` on :8799.
 */
import { existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { listPublicPathsForSitemap } from '../src/seo/routes.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');

const API_BASE = process.env.SEO_API_BASE || 'http://localhost:8000';
const FRONT_BASE = process.env.UAT_BASE_URL || 'http://localhost:5173';
const USE_FRONT = process.env.UAT_USE_VITE_PROXY === '1';
const BASE = USE_FRONT ? FRONT_BASE : API_BASE;
const SKIP_API = process.env.VERIFY_SKIP_API === '1';
const EXPECTED_ORIGIN = (process.env.VITE_SITE_URL || 'https://superhumanlymedical.io').replace(
  /\/+$/,
  '',
);

const results = [];

function pass(name, detail = '') {
  results.push({ ok: true, name, detail });
  console.log(`✅ ${name}${detail ? `: ${detail}` : ''}`);
}

function fail(name, detail) {
  results.push({ ok: false, name, detail });
  console.log(`❌ ${name}: ${detail}`);
}

async function main() {
  if (existsSync(resolve(repoRoot, 'public/sitemap.xml'))) {
    fail('static public/sitemap.xml removed', 'file still exists');
  } else {
    pass('static public/sitemap.xml removed');
  }
  if (existsSync(resolve(repoRoot, 'public/robots.txt'))) {
    fail('static public/robots.txt removed', 'file still exists');
  } else {
    pass('static public/robots.txt removed');
  }

  const expectedPaths = listPublicPathsForSitemap();
  if (!expectedPaths.includes('/privacy') || !expectedPaths.includes('/terms')) {
    fail('registry YMYL paths', 'missing /privacy or /terms');
  } else {
    pass('registry includes /privacy and /terms');
  }

  if (SKIP_API) {
    console.log('VERIFY_SKIP_API=1 — skipping live crawl fetches');
    process.exit(results.some((r) => !r.ok) ? 1 : 0);
  }

  let sitemapRes;
  try {
    sitemapRes = await fetch(`${BASE}/sitemap.xml`);
  } catch (e) {
    fail('GET /sitemap.xml', `unreachable at ${BASE} (${e.message})`);
    process.exit(1);
  }

  if (!sitemapRes.ok) {
    fail('GET /sitemap.xml', String(sitemapRes.status));
    process.exit(1);
  }

  const xml = await sitemapRes.text();
  if (!xml.includes('<urlset') || !xml.includes('<loc>')) {
    fail('sitemap XML shape', 'missing urlset/loc');
  } else {
    pass('sitemap XML valid');
  }

  if (!xml.includes(`${EXPECTED_ORIGIN}/`)) {
    fail('sitemap origin', `expected locs under ${EXPECTED_ORIGIN}`);
  } else {
    pass('sitemap uses expected origin', EXPECTED_ORIGIN);
  }

  for (const forbidden of ['/portal', '/auth', '/admin', '/doctor-support']) {
    if (xml.includes(forbidden)) {
      fail('sitemap exclusions', `found ${forbidden}`);
    }
  }
  pass('sitemap excludes private routes');

  for (const required of ['/privacy', '/terms']) {
    if (!xml.includes(`${EXPECTED_ORIGIN}${required}`)) {
      fail('sitemap YMYL URLs', `missing ${required}`);
    }
  }
  pass('sitemap includes privacy and terms');

  const robotsRes = await fetch(`${BASE}/robots.txt`);
  const robots = await robotsRes.text();
  for (const line of ['Disallow: /auth', 'Disallow: /admin', 'Disallow: /portal', 'Disallow: /doctor-support']) {
    if (!robots.includes(line)) {
      fail('robots disallow', `missing ${line}`);
    }
  }
  pass('robots private Disallow lines');

  if (!robots.includes(`Sitemap: ${EXPECTED_ORIGIN}/sitemap.xml`)) {
    fail('robots Sitemap line', robots.slice(0, 200));
  } else {
    pass('robots dynamic Sitemap URL');
  }

  const pathsRes = await fetch(`${API_BASE}/v1/seo/prerender-paths`);
  if (!pathsRes.ok) {
    fail('GET /v1/seo/prerender-paths', String(pathsRes.status));
  } else {
    const { paths } = await pathsRes.json();
    const missing = expectedPaths.filter((p) => !paths.includes(p));
    if (missing.length) {
      fail('prerender-paths parity', `missing ${missing.join(', ')}`);
    } else {
      pass('prerender-paths includes frontend public routes', `${paths.length} paths`);
    }
  }

  const failed = results.filter((r) => !r.ok);
  process.exit(failed.length ? 1 : 0);
}

main();
