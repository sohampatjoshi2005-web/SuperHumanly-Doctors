/**
 * Phase 24 — prerender dist verification (static HTML, no browser).
 */
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');
const distDir = resolve(repoRoot, 'dist');

const API_BASE = (process.env.PRERENDER_API_URL || 'http://localhost:8000').replace(/\/$/, '');

let failed = 0;
function pass(msg) {
  console.log(`✅ ${msg}`);
}
function fail(msg) {
  console.log(`❌ ${msg}`);
  failed += 1;
}

function distFileForPath(routePath) {
  if (routePath === '/') return resolve(distDir, 'index.html');
  return resolve(distDir, routePath.replace(/^\/+/, ''), 'index.html');
}

function assertBakedMeta(html, label, path) {
  const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  const descMatch =
    html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i) ||
    html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']description["']/i);
  const canonicalMatch =
    html.match(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i) ||
    html.match(/<link[^>]+href=["']([^"']+)["'][^>]+rel=["']canonical["']/i);
  const jsonLdMatch = html.match(/<script[^>]+type=["']application\/ld\+json["']/i);

  if (!titleMatch?.[1]?.trim() || titleMatch[1].trim().length < 4) {
    fail(`${label}: missing title`);
    return;
  }
  if (!descMatch?.[1]?.trim()) {
    fail(`${label}: missing description`);
    return;
  }
  if (!canonicalMatch?.[1]?.trim()) {
    fail(`${label}: missing canonical`);
    return;
  }
  if (html.includes('Initializing Clinical Context')) {
    fail(`${label}: still contains PageLoader shell`);
    return;
  }
  if (path.startsWith('/documentation/') && !html.match(/<h1[^>]*>/i)) {
    fail(`${label}: documentation missing h1 in baked HTML`);
    return;
  }
  if (!path.startsWith('/portal') && !jsonLdMatch && path !== '/contact') {
    // most marketing routes emit JSON-LD
    if (!html.includes('application/ld+json')) {
      fail(`${label}: missing JSON-LD script`);
      return;
    }
  }
  pass(`${label} baked (${titleMatch[1].trim().slice(0, 40)}…)`);
}

async function loadPaths() {
  try {
    const res = await fetch(`${API_BASE}/v1/seo/prerender-paths`);
    const data = await res.json();
    return data.paths;
  } catch {
    const { listPublicPathsForSitemap } = await import('../src/seo/routes.js');
    return listPublicPathsForSitemap();
  }
}

async function main() {
  if (!existsSync(distDir)) {
    fail('dist/ missing — run npm run build:prerender');
    process.exit(1);
  }

  const prerenderSrc = await readFile(resolve(repoRoot, 'scripts/prerender.mjs'), 'utf8');
  if (!prerenderSrc.includes('data-seo-ready')) {
    fail('prerender.mjs must wait for data-seo-ready');
  } else {
    pass('prerender waits for data-seo-ready');
  }

  const nginx = await readFile(resolve(repoRoot, 'nginx.conf'), 'utf8');
  if (!nginx.includes('try_files')) {
    fail('nginx.conf missing try_files prerender-first rule');
  } else {
    pass('nginx.conf serves prerendered HTML before SPA fallback');
  }

  const paths = await loadPaths();
  const sample = [
    '/',
    '/pricing',
    '/documentation/getting-started/how-it-works',
    '/documentation/ai-accuracy/safety-banner',
    '/faq',
  ].filter((p) => paths.includes(p));

  for (const path of sample) {
    const file = distFileForPath(path);
    if (!existsSync(file)) {
      fail(`${path}: missing ${file.replace(`${repoRoot}/`, '')}`);
      continue;
    }
    const html = await readFile(file, 'utf8');
    assertBakedMeta(html, path, path);
  }

  process.exit(failed ? 1 : 0);
}

main();
