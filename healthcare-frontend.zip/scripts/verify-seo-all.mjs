/**
 * Run full SEO verification suite (phases 20–25 + dist + parity).
 */
import { spawnSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(__dirname, '..');

const steps = [
  ['test:seo', 'node', ['--test', 'src/seo/*.test.js', 'src/lib/reportWebVitals.test.js']],
  ['verify:phase20', 'node', ['scripts/verify-phase20-crawl.mjs']],
  ['verify:phase21', 'node', ['scripts/verify-phase21-head.mjs']],
  ['verify:phase22', 'node', ['scripts/verify-phase22-schema.mjs']],
  ['verify:phase23', 'node', ['scripts/verify-phase23-docs.mjs']],
  ['verify:seo:perf', 'node', ['scripts/verify-seo-performance.mjs']],
  ['verify:seo:parity', 'node', ['scripts/verify-seo-parity.mjs']],
];

const distExists = spawnSync('test', ['-d', 'dist'], { cwd: repoRoot }).status === 0;
if (distExists) {
  steps.push(['verify:phase24', 'node', ['scripts/verify-phase24-prerender.mjs']]);
  steps.push(['verify:seo:dist', 'node', ['scripts/verify-seo-dist.mjs']]);
} else {
  console.warn('⚠️  dist/ missing — skipping dist prerender checks (run build:prerender first)');
}

let failed = 0;
for (const [name, cmd, args] of steps) {
  console.log(`\n── ${name} ──`);
  const result = spawnSync(cmd, args, { cwd: repoRoot, stdio: 'inherit', env: process.env });
  if (result.status !== 0) {
    failed += 1;
    console.error(`✗ ${name} failed`);
  }
}

process.exit(failed ? 1 : 0);
