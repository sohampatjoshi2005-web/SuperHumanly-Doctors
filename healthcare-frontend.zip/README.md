# Superhumanly Doctors: Frontend Portal

[![React 19](https://img.shields.io/badge/React-19-61DAFB?style=flat-square&logo=react&logoColor=black)](https://react.dev/)
[![Vite](https://img.shields.io/badge/Vite-646CFF?style=flat-square&logo=vite&logoColor=white)](https://vitejs.dev/)

This repository contains the high-fidelity React frontend for the **Superhumanly Doctors** platform. It provides the primary interface for both physicians (Clinical Intake & Intelligence) and administrators (Governance & Telemetry).

## 🚀 Overview
The frontend is built for performance and precision, utilizing **React Query** for state management and **Recharts** for real-time telemetry visualization. The design language follows a "High-Density Nerve Center" aesthetic, optimized for clinical environments.

## 🛠️ Development
1. **Install Dependencies**:
   ```bash
   npm install
   ```
2. **Start Development Server**:
   ```bash
   npm run dev
   ```

### SEO crawl (Milestone v2.0)

- Set `VITE_SITE_URL` in `.env` (see `.env.example`). Production builds fail without it.
- Dynamic `sitemap.xml` and `robots.txt` are served by **healthcare-backend** v4.0 (`/sitemap.xml`, `/robots.txt`, `/v1/seo/prerender-paths`). Vite dev/preview proxies those paths to `http://localhost:8000`.
- Production marketing builds: `npm run build:prerender` (Puppeteer bakes per-route HTML). See [docs/seo-deployment.md](docs/seo-deployment.md) and `nginx.conf`.
- SEO verification: `npm run verify:seo` (full suite). GSC setup: [docs/gsc-setup.md](docs/gsc-setup.md).
- Without the backend running locally, use `npm run seo:mock` and optionally `VITE_SEO_API_TARGET=http://localhost:8799`.
- Verify: `npm run test:seo`, `npm run verify:phase20`, and `npm run verify:phase21` (with API on :8000 or mock on :8799).
- Optional env: `VITE_GOOGLE_SITE_VERIFICATION`, `VITE_TWITTER_SITE` for Search Console and Twitter cards.
- Production nginx must proxy `/sitemap.xml` and `/robots.txt` to the backend (same pattern as book website deploy).

## 📚 Documentation
For the full documentation suite, including architecture, API references, and user guides, please refer to the **[Primary Repository Documentation](https://github.com/superhumanly/healthcare-backend#readme)**.

---
<p align="center">
  Superhumanly Doctors | Technical Sovereign Assistance
</p>
