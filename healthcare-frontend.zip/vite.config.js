import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

const seoApiTarget = process.env.VITE_SEO_API_TARGET || 'http://localhost:8000'

const seoProxy = {
  '/sitemap.xml': { target: seoApiTarget, changeOrigin: true },
  '/robots.txt': { target: seoApiTarget, changeOrigin: true },
  '/v1': {
    target: seoApiTarget,
    changeOrigin: true,
    secure: false,
    ws: true,
  },
}

function requireSiteUrlForProduction() {
  return {
    name: 'require-vite-site-url',
    enforce: 'pre',
    config(_config, { command, mode }) {
      if (command === 'build' && mode === 'production' && !process.env.VITE_SITE_URL?.trim()) {
        throw new Error(
          'VITE_SITE_URL is required for production builds (canonical marketing origin, no trailing slash). ' +
            'Set it in .env or the environment. See .env.example.',
        )
      }
    },
  }
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    requireSiteUrlForProduction(),
    react(),
    tailwindcss(),
  ],
  server: {
    proxy: seoProxy,
  },
  preview: {
    proxy: seoProxy,
  },
})
