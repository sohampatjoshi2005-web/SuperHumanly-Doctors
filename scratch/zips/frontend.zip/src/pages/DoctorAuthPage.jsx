import { useState, useRef, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldCheck, Lock, Activity, ArrowRight, Database, Eye, EyeOff, Zap, Command } from 'lucide-react';
import { loginDoctor } from '../lib/doctorApi';
import SEO from '../components/SEO';
import doc1 from '../assets/avatars/doc1.png';
import doc2 from '../assets/avatars/doc2.png';
import doc3 from '../assets/avatars/doc3.png';
import ai1 from '../assets/avatars/ai1.png';

/* ─── floating clinical metrics ─── */
const MEDICAL_FLOATING_CARDS = [
  { icon: Activity, label: 'Transcription', stat: '98.4%', statLabel: 'Accuracy Rating', color: '#60a5fa', x: '5%', y: '20%', delay: 0.05, rotate: -6 },
  { icon: ShieldCheck, label: 'Sovereignty', stat: 'NIST-256', statLabel: 'Verified Cloud', color: '#10b981', x: '78%', y: '14%', delay: 0.1, rotate: 4 },
  { icon: Zap, label: 'Hub Velocity', stat: '0.4s', statLabel: 'Sync Latency', color: '#f59e0b', x: '80%', y: '68%', delay: 0.15, rotate: -3 },
  { icon: Database, label: 'Registry', stat: 'v4.2', statLabel: 'Zero-Trust Hub', color: '#0052cc', x: '3%', y: '72%', delay: 0.2, rotate: 5 },
];

function FloatingCard({ icon: Icon, label, stat, statLabel, color, x, y, delay, rotate }) {
  return (
    <div
      className="absolute z-[2] pointer-events-none select-none hidden lg:block"
      style={{
        left: x, top: y,
        rotate: `${rotate}deg`,
        '--sx': `calc(50vw - ${x} - 92.5px)`, 
        '--sy': `calc(50vh - ${y} - 62.5px)`,
        animation: `cardReveal 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${0.35 + delay * 1.8}s both`,
      }}
    >
      <div
        className="rounded-[20px] border border-border bg-white p-4 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.08),0_8px_20px_-8px_rgba(0,0,0,0.04)]"
        style={{ 
          width: 185,
          animation: `floatCard 14s ease-in-out infinite ${delay + 0.6}s`,
        }}
      >
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-8 h-8 rounded-[10px] flex items-center justify-center" style={{ background: `${color}12` }}>
            <Icon size={16} style={{ color }} />
          </div>
          <span className="text-[12px] font-bold text-text2 tracking-tight">{label}</span>
        </div>
        <div className="font-serif text-[28px] text-text tracking-[-0.04em] leading-none mb-0.5">{stat}</div>
        <div className="text-[10.5px] font-semibold text-muted uppercase tracking-[0.06em]">{statLabel}</div>
        <div className="absolute top-3 right-3">
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: `${color}30`, boxShadow: `0 0 8px ${color}20` }} />
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   DOCTOR AUTH PAGE — B2B LOGIN GATEWAY
   ═══════════════════════════════════════════════════════ */
export default function DoctorAuthPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [focusedField, setFocusedField] = useState(null);
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const navigate = useNavigate();

  useEffect(() => {
    const handleMouseMove = (e) => {
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      const x = clientX / innerWidth;
      const y = clientY / innerHeight;
      setMousePos({ x, y });
      const tiltX = (y - 0.5) * 6;
      const tiltY = (x - 0.5) * -6;
      setTilt({ x: tiltX, y: tiltY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleAuth = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      const data = await loginDoctor(username, email, password);
      
      if (data && data.access_token) {
        localStorage.setItem('doc_token', data.access_token);
        localStorage.setItem('doc_user', JSON.stringify(data.user));
        navigate('/portal');
      }
    } catch (err) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-[#f8f8f6] flex items-center justify-center font-sans">
      <SEO 
        title="Clinician Authentication Portal" 
        description="Secure authenticated access to the Superhumanly Doctors workspace for verified medical professionals."
      />
      
      {/* ═══ FLAGSHIP MESH GRADIENT (Medical Palette) ═══ */}
      <div className="absolute inset-0 z-0">
        <div className="absolute w-[800px] h-[800px] rounded-full opacity-[0.08] blur-[150px]"
          style={{ background: 'radial-gradient(circle, #60a5fa 0%, transparent 70%)', left: `${25 + mousePos.x * 12}%`, top: `${15 + mousePos.y * 12}%`, transform: 'translate(-50%, -50%)', transition: 'left 2s ease-out, top 2s ease-out' }} />
        <div className="absolute w-[500px] h-[500px] rounded-full opacity-[0.06] blur-[120px]"
          style={{ background: 'radial-gradient(circle, #0052cc 0%, transparent 70%)', right: `${10 + (1 - mousePos.x) * 8}%`, bottom: `${10 + (1 - mousePos.y) * 8}%`, transition: 'right 2.5s ease-out, bottom 2.5s ease-out' }} />
        <div className="absolute w-[350px] h-[350px] rounded-full opacity-[0.05] blur-[100px]"
          style={{ background: 'radial-gradient(circle, #10b981 0%, transparent 70%)', left: `${65 + mousePos.x * 5}%`, top: `${55 + mousePos.y * 8}%`, transition: 'left 3s ease-out, top 3s ease-out' }} />
      </div>

      {/* Tech Dot Grid */}
      <div className="absolute inset-0 z-[1] opacity-[0.035]"
        style={{ backgroundImage: 'radial-gradient(#0052cc 0.5px, transparent 0.5px)', backgroundSize: '32px 32px' }} />

      {/* ═══ FLAGSHIP ORBITING RINGS ═══ */}
      <div className="absolute inset-0 z-[1] pointer-events-none flex items-center justify-center">
        {[420, 640, 860].map((size, i) => (
          <div key={i} className="absolute rounded-full border"
            style={{ width: size, height: size, borderColor: `rgba(0, 82, 204, ${0.05 - i * 0.012})`, animation: `orbitSpin ${24 + i * 16}s linear infinite`, animationDelay: `${i * 3}s` }}>
            <div className="absolute w-1.5 h-1.5 rounded-full shadow-[0_0_12px_rgba(96,165,250,0.4)]"
              style={{ top: -3, left: '50%', transform: 'translateX(-50%)', backgroundColor: `rgba(96,165,250, ${0.35 - i * 0.05})` }} />
          </div>
        ))}
      </div>

      {/* ═══ MEDICAL FLOATING CARDS ═══ */}
      {MEDICAL_FLOATING_CARDS.map((card, i) => (
        <FloatingCard key={i} {...card} />
      ))}

      {/* ═══ TOP NAVBAR ═══ */}
      <div className="fixed top-0 left-0 right-0 z-50 flex items-center justify-center p-4">
        <Link to="/" className="flex items-center gap-3 no-underline group">
          <span className="font-serif text-[26px] text-text tracking-tighter">Superhumanly <span className="italic text-accent">Doctors</span></span>
        </Link>
      </div>

      {/* ═══ 3D TILT AUTH CARD ═══ */}
      <div className="relative z-10 w-full max-w-[460px] mx-4" style={{ animation: 'heroReveal 1s cubic-bezier(0.16, 1, 0.3, 1) 0.2s both' }}>
        <div className="transition-transform duration-300 ease-out" style={{ transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}>
          
          {/* Rotating Gradient Border */}
          <div className="absolute -inset-[1px] rounded-[32px] z-0 overflow-hidden shadow-2xl">
            <div className="absolute inset-[-50%] w-[200%] h-[200%]"
              style={{ background: 'conic-gradient(from 0deg, transparent 0%, rgba(96,165,250,0.3) 8%, transparent 16%, transparent 50%, rgba(0,82,204,0.2) 58%, transparent 66%, transparent 100%)', animation: 'borderSpin 8s linear infinite', left: '-50%', top: '-50%' }} />
            <div className="absolute inset-[1px] rounded-[31px] bg-white" />
          </div>

          {/* Form Body */}
          <div className="relative z-10 rounded-[32px] border border-border bg-white overflow-hidden shadow-[0_32px_100px_-20px_rgba(0,0,0,0.1),0_0_1px_rgba(0,0,0,0.05)]">
            <div className="p-7 lg:p-12">
              
              <div className="text-center mb-10">
                <h2 className="font-serif text-[32px] sm:text-[38px] leading-tight tracking-tighter text-text mb-3">
                  Sign in to <span className="italic text-accent">Clinical Registry</span>
                </h2>
              </div>

              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-sm font-bold flex items-center gap-2 animate-shake">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-400" />
                  {error}
                </div>
              )}

              <form onSubmit={handleAuth} className="space-y-5">
                {/* Username */}
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-text2/80 ml-4">Terminal Username</label>
                  <input id="username" type="text" value={username} onChange={e => setUsername(e.target.value)} onFocus={() => setFocusedField('username')} onBlur={() => setFocusedField(null)}
                    className={`w-full px-5 py-3.5 bg-off border rounded-full text-[14px] font-bold text-text transition-all ${focusedField === 'username' ? 'border-accent ring-4 ring-accent/5 bg-white' : 'border-border/60'}`} placeholder="Clinical Handle" required />
                </div>

                {/* Universal Email */}
                <div className="space-y-2">
                   <label className="text-[11px] font-black uppercase tracking-widest text-text2/80 ml-4" htmlFor="email">Email Address</label>
                    <input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} onFocus={() => setFocusedField('email')} onBlur={() => setFocusedField(null)}
                      className={`w-full px-5 py-3.5 bg-off border rounded-full text-[14px] font-bold text-text transition-all ${focusedField === 'email' ? 'border-accent ring-4 ring-accent/5 bg-white' : 'border-border/60'}`} placeholder="dr.smith@example.com" required />
                </div>

                {/* Password / Protocol */}
                <div className="space-y-2">
                   <label className="text-[11px] font-black uppercase tracking-widest text-text2/80 ml-4" htmlFor="password">Password</label>
                  <div className="relative">
                    <Command className="absolute left-4 top-1/2 -translate-y-1/2 text-text2/40" size={16} />
                    <input id="password" type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} onFocus={() => setFocusedField('password')} onBlur={() => setFocusedField(null)}
                      className={`w-full px-5 py-3.5 bg-off border rounded-full text-[14px] font-bold text-text transition-all pl-12 pr-12 ${focusedField === 'password' ? 'border-accent ring-4 ring-accent/5 bg-white' : 'border-border/60'}`} />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 p-2 text-text2/60 hover:text-text transition-colors">
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <button type="submit" disabled={loading} className="relative w-full py-4 bg-text text-white rounded-full text-[15px] font-bold shadow-xl shadow-black/10 hover:bg-black transition-all active:scale-[0.98] mt-6 flex items-center justify-center gap-2 group overflow-hidden disabled:opacity-50">
                   <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-[150%] group-hover:translate-x-[150%] transition-transform duration-1000" />
                   {loading ? (
                     <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                   ) : (
                     <>
                       Sign in to Workspace 
                       <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
                     </>
                   )}
                </button>
              </form>
            </div>

            {/* Verification Footer */}
            <div className="bg-off/50 border-t border-border/40 px-6 sm:px-10 py-5 flex items-center justify-center gap-4 sm:gap-6">
               {[
                 { icon: ShieldCheck, label: 'HIPAA' },
                 { icon: Lock, label: 'NIST-256' },
                 { icon: Database, label: 'SOC2-II' }
               ].map((badge, i) => (
                 <div key={i} className="flex items-center gap-1.5 sm:gap-2 text-[13px] font-bold text-text2">
                    <badge.icon size={13} className="text-accent" /> {badge.label}
                 </div>
               ))}
            </div>
          </div>
        </div>
      </div>

      {/* Institutional Metadata Footer */}
      <div className="fixed bottom-0 left-0 right-0 z-20 py-6 sm:py-8 flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-10 px-6">
         <div className="flex items-center gap-3">
            <div className="flex -space-x-2">
               {[doc1, doc2, doc3, ai1].map((img, i) => (
                 <div key={i} className="w-7 h-7 sm:w-8 sm:h-8 rounded-full border-2 border-[#f8f8f6] bg-off shadow-sm overflow-hidden">
                   <img src={img} alt={`Node ${i+1}`} className="w-full h-full object-cover" />
                 </div>
               ))}
            </div>
            <span className="text-[12px] sm:text-[13px] font-bold text-text2">Verification Node Hub <strong className="text-accent">Active</strong></span>
         </div>
         <div className="hidden sm:block w-px h-5 bg-border" />
         <Link to="/" className="text-[11px] font-black text-text2/60 uppercase tracking-[0.2em] hover:text-text2/90 transition-colors no-underline">© 2026 Superhumanly Doctors</Link>
      </div>

      <style>{`
        @keyframes orbitSpin { from { transform: translate(-50%, -50%) rotate(0deg); } to { transform: translate(-50%, -50%) rotate(360deg); } }
        @keyframes borderSpin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes floatCard { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-20px); } }
        @keyframes cardReveal { from { opacity: 0; transform: translate(var(--sx), var(--sy)) scale(0.2); filter: blur(12px); } to { opacity: 1; transform: translate(0, 0) scale(1); filter: blur(0); } }
        @keyframes heroReveal { from { opacity: 0; transform: translateY(40px) scale(0.95); } to { opacity: 1; transform: translateY(0) scale(1); } }
        @keyframes shake { 
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-4px); }
          75% { transform: translateX(4px); }
        }
        .animate-shake { animation: shake 0.2s ease-in-out infinite; animation-iteration-count: 2; }
      `}</style>
    </div>
  );
}
