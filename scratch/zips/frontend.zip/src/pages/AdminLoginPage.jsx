import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, Key, ArrowRight, Activity, Command } from 'lucide-react';
import { loginDoctor } from '../lib/doctorApi';
import SEO from '../components/SEO';

export default function AdminLoginPage() {
  const [formData, setFormData] = useState({ username: '', email: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      const data = await loginDoctor(formData.username, formData.email, formData.password);
      if (data.user && data.user.role === 'admin') {
        localStorage.setItem('doc_token', data.access_token);
        localStorage.setItem('doc_user', JSON.stringify(data.user));
        navigate('/admin/dashboard');
      } else {
        throw new Error('Access Denied: Administrative Clearance Required.');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-6 font-sans selection:bg-accent/30 selection:text-white">
      <SEO 
        title="Admin Terminal" 
        description="Secure authenticated access to the Superhumanly Doctors administrative command center."
      />
      
      {/* Background Ambience */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-accent/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-[#0052cc15] blur-[100px] rounded-full" />
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(#ffffff 0.5px, transparent 0.5px)', backgroundSize: '24px 24px' }} />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="w-full max-w-[440px] relative z-10"
      >
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-[0.2em] text-accent-vibrant mb-6">
            <Shield size={12} /> Secure Admin Terminal
          </div>
          <h1 className="text-4xl font-serif text-white tracking-tight mb-4 lowercase">
            Master <span className="italic text-accent-vibrant">Authorization.</span>
          </h1>
        </div>

        <div className="bg-white/[0.03] backdrop-blur-2xl border border-white/10 rounded-[40px] p-10 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.5)]">
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[11px] font-black uppercase tracking-widest text-white/60 ml-4">Terminal Username</label>
              <div className="relative">
                <Command className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={16} />
                <input 
                  required
                  type="text" 
                  value={formData.username}
                  onChange={e => setFormData({ ...formData, username: e.target.value })}
                  placeholder="admin.root"
                  className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-5 py-4 text-white text-[15px] focus:outline-none focus:border-accent-vibrant/50 focus:bg-white/10 transition-all font-medium"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[11px] font-black uppercase tracking-widest text-white/60 ml-4">Administrative Email</label>
              <div className="relative">
                <Shield className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={16} />
                <input 
                  required
                  type="email" 
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  placeholder="systems@superhumanly.io"
                  className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-5 py-4 text-white text-[15px] focus:outline-none focus:border-accent-vibrant/50 focus:bg-white/10 transition-all font-medium"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[11px] font-black uppercase tracking-widest text-white/60 ml-4">Access Key</label>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40" size={16} />
                <input 
                  required
                  type="password" 
                  value={formData.password}
                  onChange={e => setFormData({ ...formData, password: e.target.value })}
                  placeholder="••••••••••••"
                  className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-5 py-4 text-white text-[15px] focus:outline-none focus:border-accent-vibrant/50 focus:bg-white/10 transition-all font-medium"
                />
              </div>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-[12px] font-bold text-center"
              >
                {error}
              </motion.div>
            )}

            <button 
              disabled={isLoading}
              className="w-full py-4.5 bg-accent-vibrant text-white rounded-full font-black uppercase tracking-widest text-[13px] hover:bg-white hover:text-black transition-all shadow-xl shadow-accent-vibrant/20 flex items-center justify-center gap-3 group active:scale-[0.98] disabled:opacity-50"
            >
              {isLoading ? 'Verifying Clearance...' : 'Initialize Access'} <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </form>
        </div>

        <div className="mt-12 text-center">
          <Link to="/" className="text-[11px] font-black text-white/50 uppercase tracking-[0.2em] hover:text-white/80 transition-colors no-underline">
            ← Return to Public Infrastructure
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
