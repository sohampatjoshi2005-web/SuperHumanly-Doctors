import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Shield, Activity, Users, Clock, CheckCircle2, 
  XCircle, Filter, Search, MoreHorizontal, 
  ArrowUpRight, Download, RefreshCw, LogOut,
  Building, Mail, User, Stethoscope, Terminal
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { fetchAdminStats, fetchTrialRequests, updateTrialStatus } from '../lib/doctorApi';
import SEO from '../components/SEO';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [trials, setTrials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedTrial, setSelectedTrial] = useState(null);
  const navigate = useNavigate();

  const loadData = async (isSilent = false) => {
    if (!isSilent) setLoading(true);
    else setRefreshing(true);
    try {
      const [statsData, trialsData] = await Promise.all([
        fetchAdminStats(),
        fetchTrialRequests()
      ]);
      setStats(statsData);
      setTrials(trialsData);
    } catch (err) {
      console.error('Failed to load admin data:', err);
      if (err.message.includes('Session expired')) navigate('/admin/login');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleStatusUpdate = async (trialId, newStatus) => {
    try {
      await updateTrialStatus(trialId, newStatus);
      // Optimistic update
      setTrials(prev => prev.map(t => t._id === trialId ? { ...t, status: newStatus } : t));
      loadData(true); // Refresh stats
    } catch (err) {
      alert('Failed to transition trial status.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('doc_token');
    localStorage.removeItem('doc_user');
    navigate('/admin/login');
  };

  const filteredTrials = trials.filter(t => {
    const matchesSearch = t.full_name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         t.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         t.institution.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || t.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="flex flex-col items-center gap-6">
          <div className="w-16 h-16 border-4 border-accent-vibrant/20 border-t-accent-vibrant rounded-full animate-spin" />
          <div className="text-white/40 font-black uppercase tracking-[0.3em] text-[10px]">Synchronizing Terminal...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-accent-vibrant/30 selection:text-white font-sans pb-20">
      <SEO title="Admin Command Center" description="Superhumanly Doctors Institutional Administration Ledger." />
      
      {/* Dynamic Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-0 right-0 w-[800px] h-[600px] bg-accent-vibrant/5 blur-[150px] rounded-full" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[400px] bg-[#0052cc05] blur-[120px] rounded-full" />
      </div>

      {/* TOP NAVIGATION */}
      <nav className="sticky top-0 z-50 bg-black/40 backdrop-blur-xl border-b border-white/5 px-8 py-4">
        <div className="max-w-[1600px] mx-auto flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-accent-vibrant rounded-lg flex items-center justify-center shadow-lg shadow-accent-vibrant/20">
                <Terminal size={14} className="text-white" />
              </div>
              <span className="font-serif text-xl tracking-tight">Superhumanly <span className="italic text-accent-vibrant">Admin</span></span>
            </div>
            <div className="w-px h-6 bg-white/10" />
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-widest text-white/60">Node Connected</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => loadData(true)}
              className={`p-2.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 transition-all ${refreshing ? 'animate-spin' : ''}`}
            >
              <RefreshCw size={16} className="text-white/60" />
            </button>
            <button 
              onClick={handleLogout}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-red-500/30 hover:text-red-400 transition-all text-[13px] font-bold"
            >
              <LogOut size={16} /> Exit Terminal
            </button>
          </div>
        </div>
      </nav>

      <main className="relative z-10 max-w-[1600px] mx-auto px-8 pt-12">
        {/* HEADER SECTION */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div>
            <h1 className="text-5xl lg:text-6xl font-serif tracking-tight mb-4">
              Trial <span className="italic text-accent-vibrant">Ledger.</span>
            </h1>
            <p className="text-white/40 font-medium max-w-xl">
              Monitor and authorize institutional access to the Superhumanly clinical documentation ecosystem. High-fidelity registry control.
            </p>
          </div>
          
          {/* Dashboard Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Pending Requests', val: stats?.pending_trials || 0, icon: Clock, color: 'text-amber-400' },
              { label: 'Active Doctors', val: stats?.total_doctors || 0, icon: Users, color: 'text-accent-vibrant' },
              { label: 'Institutional Approval', val: stats?.approved_trials || 0, icon: CheckCircle2, color: 'text-emerald-400' },
              { label: 'Sovereign Nodes', val: stats?.total_trials || 0, icon: Shield, color: 'text-white/60' }
            ].map((s, i) => (
              <div key={i} className="bg-white/[0.03] border border-white/5 rounded-3xl p-6 min-w-[180px]">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center bg-white/5 ${s.color}`}>
                    <s.icon size={16} />
                  </div>
                  <ArrowUpRight size={14} className="text-white/20" />
                </div>
                <div className="text-2xl font-bold mb-1">{s.val}</div>
                <div className="text-[10px] font-black uppercase tracking-widest text-white/30">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* CONTROLS & TABLE */}
        <div className="bg-white/[0.02] border border-white/5 rounded-[40px] overflow-hidden backdrop-blur-3xl shadow-2xl">
          {/* Toolbar */}
          <div className="px-8 py-6 border-b border-white/5 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4 w-full sm:w-auto">
              <div className="relative w-full sm:w-80">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={16} />
                <input 
                  type="text" 
                  placeholder="Search ledger..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-5 py-3 text-[14px] focus:outline-none focus:border-accent-vibrant/40 transition-all font-medium"
                />
              </div>
              <div className="flex items-center gap-2 px-4 py-3 bg-white/5 border border-white/10 rounded-2xl">
                <Filter size={14} className="text-white/20" />
                <select 
                  value={filterStatus}
                  onChange={e => setFilterStatus(e.target.value)}
                  className="bg-transparent text-[13px] font-bold focus:outline-none appearance-none pr-4 cursor-pointer"
                >
                  <option value="all">All Status</option>
                  <option value="pending">Pending</option>
                  <option value="approved">Approved</option>
                  <option value="rejected">Rejected</option>
                </select>
              </div>
            </div>
            
            <button className="flex items-center gap-2 px-6 py-3 bg-white text-black rounded-full text-[13px] font-black uppercase tracking-widest hover:bg-accent-vibrant hover:text-white transition-all">
              <Download size={16} /> Export CSV
            </button>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-white/5">
                  <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-[0.2em] text-white/30">Clinician / Identity</th>
                  <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-[0.2em] text-white/30">Institution / Role</th>
                  <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-[0.2em] text-white/30">Protocol Status</th>
                  <th className="px-8 py-5 text-left text-[10px] font-black uppercase tracking-[0.2em] text-white/30">Created At</th>
                  <th className="px-8 py-5 text-right text-[10px] font-black uppercase tracking-[0.2em] text-white/30">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredTrials.map((t) => (
                  <motion.tr 
                    key={t._id}
                    layoutId={t._id}
                    className="group hover:bg-white/[0.02] transition-colors cursor-pointer"
                    onClick={() => setSelectedTrial(t)}
                  >
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-accent-vibrant font-black text-sm">
                          {t.full_name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-[15px] mb-0.5">{t.full_name}</div>
                          <div className="text-[12px] text-white/30 font-medium">{t.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-2 text-[14px] font-medium text-white/70">
                          <Building size={14} className="text-white/20" /> {t.institution}
                        </div>
                        <div className="flex items-center gap-2 text-[12px] font-medium text-white/30">
                          <Stethoscope size={12} className="text-white/20" /> {t.professional_role}
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border
                        ${t.status === 'approved' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 
                          t.status === 'rejected' ? 'bg-red-500/10 border-red-500/20 text-red-400' : 
                          'bg-amber-500/10 border-amber-500/20 text-amber-400'}`}>
                        {t.status === 'pending' && <Clock size={10} />}
                        {t.status === 'approved' && <CheckCircle2 size={10} />}
                        {t.status === 'rejected' && <XCircle size={10} />}
                        {t.status}
                      </div>
                    </td>
                    <td className="px-8 py-6 text-sm text-white/40 font-medium">
                      {new Date(t.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-8 py-6 text-right">
                       <button className="p-2 rounded-lg hover:bg-white/10 transition-all text-white/20 hover:text-white">
                         <MoreHorizontal size={20} />
                       </button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
            
            {filteredTrials.length === 0 && (
              <div className="py-20 text-center">
                <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Filter size={24} className="text-white/10" />
                </div>
                <h3 className="text-xl font-bold mb-2">No results found in ledger.</h3>
                <p className="text-white/30 text-sm">Refine your search parameters or filter status.</p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* DETAIL DRAWER / MODAL */}
      <AnimatePresence>
        {selectedTrial && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedTrial(null)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100]"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 w-full max-w-[540px] h-full bg-[#0a0a0a] border-l border-white/5 z-[101] shadow-[0_0_100px_rgba(0,0,0,1)] flex flex-col"
            >
              <div className="p-10 border-b border-white/5 flex items-center justify-between bg-white/[0.02]">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-accent-vibrant/10 border border-accent-vibrant/20 flex items-center justify-center text-accent-vibrant text-2xl font-black">
                    {selectedTrial.full_name.charAt(0)}
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight">{selectedTrial.full_name}</h2>
                    <p className="text-white/40 font-medium">{selectedTrial.email}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedTrial(null)}
                  className="p-3 rounded-2xl hover:bg-white/5 transition-all"
                >
                  <XCircle size={24} className="text-white/20" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-10 space-y-12">
                <div className="grid grid-cols-2 gap-8">
                  <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6">
                    <div className="text-[10px] font-black uppercase tracking-widest text-white/30 mb-2">Institutional Entity</div>
                    <div className="font-bold flex items-center gap-3">
                      <Building size={16} className="text-accent-vibrant" /> {selectedTrial.institution}
                    </div>
                  </div>
                  <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-6">
                    <div className="text-[10px] font-black uppercase tracking-widest text-white/30 mb-2">Clinical Mandate</div>
                    <div className="font-bold flex items-center gap-3">
                      <Stethoscope size={16} className="text-accent-vibrant" /> {selectedTrial.professional_role}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-[11px] font-black uppercase tracking-widest text-white/30 mb-4">Master Use Case Architecture</h4>
                  <div className="bg-white/[0.03] border border-white/5 rounded-[32px] p-8 font-medium leading-[1.7] text-white/80 italic text-lg">
                    "{selectedTrial.use_case}"
                  </div>
                </div>

                <div className="space-y-4">
                   <h4 className="text-[11px] font-black uppercase tracking-widest text-white/30 mb-4">Protocol Metadata</h4>
                   <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm py-3 border-b border-white/5">
                        <span className="text-white/30">Transmission Timestamp</span>
                        <span className="font-mono text-white/60">{new Date(selectedTrial.created_at).toLocaleString()}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm py-3 border-b border-white/5">
                        <span className="text-white/30">Security Clearance</span>
                        <span className="font-mono text-white/60">Verified HIPAA/SOC2-II</span>
                      </div>
                      <div className="flex items-center justify-between text-sm py-3 border-b border-white/5">
                         <span className="text-white/30">Network Node</span>
                         <span className="font-mono text-white/60">US-EAST-GTY-04</span>
                      </div>
                   </div>
                </div>
              </div>

              <div className="p-10 border-t border-white/5 bg-white/[0.02] flex items-center gap-4">
                  {selectedTrial.status === 'pending' ? (
                    <>
                      <button 
                        onClick={() => handleStatusUpdate(selectedTrial._id, 'approved')}
                        className="flex-1 py-4.5 bg-accent-vibrant text-white rounded-full font-black uppercase tracking-widest text-[13px] hover:bg-white hover:text-black transition-all flex items-center justify-center gap-3 shadow-xl shadow-accent-vibrant/20"
                      >
                         <CheckCircle2 size={18} /> Authorize Clinical Access
                      </button>
                      <button 
                        onClick={() => handleStatusUpdate(selectedTrial._id, 'rejected')}
                        className="flex-1 py-4.5 bg-white/5 border border-white/10 text-white hover:bg-red-500/20 hover:border-red-500/40 hover:text-red-400 rounded-full font-black uppercase tracking-widest text-[13px] transition-all flex items-center justify-center gap-3"
                      >
                         <XCircle size={18} /> Rescind Protocol
                      </button>
                    </>
                  ) : (
                    <div className="w-full text-center py-4 bg-white/5 rounded-2xl border border-white/5 text-[11px] font-black uppercase tracking-[0.2em] text-white/20">
                      Protocol Processed on {new Date(selectedTrial.processed_at).toLocaleDateString()} by {selectedTrial.processed_by}
                    </div>
                  )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
