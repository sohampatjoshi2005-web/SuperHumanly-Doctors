import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, Book, Layout, Cpu, Shield, Globe, 
  ChevronRight, ArrowLeft, Terminal, Zap, CheckCircle2,
  Activity, Brain, ClipboardList, Database, Mail, AlertTriangle,
  Lock, RefreshCw, Workflow, Users, HelpCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import LandingNavbar from '../components/landing/LandingNavbar';
import LandingFooter from '../components/landing/LandingFooter';
import SEO from '../components/SEO';
import { getMedicalWebPageSchema } from '../lib/StructuredData';
const sections = [
  {
    id: 'intro',
    title: 'Platform Introduction',
    icon: Book,
    content: [
      {
        title: 'The Superhumanly Vision & Architecture',
        text: 'Superhumanly Doctors is an enterprise-grade clinical sovereignty protocol engineered for high-velocity, data-dense medical environments. We do not merely offer a dictation tool; we provide a comprehensive bimodal architecture that seamlessly bridges legacy hospital data systems (such as EHRs and HMS) with cutting-edge, agentic artificial intelligence. Our core mission is to eradicate documentation fatigue while ensuring 100% clinician oversight and maintaining absolute technical data sovereignty across all institutional nodes.',
        alert: {
          type: 'info',
          title: 'Mission-Critical Reliability',
          text: 'Superhumanly is architected for 99.99% availability, utilizing zero-trust data isolation protocols designed to meet the rigorous demands of trauma centers and high-volume outpatient clinics alike.'
        }
      },
      {
        title: 'Who is this platform for?',
        text: 'This platform is explicitly designed for medical professionals, clinical directors, and healthcare IT administrators who refuse to compromise on speed, accuracy, and data security.',
        list: [
          'Physicians & Specialists: High-fidelity ambient scribe capabilities to focus entirely on the patient encounter.',
          'Nurses & Allied Health: Rapid, structured documentation tools for high-stress triage and acute care environments.',
          'Institutional IT: Demanding HIPAA/SOC2 compliance, Zero-Trust data residency, and seamless FHIR integration.'
        ]
      },
      {
        title: 'The "Precision Instrument" Design Language',
        text: 'We fundamentally reject the "generic software" aesthetic. Superhumanly is built as a true clinical workstation—a precision instrument. Every interface interaction, typography choice, and data visualization is scientifically optimized for maximum information density, low-latency cognitive processing, and extreme discoverability. It mirrors the ergonomics, reliability, and precision found only in state-of-the-art surgical and diagnostic equipment.'
      },
      {
        title: 'Core Clinical Modalities',
        text: 'The platform is strategically divided into four primary workspaces, each dedicated to a distinct phase of the clinical and administrative workflow:',
        steps: [
          { label: 'Ambient Workspace', desc: 'Secure acoustic capture and real-time clinical synthesis using advanced NLP.' },
          { label: 'EHR Sync Engine', desc: 'Enterprise, FHIR-compliant bidirectional synchronization with your hospital database.' },
          { label: 'Intelligence Hub', desc: 'Longitudinal patient data analysis, predictive risk scoring, and deep querying.' },
          { label: 'AI Swarm', desc: 'Autonomous agentic co-workers handling administrative, scheduling, and diagnostic research tasks.' }
        ]
      }
    ]
  },
  {
    id: 'ambient',
    title: 'Ambient Workspace',
    icon: Workflow,
    content: [
      {
        title: 'Clinical Grammar & Synthesis Engine',
        text: 'The Ambient Workspace is a zero-latency ingestion layer that utilizes a proprietary Clinical Grammar Engine. Unlike generic transcription services, our engine is trained on millions of medical specialized corpora, allowing it to accurately differentiate between incidental patient conversation and actionable clinical symptoms.',
        steps: [
          { label: 'Acoustic Capture', desc: 'Beamforming technology isolates the physician\'s voice from background noise.' },
          { label: 'Entity Extraction', desc: 'Auto-detects pharmacological intent, DOS, and anatomical locations.' },
          { label: 'SOAP Synthesis', desc: 'Conversational data is dynamically mapped into Subjective and Objective formats.' }
        ]
      },
      {
        title: 'Operational Workflow',
        text: 'To initialize a session, navigate to the "Patients" registry, select the active node, and click "Initialize Encounter". The system will begin immediate audio analysis. You may also utilize the "Manual Handoff" mode for asynchronous note processing.',
        code: '// Example: Ingesting Asynchronous Encounter Data\nconst result = await ClinicalCore.process({\n  source: "MANUAL_INPUT",\n  format: "UNSTRUCTURED_DRAFT",\n  synthesis_level: "MAX_FIDELITY"\n});'
      },
      {
        title: 'Troubleshooting: Low Fidelity & Interruptions',
        text: 'Common issues encountered during ambient capture:',
        list: [
          'Signal Degradation: If the "Fidelity Indicator" drops below 80%, check for hardware obstructions or interference from mobile devices.',
          'Speaker Collision: If multiple clinicians are speaking, use the "Lock Primary Mic" toggle to force focus on a single acoustic source.',
          'Missing Entities: Ensure medical terminology is pronounced clearly. Generic LLM failures can be bypassed by using the "Dictation Override" mode.'
        ],
        alert: {
          type: 'warning',
          title: 'Encryption Key Rotation',
          text: 'Ambient sessions are encrypted with session-bound keys. If a session is interrupted, you must re-verify your identity to resume capture.'
        }
      }
    ]
  },
  {
    id: 'ehr-sync',
    title: 'EHR Sync Engine',
    icon: RefreshCw,
    content: [
      {
        title: 'Bidirectional Interoperability (FHIR R4)',
        text: 'The Superhumanly Sync Engine is built on the HL7® FHIR® R4 standard, providing deep bidirectional integration with major EHR platforms. It handles the complex mapping between unstructured clinical narratives and structured data fields in your hospital\'s central database.',
        steps: [
          { label: 'Resource Mapping', desc: 'Auto-maps SOAP notes to Observation, Condition, and Procedure resources.' },
          { label: 'Delta Analysis', desc: 'Identifies discrepancies between real-time notes and existing EHR history.' },
          { label: 'Atomic Commit', desc: 'Ensures updates are transactional, preventing partial data corruption.' }
        ]
      },
      {
        title: 'Institutional Integration Protocols',
        text: 'Our engine utilizes specialized secure gateways to traverse institutional firewalls without compromising security. It supports OAuth 2.0 / OpenID Connect for secure clinician authorization.',
        code: '// Example: Establishing FHIR Handshake\nconst connector = new EHRConnector({\n  vendor: "EPIC_ORCHARD",\n  version: "R4-2024",\n  endpoint: "https://gateway.hospital.internal"\n});\n\nconst sync = await connector.initialize();'
      },
      {
        title: 'Troubleshooting: Synchronization Delays',
        text: 'Sync operations are governed by integrity checks. Potential failure modes include:',
        list: [
          'Handshake Timeout: The institutional node is unreachable. Verify that the HMS Gateway is bypassed or whitelisted.',
          'Schema Mismatch: Custom EHR fields may require custom mapping. Re-run the "Schema Discovery" tool from the Connect tab.',
          'Conflict Deadlock: Another user is editing the same record. The system defaults to "Clinician Override" to prevent data loss.'
        ],
        alert: {
          type: 'info',
          title: 'Integrity Monitoring',
          text: 'Every sync event is cryptographically hashed and recorded in the Immutable Audit Ledger for compliance verification.'
        }
      }
    ]
  },
  {
    id: 'intelligence',
    title: 'Intelligence Hub',
    icon: Brain,
    content: [
      {
        title: 'Superhumanly Thoughts™ (NLQ Engine)',
        text: 'The Intelligence Hub utilizes a sophisticated Natural Language Querying (NLQ) engine known as Superhumanly Thoughts™. It allows clinicians to interrogate their local patient dataset using plain English, bypassing the need for complex SQL or database queries.',
        steps: [
          { label: 'Semantic Search', desc: 'Find patients based on symptoms or history rather than just keywords.' },
          { label: 'Longitudinal Analysis', desc: 'Trace the progression of conditions over months or years in seconds.' },
          { label: 'Telemetry Visuals', desc: 'Dynamically generate trend lines and vital signs heatmaps on the fly.' }
        ]
      },
      {
        title: 'Interrogating the Dataset',
        text: 'To query your hub, navigate to the "Intelligence" tab and enter your prompt. The system provides high-fidelity insights that are directly linked back to source clinical notes for verification.',
        code: '// Example: Complex Longitudinal Interrogation\nconst report = await Intelligence.analyze({\n  query: "Identify patients with rising MAP and underlying CKD stage 3+",\n  scope: "INSTITUTIONAL_REGISTRY",\n  fidelity: "CLINICAL_GRADE"\n});'
      },
      {
        title: 'Predictive Risk Protocols',
        text: 'The hub continuously scans incoming data streams for "Silent Risk Peaks." These are patterns that indicate a high probability of clinical deterioration before vitals fall outside standard alarm limits.',
        list: [
          'Early Sepsis Warning: Analysis of subtle variations in tachycardia and respiratory rate trends.',
          'Re-Admission Risk: Modeling patient recovery speed against historical benchmarks for specific procedures.',
          'Pharmacological Conflict: Predictive modeling of potential drug-drug interactions based on real-time prescription drafts.'
        ],
        alert: {
          type: 'info',
          title: 'Explainability Protocol',
          text: 'Every predictive insight is accompanied by a "Evidence Trace," showing the specific clinical markers that triggered the alert.'
        }
      }
    ]
  },
  {
    id: 'swarm',
    title: 'AI Swarm (Digital Co-Workers)',
    icon: Users,
    content: [
      {
        title: 'Multi-Agent Orchestration',
        text: 'The Superhumanly AI Swarm is a collective of specialized agents designed to handle administrative and clinical sub-tasks autonomously. Instead of a single monolithic model, we utilize an orchestration layer that delegates tasks to the agent best suited for the clinical domain required.',
        steps: [
          { label: 'Task Delegation', desc: 'Identify required output (e.g., Insurance Appeal) and assign to the swarm.' },
          { label: 'Collaborative Drafting', desc: 'Multiple agents cross-reference work for maximum accuracy.' },
          { label: 'Human-in-the-Loop', desc: 'Clinician reviews final output before commitment.' }
        ]
      },
      {
        title: 'Specialized Agent Profiles',
        text: 'Understanding the strengths of each digital co-worker allows for more efficient delegation:',
        list: [
          'Atlas (The Coordinator): Specializes in patient logistics, scheduling, and EHR data positioning. Use Atlas for high-volume data movement.',
          'Lumina (The Researcher): Trained on the latest medical literature and institutional historical records. Lumina finding medical precedents and research.',
          'Echo (The Administrator): Expert in insurance coding, billing justifications, and discharge summaries. Echo handles the documentation tail-end.'
        ],
        code: '// Example: Delegating to the Swarm\nconst swarm = new AgenticSwarm();\nswarm.delegate({\n  task: "Generate Insurance Justification",\n  context: patientA_Encounter,\n  assignedTo: "ECHO"\n});'
      },
      {
        title: 'Common Problems: Agent Deadlock',
        text: 'While autonomous, agents may occasionally require clarification:',
        list: [
          'Ambiguous Context: If clinical notes are contradictory, the Swarm will pause and request a "Clinician Resolution".',
          'Search Timeout: If Lumina cannot find a precedent, verify that the institutional library nodes are online.',
          'Output Variance: If two agents disagree, the system provides a "Differential Draft" for the physician to choose from.'
        ]
      }
    ]
  },
  {
    id: 'security',
    title: 'Security & Sovereignty',
    icon: Shield,
    content: [
      {
        title: 'Zero-Trust Clinical Architecture',
        text: 'Superhumanly is engineered on a Zero-Trust architecture, meaning no entity (whether internal or external) is trusted by default. Every data request must be authenticated and authorized via a multi-dimensional identity handshake.',
        steps: [
          { label: 'Identity Verification', desc: 'Hardware-backed biometric or MFA required for every institutional node access.' },
          { label: 'Least Privilege', desc: 'Clinicians only access the minimum patient dataset required for the active encounter.' },
          { label: 'Continuous Auditing', desc: 'Real-time telemetry monitors for anomalous data access patterns.' }
        ]
      },
      {
        title: 'Encryption & Cryptographic Specs',
        text: 'We utilize NIST-standard cryptographic protocols to ensure clinical metadata and narrative documentation remain unreadable to unauthorized parties.',
        list: [
          'At-Rest: AES-256-GCM encryption with keys managed via FIPS 140-2 Level 3 Hardware Security Modules (HSM).',
          'In-Transit: TLS 1.3 with Perfect Forward Secrecy (PFS) ensuring historical data remains secure even if a key is compromised.',
          'Sovereign Residency: Data is stored exclusively on nodes within your legal jurisdiction (US-East, EU-Central, etc.), never in a multi-tenant cloud.'
        ]
      },
      {
        title: 'HIPAA & Compliance Protocols',
        text: 'The platform is built from the ground up to exceed HIPAA, SOC2 Type II, and GDPR requirements. We provide institutional admins with a "Compliance Dashboard" to generate instant audit logs for regulatory reviews.',
        alert: {
          type: 'info',
          title: 'Institutional Air-Gap',
          text: 'For extreme security environments, we offer "Air-Gapped" deployments where the clinical intelligence core runs on completely isolated hardware with no external WAN dependencies.'
        }
      }
    ]
  }
];

export default function DocumentationPage() {
  const [activeSection, setActiveSection] = useState('intro');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activeSection]);

  const filteredSections = sections.filter(s => 
    s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.content.some(c => c.title.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="bg-white min-h-screen selection:bg-accent/10">
      <SEO 
        title="Superhumanly Doctors - Detailed Tool Documentation" 
        description="Comprehensive clinical documentation for the Superhumanly AI ecosystem. Learn how to optimize your medical workflow."
        schema={getMedicalWebPageSchema("Superhumanly Clinical Documentation", "Comprehensive guides for medical AI tools and clinical workflows.")}
      />
      <LandingNavbar />

      <main className="pt-32 pb-20">
        <div className="px-10">
          
          {/* Header Area */}
          <div className="mb-12">
            <div className="flex items-center gap-2 text-muted text-sm font-bold uppercase tracking-wider mb-4">
              <Link to="/" className="hover:text-accent flex items-center gap-1 transition-colors">
                <ArrowLeft size={14} /> Home
              </Link>
              <ChevronRight size={14} />
              <span className="text-text">Documentation</span>
            </div>
            <div className='flex justify-between items-center'>
              <h1 className="font-serif text-5xl sm:text-7xl text-text mb-6 tracking-tight leading-[0.95]">
                Institutional <span className="italic text-accent">Knowledge Base</span>
              </h1>
              
              {/* Search Bar */}
              <div className="relative group">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-muted group-focus-within:text-accent transition-colors" size={24} />
                <input 
                  type="text"
                  placeholder="Search tools, trouble-shooting, or clinical specs..."
                  className="w-full pl-16 min-w-lg pr-4 py-4 bg-off/50 border border-border/60 rounded-[28px] focus:outline-none focus:ring-4 focus:ring-accent/5 focus:border-accent transition-all text-text font-medium text-lg"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 xl:gap-10">
            
            {/* Sidebar Navigation */}
            <aside className="lg:col-span-3">
              <div className="sticky top-32 flex flex-col gap-1">
                <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted mb-4 px-4 opacity-50">Clinical Directory</div>
                {sections.map(section => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`flex items-center gap-4 px-5 py-4 rounded-2xl text-left transition-all group ${
                      activeSection === section.id 
                        ? 'bg-text text-white shadow-xl shadow-black/10 scale-[1.02]' 
                        : 'text-text2 hover:bg-off'
                    }`}
                  >
                    <section.icon size={20} className={activeSection === section.id ? 'text-white' : 'text-muted group-hover:text-accent transition-colors'} />
                    <span className="font-bold text-[15px]">{section.title}</span>
                  </button>
                ))}
                
                <div className="mt-8 pt-8 border-t border-border/60">
                  <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted mb-4 px-4 opacity-50">Emergency Support</div>
                  <a href="mailto:support@superhumanlymedical.io" className="flex items-center gap-4 px-5 py-4 text-text2 hover:text-accent transition-colors font-bold text-[15px]">
                    <HelpCircle size={20} className="text-muted" /> Help Center
                  </a>
                  <a href="#" className="flex items-center gap-4 px-5 py-4 text-text2 hover:text-accent transition-colors font-bold text-[15px]">
                    <Activity size={20} className="text-muted" /> Engineering Status
                  </a>
                </div>
              </div>
            </aside>

            {/* Content Area */}
            <div className="lg:col-span-9">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeSection}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                  className="prose prose-slate"
                >
                  {sections.find(s => s.id === activeSection)?.content.map((block, idx) => (
                    <section key={idx} className="mb-20 last:mb-0">
                      <h2 className="font-serif text-4xl text-text mb-8 tracking-tight flex items-center gap-4">
                        {block.title}
                        {idx === 0 && (
                          <span className="text-[10px] bg-accent/5 text-accent px-3 py-1 rounded-full font-black uppercase tracking-widest border border-accent/10">Verified Protocol</span>
                        )}
                      </h2>
                      
                      <p className="text-xl text-text2 leading-relaxed mb-10 font-medium">
                        {block.text}
                      </p>

                      {block.list && (
                        <div className="my-10 space-y-4">
                          {block.list.map((item, i) => (
                            <div key={i} className="flex gap-4 p-5 bg-off/50 border border-border rounded-2xl">
                              <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                              <div className="text-text2 text-[16px] font-medium leading-relaxed">{item}</div>
                            </div>
                          ))}
                        </div>
                      )}

                      {block.alert && (
                        <div className={`my-10 p-8 rounded-[32px] overflow-hidden relative border-2 ${
                          block.alert.type === 'warning' ? 'bg-orange-50/50 border-orange-100' : 'bg-accent-[0.03] border-accent/10'
                        }`}>
                          <div className={`absolute top-0 right-0 w-48 h-48 rounded-full -translate-y-1/2 translate-x-1/2 opacity-[0.03] ${
                            block.alert.type === 'warning' ? 'bg-orange-500' : 'bg-accent'
                          }`} />
                          <div className="flex gap-6 items-start relative z-10">
                            <div className={`p-3 rounded-2xl ${
                              block.alert.type === 'warning' ? 'bg-orange-100 text-orange-600' : 'bg-accent/10 text-accent'
                            }`}>
                              {block.alert.type === 'warning' ? <AlertTriangle size={24} /> : <Shield size={24} />}
                            </div>
                            <div>
                              <div className={`font-black text-[13px] uppercase tracking-widest mb-2 ${
                                block.alert.type === 'warning' ? 'text-orange-700' : 'text-accent'
                              }`}>
                                {block.alert.title}
                              </div>
                              <div className="text-text text-lg font-medium leading-relaxed">{block.alert.text}</div>
                            </div>
                          </div>
                        </div>
                      )}

                      {block.steps && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-10">
                          {block.steps.map((step, sIdx) => (
                            <div key={sIdx} className="p-8 border border-border/60 bg-off/30 rounded-[32px] hover:border-accent/40 hover:bg-white transition-all group scale-100 hover:scale-[1.02]">
                              <div className="text-[12px] font-black text-accent uppercase tracking-widest mb-4 flex items-center justify-between">
                                <span>Phase 0{sIdx + 1}</span>
                                <CheckCircle2 size={16} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                              </div>
                              <div className="text-text text-[18px] font-bold mb-3">{step.label}</div>
                              <div className="text-text2 text-[15px] font-medium leading-relaxed opacity-70">
                                {step.desc}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {block.code && (
                        <div className="my-10 rounded-[32px] overflow-hidden border border-text/10 bg-[#0d1117] shadow-2xl relative group">
                          <div className="px-6 py-4 bg-white/5 border-b border-white/10 flex items-center justify-between">
                            <div className="flex gap-2">
                              <div className="w-3 h-3 rounded-full bg-red-500/40" />
                              <div className="w-3 h-3 rounded-full bg-yellow-500/40" />
                              <div className="w-3 h-3 rounded-full bg-green-500/40" />
                            </div>
                            <div className="flex items-center gap-2 text-white/30 text-[11px] font-black uppercase tracking-widest">
                              <Terminal size={14} /> Clinical SDK v2.4
                            </div>
                          </div>
                          <pre className="p-8 text-[14px] font-mono text-white/90 overflow-x-auto leading-relaxed custom-scrollbar-dark">
                            <code>{block.code}</code>
                          </pre>
                        </div>
                      )}
                    </section>
                  ))}

                  {/* Footer Action */}
                  <div className="mt-24 p-12 bg-off border border-border/60 rounded-[40px] flex flex-col md:flex-row items-center justify-between gap-8">
                    <div>
                      <h4 className="font-serif text-3xl text-text mb-2 tracking-tight">Need dedicated integration assistance?</h4>
                      <p className="text-lg text-muted font-medium">Our engineering team provides 24/7 support for institutional node deployments.</p>
                    </div>
                    <button className="px-10 py-4 bg-text text-white rounded-2xl text-[16px] font-bold hover:bg-black transition-all shadow-xl shadow-black/10 active:scale-95 whitespace-nowrap">
                      Contact Integration Team
                    </button>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </main>

      <LandingFooter />

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar-dark::-webkit-scrollbar { height: 4px; }
        .custom-scrollbar-dark::-webkit-scrollbar-track { background: rgba(255,255,255,0.05); }
        .custom-scrollbar-dark::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
      `}} />
    </div>
  );
}
