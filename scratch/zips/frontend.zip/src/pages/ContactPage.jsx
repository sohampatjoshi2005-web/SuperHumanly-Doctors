import LandingNavbar from '../components/landing/LandingNavbar';
import LandingFooter from '../components/landing/LandingFooter';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, ArrowRight } from 'lucide-react';
import SEO from '../components/SEO';

export default function ContactPage() {
  return (
    <div className="bg-white min-h-screen">
      <SEO 
        title="Institutional Consultation" 
        description="Consult with the Superhumanly Doctors engineering team for institutional deployments, private multi-node systems, and technical partnerships."
      />
      <LandingNavbar />
      
      <main className="pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-5xl lg:text-7xl font-serif text-text tracking-tight mb-8">
                Consult with our <span className="italic text-accent">Medical Team.</span>
              </h1>
              <p className="text-xl text-text2/60 font-medium leading-[1.6] max-w-lg mb-12">
                Whether you're a single practitioner or a global health system, our engineering team is ready to help you deploy sovereign clinical intelligence.
              </p>

              <div className="space-y-10">
                <div className="flex gap-6">
                  <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center shrink-0">
                    <Mail size={22} className="text-accent" />
                  </div>
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-text2/30 mb-2">Technical Inquiries</h4>
                    <p className="text-lg font-bold">solutions@superhumanlymedical.io</p>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center shrink-0">
                    <MapPin size={22} className="text-accent" />
                  </div>
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-text2/30 mb-2">Institutional HQ</h4>
                    <p className="text-lg font-bold">44 Medical Plaza, Suite 900 <br />San Francisco, CA 94103</p>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="p-8 sm:p-10 rounded-[40px] bg-off border border-border shadow-2xl relative"
            >
               <div className="absolute -top-10 -right-10 w-40 h-40 bg-accent/5 blur-[80px] rounded-full"></div>
               <form className="space-y-6 relative z-10" onSubmit={(e) => e.preventDefault()}>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                     <div className="space-y-2">
                        <label className="text-[11px] font-black uppercase tracking-widest text-text/40 ml-4">Full Name</label>
                        <input type="text" placeholder="Dr. Sophia Garcia" className="w-full bg-white border border-border rounded-2xl px-5 py-4 text-[15px] focus:outline-none focus:border-accent transition-all font-medium" />
                     </div>
                     <div className="space-y-2">
                        <label className="text-[11px] font-black uppercase tracking-widest text-text/40 ml-4">Professional Email</label>
                        <input type="email" placeholder="sophia@hospital.org" className="w-full bg-white border border-border rounded-2xl px-5 py-4 text-[15px] focus:outline-none focus:border-accent transition-all font-medium" />
                     </div>
                  </div>
                  <div className="space-y-2">
                     <label className="text-[11px] font-black uppercase tracking-widest text-text/40 ml-4">Institutional Affiliation</label>
                     <input type="text" placeholder="General Medical Hospital Group" className="w-full bg-white border border-border rounded-2xl px-5 py-4 text-[15px] focus:outline-none focus:border-accent transition-all font-medium" />
                  </div>
                  <div className="space-y-2">
                     <label className="text-[11px] font-black uppercase tracking-widest text-text/40 ml-4">Inquiry Scope</label>
                     <select className="w-full bg-white border border-border rounded-2xl px-5 py-4 text-[15px] focus:outline-none focus:border-accent transition-all font-medium appearance-none">
                        <option>Individual Practitioner</option>
                        <option>Clinical Research Group</option>
                        <option>Public/Private Hospital System</option>
                        <option>Technical Partnership</option>
                     </select>
                  </div>
                  <div className="space-y-2">
                     <label className="text-[11px] font-black uppercase tracking-widest text-text/40 ml-4">Message</label>
                     <textarea rows={4} placeholder="Tell us about your institutional requirements..." className="w-full bg-white border border-border rounded-2xl px-5 py-4 text-[15px] focus:outline-none focus:border-accent transition-all font-medium resize-none"></textarea>
                  </div>
                  <button className="w-full py-4 bg-text text-white rounded-full font-black uppercase tracking-widest hover:bg-black transition-all shadow-xl shadow-black/10 active:scale-95 flex items-center justify-center gap-2 group">
                     Transmit Inquiry <Send size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  </button>
               </form>
            </motion.div>
          </div>
        </div>
      </main>

      <LandingFooter />
    </div>
  );
}
