import LandingNavbar from '../components/landing/LandingNavbar';
import LandingFooter from '../components/landing/LandingFooter';
import { Check, ArrowRight, Zap, ShieldCheck, Database } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import { getMedicalWebPageSchema } from '../lib/StructuredData';

const pricingTiers = [
  {
    name: "Standard Node",
    price: "$299",
    description: "For individual practitioners and specialized clinics looking to automate routine clinical documentation.",
    features: [
      "AI Intake Kernel (Whisper v3)",
      "Automated Patient Synthesis",
      "Standard Rx Pro-Engine",
      "50GB Sovereign Storage",
      "Priority Email Protocol"
    ],
    cta: "Initialize Node",
    highlight: false,
    color: "blue"
  },
  {
    name: "Institutional Hub",
    price: "Custom",
    description: "Full-scale clinical sovereignty for hospitals, universities, and multi-specialty health systems.",
    features: [
      "Everything in Standard",
      "Institutional Registry Sync",
      "SOC-2 Type II + HIPAA Secure",
      "FHIR R4 Gateway Integration",
      "Dedicated Technical Strategist",
      "On-premise Kernel Options"
    ],
    cta: "Contact Clinical Sales",
    highlight: true,
    color: "accent"
  },
  {
    name: "Research & Intelligence",
    price: "$599",
    description: "Advanced population analytics and longitudinal data tracking for high-velocity research teams.",
    features: [
      "High-density Intelligence Hub",
      "Longitudinal Variance Protocols",
      "Population Risk Stratification",
      "Registry Export (JSON/FHIR)",
      "Institutional AI Training Node"
    ],
    cta: "Begin Research",
    highlight: false,
    color: "purple"
  }
];

const featureMatrix = [
  { feature: "AI Intake Latency", standard: "< 2s", institutional: "< 800ms", research: "< 1.2s" },
  { feature: "Registry Scoping", standard: "Individual", institutional: "Institutional", research: "Population" },
  { feature: "FHIR R4 Gateway", standard: "Manual Export", institutional: "Native Bridge", research: "Native Bridge" },
  { feature: "Zero-Trust Isolation", standard: "Shared Node", institutional: "Isolated Node", research: "Isolated Node" },
  { feature: "Data Sovereignty", standard: "Cloud Slates", institutional: "Private Slates", research: "On-Prem Options" },
  { feature: "Intelligence API", standard: "Limited", institutional: "High-Throughput", research: "Full Analytics" },
];

export default function PricingPage() {
  return (
    <div className="bg-white min-h-screen">
      <SEO 
        title="Institutional Pricing Protocols" 
        description="Transparent protocols for high-fidelity clinical intelligence. Explore our Standard, Institutional, and Research tiers with absolute medical sovereignty."
        schema={getMedicalWebPageSchema("Institutional Pricing", "Transparent protocols for high-fidelity clinical intelligence.")}
      />
      <LandingNavbar />
      
      <main className="pt-40 pb-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
          <div className="text-center mb-24">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/5 border border-accent/10 mb-6">
                <ShieldCheck size={14} className="text-accent" />
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-accent">Value Sovereignty Verified</span>
              </div>
              <h1 className="text-[56px] lg:text-[84px] font-serif tracking-tight text-text leading-[0.9] mb-8">
                Institutional <br/><span className="italic text-accent">Pricing Protocols.</span>
              </h1>
              <p className="text-[18px] lg:text-[20px] text-muted/70 max-w-2xl mx-auto font-medium leading-relaxed">
                Engineering the economics of healthcare through transparent, institutional-grade protocols. Built for sovereignty, scale, and medical accuracy.
              </p>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32">
            {pricingTiers.map((tier, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className={`relative p-10 rounded-[40px] border transition-all duration-300 flex flex-col h-full group ${
                  tier.highlight 
                    ? 'border-accent bg-accent/[0.02] shadow-2xl shadow-accent/10 scale-105 z-10' 
                    : 'border-border bg-white hover:border-accent/40 shadow-sm'
                }`}
              >
                {tier.highlight && (
                  <div className="absolute top-0 right-10 -translate-y-1/2 px-4 py-2 bg-text text-white text-[10px] font-black uppercase tracking-widest rounded-full shadow-xl">
                    Institutional Standard
                  </div>
                )}
                
                <div className="mb-10">
                  <h3 className={`text-[11px] font-black uppercase tracking-[0.3em] mb-6 ${tier.color === 'accent' ? 'text-accent' : 'text-muted/40'}`}>
                    {tier.name}
                  </h3>
                  <div className="flex items-baseline gap-2 mb-6">
                    <span className="text-[48px] font-serif font-black tracking-tighter text-text">{tier.price}</span>
                    {tier.price !== "Custom" && <span className="text-[13px] text-muted/40 font-bold uppercase tracking-widest">/ Node / Mo</span>}
                  </div>
                  <p className="text-[15px] text-muted/70 leading-relaxed font-medium">
                    {tier.description}
                  </p>
                </div>

                <div className="space-y-5 mb-12 flex-1">
                  {tier.features.map((feature, fidx) => (
                    <div key={fidx} className="flex items-start gap-4">
                      <div className="mt-1 w-5 h-5 rounded-full bg-accent/5 flex items-center justify-center shrink-0 border border-accent/10">
                        <Check size={11} className="text-accent" />
                      </div>
                      <span className="text-[14px] font-bold text-text/80 leading-snug">{feature}</span>
                    </div>
                  ))}
                </div>

                <Link 
                  to={tier.cta.includes("Contact") ? "/contact" : "/request-trial"}
                  className={`w-full py-5 rounded-2xl text-[14px] font-black uppercase tracking-widest transition-all text-center flex items-center justify-center gap-3 group/btn ${
                    tier.highlight 
                      ? 'bg-text text-white hover:bg-black shadow-xl shadow-black/10' 
                      : 'bg-off text-text hover:bg-border/60 border border-border/40'
                  }`}
                >
                  {tier.cta} <ArrowRight size={18} className="group-hover/btn:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Feature Protocol Matrix (Ultra-Detailed) */}
          <section className="mb-32">
            <div className="text-center mb-16">
              <h2 className="text-[32px] font-serif italic text-text mb-4">Feature Protocol Matrix</h2>
              <p className="text-muted/60 text-[15px] font-medium">Technical specifications across institutional nodes.</p>
            </div>
            
            <div className="overflow-hidden border border-border/60 rounded-[32px] bg-white shadow-sm">
               <table className="w-full text-left border-collapse">
                  <thead>
                     <tr className="bg-off/50">
                        <th className="px-8 py-5 text-[11px] font-black uppercase tracking-widest text-muted/40 border-b border-border/60">Protocol Feature</th>
                        <th className="px-8 py-5 text-[11px] font-black uppercase tracking-widest text-muted/40 border-b border-border/60">Standard</th>
                        <th className="px-8 py-5 text-[11px] font-black uppercase tracking-widest text-accent border-b border-border/60">Institutional</th>
                        <th className="px-8 py-5 text-[11px] font-black uppercase tracking-widest text-muted/40 border-b border-border/60">Research</th>
                     </tr>
                  </thead>
                  <tbody>
                     {featureMatrix.map((row, i) => (
                        <tr key={i} className="hover:bg-off/30 transition-colors">
                           <td className="px-8 py-5 text-[14px] font-black text-text border-b border-border/40">{row.feature}</td>
                           <td className="px-8 py-5 text-[14px] font-bold text-muted/60 border-b border-border/40">{row.standard}</td>
                           <td className="px-8 py-5 text-[14px] font-black text-accent border-b border-border/40">{row.institutional}</td>
                           <td className="px-8 py-5 text-[14px] font-bold text-muted/60 border-b border-border/40">{row.research}</td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>
          </section>

          <section className="py-20 lg:py-24 px-10 sm:px-16 rounded-[48px] bg-text text-white relative overflow-hidden text-center sm:text-left">
             <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-accent-vibrant/10 blur-[120px] rounded-full -mr-40 -mt-40"></div>
             <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 items-center gap-16">
                <div>
                  <div className="w-16 h-16 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center mb-8 shadow-2xl">
                    <Database size={32} className="text-accent-vibrant" />
                  </div>
                   <h2 className="text-[42px] lg:text-[56px] font-serif mb-8 leading-[1.1] tracking-tight">Need a custom technical sovereign environment?</h2>
                   <p className="text-white/60 text-[18px] mb-12 max-w-xl leading-relaxed">
                      We offer complete on-premise and private cloud deployments for institutions requiring total control over their clinical data kernels and private AI weights.
                   </p>
                   <div className="flex flex-wrap justify-center sm:justify-start gap-4">
                      <div className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/5 border border-white/10 text-[12px] font-bold uppercase tracking-widest">
                        <ShieldCheck size={16} className="text-accent-vibrant" /> HIPAA + SOC-2 v2 Certified
                      </div>
                      <div className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/5 border border-white/10 text-[12px] font-bold uppercase tracking-widest">
                        <Database size={16} className="text-accent-vibrant" /> Private Institutional Node
                      </div>
                   </div>
                </div>
                <div className="flex lg:justify-end">
                   <Link to="/contact" className="w-full sm:w-auto px-12 py-6 bg-white text-black rounded-full font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all shadow-2xl shadow-black/20 group text-center">
                      Consult with Medical Engineering <ArrowRight size={20} className="inline ml-3 group-hover:translate-x-1 transition-transform" />
                   </Link>
                </div>
             </div>
          </section>
        </div>
      </main>

      <LandingFooter />
    </div>
  );
}
