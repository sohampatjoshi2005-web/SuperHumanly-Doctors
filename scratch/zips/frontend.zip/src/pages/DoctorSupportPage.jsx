import { useState, useEffect } from 'react';
import { Database, Workflow, LogOut, ShieldAlert, X, Menu, Users, Plus, ShieldCheck, Lock, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import Sidebar from '../components/doctor/Sidebar';
import WorkflowTab from '../components/doctor/WorkflowTab';
import DatabaseTab from '../components/doctor/DatabaseTab';
import EHRSyncTab from '../components/doctor/EHRSyncTab'; // NEW
import IntelligenceTab from '../components/doctor/IntelligenceTab'; // NEW
import ClinicTab from '../components/doctor/ClinicTab'; // NEW
import InteractiveTutorial from '../components/ui/InteractiveTutorial';
import UpgradeModal from '../components/doctor/UpgradeModal';
import { fetchTrialStatus } from '../lib/doctorApi';
import { Activity, Globe, Sparkles, Cpu } from 'lucide-react'; // Added icons

export default function DoctorSupportPage() {
  const [activeTab, setActiveTab] = useState('ambient'); // 'ambient', 'ehr', 'intelligence'
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [encounterToLoad, setEncounterToLoad] = useState(null);
  const [activeEncounterId, setActiveEncounterId] = useState(null);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [isMenuOpenMobile, setIsMenuOpenMobile] = useState(false);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [recentPatients, setRecentPatients] = useState([]);
  const [trialData, setTrialData] = useState(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  const loadTrialStatus = async () => {
    try {
      const data = await fetchTrialStatus();
      setTrialData(data);
    } catch (e) {
      console.error('Failed to load trial status', e);
    }
  };

  // Manage Recent Patients
  useEffect(() => {
    const saved = localStorage.getItem('recent_patients');
    if (saved) setRecentPatients(JSON.parse(saved));
    
    const savedUser = localStorage.getItem('doc_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
    }
    
    loadTrialStatus();
  }, []);

  useEffect(() => {
    if (selectedCustomer && selectedCustomer.id !== 'TUT-001') {
      setRecentPatients(prev => {
        const updated = [selectedCustomer, ...prev.filter(p => p.id !== selectedCustomer.id)].slice(0, 5);
        localStorage.setItem('recent_patients', JSON.stringify(updated));
        return updated;
      });
    }
  }, [selectedCustomer]);

  // Close drawers on tab change
  useEffect(() => {
    setIsMenuOpenMobile(false);
    setShowMobileSidebar(false);
  }, [activeTab]);

  // When a user selects 'Load' from the Sidebar History
  const handleLoadEncounter = (encounter) => {
    setActiveTab('ambient');
    setActiveEncounterId(encounter.id);
    setEncounterToLoad({ ...encounter, _loadTimestamp: Date.now() });
  };

  const handleFinalLogout = () => {
    localStorage.removeItem('doc_token');
    localStorage.removeItem('doc_user');
    navigate('/auth');
  };

  return (
    <div className="max-w-[1900px] mx-auto pt-32 lg:pt-2 px-0 lg:px-2 flex flex-col min-h-screen lg:h-screen pb-2 fade-in relative overflow-x-hidden lg:overflow-hidden">
      <InteractiveTutorial 
        setActiveTab={setActiveTab} 
        activeTab={activeTab} 
        setSelectedCustomer={setSelectedCustomer}
      />
      {/* Immersive background decoration similar to other sections */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-accent-light/40 rounded-full blur-[120px] -z-10 pointer-events-none mix-blend-multiply"></div>
      
      {/* Mobile Header (Standard Institutional) */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-[100] bg-white">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-border/60">
          <Link to="/" className="flex items-center gap-2.5 no-underline">
            <div className="w-8 h-8 bg-text rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">S</span>
            </div>
            <span className="font-serif text-[20px] text-text font-medium tracking-tight">Superhumanly <span className="italic text-accent">Doctors</span></span>
          </Link>
          
          <button 
            onClick={() => setIsMenuOpenMobile(true)}
            className="p-2 -mr-2 text-text hover:text-accent transition-colors"
          >
            <Menu size={24} />
          </button>
        </div>

        {/* Quick Continuity Bar (Mobile Only) */}
        <div className="px-4 py-2 border-b border-border/40 flex items-center gap-3 overflow-x-auto no-scrollbar bg-[linear-gradient(180deg,rgba(248,250,252,0.98),rgba(243,246,250,0.94))] backdrop-blur-md">
           <button 
             onClick={() => setShowMobileSidebar(true)}
             className="w-10 h-10 rounded-2xl border border-border/70 bg-white shadow-sm flex items-center justify-center text-text shrink-0"
           >
             <Users size={16} />
           </button>
           <div className="w-px h-6 bg-border/60 shrink-0" />
           <div className="flex items-center gap-3 pr-4">
              {recentPatients.length === 0 ? (
                <span className="text-[10px] font-bold text-muted/40 uppercase tracking-[0.16em] whitespace-nowrap">No Recent Continuity</span>
              ) : (
                recentPatients.map(p => (
                  <button 
                    key={p.id}
                    onClick={() => setSelectedCustomer(p)}
                    className={`h-10 px-1.5 rounded-2xl border flex items-center gap-2.5 transition-all shrink-0 ${
                      selectedCustomer?.id === p.id 
                        ? 'bg-accent border-accent text-white shadow-[0_10px_24px_rgba(0,82,204,0.24)]' 
                        : 'bg-white/95 border-border/80 text-text2 hover:border-accent shadow-sm'
                    }`}
                  >
                    <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-md font-black ${selectedCustomer?.id === p.id ? 'bg-white/20' : 'bg-accent/10 text-accent'}`}>
                       {p.name.split(' ').map(n=>n[0]).join('').toUpperCase()}
                    </div>
                    <span className="text-md font-black tracking-tight whitespace-nowrap pr-2">{p.name.split(' ')[0]}</span>
                  </button>
                ))
              )}
           </div>
        </div>
      </div>

      {/* ═══ UNIFIED MOBILE DRAWER ═══ */}
      <AnimatePresence>
        {isMenuOpenMobile && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpenMobile(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[1000] lg:hidden"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 250 }}
              className="fixed top-0 right-0 bottom-0 w-full max-w-[300px] bg-white z-[1001] lg:hidden shadow-[-10px_0_40px_rgba(0,0,0,0.05)] flex flex-col"
            >
              <div className="flex items-center justify-between px-7 pt-8 pb-4 mb-2">
                 <span className="text-2xl font-medium text-text font-serif">Medical Terminal</span>
                 <button onClick={() => setIsMenuOpenMobile(false)} className="p-2 -mr-2 text-muted/30 hover:text-text transition-colors">
                    <X size={20} />
                 </button>
              </div>

              <div className="flex-1 px-4 space-y-1">
                {[
                  { id: 'ambient', label: 'Ambient Notes', icon: Activity },
                  { id: 'ehr', label: 'System Sync', icon: Globe },
                  { id: 'intelligence', label: 'Clinical Logic', icon: Sparkles },
                  ...(user?.role === 'clinic_admin' || user?.role === 'admin' ? [
                    { id: 'clinic', label: 'Clinic Admin', icon: ShieldCheck }
                  ] : [])
                ].map(tab => (
                  <button 
                    key={tab.id}
                    className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-[15px] font-bold transition-all ${
                      activeTab === tab.id 
                        ? 'bg-text text-white shadow-lg' 
                        : 'bg-transparent text-text2 hover:bg-off'
                    }`}
                    onClick={() => setActiveTab(tab.id)}
                  >
                    <tab.icon size={18} className={activeTab === tab.id ? 'text-white' : 'text-accent/60'} />
                    {tab.label}
                  </button>
                ))}

                <div className="h-px bg-border/40 my-6 mx-4" />
                
                <button 
                  onClick={() => { setIsMenuOpenMobile(false); setTimeout(() => setShowMobileSidebar(true), 200); }}
                  className="w-full flex items-center gap-4 px-5 py-4 text-[15px] font-bold text-text2 hover:bg-off transition-all rounded-2xl"
                >
                  <Users size={18} className="text-accent/60" /> Patient Registry
                </button>
              </div>

              <div className="mt-auto p-6">
                <button 
                  onClick={() => {
                    setIsMenuOpenMobile(false);
                    setShowLogoutConfirm(true);
                  }}
                  className="w-full h-12 flex items-center justify-center gap-2 text-red-500 text-[14px] font-bold border border-red-50 hover:bg-red-50 rounded-xl transition-all"
                >
                  <LogOut size={16} /> Secure Log Out
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {showMobileSidebar && (
        <div className="lg:hidden">
          <Sidebar 
            selectedCustomer={selectedCustomer} 
            setSelectedCustomer={setSelectedCustomer}
            onLoadEncounter={handleLoadEncounter}
            isCollapsed={false}
            setIsCollapsed={setIsSidebarCollapsed}
            isOpenMobile={showMobileSidebar}
            onCloseMobile={() => setShowMobileSidebar(false)}
          />
        </div>
      )}
      
      {/* ═══ UNIFIED ATTACHED HORIZON (Bold Logo + Large Tabs + Actions) ═══ */}
      <div 
        className="hidden lg:flex items-end justify-between px-0 relative z-[110] translate-y-[1px] transition-all duration-500 pt-0"
      >
        {/* Left: Prominent Brand Section - Synchronized Motion */}
        <motion.div 
          initial={false}
          animate={{ 
            width: isSidebarCollapsed ? 80 : 320 
          }}
          transition={{
            type: 'spring',
            stiffness: 400,
            damping: 40,
            mass: 1
          }}
          className="flex items-center gap-4 pt-0 pb-3 pl-0 shrink-0 overflow-hidden"
        >
          <Link to="/" className="flex items-center gap-3 no-underline hover:opacity-90 transition-opacity group shrink-0">
            <div className="w-9 h-9 bg-text rounded-full flex items-center justify-center shadow-[0_8px_24px_rgba(0,0,0,0.12)] transition-all duration-300 group-hover:rotate-3 group-hover:scale-110">
              <span className="text-white font-bold text-xl">S</span>
            </div>
            {!isSidebarCollapsed && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="font-serif text-[24px] text-text tracking-tighter font-medium leading-none whitespace-nowrap"
              >
                Superhumanly <span className="italic text-accent font-medium">Doctors</span>
              </motion.div>
            )}
          </Link>
        </motion.div>

        {/* Center: Large Docked Tabs */}
        <div className="flex-1 flex items-end gap-1.5 pl-0">
          {[
            { id: 'ambient', label: 'Ambient Notes', icon: Activity },
            { id: 'ehr', label: 'EHR Sync', icon: Globe },
            { id: 'intelligence', label: 'Clinical Logic', icon: Sparkles },
            { id: 'database', label: 'Patient Registry', icon: Users },
            ...((user?.role === 'clinic_admin' || user?.role === 'admin') ? [{ id: 'clinic', label: 'Clinic Admin', icon: ShieldCheck }] : [])
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => {
                if (tab.id === 'ambient') { setActiveTab('ambient'); setEncounterToLoad(null); }
                else setActiveTab(tab.id);
              }}
              className={`group relative flex items-center gap-3 px-5 py-3 rounded-t-[20px] text-md font-black transition-all duration-300 ${
                activeTab === tab.id 
                  ? 'bg-white border-t border-x border-border/60 text-text shadow-[0_-8px_24px_rgba(0,0,0,0.03)]' 
                  : 'bg-off/40 hover:bg-white/80 text-muted/90 hover:text-text border-t border-x border-transparent hover:border-border/20 hover:shadow-[0_-4px_12px_rgba(0,0,0,0.02)]'
              }`}
            >
              <tab.icon size={18} className={`${activeTab === tab.id ? 'text-accent' : 'text-muted/90 group-hover:text-accent/60'} transition-colors`} />
              <span className="tracking-tight">{tab.label}</span>
              
              {/* Masking Bridge - Attaches Tab to Container */}
              {activeTab === tab.id && (
                <motion.div 
                  layoutId="activeTabBridge"
                  className="absolute bottom-[-1px] left-0 right-0 h-[2px] bg-white z-50" 
                />
              )}
            </button>
          ))}
        </div>


        {/* Right: Global Actions */}
        <div className="flex items-center gap-6 pt-0 pb-2 pr-0">
          <button 
            id="tutorial-logout-btn"
            onClick={() => setShowLogoutConfirm(true)}
            className="flex items-center gap-2 px-5 py-2 rounded-xl text-[12px] font-black bg-white border border-border/60 text-red-500 hover:bg-red-50 transition-all shadow-sm active:scale-95"
          >
            <LogOut size={14} /> Log Out
          </button>
        </div>
      </div>


      {/* Logout Confirmation Modal */}
      <AnimatePresence>
        {showLogoutConfirm && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLogoutConfirm(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[1000] flex items-center justify-center p-4"
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white rounded-[32px] w-full max-w-[440px] overflow-hidden shadow-[0_32px_100px_-20px_rgba(0,0,0,0.15)] border border-border"
              >
                <div className="p-8">
                  <div className="flex justify-between items-start mb-8">
                    <div className="w-14 h-14 rounded-2xl bg-red-50 flex items-center justify-center text-red-600">
                      <ShieldAlert size={28} />
                    </div>
                    <button 
                      onClick={() => setShowLogoutConfirm(false)}
                      className="p-2 hover:bg-off rounded-full text-muted transition-colors"
                    >
                      <X size={20} />
                    </button>
                  </div>

                  <h2 className="font-serif text-[32px] tracking-tight text-text mb-3 leading-tight">
                    Terminate <span className="italic text-red-600">Secure Session</span>?
                  </h2>
                  <p className="text-[16px] text-muted/60 font-medium leading-relaxed mb-10 pl-1">
                    You are about to exit the clinical registry. Ensure all encounter notes are saved before proceeding.
                  </p>

                  <div className="flex flex-col gap-3">
                    <button 
                      onClick={handleFinalLogout}
                      className="w-full py-4 bg-red-600 text-white rounded-full text-[15px] font-bold shadow-lg shadow-red-200 hover:bg-red-700 transition-all active:scale-[0.98]"
                    >
                      Confirm and Logout
                    </button>
                    <button 
                      onClick={() => setShowLogoutConfirm(false)}
                      className="w-full py-4 bg-off text-text rounded-full text-[15px] font-bold hover:bg-border/40 transition-all"
                    >
                      Remain in Workspace
                    </button>
                  </div>
                </div>
                
                <div className="bg-red-50/50 py-4 px-8 border-t border-red-100 flex items-center justify-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
                  <span className="text-[11px] font-black uppercase tracking-widest text-red-600/60">Sovereignty Protocol Verified</span>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>


      <div className="flex flex-1 border-0 lg:border border-border bg-transparent lg:bg-white rounded-none lg:rounded-[24px] shadow-none lg:shadow-[0_12px_60px_rgba(0,0,0,0.05),inset_0_1px_rgba(255,255,255,0.8)] overflow-visible lg:overflow-hidden mb-0 relative">
        
        {/* Sidebar */}
        <Sidebar 
          selectedCustomer={selectedCustomer} 
          setSelectedCustomer={setSelectedCustomer}
          onLoadEncounter={handleLoadEncounter}
          isCollapsed={isSidebarCollapsed}
          setIsCollapsed={setIsSidebarCollapsed}
          isOpenMobile={false}
          onCloseMobile={() => setShowMobileSidebar(false)}
          trialData={trialData}
          onUpgradeClick={() => setShowUpgradeModal(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 bg-transparent lg:bg-white relative overflow-visible lg:overflow-hidden">
          <motion.div layout className="h-auto lg:h-full">
            <AnimatePresence mode="wait">
              {activeTab === 'database' && (
                 <motion.div 
                   key="database"
                   initial={{ opacity: 0, x: 10 }}
                   animate={{ opacity: 1, x: 0 }}
                   exit={{ opacity: 0, x: -10 }}
                   transition={{ duration: 0.3, ease: "easeInOut" }}
                   className="h-full"
                 >
                   <DatabaseTab 
                      setActiveTab={setActiveTab} 
                      setSelectedCustomer={setSelectedCustomer}
                   />
                 </motion.div>
              )}
              {activeTab === 'ambient' && (
                 <motion.div 
                   key="ambient"
                   initial={{ opacity: 0, x: 10 }}
                   animate={{ opacity: 1, x: 0 }}
                   exit={{ opacity: 0, x: -10 }}
                   transition={{ duration: 0.3, ease: "easeInOut" }}
                   className="h-auto lg:h-full"
                 >
                   <WorkflowTab 
                      selectedCustomer={selectedCustomer} 
                      encounterToLoad={encounterToLoad}
                      onEncounterActive={setActiveEncounterId}
                      trialData={trialData}
                      onUpgradeClick={() => setShowUpgradeModal(true)}
                      onTrialRefresh={loadTrialStatus}
                   />
                 </motion.div>
              )}
              {activeTab === 'ehr' && (
                 <motion.div 
                   key="ehr"
                   initial={{ opacity: 0, x: 10 }}
                   animate={{ opacity: 1, x: 0 }}
                   exit={{ opacity: 0, x: -10 }}
                   transition={{ duration: 0.3, ease: "easeInOut" }}
                   className="h-full"
                 >
                   <EHRSyncTab 
                      setActiveTab={setActiveTab} 
                      activeEncounterId={activeEncounterId}
                   />
                 </motion.div>
              )}
              {activeTab === 'intelligence' && (
                 <motion.div 
                   key="intelligence"
                   initial={{ opacity: 0, x: 10 }}
                   animate={{ opacity: 1, x: 0 }}
                   exit={{ opacity: 0, x: -10 }}
                   transition={{ duration: 0.3, ease: "easeInOut" }}
                   className="h-full"
                 >
                   <IntelligenceTab />
                 </motion.div>
              )}
              {activeTab === 'clinic' && (
                 <motion.div 
                   key="clinic"
                   initial={{ opacity: 0, x: 10 }}
                   animate={{ opacity: 1, x: 0 }}
                   exit={{ opacity: 0, x: -10 }}
                   transition={{ duration: 0.3, ease: "easeInOut" }}
                   className="h-full"
                 >
                   <ClinicTab />
                 </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </main>

      </div>

      <UpgradeModal 
        isOpen={showUpgradeModal} 
        onClose={() => setShowUpgradeModal(false)} 
        trialData={trialData}
      />
    </div>
  );
}
