import { useState, useRef, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, Lock, Activity, ArrowRight, 
  User, Mail, Building, Stethoscope, CheckCircle2,
  Fingerprint, Database, Zap, Globe, Cpu
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SEO from '../components/SEO';
import { submitTrialRequest } from '../lib/doctorApi';

/* ─── floating clinical metrics ─── */
const MEDICAL_FLOATING_CARDS = [
  { icon: Activity, label: 'Transcription', stat: '98.4%', statLabel: 'Accuracy Rating', color: '#60a5fa', x: '5%', y: '20%', delay: 0.05, rotate: -6 },
  { icon: ShieldCheck, label: 'Sovereignty', stat: 'NIST-256', statLabel: 'Verified Cloud', color: '#10b981', x: '78%', y: '14%', delay: 0.1, rotate: 4 },
  { icon: Zap, label: 'Hub Velocity', stat: '0.4s', statLabel: 'Sync Latency', color: '#f59e0b', x: '80%', y: '68%', delay: 0.15, rotate: -3 },
  { icon: Database, label: 'Registry', stat: 'v4.2', statLabel: 'Zero-Trust Hub', color: '#0052cc', x: '3%', y: '72%', delay: 0.2, rotate: 5 },
];

function FloatingCard({ icon: Icon, label, stat, statLabel, color, x, y, delay, rotate }) {
  return (
    <div
      className="absolute z-[2] pointer-events-none select-none hidden lg:block"
      style={{
        left: x, top: y,
        rotate: `${rotate}deg`,
        '--sx': `calc(50vw - ${x} - 92.5px)`, 
        '--sy': `calc(50vh - ${y} - 62.5px)`,
        animation: `cardReveal 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${0.35 + delay * 1.8}s both`,
      }}
    >
      <div
        className="rounded-[20px] border border-border bg-white p-4 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.08),0_8px_20px_-8px_rgba(0,0,0,0.04)]"
        style={{ 
          width: 185,
          animation: `floatCard 14s ease-in-out infinite ${delay + 0.6}s`,
        }}
      >
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-8 h-8 rounded-[10px] flex items-center justify-center" style={{ background: `${color}12` }}>
            <Icon size={16} style={{ color }} />
          </div>
          <span className="text-[12px] font-bold text-text2 tracking-tight">{label}</span>
        </div>
        <div className="font-serif text-[28px] text-text tracking-[-0.04em] leading-none mb-0.5">{stat}</div>
        <div className="text-[10.5px] font-semibold text-muted uppercase tracking-[0.06em]">{statLabel}</div>
        <div className="absolute top-3 right-3">
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: `${color}30`, boxShadow: `0 0 8px ${color}20` }} />
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   REQUEST TRIAL PAGE — FLAGSHIP ULTRA REDESIGN
   ═══════════════════════════════════════════════════════ */
export default function RequestTrialPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({ 
    full_name: '', 
    institution: '', 
    email: '', 
    professional_role: '',
    use_case: '' 
  });
  const [focusedField, setFocusedField] = useState(null);
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const navigate = useNavigate();

  useEffect(() => {
    const handleMouseMove = (e) => {
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      const x = clientX / innerWidth;
      const y = clientY / innerHeight;
      setMousePos({ x, y });
      const tiltX = (y - 0.5) * 5;
      const tiltY = (x - 0.5) * -5;
      setTilt({ x: tiltX, y: tiltY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      await submitTrialRequest({
        full_name: formData.full_name,
        email: formData.email,
        institution: formData.institution,
        professional_role: formData.professional_role,
        use_case: formData.use_case || 'General Clinical Documentation'
      });
      setIsSubmitted(true);
    } catch (err) {
      setError(err.message || 'Transmission failure. Please re-verify clinical credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-[#f8f8f6] flex items-center justify-center font-sans">
      <SEO 
        title="Request Private Trial" 
        description="Initiate an institutional pilot for the Superhumanly Doctors AI documentation platform. Experience sovereign clinical intelligence."
      />
      
      {/* ═══ FLAGSHIP MESH GRADIENT (Medical Palette) ═══ */}
      <div className="absolute inset-0 z-0">
        <div className="absolute w-[800px] h-[800px] rounded-full opacity-[0.08] blur-[150px]"
          style={{ background: 'radial-gradient(circle, #60a5fa 0%, transparent 70%)', left: `${30 + mousePos.x * 10}%`, top: `${20 + mousePos.y * 10}%`, transform: 'translate(-50%, -50%)', transition: 'left 2s ease-out, top 2s ease-out' }} />
        <div className="absolute w-[500px] h-[500px] rounded-full opacity-[0.06] blur-[120px]"
          style={{ background: 'radial-gradient(circle, #0052cc 0%, transparent 70%)', right: `${15 + (1 - mousePos.x) * 5}%`, bottom: `${15 + (1 - mousePos.y) * 5}%`, transition: 'right 2.5s ease-out, bottom 2.5s ease-out' }} />
      </div>

      {/* Tech Dot Grid */}
      <div className="absolute inset-0 z-[1] opacity-[0.035]"
        style={{ backgroundImage: 'radial-gradient(#0052cc 0.5px, transparent 0.5px)', backgroundSize: '32px 32px' }} />

      {/* ═══ FLAGSHIP ORBITING RINGS ═══ */}
      <div className="absolute inset-0 z-[1] pointer-events-none flex items-center justify-center">
        {[440, 680, 920].map((size, i) => (
          <div key={i} className="absolute rounded-full border"
            style={{ width: size, height: size, borderColor: `rgba(0, 82, 204, ${0.05 - i * 0.012})`, animation: `orbitSpin ${28 + i * 18}s linear infinite`, animationDelay: `${i * 3}s` }}>
            <div className="absolute w-1.5 h-1.5 rounded-full shadow-[0_0_12px_rgba(96,165,250,0.4)]"
              style={{ top: -3, left: '50%', transform: 'translateX(-50%)', backgroundColor: `rgba(96,165,250, ${0.35 - i * 0.05})` }} />
          </div>
        ))}
      </div>

      {/* ═══ MEDICAL FLOATING CARDS ═══ */}
      {MEDICAL_FLOATING_CARDS.map((card, i) => (
        <FloatingCard key={i} {...card} />
      ))}

      {/* ═══ TOP NAVBAR ═══ */}
      <div className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-10 py-6">
        <Link to="/" className="flex items-center gap-3 no-underline group">
          <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center shadow-lg shadow-accent/20 transition-all duration-500 group-hover:scale-110 group-hover:rotate-6">
            <span className="text-white font-black text-sm">S</span>
          </div>
          <span className="font-serif text-[24px] text-text tracking-tighter">Superhumanly <span className="italic text-accent">Medical</span></span>
        </Link>
        <Link to="/auth" className="px-6 py-2.5 rounded-full border border-border bg-white/80 backdrop-blur-sm text-[13px] font-bold text-text2 hover:bg-white hover:shadow-xl transition-all active:scale-95 no-underline">
          Physician Sign in
        </Link>
      </div>

      {/* ═══ 3D TILT REQUEST CARD ═══ */}
      <div className="relative z-10 w-full max-w-[540px] mx-4" style={{ animation: 'heroReveal 1.2s cubic-bezier(0.16, 1, 0.3, 1) 0.1s both' }}>
        <div className="transition-transform duration-300 ease-out" style={{ transform: `perspective(1200px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}>
          
          {/* Rotating Gradient Border */}
          <div className="absolute -inset-[1px] rounded-[36px] z-0 overflow-hidden shadow-2xl">
            <div className="absolute inset-[-50%] w-[200%] h-[200%]"
              style={{ background: 'conic-gradient(from 0deg, transparent 0%, rgba(96,165,250,0.3) 8%, transparent 16%, transparent 50%, rgba(0,82,204,0.2) 58%, transparent 66%, transparent 100%)', animation: 'borderSpin 10s linear infinite', left: '-50%', top: '-50%' }} />
            <div className="absolute inset-[1px] rounded-[35px] bg-white" />
          </div>

          {/* Card Body */}
          <div className="relative z-10 rounded-[36px] border border-border bg-white overflow-hidden shadow-[0_40px_120px_-30px_rgba(0,0,0,0.12),0_0_1px_rgba(0,0,0,0.05)]">
            <div className="p-10 lg:p-12">
              
              <AnimatePresence mode="wait">
                {!isSubmitted ? (
                  <motion.div
                    key="form"
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15, scale: 0.98 }}
                    transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                  >
                    <div className="text-center mb-10">
                      <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-off border border-border text-[10px] font-black uppercase tracking-[0.15em] text-muted mb-6">
                        <Activity size={12} className="text-accent" /> Institutional Trial Hub
                      </div>
                      <h1 className="font-serif text-[42px] leading-tight tracking-tighter text-text mb-4">
                        Initialize your clinical <span className="italic text-accent">trial protocol.</span>
                      </h1>
                      <p className="text-[15px] text-muted font-bold max-w-[420px] mx-auto leading-relaxed">
                        Join the physicians setting the new standard for documentation architecture. Deployment within 24 hours.
                      </p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-5">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Name Field */}
                        <div className="space-y-2">
                          <label className="text-[14px] font-bold text-text2/70 pl-1" htmlFor="full_name">Full Name</label>
                          <div className={`group relative rounded-2xl border transition-all duration-300 ${focusedField === 'full_name' ? 'border-accent ring-4 ring-accent/5 bg-white shadow-lg' : 'border-border/60 bg-off'}`}>
                             <input required id="full_name" type="text" value={formData.full_name} onChange={e => setFormData({...formData, full_name: e.target.value})} onFocus={() => setFocusedField('full_name')} onBlur={() => setFocusedField(null)}
                               className="w-full px-5 py-3.5 bg-transparent border-none text-[14px] font-bold text-text focus:outline-none" placeholder="Dr. Alexander Smith" disabled={isLoading} />
                          </div>
                        </div>
                        {/* Role Field */}
                        <div className="space-y-2">
                          <label className="text-[14px] font-bold text-text2/70 pl-1" htmlFor="professional_role">Professional Role</label>
                          <div className={`group relative rounded-2xl border transition-all duration-300 ${focusedField === 'professional_role' ? 'border-accent ring-4 ring-accent/5 bg-white shadow-lg' : 'border-border/60 bg-off'}`}>
                             <input required id="professional_role" type="text" value={formData.professional_role} onChange={e => setFormData({...formData, professional_role: e.target.value})} onFocus={() => setFocusedField('professional_role')} onBlur={() => setFocusedField(null)}
                               className="w-full px-5 py-3.5 bg-transparent border-none text-[14px] font-bold text-text focus:outline-none" placeholder="Senior Cardiologist" disabled={isLoading} />
                          </div>
                        </div>
                      </div>

                      {/* Institution Field */}
                      <div className="space-y-2">
                        <label className="text-[14px] font-bold text-text2/70 pl-1" htmlFor="institution">Medical Institution / Practice</label>
                        <div className={`group relative rounded-2xl border transition-all duration-300 ${focusedField === 'institution' ? 'border-accent ring-4 ring-accent/5 bg-white shadow-lg' : 'border-border/60 bg-off'}`}>
                           <Building size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted/30 group-focus-within:text-accent transition-colors" />
                           <input required id="institution" type="text" value={formData.institution} onChange={e => setFormData({...formData, institution: e.target.value})} onFocus={() => setFocusedField('institution')} onBlur={() => setFocusedField(null)}
                             className="w-full pl-12 pr-5 py-3.5 bg-transparent border-none text-[14px] font-bold text-text focus:outline-none" placeholder="Mayo Clinic / Independent Practice" disabled={isLoading} />
                        </div>
                      </div>

                      {/* Email Field */}
                      <div className="space-y-2">
                         <label className="text-[14px] font-bold text-text2/70 pl-1" htmlFor="email">Work Email</label>
                         <div className={`group relative rounded-2xl border transition-all duration-300 ${focusedField === 'email' ? 'border-accent ring-4 ring-accent/5 bg-white shadow-lg' : 'border-border/60 bg-off'}`}>
                            <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted/30 group-focus-within:text-accent transition-colors" />
                            <input required id="email" type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} onFocus={() => setFocusedField('email')} onBlur={() => setFocusedField(null)}
                              className="w-full pl-12 pr-5 py-3.5 bg-transparent border-none text-[14px] font-bold text-text focus:outline-none" placeholder="smith@institution.com" disabled={isLoading} />
                         </div>
                      </div>

                      {/* Use Case Field */}
                      <div className="space-y-2">
                         <label className="text-[14px] font-bold text-text2/70 pl-1" htmlFor="use_case">Primary Objective / Use Case</label>
                         <div className={`group relative rounded-2xl border transition-all duration-300 ${focusedField === 'use_case' ? 'border-accent ring-4 ring-accent/5 bg-white shadow-lg' : 'border-border/60 bg-off'}`}>
                            <Stethoscope size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted/30 group-focus-within:text-accent transition-colors" />
                            <input id="use_case" type="text" value={formData.use_case} onChange={e => setFormData({...formData, use_case: e.target.value})} onFocus={() => setFocusedField('use_case')} onBlur={() => setFocusedField(null)}
                              className="w-full pl-12 pr-5 py-3.5 bg-transparent border-none text-[14px] font-bold text-text focus:outline-none" placeholder="Automating SOAP notes for high-volume cardiology clinic" disabled={isLoading} />
                         </div>
                      </div>

                      {error && (
                        <div className="text-[12px] font-bold text-red-500 bg-red-50 border border-red-100 rounded-xl p-3 text-center">
                          {error}
                        </div>
                      )}

                      <button 
                        type="submit" 
                        disabled={isLoading}
                        className="relative w-full py-4.5 bg-text text-white rounded-full text-[16px] font-bold shadow-xl shadow-black/10 hover:bg-black transition-all active:scale-[0.98] mt-8 flex items-center justify-center gap-3 group/btn overflow-hidden disabled:opacity-50"
                      >
                         <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-[150%] group-hover:translate-x-[150%] transition-transform duration-1000" />
                         {isLoading ? 'Transmitting...' : 'Request Sovereign Trial'} 
                         {!isLoading && <ArrowRight size={18} className="transition-transform group-hover/btn:translate-x-1" />}
                      </button>
                    </form>

                    <div className="mt-12 flex items-center justify-center gap-10">
                       {[
                         { icon: ShieldCheck, label: 'NIST-256' },
                         { icon: Database, label: 'SOC2-II' },
                         { icon: Lock, label: 'Sovereign' }
                       ].map((badge, i) => (
                         <div key={i} className="flex items-center gap-2.5 text-[12px] font-black text-muted/70">
                            <badge.icon size={13} className="text-accent/70" /> {badge.label}
                         </div>
                       ))}
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.95, filter: 'blur(10px)' }}
                    animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
                    transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                    className="text-center"
                  >
                    <div className="w-24 h-24 bg-accent/5 rounded-full flex items-center justify-center mx-auto mb-10 shadow-[0_0_60px_rgba(0,82,204,0.08)]">
                       <CheckCircle2 size={48} className="text-accent" />
                    </div>
                    <h2 className="font-serif text-[48px] leading-[0.95] tracking-tighter text-text mb-6">
                      Protocol <br />
                      <span className="italic text-accent">Verified.</span>
                    </h2>
                    <p className="text-[17px] text-muted font-bold max-w-[360px] mx-auto leading-relaxed mb-12">
                      An Institutional Launch Specialist will contact you at <strong>{formData.email}</strong> within 24 hours to coordinate secure deployment.
                    </p>

                    <div className="p-8 bg-off rounded-3xl border border-border/60 mb-12 flex flex-col gap-2">
                       <div className="text-[10px] font-black uppercase tracking-widest text-muted/40 uppercase">Registry Allocation ID</div>
                       <div className="text-[16px] font-mono font-bold text-text tracking-[0.2em] uppercase">NODE-TRIAL-9922-A</div>
                    </div>

                    <Link to="/" className="inline-flex items-center gap-2 px-10 py-4 bg-text text-white rounded-full text-[15px] font-bold hover:bg-black transition-all active:scale-95 shadow-xl shadow-black/5 no-underline">
                       Return to Command Center <ArrowRight size={18} />
                    </Link>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Institutional Metadata Footer */}
      <div className="fixed bottom-0 left-0 right-0 z-20 py-8 flex items-center justify-center gap-10">
         <div className="flex items-center gap-3">
            <div className="flex -space-x-2">
               {[1,2,3,4].map(i => <div key={i} className="w-7 h-7 rounded-full border-2 border-[#f8f8f6] bg-off shadow-sm" />)}
            </div>
            <span className="text-[12px] font-bold text-muted">Verification Registry <strong className="text-text">Active</strong></span>
         </div>
         <div className="w-px h-4 bg-border/60" />
         <span className="text-[11px] font-black uppercase tracking-widest text-muted/30">© 2026 Superhumanly Medical</span>
      </div>

      <style>{`
        @keyframes orbitSpin { from { transform: translate(-50%, -50%) rotate(0deg); } to { transform: translate(-50%, -50%) rotate(360deg); } }
        @keyframes borderSpin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes floatCard { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-22px); } }
        @keyframes cardReveal { from { opacity: 0; transform: translate(var(--sx), var(--sy)) scale(0.2); filter: blur(12px); } to { opacity: 1; transform: translate(0, 0) scale(1); filter: blur(0); } }
        @keyframes heroReveal { from { opacity: 0; transform: translateY(50px) scale(0.96); filter: blur(8px); } to { opacity: 1; transform: translateY(0) scale(1); filter: blur(0); } }
      `}</style>
    </div>
  );
}
