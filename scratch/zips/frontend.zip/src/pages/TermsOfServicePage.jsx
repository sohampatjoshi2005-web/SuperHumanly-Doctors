import LandingNavbar from '../components/landing/LandingNavbar';
import LandingFooter from '../components/landing/LandingFooter';
import { motion } from 'framer-motion';
import { FileText, Gavel, AlertTriangle, Scale } from 'lucide-react';
import SEO from '../components/SEO';

export default function TermsOfServicePage() {
  const terms = [
    {
      title: "1. Acceptance of Terms",
      content: "By accessing 'Superhumanly Doctors', you agree to be bound by these institutional terms of service. This platform is designed strictly for use by licensed medical professionals and healthcare administrative staff."
    },
    {
      title: "2. License & Access",
      content: "We grant you a non-exclusive, non-transferable, revocable license to access the clinical portal for documented healthcare delivery. Any attempt to reverse engineer the AI weights or scrape clinical kernels is strictly prohibited."
    },
    {
      title: "3. Professional Responsibility",
      content: "Clinicians remain solely responsible for any medical decisions, diagnoses, or prescriptions generated with the assistance of our AI tools. You must review and verify all 'Auto-Prescription' and 'Patient Summary' outputs before therapeutic application."
    },
    {
      title: "4. User Accounts",
      content: "Accounts are user-specific and non-shareable. You are responsible for maintaining the confidentiality of your credentials. Any suspected breach must be reported to our Security Response team immediately."
    },
    {
      title: "5. Service Availability",
      content: "While we aim for 99.99% uptime for institutional nodes, we do not guarantee uninterrupted access during scheduled maintenance or regional network outages. We maintain redundant 'Clinical Slates' to minimize disruption."
    },
    {
      title: "6. Liability Limitations",
      content: "Superhumanly Medical shall not be liable for any medical malpractice, clinical errors, or indirect damages resulting from the use of our software. The platform is an augmentation of care, not a replacement for clinical judgement."
    }
  ];

  return (
    <div className="bg-white min-h-screen">
      <SEO 
        title="Institutional Terms of Service" 
        description="The legal and technical framework governing the use of the Superhumanly Doctors clinical intelligence platform."
      />
      <LandingNavbar />
      
      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-16"
          >
            <div className="flex items-center gap-3 mb-6">
               <Scale size={28} className="text-accent" />
               <span className="text-[12px] font-black uppercase tracking-[0.3em] text-accent">Service Framework v1.2</span>
            </div>
            <h1 className="text-5xl font-serif text-text mb-6">Terms of Service</h1>
            <p className="text-xl text-text2/60 font-medium">
              Legal governance for the future of clinicial intelligence.
            </p>
          </motion.div>

          <div className="space-y-12">
            {terms.map((term, idx) => (
              <div key={idx} className="border-b border-border pb-10">
                <h3 className="text-2xl font-serif text-text mb-4 italic">{term.title}</h3>
                <p className="text-[16px] text-text2/70 leading-[1.8] font-medium">
                  {term.content}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-20 p-8 rounded-[40px] border-2 border-dashed border-border flex items-start gap-6">
             <div className="w-12 h-12 rounded-full bg-off flex items-center justify-center shrink-0">
                <AlertTriangle size={24} className="text-accent" />
             </div>
             <div>
                <h4 className="text-xl font-bold mb-3">Critical Clinical Disclosure</h4>
                <p className="text-text2/60 leading-relaxed font-medium text-[15px]">
                   Superhumanly Doctors is a documentation and management tool. It is NOT a medical device, nor does it provide medical advice. All AI-generated outputs require mandatory physician validation. Using this software constitutes agreement that human clinical judgement is superior and final.
                </p>
             </div>
          </div>
        </div>
      </main>

      <LandingFooter />
    </div>
  );
}
