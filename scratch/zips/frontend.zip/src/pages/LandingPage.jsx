import LandingNavbar from '../components/landing/LandingNavbar';
import HeroSection from '../components/landing/HeroSection';
import Marquee from '../components/landing/Marquee';
import SolutionsSection from '../components/landing/SolutionsSection';
import LandingFooter from '../components/landing/LandingFooter';
import { useState, useEffect } from 'react';
import { ArrowRight, Twitter, Github, Linkedin, ShieldCheck, Database, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

import SEO from '../components/SEO';
import { getOrganizationSchema } from '../lib/StructuredData';

export default function LandingPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('doc_token');
    setIsLoggedIn(!!token);
  }, []);

  return (
    <div className="bg-white selection:bg-accent/10 min-h-screen">
      <SEO 
        title="AI-Powered Clinical Intelligence" 
        description="Engineering the future of clinical documentation. Built for physicians who value technical sovereignty and high-fidelity continuity."
        schema={getOrganizationSchema()}
      />
      <LandingNavbar />
      
      <main className="pt-10">
        <HeroSection />
        <Marquee />
        <SolutionsSection />

        {/* TECHNICAL ECOSYSTEM & INTEROPERABILITY (New Premium Section) */}
        <section className="py-24 sm:py-32 bg-white relative overflow-hidden">
          <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-border to-transparent"></div>
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="flex flex-col lg:flex-row items-center gap-16 lg:gap-24">
              <div className="flex-1">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/5 border border-accent/10 mb-6">
                  <Database size={14} className="text-accent" />
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-accent">Interoperability Protocol</span>
                </div>
                <h2 className="text-[42px] lg:text-[56px] font-serif leading-[1.1] text-text mb-8">
                  Engineered for <br/>
                  <span className="italic text-accent">institutional harmony.</span>
                </h2>
                <p className="text-[17px] text-muted leading-relaxed font-medium mb-12 max-w-xl">
                  Superhumanly Doctors isn't a silo. Our core kernel is built on HL7® FHIR® R4 standards, ensuring your clinical intelligence flows seamlessly between every node in your hospital's ecosystem.
                </p>
                
                <div className="grid grid-cols-2 gap-y-12 gap-x-8">
                  {[
                    { title: "FHIR R4", desc: "Native support for HL7 clinical standard resources.", icon: "01" },
                    { title: "Zero-Trust", desc: "Cryptographic per-user data isolation protocols.", icon: "02" },
                    { title: "HL7 v2", desc: "Legacy bridge for traditional PMS/EHR systems.", icon: "03" },
                    { title: "Smart on FHIR", desc: "Seamless embed capabilities for institutional portals.", icon: "04" }
                  ].map((feat, i) => (
                    <div key={i} className="flex flex-col items-start gap-4">
                      <div className="text-[10px] font-black text-accent font-mono tracking-widest">{feat.icon} // PROTOCOL</div>
                      <h4 className="text-[18px] font-bold text-text">{feat.title}</h4>
                      <p className="text-[13px] text-muted font-medium leading-relaxed">{feat.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex-1 relative w-full aspect-square max-w-[500px]">
                {/* Visual Interoperability Diagram (CSS/SVG) */}
                <div className="absolute inset-0 bg-off rounded-[40px] border border-border shadow-2xl overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-accent-vibrant/5"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative w-full h-full flex items-center justify-center">
                      {/* Animated Central Node */}
                      <motion.div 
                        animate={{ 
                          scale: [1, 1.05, 1],
                          boxShadow: ["0 0 20px rgba(0,82,204,0.1)", "0 0 40px rgba(0,82,204,0.3)", "0 0 20px rgba(0,82,204,0.1)"]
                        }}
                        transition={{ duration: 3, repeat: Infinity }}
                        className="w-24 h-24 rounded-3xl bg-white border border-border flex items-center justify-center z-10 shadow-xl"
                      >
                         <Zap size={32} className="text-accent" />
                      </motion.div>
                      
                      {/* Orbital Nodes */}
                      {[0, 90, 180, 270].map((angle, i) => (
                        <motion.div 
                          key={i}
                          animate={{ rotate: 360 }}
                          transition={{ duration: 15 + i*2, repeat: Infinity, ease: "linear" }}
                          className="absolute w-full h-full pointer-events-none"
                        >
                           <div 
                             className="absolute w-12 h-12 bg-white border border-border rounded-xl flex items-center justify-center top-12 left-1/2 -ml-6 shadow-sm"
                             style={{ transform: `rotate(-${angle}deg)` }}
                           >
                              <div className="w-1.5 h-1.5 rounded-full bg-accent/20" />
                           </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CLINICAL SOVEREIGNTY INFRASTRUCTURE (Technical Elite Section) */}
        <section className="py-24 sm:py-32 bg-text text-white overflow-hidden relative">
          {/* Technical Grid Background */}
          <div className="absolute inset-0 opacity-[0.05] pointer-events-none"
               style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '64px 64px' }} />
          <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-accent-vibrant/60 to-transparent"></div>
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col xl:flex-row items-start xl:items-center justify-between gap-16 sm:gap-20 xl:gap-24 relative z-10">
            <div className="flex-1 max-w-2xl">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/20 mb-8 font-black uppercase tracking-[0.15em] text-[10px] text-accent-vibrant shadow-lg shadow-accent-vibrant/5">
                 <ShieldCheck size={11} className="text-accent-vibrant shrink-0" />
                 Sovereignty Protocol v4.2
              </div>
              <h2 className="text-[44px] sm:text-[64px] lg:text-[72px] leading-[1.05] sm:leading-[0.9] font-serif tracking-tight mb-8">Clinical Sovereignty for<br className="hidden sm:block" /><span className="text-accent-vibrant italic font-medium">institutional scale.</span></h2>
              <p className="text-[17px] sm:text-[18px] text-white/80 font-medium leading-relaxed max-w-xl">
                Zero-trust, multi-region clinical infrastructure designed to ensure absolute technical sovereignty over your medical data.
              </p>
              
              <div className="mt-12 flex gap-10 items-center flex-wrap">
                 <div className="flex flex-col gap-1">
                    <div className="text-[9px] font-black uppercase tracking-widest text-white/60">Registry Hub ID</div>
                    <div className="text-[14px] font-mono font-bold text-accent-vibrant">NODE-ALPHA-7722</div>
                 </div>
                 <div className="flex flex-col gap-1">
                    <div className="text-[9px] font-black uppercase tracking-widest text-white/60">Active Protocol</div>
                    <div className="flex items-center gap-1.5">
                       <div className="w-1 h-1 rounded-full bg-green" />
                       <div className="text-[12px] font-mono font-bold text-white/90 uppercase">Isolated</div>
                    </div>
                 </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full xl:w-auto">
               {[
                 { title: "NIST AES-256", sub: "SP 800-111 Standard", label: "Encryption" },
                 { title: "ISO 27001", sub: "Certified Sec.-Log", label: "Architecture" },
                 { title: "SOC-2 + HIPAA", sub: "Verified Integrity", label: "Compliance" },
                 { title: "99.99% Uptime", sub: "Redundant Slates", label: "Service-Node" }
               ].map((spec, i) => (
                 <div key={i} className="p-6 sm:p-8 border border-white/20 bg-white/[0.02] backdrop-blur-sm group hover:bg-accent-vibrant/[0.04] transition-all min-w-0 sm:min-w-[280px] rounded-[16px]">
                    <div className="flex flex-col items-start gap-4">
                       <div className="text-[8px] font-black uppercase tracking-[0.2em] text-accent-vibrant mb-0.5">{spec.label}</div>
                       <div className="text-[20px] sm:text-[24px] font-serif font-black text-white leading-none tracking-tight">{spec.title}</div>
                       <div className="w-full h-px bg-white/20" />
                       <div className="text-[11px] font-bold text-white/60 uppercase tracking-widest leading-none">{spec.sub}</div>
                    </div>
                 </div>
               ))}
            </div>
          </div>

          <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
        </section>

        {/* FINAL CTA SECTION (Blended) */}
        <section className="py-24 sm:py-32 px-4 sm:px-6 lg:px-12 relative overflow-hidden bg-white border-t border-border/40 text-center">
           {/* Subtle background glow */}
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-accent/5 rounded-full blur-[120px] -z-10"></div>
           
           <div className="max-w-6xl mx-auto">
              <motion.div 
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                 <h2 className="font-serif text-[56px] lg:text-[84px] leading-[0.95] tracking-tight text-text mb-6">
                   Superhumanly <span className="text-accent italic font-medium">Doctors™️</span>
                 </h2>
                 <p className="text-[20px] lg:text-[28px] text-text font-serif italic mb-4 max-w-2xl mx-auto leading-tight">
                   AI-Powered Clinical Intelligence & <br className="hidden sm:block"/>Automation Platform
                 </p>
                 <p className="text-[17px] text-text2 font-medium mb-12 max-w-xl mx-auto leading-[1.7]">
                   From fragmented manual workflows → to an AI-powered, real-time healthcare ecosystem.
                 </p>
                 <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                   <Link 
                      to={isLoggedIn ? "/portal" : "/auth"}
                     className="w-full sm:w-auto px-10 py-5 bg-text text-white rounded-full text-[16px] font-bold hover:bg-black transition-all shadow-xl shadow-black/10 active:scale-95 group/btn flex items-center justify-center gap-2"
                   >
                      {isLoggedIn ? "My Workspace" : "Launch Portal"} <ArrowRight size={18} className="group-hover/btn:translate-x-1 transition-transform" />
                   </Link>
                    <Link 
                      to="/request-trial"
                      className="w-full sm:w-auto px-10 py-5 border border-black/30 rounded-full text-[16px] font-bold text-black bg-white hover:border-text transition-all active:scale-95 no-underline flex items-center justify-center"
                    >
                      Request Private Trial
                    </Link>
                 </div>
                 <div className="mt-12 text-[12px] font-black uppercase tracking-[0.2em] text-black">
                    Institutional Medical Sovereignty Verified.
                 </div>
              </motion.div>
           </div>
        </section>
      </main>

      <LandingFooter />
    </div>
  );
}
