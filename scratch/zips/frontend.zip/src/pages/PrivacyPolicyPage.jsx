import LandingNavbar from '../components/landing/LandingNavbar';
import LandingFooter from '../components/landing/LandingFooter';
import { motion } from 'framer-motion';
import { ShieldCheck, Lock, Eye, FileLock, UserCheck } from 'lucide-react';
import SEO from '../components/SEO';

export default function PrivacyPolicyPage() {
  const sections = [
    {
      title: "1. Clinical Data Sovereignty",
      content: "At Superhumanly Doctors, we prioritize the absolute sovereignty of clinical data. All patient encounters, transcriptions, and medical notes are encrypted at rest and in transit using NIST-standard AES-256 encryption. We do not own, sell, or utilize your clinical data for training global models without explicit institutional consent."
    },
    {
      title: "2. HIPAA & SOC-2 Compliance",
      content: "Our infrastructure is designed to exceed HIPAA and SOC-2 Type II standards. We maintain strict audit logs of every data access event, ensuring full transparency for institutional compliance officers. All data processing occurs within isolated, user-specific nodes."
    },
    {
      title: "3. Information Collection",
      content: "We collect minimal administrative data required to manage your account and provide the services. This includes your professional email, institutional affiliation, and billing information. Clinical data extracted from audio or text is processed locally within your secure workspace kernel."
    },
    {
      title: "4. Data Retention & Deletion",
      content: "Users maintain full control over their data lifecycle. You may export or permanently delete clinical records from your repository at any time. Once deleted, data is scrubbed from our primary and backup nodes according to DoD-level sanitation protocols."
    },
    {
      title: "5. Artificial Intelligence Ethics",
      content: "Our AI 'Doctor Assistant' operates on a 'human-in-the-loop' principle. AI-generated summaries and prescriptions must be verified by a licensed clinician. We do not permit autonomous medical decision-making without physician oversight."
    }
  ];

  return (
    <div className="bg-white min-h-screen">
      <SEO 
        title="Privacy & Sovereignty Policy" 
        description="Our commitment to institutional medical sovereignty and the technical protocols we use to ensure zero-trust data isolation."
      />
      <LandingNavbar />
      
      <main className="pt-32 pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-16"
          >
            <div className="flex items-center gap-3 mb-6">
               <ShieldCheck size={28} className="text-accent" />
               <span className="text-[12px] font-black uppercase tracking-[0.3em] text-accent">Legal Protocol v2.5</span>
            </div>
            <h1 className="text-5xl font-serif text-text mb-6">Privacy Policy</h1>
            <p className="text-xl text-text2/60 font-medium">
              Last updated: April 13, 2026. <br />
              Establishing the foundation of trust between technology and medicine.
            </p>
          </motion.div>

          {/* Quick Info Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-16">
             <div className="p-6 rounded-3xl bg-off border border-border">
                <Lock size={24} className="text-accent mb-4" />
                <h4 className="font-bold mb-2">Zero-Trust Architecture</h4>
                <p className="text-sm text-text2/60 font-medium">Encrypted at every layer. Your medical keys remain yours.</p>
             </div>
             <div className="p-6 rounded-3xl bg-off border border-border">
                <Eye size={24} className="text-accent mb-4" />
                <h4 className="font-bold mb-2">Transparency Hub</h4>
                <p className="text-sm text-text2/60 font-medium">Real-time audit trails of every clinical data interaction.</p>
             </div>
          </div>

          <div className="space-y-12">
            {sections.map((section, idx) => (
              <div key={idx} className="border-b border-border pb-10">
                <h3 className="text-2xl font-serif text-text mb-4 italic">{section.title}</h3>
                <p className="text-[16px] text-text2/70 leading-[1.8] font-medium">
                  {section.content}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-20 p-8 rounded-[32px] bg-text text-white relative overflow-hidden">
             <div className="relative z-10">
                <h4 className="text-xl font-serif mb-4 flex items-center gap-3">
                   <FileLock size={20} className="text-accent-vibrant" /> Institutional Inquiries
                </h4>
                <p className="text-white/60 mb-6 font-medium">
                   For full DPA (Data Processing Agreement) or institutional compliance documentation, please contact our Legal Engineering team.
                </p>
                <a href="mailto:legal@superhumanlymedical.io" className="text-accent-vibrant font-black uppercase tracking-widest text-sm hover:text-white transition-colors underline decoration-2 underline-offset-8">
                   Contact Legal Support
                </a>
             </div>
          </div>
        </div>
      </main>

      <LandingFooter />
    </div>
  );
}
