import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, Volume2, VolumeX } from 'lucide-react';

/**
 * ClinicalAudioPlayer - A high-fidelity, custom-built audio playback component.
 * Designed to replace standard browser players in medical software environments.
 */
export default function ClinicalAudioPlayer({ src }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef(null);

  const togglePlay = (e) => {
    e.stopPropagation();
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const onTimeUpdate = () => {
    const current = audioRef.current.currentTime;
    const total = audioRef.current.duration;
    setProgress((current / total) * 100);
  };

  const onLoadedMetadata = () => {
    setDuration(audioRef.current.duration);
  };

  const handleSeek = (e) => {
    e.stopPropagation();
    const seekTime = (e.target.value / 100) * duration;
    audioRef.current.currentTime = seekTime;
    setProgress(e.target.value);
  };

  const formatTime = (time) => {
    if (isNaN(time)) return "0:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full bg-white/60 backdrop-blur-md rounded-2xl p-4 border border-border/10 shadow-sm flex items-center gap-5 group/player">
      <audio
        ref={audioRef}
        src={src}
        onTimeUpdate={onTimeUpdate}
        onLoadedMetadata={onLoadedMetadata}
        onEnded={() => setIsPlaying(false)}
        muted={isMuted}
      />

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={togglePlay}
        className="w-12 h-12 rounded-full bg-text text-white flex items-center justify-center hover:bg-accent transition-all shadow-[0_4px_12px_rgba(0,0,0,0.1)] relative z-10"
      >
        {isPlaying ? (
          <Pause size={20} fill="currentColor" />
        ) : (
          <Play size={20} fill="currentColor" className="ml-1" />
        )}
      </motion.button>

      <div className="flex-1 flex flex-col gap-2">
        <div className="relative h-2 w-full bg-accent/10 rounded-full overflow-hidden group/seek">
          <motion.div
            className="absolute top-0 left-0 h-full bg-accent shadow-[0_0_8px_rgba(0,82,204,0.4)]"
            style={{ width: `${progress}%` }}
          />
          <input
            type="range"
            min="0"
            max="100"
            step="0.1"
            value={progress}
            onChange={handleSeek}
            onClick={(e) => e.stopPropagation()}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
          />
          
          {/* Subtle seek indicator */}
          <div className="absolute top-0 bottom-0 w-1 bg-white/40 z-10 hidden group-hover/seek:block pointer-events-none" style={{ left: `${progress}%` }} />
        </div>
        
        <div className="flex justify-between items-center text-[10px] font-black text-muted/50 font-mono tracking-tighter uppercase">
          <div className="flex items-center gap-1.5">
            <span className="text-accent/80">{formatTime(audioRef.current?.currentTime)}</span>
            <span className="opacity-30">/</span>
            <span>{formatTime(duration)}</span>
          </div>
          <div className="flex items-center gap-4">
             <button
              onClick={(e) => { e.stopPropagation(); setIsMuted(!isMuted); }}
              className="hover:text-accent transition-colors"
            >
              {isMuted || audioRef.current?.volume === 0 ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
