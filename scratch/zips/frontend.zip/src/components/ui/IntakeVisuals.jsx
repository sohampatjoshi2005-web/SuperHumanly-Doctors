import React, { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, CheckCircle2, ChevronRight, Zap, Database, Lock, Cpu, Globe, Check } from 'lucide-react';

/**
 * NeuralOrb - A high-fidelity circular processing indicator with liquid-like SVG animations.
 * Designed for institutional-grade clinical software.
 */
export const NeuralOrb = ({ progress = 0, isProcessing = true }) => {
  return (
    <div className="relative w-24 h-24 flex items-center justify-center">
      {/* Outer Glow Ring */}
      <motion.div
        animate={{ 
          scale: [1, 1.1, 1],
          opacity: [0.3, 0.6, 0.3]
        }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        className="absolute inset-0 rounded-full bg-accent/20 blur-xl"
      />

      {/* Main Glass Orb */}
      <div className="relative w-20 h-20 rounded-full bg-white border border-accent/10 shadow-[0_10px_30px_rgba(0,82,204,0.15)] overflow-hidden backdrop-blur-md flex items-center justify-center">
        {/* Liquid Wave Effect */}
        <motion.div
          className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-accent/40 to-accent/10"
          initial={{ height: "0%" }}
          animate={{ height: `${progress}%` }}
          transition={{ type: "spring", stiffness: 50, damping: 20 }}
        >
          <svg className="absolute top-0 left-0 w-[200%] h-4 -translate-y-full fill-accent/20 animate-wave" viewBox="0 0 100 20">
            <path d="M0 10 Q25 0 50 10 T100 10 V20 H0 Z" />
          </svg>
        </motion.div>

        {/* Neural Pulse Icon */}
        <motion.div
          animate={isProcessing ? {
            scale: [1, 1.15, 1],
            filter: ["drop-shadow(0 0 0px rgba(0,78,179,0))", "drop-shadow(0 0 8px rgba(0,78,179,0.4))", "drop-shadow(0 0 0px rgba(0,78,179,0))"]
          } : {}}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="relative z-10 text-accent"
        >
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M2 12h3L9 4l6 16 4-8h3" />
          </svg>
        </motion.div>
      </div>

      {/* Rotating High-Tech Ring */}
      <svg className="absolute inset-0 w-full h-full -rotate-90">
        <circle
          cx="48"
          cy="48"
          r="45"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          className="text-accent/5"
        />
        <motion.circle
          cx="48"
          cy="48"
          r="45"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeDasharray="283"
          initial={{ strokeDashoffset: 283 }}
          animate={{ strokeDashoffset: 283 - (283 * progress) / 100 }}
          className="text-accent shadow-sm"
        />
      </svg>
    </div>
  );
};

/**
 * SegmentedProgress - A high-fidelity segmented progress bar with glowing active states.
 */
export const SegmentedProgress = ({ progress = 0, segments = 20 }) => {
  return (
    <div className="w-full flex gap-1 h-1.5 items-center">
      {Array.from({ length: segments }).map((_, i) => {
        const threshold = (i / segments) * 100;
        const isActive = progress >= threshold;
        const isCurrent = progress >= threshold && progress < ((i + 1) / segments) * 100;

        return (
          <div
            key={i}
            className={`flex-1 h-full rounded-full transition-all duration-500 ${
              isActive 
                ? 'bg-accent shadow-[0_0_8px_rgba(0,82,204,0.4)]' 
                : 'bg-accent/10'
            } ${isCurrent ? 'animate-pulse scale-y-125' : ''}`}
          />
        );
      })}
    </div>
  );
};

/**
 * SecureStatusBadge - A premium, institutional-grade status badge for verified clinical data.
 */
export const SecureStatusBadge = ({ label = "Intake Verified", status = "success" }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border shadow-sm backdrop-blur-md ${
        status === 'success' 
          ? 'bg-green-50/50 border-green/20 text-green' 
          : 'bg-accent-light/50 border-accent/20 text-accent'
      }`}
    >
      <div className="relative flex items-center justify-center">
        <div className={`absolute inset-0 rounded-full animate-ping opacity-20 ${status === 'success' ? 'bg-green' : 'bg-accent'}`} />
        <div className={`w-2 h-2 rounded-full relative z-10 ${status === 'success' ? 'bg-green' : 'bg-accent'}`} />
      </div>
      <span className="text-[10px] font-black uppercase tracking-[0.15em]">{label}</span>
    </motion.div>
  );
};

/**
 * ClinicalWaveform - A high-fidelity audio visualization component.
 */
export const ClinicalWaveform = ({ isActive = true, color = "accent" }) => {
  const barsCount = 48;

  // Memoize bar data to prevent restarts on re-renders (e.g. from timer updates)
  const barData = useMemo(() => {
    return Array.from({ length: barsCount }).map((_, i) => {
      const centerDist = Math.abs(i - barsCount / 2) / (barsCount / 2);
      const baseHeight = 8 + (1 - centerDist) * 52;
      return {
        heights: [
          baseHeight * (0.7 + Math.random() * 0.3),
          baseHeight * (0.3 + Math.random() * 0.2),
          baseHeight * (1.1 + Math.random() * 0.4),
          baseHeight * (0.5 + Math.random() * 0.3),
          baseHeight * (1.4 + Math.random() * 0.5),
          baseHeight * (0.8 + Math.random() * 0.2),
        ],
        duration: 1.8 + Math.random() * 2.2,
        delay: i * 0.03
      };
    });
  }, [barsCount]);

  return (
    <div className="flex items-center justify-center gap-[2px] h-28 w-full px-4 overflow-hidden">
      {barData.map((data, i) => (
        <motion.div
          key={i}
          initial={{ height: 4, opacity: 0.3 }}
          animate={isActive ? {
            height: data.heights,
            opacity: [0.4, 0.7, 0.5, 0.8, 0.6, 0.4]
          } : { height: 4, opacity: 0.3 }}
          transition={{
            duration: data.duration,
            repeat: Infinity,
            repeatType: "mirror",
            ease: "easeInOut",
            delay: data.delay
          }}
          className={`w-1 rounded-full ${color === 'accent' ? 'bg-accent shadow-[0_0_12px_rgba(0,82,204,0.2)]' : 'bg-[#d94040] shadow-[0_0_12px_rgba(217,64,64,0.2)]'}`}
        />
      ))}
    </div>
  );
};

/**
 * SignalMeter - A segmented meter for visualizing vocal clarity.
 */
export const SignalMeter = ({ level = 80, label = "VOCAL CLARITY" }) => {
  const segments = 5;
  const activeSegments = Math.ceil((level / 100) * segments);
  
  return (
    <div className="flex flex-col gap-2 w-32">
      <div className="flex justify-between items-center px-1">
        <span className="text-[9px] font-black text-muted/50 tracking-widest uppercase">{label}</span>
        <span className={`text-[9px] font-black uppercase tracking-wider ${level > 70 ? 'text-green' : 'text-accent'}`}>
          {level > 70 ? 'Optimal' : level > 40 ? 'Good' : 'Weak'}
        </span>
      </div>
      <div className="flex gap-1 h-1.5">
        {Array.from({ length: segments }).map((_, i) => (
          <div
            key={i}
            className={`flex-1 rounded-[2px] transition-all duration-500 ${
              i < activeSegments 
                ? (level > 70 ? 'bg-green shadow-[0_0_6px_rgba(19,92,54,0.3)]' : 'bg-accent shadow-[0_0_6px_rgba(0,82,204,0.3)]')
                : 'bg-black/5'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

/**
 * CaptureStatus - A professional "On Air" style status indicator.
 */
export const CaptureStatus = ({ isActive = true }) => {
  return (
    <div className="flex items-center gap-3 bg-white/60 backdrop-blur-md border border-border/20 px-4 py-2 rounded-xl shadow-sm">
      <div className="relative flex items-center justify-center">
        <motion.div 
          animate={isActive ? { scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] } : {}}
          transition={{ duration: 1.5, repeat: Infinity }}
          className={`absolute inset-0 rounded-full ${isActive ? 'bg-[#d94040]' : 'bg-muted/30'}`}
        />
        <div className={`w-2.5 h-2.5 rounded-full relative z-10 ${isActive ? 'bg-[#d94040] shadow-[0_0_8px_rgba(217,64,64,0.5)]' : 'bg-muted/40'}`} />
      </div>
      <span className={`text-[11px] font-black uppercase tracking-[0.15em] ${isActive ? 'text-[#d94040]' : 'text-muted'}`}>
        {isActive ? 'Active Capture' : 'Standby'}
      </span>
    </div>
  );
};

/**
 * ClinicalSkeleton - A premium skeleton loader for technical clinical data.
 */
export const ClinicalSkeleton = ({ width = "w-full", height = "h-4", className = "" }) => {
  return (
    <div className={`relative overflow-hidden bg-off/40 rounded-full ${width} ${height} ${className}`}>
      <motion.div
        animate={{ x: ["-100%", "200%"] }}
        transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent"
      />
    </div>
  );
};

/**
 * SynthesisSlab - A simplified construction block for clinical note synthesis.
 */
export const SynthesisSlab = ({ label, step, currentStep, icon: Icon }) => {
  const isPending = currentStep < step;
  const isActive = currentStep === step;
  const isFinalized = currentStep > step;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-4">
        <div className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all duration-500 ${
          isFinalized ? 'bg-green/5 border-green/20 text-green shadow-sm' :
          isActive ? 'bg-accent/5 border-accent/20 text-accent shadow-sm' :
          'bg-off/40 border-border/10 text-muted/20'
        }`}>
          {isFinalized ? <CheckCircle2 size={18} /> : <Icon size={18} className={isActive ? 'animate-pulse' : ''} />}
        </div>
        <div className="flex-1 min-w-0">
          <div className={`text-[12px] font-black uppercase tracking-[0.1em] transition-colors duration-500 mb-1 ${
            isFinalized || isActive ? 'text-text' : 'text-muted/30'
          }`}>
            {label}
          </div>
          <div className="h-5 flex items-center">
            {isFinalized ? (
              <div className="flex items-center gap-2">
                <Check size={12} className="text-green" />
                <div className="text-[10px] font-black text-green/60 uppercase tracking-widest">Entry Finalized</div>
              </div>
            ) : isActive ? (
              <div className="flex items-center gap-3 w-full">
                <div className="flex-1 h-1 bg-accent/10 rounded-full overflow-hidden relative">
                   <motion.div 
                     initial={{ width: "0%" }}
                     animate={{ width: "100%" }}
                     transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                     className="absolute h-full bg-accent/40"
                   />
                </div>
                <span className="text-[9px] font-black text-accent uppercase tracking-[0.2em] animate-pulse">Analyzing</span>
              </div>
            ) : (
              <div className="text-[9px] font-black text-muted/20 uppercase tracking-[0.2em]">Awaiting Data Stream</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * DataSynapse - A high-fidelity data packet visualization.
 */
export const DataSynapse = ({ progress = 0 }) => {
  return (
    <div className="absolute top-[35%] left-1/4 right-1/4 h-[1px] z-50 pointer-events-none hidden lg:block overflow-visible">
      <svg className="w-full h-8 -top-4 relative overflow-visible">
        <line x1="0" y1="50%" x2="100%" y2="50%" stroke="rgba(0,82,204,0.05)" strokeWidth="1" strokeDasharray="4 4" />
        {/* Animated Packets */}
        {[0.1, 0.4, 0.7].map((delay, i) => (
          <motion.circle
            key={i}
            r="2"
            fill="#0052cc"
            initial={{ cx: "0%" }}
            animate={{ cx: "100%", opacity: [0, 1, 0] }}
            transition={{ duration: 2, repeat: Infinity, delay: delay, ease: "linear" }}
            style={{ filter: "drop-shadow(0 0 4px #0052cc)" }}
          />
        ))}
      </svg>
    </div>
  );
};

/**
 * SynthesisTelemetry - Minimalist institutional-grade status bar.
 */
export const SynthesisTelemetry = ({ progress = 0, confidence = 98 }) => {
  return (
    <div className="mt-auto pt-6 border-t border-border/10 flex items-center justify-between">
      <div className="flex items-center gap-5">
        <div className="flex items-center gap-2 text-[10px] font-black text-muted/40 uppercase tracking-[0.2em]">
          <Activity size={12} className="text-accent/30" />
          <span>Synthesis Engine Active</span>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <div className="text-[13px] font-black text-text font-mono tracking-tighter">
          {Math.round(progress)}%
        </div>
        <div className="w-32 h-1 bg-off rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ type: "spring", stiffness: 50 }}
            className="h-full bg-accent"
          />
        </div>
      </div>
    </div>
  );
};
