import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, User, Activity, Stethoscope, ClipboardList, Pill, Clock, Hash } from 'lucide-react';

/**
 * EncounterDetailModal - A focused, high-fidelity view for exploring historical clinical records.
 * Part of Phase 48: Interactive Longitudinal Review.
 */
const EncounterDetailModal = ({ encounter, isOpen, onClose }) => {
  if (!encounter) return null;

  const soapData = [
    { 
      title: 'Subjective', 
      content: encounter.clinical_data?.soap?.subjective || encounter.soap?.subjective, 
      icon: <User size={18} />, 
      color: '#0052cc' 
    },
    { 
      title: 'Objective', 
      content: encounter.clinical_data?.soap?.objective || encounter.soap?.objective, 
      icon: <Activity size={18} />, 
      color: '#111111' 
    },
    { 
      title: 'Assessment', 
      content: encounter.clinical_data?.soap?.assessment || encounter.soap?.assessment || encounter.diagnosis, 
      icon: <Stethoscope size={18} />, 
      color: '#7c3aed' 
    },
    { 
      title: 'Plan', 
      content: encounter.clinical_data?.soap?.plan || encounter.soap?.plan, 
      icon: <ClipboardList size={18} />, 
      color: '#16a34a' 
    }
  ];

  const renderContent = (content) => {
    if (!content) return "Not recorded.";
    if (typeof content === 'string') {
      return content.split('\n').map((line, i) => (
        <div key={i} className="mb-1.5">{line}</div>
      ));
    }
    return JSON.stringify(content);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 lg:p-12">
          {/* Institutional Backdrop */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-text/60 backdrop-blur-md"
          />

          {/* Modal Architecture */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="relative w-full max-w-5xl h-full max-h-[90vh] bg-white rounded-[44px] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.3)] overflow-hidden flex flex-col"
          >
            {/* Header: Identity & Context */}
            <div className="px-8 lg:px-12 py-8 lg:py-10 border-b border-border/10 flex items-center justify-between shrink-0 bg-white relative z-20">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <div className="text-[10px] font-black text-accent uppercase tracking-[0.3em] bg-accent/5 px-2.5 py-1 rounded-lg border border-accent/10">Historical Context</div>
                  <div className="text-[10px] font-black text-muted uppercase tracking-[0.25em] flex items-center gap-2 bg-off px-2.5 py-1 rounded-lg border border-border/40">
                    <Clock size={12} className="text-muted/60" />
                    {new Date(encounter.created_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                  </div>
                </div>
                <h2 className="text-[26px] lg:text-[32px] font-black text-text tracking-tight truncate leading-tight">
                  {encounter.diagnosis || "Diagnostic Record Archive"}
                </h2>
              </div>
              <button 
                onClick={onClose}
                className="w-14 h-14 rounded-full bg-off hover:bg-border/20 flex items-center justify-center transition-all duration-300 group shrink-0 ml-4"
              >
                <X size={26} className="text-muted group-hover:text-text transition-colors" />
              </button>
            </div>

            {/* Core Content Layer */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-8 lg:p-14 bg-white relative z-10">
               <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
                  
                  {/* Primary Data: SOAP Clinical Note */}
                  <div className="lg:col-span-8 flex flex-col gap-12">
                     {soapData.map((section, idx) => section.content && (
                       <div key={idx} className="flex flex-col gap-5 group">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-2xl bg-off border border-border/20 flex items-center justify-center shadow-sm transition-all duration-500 group-hover:border-accent/30" style={{ color: section.color }}>
                              {section.icon}
                            </div>
                            <div className="text-[14px] font-black uppercase tracking-[0.25em] text-text/60">
                              {section.title}
                            </div>
                          </div>
                          <div className="pl-14 relative">
                             <div className="absolute left-[19px] top-0 bottom-0 w-[2px] bg-border/20 rounded-full group-hover:bg-accent/10 transition-colors" />
                             <div className="text-[16px] text-text/90 leading-[1.8] font-medium py-1 tracking-tight">
                               {renderContent(section.content)}
                             </div>
                          </div>
                       </div>
                     ))}
                  </div>

                  {/* Secondary Data: Rx & Technical Meta */}
                  <div className="lg:col-span-4 flex flex-col gap-10">
                     {/* Structured Prescription Ledger */}
                     <div className="bg-off/30 rounded-[36px] p-7 border border-border/30 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none">
                           <Pill size={80} strokeWidth={1} />
                        </div>

                        <div className="flex items-center gap-3 mb-8 relative z-10">
                           <div className="w-9 h-9 rounded-xl bg-accent text-white flex items-center justify-center shadow-lg shadow-accent/20">
                              <Pill size={18} />
                           </div>
                           <span className="text-[13px] font-black uppercase tracking-widest text-text">Archived Rx</span>
                        </div>
                        
                        <div className="space-y-4 relative z-10">
                           {encounter.rx_json?.medicines?.map((med, midx) => (
                             <div key={midx} className="bg-white p-5 rounded-2xl border border-border/20 shadow-sm hover:shadow-md transition-shadow">
                                <div className="text-[15px] font-black text-text mb-1.5">{med.name}</div>
                                <div className="flex items-center gap-2 mb-3">
                                   <div className="text-[10px] font-black text-accent uppercase tracking-widest bg-accent/[0.03] px-2 py-0.5 rounded border border-accent/10">
                                      {med.dosage}
                                   </div>
                                   <div className="text-[10px] font-black text-muted uppercase tracking-widest bg-off px-2 py-0.5 rounded border border-border/20">
                                      {med.frequency}
                                   </div>
                                </div>
                                <div className="text-[12px] text-muted/70 leading-relaxed font-medium italic">
                                   {med.instructions}
                                </div>
                             </div>
                           )) || (
                             <div className="text-center py-10 text-muted/30 text-[12px] font-black uppercase tracking-widest border border-dashed border-border/40 rounded-3xl">
                               No active Rx found
                             </div>
                           )}
                        </div>
                     </div>

                     {/* Institutional Ledger Meta */}
                     <div className="px-4 space-y-5">
                        <div className="flex flex-col gap-1.5">
                           <span className="text-[10px] font-black text-muted uppercase tracking-[0.2em]">Encounter UUID</span>
                           <div className="text-[11px] font-mono text-text/40 bg-off/50 px-3 py-2 rounded-lg border border-border/10 truncate">
                              {encounter.id}
                           </div>
                        </div>
                        <div className="flex items-center justify-between pt-2">
                           <span className="text-[10px] font-black text-muted uppercase tracking-[0.2em]">Record Integrity</span>
                           <div className="flex items-center gap-2">
                              <div className="w-1.5 h-1.5 rounded-full bg-green animate-pulse" />
                              <span className="text-[10px] font-black text-green uppercase tracking-widest">Verified Vault</span>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

            {/* Action Tier */}
            <div className="px-8 lg:px-12 py-8 bg-off/20 border-t border-border/10 flex items-center justify-between shrink-0 relative z-20">
               <div className="text-[11px] font-bold text-muted/40 uppercase tracking-widest hidden sm:block">
                  Institutional Grade Security • HL7-FHIR Native
               </div>
               <button 
                onClick={onClose}
                className="w-full sm:w-auto px-12 py-4 bg-text text-white rounded-full text-[15px] font-black hover:bg-black transition-all shadow-xl active:scale-95 shadow-text/10"
               >
                 Close Historical Record
               </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default EncounterDetailModal;
