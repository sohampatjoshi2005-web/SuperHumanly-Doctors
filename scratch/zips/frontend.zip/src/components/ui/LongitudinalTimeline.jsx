import React from 'react';
import { motion } from 'framer-motion';
import { Stethoscope, Pill, FileText, Clock, ChevronRight } from 'lucide-react';

/**
 * LongitudinalTimeline - A high-fidelity vertical timeline of patient encounters.
 * Part of Phase 47: Patient History & Longitudinal Context.
 */
const LongitudinalTimeline = ({ history = [], isLoading = false }) => {
  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col gap-10 p-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="flex gap-6 animate-pulse">
            <div className="w-12 h-12 bg-off rounded-full shrink-0" />
            <div className="flex-1 space-y-4">
              <div className="h-4 bg-off rounded-full w-1/3" />
              <div className="h-24 bg-off rounded-[24px] w-full" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!history || history.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center p-8 py-20">
        <div className="w-20 h-20 bg-off/50 rounded-full flex items-center justify-center mb-6 text-muted/20 border border-dashed border-border/60">
          <Clock size={36} />
        </div>
        <h3 className="text-[20px] font-black text-text/40 tracking-tight">No Clinical History</h3>
        <p className="text-[14px] text-muted/40 max-w-[240px] mt-2 font-medium leading-relaxed">
          Historical encounter data will appear here automatically once recorded and archived.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col gap-10 p-1 relative">
      {/* Institutional Timeline Accent Line */}
      <div className="absolute left-[23px] top-8 bottom-8 w-[2px] bg-gradient-to-b from-border/5 via-border/20 to-border/5 z-0 rounded-full" />

      {history.map((encounter, idx) => (
        <motion.div
          key={encounter.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: idx * 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="flex gap-6 relative z-10 group"
        >
          {/* Node Icon Cluster */}
          <div className="relative shrink-0">
            <div className="w-12 h-12 rounded-full bg-white border border-border/40 shadow-sm flex items-center justify-center group-hover:border-accent/40 group-hover:shadow-md transition-all duration-500">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors duration-500 ${
                encounter.diagnosis ? 'bg-accent/5 text-accent' : 'bg-off text-muted/40'
              }`}>
                {encounter.diagnosis ? <Stethoscope size={16} /> : <FileText size={16} />}
              </div>
            </div>
            {idx === 0 && (
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green rounded-full border-2 border-white shadow-sm" />
            )}
          </div>

          {/* Content Card */}
          <div className="flex-1 min-w-0 flex flex-col gap-3">
            <div className="flex items-center justify-between px-1">
              <div className="text-[10px] font-black text-muted uppercase tracking-[0.25em]">
                {new Date(encounter.created_at).toLocaleDateString('en-US', { 
                  month: 'short', day: 'numeric', year: 'numeric' 
                })}
              </div>
              <div className="text-[9px] font-black text-accent/40 uppercase tracking-[0.2em] bg-accent/[0.03] px-2.5 py-1 rounded-lg border border-accent/5">
                Archive ID: {encounter.id.slice(0, 8)}
              </div>
            </div>

            <button 
              onClick={() => onEncounterClick(encounter.id)}
              className="w-full text-left bg-white/40 border border-border/20 rounded-[28px] p-6 hover:border-accent/40 hover:bg-white/60 transition-all duration-500 shadow-sm hover:shadow-xl relative overflow-hidden group/card active:scale-[0.99] cursor-pointer"
            >
               {/* Institutional Precision Pattern */}
               <div className="absolute inset-0 opacity-[0.02] pointer-events-none group-hover:opacity-[0.04] transition-opacity duration-500" 
                  style={{ backgroundImage: 'radial-gradient(circle, #004eb3 1px, transparent 1px)', backgroundSize: '20px 20px' }} 
               />

               <div className="relative z-10">
                  <div className="text-[19px] font-black text-text tracking-tight mb-2 group-hover/card:text-accent transition-colors duration-500">
                    {encounter.diagnosis || "Undocumented Diagnosis"}
                  </div>
                  <p className="text-[14px] text-muted/80 leading-relaxed font-medium line-clamp-2 mb-4">
                    {encounter.patient_summary || "Automated clinical summary for this encounter has not been generated or is currently being processed."}
                  </p>

                  {encounter.rx_json?.medicines && encounter.rx_json.medicines.length > 0 && (
                    <div className="flex flex-wrap gap-2 pt-4 border-t border-border/10">
                      {encounter.rx_json.medicines.slice(0, 3).map((med, midx) => (
                        <div key={midx} className="flex items-center gap-2 px-3 py-1.5 bg-off/50 rounded-xl border border-border/20 group-hover/card:border-accent/10 transition-colors">
                          <Pill size={12} className="text-accent/50" />
                          <span className="text-[11px] font-black text-text/70 uppercase tracking-tight">{med.name}</span>
                        </div>
                      ))}
                      {encounter.rx_json.medicines.length > 3 && (
                        <div className="text-[10px] font-black text-muted/30 uppercase tracking-widest self-center ml-2">
                          +{encounter.rx_json.medicines.length - 3} more
                        </div>
                      )}
                    </div>
                  )}
               </div>
            </button>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default LongitudinalTimeline;
