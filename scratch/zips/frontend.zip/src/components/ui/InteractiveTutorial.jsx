import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, ChevronLeft, Sparkles, User, Database, Workflow, ShieldCheck, Zap } from 'lucide-react';

const steps = [
  {
    id: 'welcome',
    title: 'Clinical Workspace',
    description: 'Welcome, Doctor. We have prepared an agentic workspace to streamline your clinical encounters and data auditing.',
    icon: <Sparkles className="text-accent" size={20} />,
    targetId: null,
    onStart: (setActiveTab) => setActiveTab('workflow'),
  },
  {
    id: 'patients',
    title: 'Patient Continuity',
    description: 'Select your active patient profile from the curated registry to begin or resume an encounter.',
    icon: <User className="text-accent" size={20} />,
    targetId: 'tutorial-sidebar-patients',
    placement: 'right',
    onStart: (setActiveTab, setSelectedCustomer) => {
      setActiveTab('workflow');
      setSelectedCustomer({ id: 'TUT-001', name: 'Alexander Thompson (Test)' });
      window.superhumanly_mock_active = 'sidebar';
    },
  },
  {
    id: 'timeline',
    title: 'Clinical Timeline',
    description: 'Review the longitudinal history of your selected patient. Audit past notes and historical data points instantly.',
    icon: <Sparkles className="text-accent" size={20} />, 
    targetId: 'tutorial-sidebar-timeline',
    placement: 'right',
    onStart: (setActiveTab, setSelectedCustomer) => {
      setActiveTab('workflow');
      setSelectedCustomer({ id: 'TUT-001', name: 'Alexander Thompson (Test)' });
      window.superhumanly_mock_active = 'sidebar';
    },
  },
  {
    id: 'workspace',
    title: 'Intake Workspace',
    description: 'Provide clinical context via raw audio or structured text. Our engine will orchestrate a high-fidelity assessment.',
    icon: <Zap className="text-accent" size={20} />,
    targetId: 'tutorial-workflow-workspace',
    placement: 'right',
    onStart: (setActiveTab, setSelectedCustomer) => {
      setActiveTab('workflow');
      setSelectedCustomer({ id: 'TUT-001', name: 'Alexander Thompson (Test)' });
      window.superhumanly_mock_active = null; 
    },
  },
  {
    id: 'synthesis',
    title: 'Intelligent Synthesis',
    description: 'Examine the AI-generated medical summary, including structured assessments, red-flags, and clinical plans.',
    icon: <Workflow className="text-accent" size={20} />,
    targetId: 'tutorial-workflow-review',
    placement: 'top',
    onStart: (setActiveTab, setSelectedCustomer) => {
      setActiveTab('workflow');
      setSelectedCustomer({ id: 'TUT-001', name: 'Alexander Thompson (Test)' });
      window.superhumanly_mock_active = 'workflow';
      window.dispatchEvent(new CustomEvent('superhumanly-tutorial-mock'));
    },
  },
  {
    id: 'historical',
    title: 'Global Database',
    description: 'Switch to the historical registry to search across your entire patient population.',
    icon: <Database className="text-accent" size={20} />,
    targetId: 'tutorial-database-btn',
    placement: 'bottom',
    onStart: (setActiveTab) => {
      setActiveTab('workflow');
      window.superhumanly_mock_active = null; 
    },
  },
  {
    id: 'registry',
    title: 'Historical Archive',
    description: 'Audit patient records across the entire facility. Review historical encounters with precision.',
    icon: <Database className="text-accent" size={20} />,
    targetId: 'tutorial-database-header',
    placement: 'bottom',
    onStart: (setActiveTab) => {
      setActiveTab('database');
      window.superhumanly_mock_active = 'database';
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('superhumanly-tutorial-db-mock'));
      }, 100);
    },
  },
  {
    id: 'security',
    title: 'Secure Session',
    description: 'Terminate your secure clinical session to ensure data sovereignty and integrity.',
    icon: <ShieldCheck className="text-accent" size={20} />,
    targetId: 'tutorial-logout-btn',
    placement: 'left',
    onStart: (setActiveTab) => {
      setActiveTab('workflow');
      window.superhumanly_mock_active = null;
    },
  }
];

export default function InteractiveTutorial({ setActiveTab, activeTab, setSelectedCustomer }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [coords, setCoords] = useState({ top: 0, left: 0, width: 0, height: 0 });
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    const hasSeen = localStorage.getItem('superhumanly_tutorial_complete');
    if (!hasSeen) {
      setTimeout(() => setIsVisible(true), 1500); // Wait for page fade-in
    }
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const step = steps[currentStep];
    
    // Reset coordinates before transition to prevent stale data from causing off-screen shifts
    setCoords({
      top: window.innerHeight / 2,
      left: window.innerWidth / 2,
      width: 0,
      height: 0
    });

    if (step.onStart) step.onStart(setActiveTab, setSelectedCustomer);

    // Dynamic polling to catch elements as they mount and animate
    updateCoords();
    const pollInterval = setInterval(updateCoords, 100);
    const stopPolling = setTimeout(() => clearInterval(pollInterval), 1000);

    window.addEventListener('resize', updateCoords);
    return () => {
      window.removeEventListener('resize', updateCoords);
      clearInterval(pollInterval);
      clearTimeout(stopPolling);
    };
  }, [currentStep, isVisible, activeTab]);

  const updateCoords = () => {
    const step = steps[currentStep];
    if (!step.targetId) {
      setCoords({
        top: window.innerHeight / 2,
        left: window.innerWidth / 2,
        width: 0,
        height: 0
      });
      return;
    }
    const el = document.getElementById(step.targetId);
    if (el) {
      const rect = el.getBoundingClientRect();
      setCoords({
        top: rect.top,
        left: rect.left,
        width: rect.width,
        height: rect.height,
      });
    }
  };

  const handleSkip = () => {
    setIsVisible(false);
    window.superhumanly_mock_active = null;
    setSelectedCustomer(null);
    window.dispatchEvent(new CustomEvent('superhumanly-tutorial-clear'));
    localStorage.setItem('superhumanly_tutorial_complete', 'true');
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleComplete();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = () => {
    setIsVisible(false);
    window.superhumanly_mock_active = null;
    setSelectedCustomer(null);
    window.dispatchEvent(new CustomEvent('superhumanly-tutorial-clear'));
    localStorage.setItem('superhumanly_tutorial_complete', 'true');
  };

  if (!isMounted || !isVisible) return null;

  const step = steps[currentStep];
  
  // Calculate card position
  let cardStyle = {};
  if (!step.targetId) {
    // Perfectly center the card without using CSS translates (helps Framer Motion layout)
    cardStyle = { top: coords.top - 100, left: coords.left - 190 };
  } else {
    const padding = 20;
    if (step.placement === 'right') {
      cardStyle = { top: coords.top, left: coords.left + coords.width + padding };
    } else if (step.placement === 'bottom') {
      cardStyle = { top: coords.top + coords.height + padding, left: coords.left + (coords.width / 2) - 190 };
    } else if (step.placement === 'top') {
      cardStyle = { top: coords.top - 200 - padding, left: coords.left + (coords.width / 2) - 190 }; // Est. card height
    } else if (step.placement === 'left') {
      cardStyle = { top: coords.top, left: coords.left - 400 };
    }
  }

  return (
    <div className="fixed inset-0 z-[9999] pointer-events-none">
      {/* Dimmed Overlay with Natural Rounded Cutout */}
      <AnimatePresence>
        {isVisible && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 pointer-events-auto bg-transparent overflow-hidden"
          >
            {/* The "Hole" defined by a massive shadow on a small rounded rect */}
            <motion.div
              initial={false}
              animate={{
                top: step.targetId ? coords.top - 12 : '50%',
                left: step.targetId ? coords.left - 12 : '50%',
                width: step.targetId ? coords.width + 24 : 0,
                height: step.targetId ? coords.height + 24 : 0,
                opacity: step.targetId ? 1 : 0
              }}
              transition={{ type: 'spring', damping: 30, stiffness: 200 }}
              className="absolute rounded-[24px] shadow-[0_0_0_9999px_rgba(0,0,0,0.08),inset_0_0_20px_rgba(0,0,0,0.02)] pointer-events-none"
            />
            {/* Fallback for global steps (Welcome) */}
            {!step.targetId && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute inset-0 bg-black/[0.05] backdrop-blur-[1px]"
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Single Persistent Moving Card */}
      <motion.div
        layout
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ 
          opacity: isVisible ? 1 : 0, 
          scale: isVisible ? 1 : 0.95,
          ...cardStyle
        }}
        transition={{ 
          layout: { type: 'spring', damping: 30, stiffness: 200 },
          opacity: { duration: 0.3 }
        }}
        className="absolute w-[380px] bg-white/80 backdrop-blur-2xl border border-white/40 rounded-[32px] shadow-[0_32px_80px_-20px_rgba(0,0,0,0.18)] p-6 pointer-events-auto flex flex-col gap-4 overflow-hidden"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
            className="flex flex-col gap-4"
          >
            <div className="flex justify-between items-start">
              <div className="w-12 h-12 rounded-2xl bg-accent/10 flex items-center justify-center">
                {step.icon}
              </div>
              <button 
                onClick={handleComplete}
                className="p-2 hover:bg-black/5 rounded-full text-muted/40 hover:text-text transition-colors group"
              >
                <X size={20} className="group-hover:rotate-90 transition-transform" />
              </button>
            </div>

            <div className="flex flex-col gap-2">
              <h2 className="font-serif text-[28px] tracking-tight text-text leading-tight">
                {step.title}
              </h2>
              <p className="text-[15px] text-muted/80 font-medium leading-relaxed">
                {step.description}
              </p>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Persistent Navigation Footer */}
        <div className="flex items-center justify-between mt-6 pt-4 border-t border-border/10">
          <button 
            onClick={handleComplete}
            className="px-4 py-2.5 rounded-full text-[14px] font-bold text-muted/60 hover:text-text hover:bg-black/5 transition-all"
          >
            Skip 
          </button>

          <div className="flex gap-1.5">
            {steps.map((_, i) => (
              <div 
                key={i} 
                className={`h-1.5 rounded-full transition-all duration-500 ${i === currentStep ? 'w-6 bg-accent' : 'w-1.5 bg-accent/20'}`} 
              />
            ))}
          </div>

          <div className="flex gap-2.5 items-center">
            <AnimatePresence>
              {currentStep > 0 && (
                <motion.div
                  initial={{ opacity: 0, width: 0, x: -10 }}
                  animate={{ opacity: 1, width: 'auto', x: 0 }}
                  exit={{ opacity: 0, width: 0, x: -10 }}
                  transition={{ duration: 0.3, ease: 'easeOut' }}
                  className="overflow-hidden"
                >
                  <button 
                    onClick={handleBack}
                    className="p-2.5 rounded-full text-muted hover:text-text hover:bg-black/5 transition-all border border-border/40"
                    title="Previous Step"
                  >
                    <ChevronLeft size={18} />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
            
            <button 
              onClick={handleNext}
              className={`flex items-center justify-center rounded-full bg-text text-white text-[13px] font-bold shadow-lg shadow-black/10 hover:bg-black active:scale-95 transition-all group ${currentStep === steps.length - 1 ? 'px-6 py-2.5' : 'w-10 h-10'}`}
            >
              {currentStep === steps.length - 1 ? 'Finish' : <ChevronRight size={18} />}
            </button>
          </div>
        </div>

        <div className="absolute top-0 right-0 p-4 pointer-events-none opacity-10">
          <Zap size={60} className="text-accent" />
        </div>
      </motion.div>

      {/* Pulsing Highlight for Target Removed as requested */}
    </div>
  );
}
