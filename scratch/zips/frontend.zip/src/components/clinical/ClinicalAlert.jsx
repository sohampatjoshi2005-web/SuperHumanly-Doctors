import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, AlertTriangle, ArrowRight, Activity, FlaskConical, Bell } from 'lucide-react';

const ClinicalAlert = ({ risks, onAction }) => {
  if (!risks || risks.length === 0) return null;

  return (
    <div className="space-y-4 my-4">
      <AnimatePresence>
        {risks.map((risk) => (
          <motion.div 
            key={risk.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className={`relative overflow-hidden p-6 rounded-[24px] border-2 shadow-xl ${
              risk.severity === 'High' 
                ? 'bg-white border-red-100 shadow-red-900/[0.03]' 
                : 'bg-white border-orange-100 shadow-orange-900/[0.03]'
            }`}
          >
            {/* Background Accent */}
            <div className={`absolute top-0 right-0 w-32 h-32 blur-3xl opacity-[0.05] -mr-16 -mt-16 ${
              risk.severity === 'High' ? 'bg-red-600' : 'bg-orange-600'
            }`} />

            <div className="flex items-start justify-between relative z-10">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm ${
                  risk.severity === 'High' ? 'bg-red-50 text-red-600' : 'bg-orange-50 text-orange-600'
                }`}>
                  {risk.severity === 'High' ? <Shield className="animate-pulse" size={24} /> : <AlertTriangle size={24} />}
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${
                      risk.severity === 'High' ? 'text-red-600' : 'text-orange-600'
                    }`}>
                      Proactive Clinical Alert
                    </span>
                    <span className="w-1 h-1 rounded-full bg-border" />
                    <span className="text-[10px] font-bold text-muted/40 uppercase tracking-widest">Just Now</span>
                  </div>
                  <h4 className="text-[18px] font-bold text-text leading-tight">{risk.name}</h4>
                  <p className="mt-2 text-[13px] font-medium text-muted/70 leading-relaxed max-w-lg">
                    {risk.reason}
                  </p>
                </div>
              </div>
              <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.15em] border ${
                risk.severity === 'High' 
                  ? 'bg-red-600 text-white border-red-600' 
                  : 'bg-orange-500 text-white border-orange-500'
              }`}>
                {risk.severity} Severity
              </div>
            </div>

            {/* Vitals Summary Grid */}
            {risk.vitals && (
              <div className="grid grid-cols-3 gap-3 mt-6">
                {Object.entries(risk.vitals).map(([k, v]) => (
                  <div key={k} className="bg-off/40 border border-border/40 p-3 rounded-xl flex flex-col items-center">
                    <span className="text-[9px] font-black text-muted/30 uppercase tracking-widest mb-1">{k}</span>
                    <span className="text-[14px] font-bold text-text">{v}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Action Bar */}
            <div className="flex flex-wrap gap-3 mt-6 pt-6 border-t border-border/40">
              {risk.actions?.map((action, i) => (
                <button 
                  key={i}
                  onClick={() => onAction && onAction(action)}
                  className={`px-5 py-2.5 rounded-xl text-[12px] font-black transition-all flex items-center gap-2 shadow-sm ${
                    i === 0 
                      ? 'bg-text text-white hover:bg-black' 
                      : 'bg-white border border-border/80 text-text hover:bg-off'
                  }`}
                >
                  {action.label} 
                  {action.type === 'order_lab' && <FlaskConical size={14} />}
                  {action.type === 'navigation' && <ArrowRight size={14} />}
                </button>
              ))}
              <div className="flex-1" />
              <button className="p-2.5 text-muted/30 hover:text-text transition-colors">
                <Bell size={18} />
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};

export default ClinicalAlert;
