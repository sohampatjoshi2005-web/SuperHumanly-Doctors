import { Link } from 'react-router-dom';
import { ArrowRight, ShieldCheck, Twitter, Linkedin, Github } from 'lucide-react';

export default function LandingFooter() {
  const navColumns = [
    { 
      title: "Protocol", 
      links: [
        { label: "Audio Engine", path: "/documentation" },
        { label: "Text Intelligence", path: "/documentation" },
        { label: "Clinical Registry", path: "/portal" },
        { label: "Digital Identity", path: "/auth" },
        { label: "Lab v2 Kernel", path: "/documentation" }
      ] 
    },
    { 
      title: "Governance", 
      links: [
        { label: "Sovereignty", path: "/about" },
        { label: "HIPAA/SOC-2", path: "/privacy" },
        { label: "NIST Encryption", path: "/privacy" },
        { label: "Audit Integrity", path: "/about" },
        { label: "Data Privacy", path: "/privacy" }
      ] 
    },
    { 
      title: "Institution", 
      links: [
        { label: "Request Trial", path: "/request-trial" },
        { label: "About Us", path: "/about" },
        { label: "Health Systems", path: "/about" },
        { label: "API Reference", path: "/documentation" },
        { label: "Contact Support", path: "/contact" }
      ] 
    },
    { 
      title: "Support", 
      links: [
        { label: "Portal Entry", path: "/auth" },
        { label: "Documentation", path: "/documentation" },
        { label: "Pricing Hub", path: "/pricing" },
        { label: "API Status", path: "/faq" },
        { label: "Medical FAQ", path: "/faq" }
      ] 
    }
  ];

  return (
    <div className="px-3 sm:px-4 md:px-6 pb-4 sm:pb-6 mt-10 sm:mt-16 bg-white">
      <footer className="relative bg-[#0a0a0a] rounded-[20px] sm:rounded-[32px] border border-white/10 pt-12 sm:pt-16 lg:pt-20 pb-8 sm:pb-12 px-4 sm:px-6 lg:px-12 overflow-hidden shadow-2xl">
        {/* Material Background Effects */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[300px] sm:w-[600px] h-[200px] sm:h-[300px] bg-accent/10 blur-[120px] rounded-full z-0 opacity-40 pointer-events-none" />
        <div className="absolute inset-0 z-0 opacity-[0.03] pointer-events-none bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA1MCA1MCI+PGZpbHRlciBpZD0ibm9pc2UiPjxmZVR1cmJ1bGVuY2UgdHlwZT0iZnJhY3RhbE5vaXNlIiBiYXNlRnJlcXVlbmN5PSIwLjY1IiBudW1PY3RhdmVzPSIzIiBzdGl0Y2hUaWxlcz0ic3RpdGNoIi8+PC9maWx0ZXI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsdGVyPSJ1cmwoI25vaXNlKSIvPjwvc3ZnPg==')]" />

        <div className="relative z-10 mx-auto">
          {/* Main Grid: Brand column + Nav columns */}
          <div className="grid grid-cols-1 lg:grid-cols-[1.5fr_1fr_1fr_1fr_1fr] gap-10 sm:gap-12 lg:gap-16 mb-12 sm:mb-16 lg:mb-20">
            {/* Brand & Newsletter Column */}
            <div className="flex flex-col gap-8 sm:gap-10 lg:pr-12">
              <div>
                <Link className="font-serif text-[36px] sm:text-[36px] lg:text-[48px] text-white tracking-[-0.02em] leading-none mb-4 sm:mb-6 inline-block group" to="/">
                  Superhumanly <span className="italic text-accent-vibrant font-medium">Medical</span>
                </Link>
                <p className="text-[14px] sm:text-[15px] text-white/80 leading-[1.6] max-w-[340px] font-medium">
                  Engineering the future of clinical documentation. Built for physicians who value technical sovereignty and high-fidelity continuity.
                </p>
              </div>

              {/* Newsletter Block */}
              <div className="max-w-[340px]">
                <h4 className="text-[9px] sm:text-[10px] font-black uppercase tracking-[0.2em] text-white/60 mb-4 sm:mb-5">Stay in the medical loop</h4>
                <div className="relative flex items-center">
                  <input 
                    type="email" 
                    placeholder="Physician email address"
                    className="w-full bg-white/5 border border-white/10 rounded-full px-4 sm:px-5 py-2.5 sm:py-3 text-[13px] sm:text-[14px] text-white placeholder:text-white/40 focus:outline-none focus:border-accent/40 transition-all font-sans"
                  />
                  <button className="absolute right-1.5 p-1.5 sm:p-2 bg-accent text-white rounded-full hover:bg-accent2 transition-all group/btn">
                    <ArrowRight size={16} className="sm:hidden group-hover/btn:translate-x-0.5 transition-transform" />
                    <ArrowRight size={18} className="hidden sm:block group-hover/btn:translate-x-0.5 transition-transform" />
                  </button>
                </div>
                <p className="mt-3 sm:mt-4 text-[9px] sm:text-[10px] text-white/40 font-bold uppercase tracking-widest">Weekly clinical insights. No noise.</p>
              </div>
            </div>

            {/* Navigation Columns — 2-col on tablet, full row on desktop */}
            <div className="col-span-1 lg:col-span-4 grid grid-cols-2 sm:grid-cols-4 gap-8 sm:gap-6 lg:gap-10">
              {navColumns.map((col, idx) => (
                <div key={idx}>
                  <h4 className="text-[9px] sm:text-[10px] font-black uppercase tracking-[0.2em] text-white/60 mb-5 sm:mb-6 lg:mb-8">{col.title}</h4>
                  <div className="flex flex-col gap-3 sm:gap-4">
                    {col.links.map((link, lidx) => (
                      <Link key={lidx} to={link.path} className="text-[13px] sm:text-[14px] text-white/80 hover:text-white transition-all duration-200 no-underline font-bold hover:translate-x-1 inline-block">
                        {link.label}
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-6 sm:pt-8 lg:pt-10 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-5 sm:gap-8">
            <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-8">
              <span className="text-[11px] sm:text-[12px] text-white/50 font-bold tracking-tight text-center sm:text-left">© 2026 Superhumanly Medical. All rights reserved.</span>
              <div className="hidden md:flex items-center gap-3 text-white/40">
                <ShieldCheck size={14} />
                <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-[0.1em]">ISO 27001 + HIPAA COMPLIANT</span>
              </div>
            </div>

            {/* Social Connectivity */}
            <div className="flex items-center gap-3 sm:gap-4">
              {[Twitter, Linkedin, Github].map((Icon, idx) => (
                <a 
                  key={idx}
                  href="#"
                  className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-white/50 hover:text-white hover:bg-white/5 transition-all duration-300 border border-white/5 hover:border-white/10 active:scale-95"
                >
                  <Icon size={16} className="sm:hidden" />
                  <Icon size={18} className="hidden sm:block" />
                </a>
              ))}
              <div className="w-[1px] h-4 bg-white/5 mx-1 sm:mx-2" />
              <Link to="/auth" className="text-[11px] sm:text-[12px] font-black text-accent-vibrant hover:text-white transition-colors uppercase tracking-[0.15em]">Enter Portal</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
