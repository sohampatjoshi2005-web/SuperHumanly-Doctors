import { motion } from 'framer-motion';
import { ShieldCheck, Database, Cpu, Activity, Stethoscope, Microscope } from 'lucide-react';

const partners = [
  { name: "HL7 FHIR", icon: Database },
  { name: "Epic Systems", icon: Activity },
  { name: "Oracle Cerner", icon: Database },
  { name: "athenahealth", icon: ShieldCheck },
  { name: "Meditech", icon: Cpu },
  { name: "FDA Approved AI", icon: Microscope },
  { name: "HIPAA Compliant", icon: ShieldCheck },
  { name: "NIST Encrypted", icon: ShieldCheck },
  { name: "ISO 27001", icon: ShieldCheck },
];

export default function Marquee() {
  return (
    <div className="py-2 sm:py-3 border-y border-border/40 bg-white/50 relative overflow-hidden">
      {/* Dynamic technical border accent */}
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-accent/10 to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-accent/10 to-transparent"></div>
      
      <div className="absolute top-0 left-0 w-24 sm:w-48 h-full bg-gradient-to-r from-white to-transparent z-10"></div>
      <div className="absolute top-0 right-0 w-24 sm:w-48 h-full bg-gradient-to-l from-white to-transparent z-10"></div>
      
      <div className="flex animate-marquee whitespace-nowrap items-center py-1 sm:py-2">
        {[...partners, ...partners].map((partner, idx) => (
          <div 
            key={idx} 
            className="flex items-center gap-2.5 sm:gap-3.5 px-8 sm:px-14 text-muted-light group hover:text-text transition-colors duration-300 pointer-events-none"
          >
            <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-md bg-off border border-border/40 flex items-center justify-center shrink-0">
               <partner.icon size={13} className="sm:hidden text-muted/80 group-hover:text-accent transition-colors duration-300" />
               <partner.icon size={15} className="hidden sm:block text-muted/80 group-hover:text-accent transition-colors duration-300" />
            </div>
            <span className="text-[11px] sm:text-[12px] font-black uppercase tracking-[0.2em] text-muted/80 group-hover:text-text">{partner.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
