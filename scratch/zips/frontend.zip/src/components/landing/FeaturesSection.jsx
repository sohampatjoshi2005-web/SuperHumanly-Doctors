import { motion } from 'framer-motion';
import { Database, Workflow, Shield, Zap, Activity, Mail } from 'lucide-react';

const features = [
  {
    title: "Clinical AI Transcription",
    description: "Capture clinical encounters with up to 98.4% transcription accuracy using our medical-tuned audio pipeline. Automatically identifies symptoms and history.",
    icon: Activity,
    color: "blue"
  },
  {
    title: "Automated Rx Workflow",
    description: "Go from encounter to digital prescription in seconds. Our AI extracts clinical logic and prepares professional documentation for your review.",
    icon: Workflow,
    color: "purple"
  },
  {
    title: "Patient Identity Registry",
    description: "High-density, professional registry with real-time continuous search. Maintain one-click continuity between lookup and active documentation.",
    icon: Database,
    color: "teal"
  },
  {
    title: "Zero-Knowledge Privacy",
    description: "HIPAA-compliant, encrypted, and isolated infrastructure. We treat clinical data with the weight of professional integrity it deserves.",
    icon: Shield,
    color: "green"
  },
  {
    title: "Direct Digital Dispatch",
    description: "Securely email prescriptions and clinical summaries directly to patients or pharmacies with automated delivery verification.",
    icon: Mail,
    color: "orange"
  },
  {
    title: "Elite Performance v2.0",
    description: "Optimized for high-density clinical environments. Smooth, rapid, and authoritative UI built for professionals who value their time.",
    icon: Zap,
    color: "pink"
  }
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-16 sm:py-20 lg:py-32 px-4 sm:px-6 bg-[#f8f9fa] relative overflow-hidden">
      {/* Background Dots */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{ backgroundImage: 'radial-gradient(circle at 10px 10px, #000 2px, transparent 0)', backgroundSize: '40px 40px' }} />
      
      <div className="mx-auto relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14 lg:mb-20 px-2 sm:px-0">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 sm:px-4 py-1.5 rounded-full bg-accent/[0.04] border border-accent/10 mb-5 sm:mb-8"
          >
            <Zap size={14} className="text-accent fill-accent/20" />
            <span className="text-[9px] sm:text-[12px] font-black uppercase tracking-[0.15em] text-accent">Professional Capabilities</span>
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="font-serif text-[44px] sm:text-[36px] lg:text-[64px] leading-[1.05] tracking-tight text-text mb-5 sm:mb-8"
          >
            Clinical authority through <br className="hidden sm:block" />
            <span className="text-accent italic font-medium">automated precision.</span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-[15.5px] sm:text-[17px] lg:text-[18px] text-text2/60 font-medium leading-relaxed"
          >
            Built for healthcare providers who refuse to compromise on efficiency or clinical accuracy.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {features.map((f, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white p-6 sm:p-8 lg:p-10 rounded-[20px] sm:rounded-[32px] border border-border/40 hover:border-accent/20 transition-all hover:shadow-[0_20px_50px_rgba(0,0,0,0.04)] group"
            >
              <div className={`w-11 h-11 sm:w-14 sm:h-14 rounded-xl sm:rounded-2xl flex items-center justify-center mb-5 sm:mb-8 transition-transform group-hover:scale-110 group-hover:rotate-3 shadow-sm ${
                f.color === 'blue' ? 'bg-[#e8f1ff] text-[#0052cc]' :
                f.color === 'purple' ? 'bg-[#f3efff] text-[#6b46ff]' :
                f.color === 'teal' ? 'bg-[#e2f8f8] text-[#008b8b]' :
                f.color === 'green' ? 'bg-[#edf7f1] text-[#1a7a4a]' :
                f.color === 'orange' ? 'bg-[#fff3e6] text-[#ff8c00]' :
                'bg-[#fff0f5] text-[#db7093]'
              }`}>
                <f.icon size={22} className="sm:hidden" />
                <f.icon size={28} className="hidden sm:block" />
              </div>
              <h3 className="text-[17px] sm:text-[20px] font-black text-text mb-3 sm:mb-4 tracking-tight">{f.title}</h3>
              <p className="text-[14px] sm:text-[15px] font-medium text-muted leading-relaxed line-clamp-3 group-hover:text-text2 transition-colors">
                {f.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
