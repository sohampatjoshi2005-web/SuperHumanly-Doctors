import { motion } from 'framer-motion';
import { 
  Stethoscope, ClipboardList, Database, ShieldCheck, 
  Activity, Zap, ArrowRight, Microscope, 
  Search, Lock, Globe, HeartPulse
} from 'lucide-react';

const SolutionItem = ({ title, description, icon: Icon, color, delay = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="p-6 sm:p-7 flex flex-col items-start border border-border/50 hover:border-accent/30 bg-white hover:shadow-[0_8px_30px_rgba(0,0,0,0.03)] transition-all duration-500 rounded-[24px] sm:rounded-[32px] group relative overflow-hidden"
    >
      <div className={`w-11 h-11 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center mb-6 sm:mb-8 bg-off border border-border/40 text-text/40 group-hover:text-accent transition-all duration-500 ${
        color === 'blue' ? 'group-hover:bg-blue-50/50' :
        color === 'teal' ? 'group-hover:bg-teal-50/50' :
        color === 'purple' ? 'group-hover:bg-purple-50/50' :
        color === 'green' ? 'group-hover:bg-green-50/50' :
        color === 'orange' ? 'group-hover:bg-orange-50/50' :
        'group-hover:bg-pink-50/50'
      }`}>
        <Icon size={20} className="sm:hidden" />
        <Icon size={22} className="hidden sm:block" />
      </div>

      <h3 className="text-[19px] sm:text-[21px] font-black text-text mb-1 sm:mb-2 tracking-tight">
        {title}
      </h3>
      <p className="text-[14px] sm:text-[15px] font-medium text-text2 leading-[1.6] mb-4 sm:mb-4 flex-1">
        {description}
      </p>

      <div className="mt-auto pt-5 sm:pt-6 border-t border-border/70 w-full flex items-center justify-between">
        <a href="#" className="flex items-center gap-1.5 text-md sm:text-md font-bold text-accent transition-all hover:gap-2 w-full justify-end">
           Explore <ArrowRight size={14} />
        </a>
      </div>
    </motion.div>
  );
};

export default function SolutionsSection() {
  const solutions = [
    {
      title: "Ambient Digital Note-Taking",
      description: "Real-time voice → structured clinical notes with Auto ICD/CPT coding and context-aware summaries.",
      icon: Activity,
      color: "blue"
    },
    {
      title: "HMS / EHR Integration Layer",
      description: "Seamless integration with Epic, Cerner, Athena, and custom HMS with an API-driven Patient 360 view.",
      icon: Globe,
      color: "orange"
    },
    {
      title: "Healthcare Data Intelligence",
      description: "Ask your data in plain English with Superhumanly Thoughts™. Predictive risk scoring and clinical insights.",
      icon: Database,
      color: "teal"
    },
    {
      title: "AI Agents / Co-Workers",
      description: "Specialized clinical, coding, and patient engagement agents designed to coordinate care automatically.",
      icon: Zap,
      color: "purple"
    }
  ];

  return (
    <section id="solutions" className="py-16 sm:py-20 lg:py-28 px-4 sm:px-6 lg:px-12 bg-white relative overflow-hidden">
      <div className="mx-auto">
        <div className="flex flex-col lg:flex-row items-start lg:items-end justify-between gap-2 sm:gap-10 lg:gap-16 mb-12 sm:mb-20 lg:px-4">
           <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/[0.04] border border-accent/10 mb-5 sm:mb-8 font-black uppercase tracking-[0.15em] text-[9px] sm:text-[10px] text-accent">Technical Clinical Ecosystem</div>
              <h2 className="font-serif text-[42px] sm:text-[36px] lg:text-[56px] leading-[1.05] sm:leading-[0.95] tracking-tight text-text">
                 High-fidelity protocols for <br className="hidden sm:block"/>
                 <span className="text-accent italic font-medium">professional documentation.</span>
              </h2>
           </div>
           <p className="text-[15.5px] sm:text-[17px] text-text2 max-w-[360px] font-medium leading-[1.7] pb-0 lg:pb-3">
              Superhumanly Medical provides a high-density environment for physicians who demand institutional accuracy.
           </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {solutions.map((s, idx) => (
            <SolutionItem 
              key={idx} 
              {...s} 
              delay={idx * 0.05}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
