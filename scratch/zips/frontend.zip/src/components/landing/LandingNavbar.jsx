import { useState, useEffect, useRef, useLayoutEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Rocket, Brain, Layout, Database, ShieldCheck, Sparkles, 
  MessageSquare, MousePointer2, Users, HeartPulse, Stethoscope, 
  FileText, BookOpen, Zap, HelpCircle, Mail, Activity, ClipboardList, Thermometer,
  Menu, X, ChevronDown
} from 'lucide-react';

export default function LandingNavbar() {
  const [openNav, setOpenNav] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [metrics, setMetrics] = useState({ width: 0, height: 0, left: 0, show: false });
  const [triggerMetrics, setTriggerMetrics] = useState({ left: 0, top: 0, width: 0, height: 0, show: false, isSliding: false });
  const [optionMetrics, setOptionMetrics] = useState({ left: 0, top: 0, width: 0, height: 0, show: false, isSliding: false });
  const optionHoverTimer = useRef(null);
  const navRef = useRef(null);
  const menuRef = useRef(null);
  const contentRefs = useRef({});
  const triggerRefs = useRef({});

  // Mobile state
  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileAccordion, setMobileAccordion] = useState(null);

  const location = useLocation();

  useEffect(() => {
    const token = localStorage.getItem('doc_token');
    setIsLoggedIn(!!token);
    setOpenNav(null);
    setMobileOpen(false);
    setMobileAccordion(null);
  }, [location]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  useEffect(() => {
    function handleClickOutside(event) {
      if (navRef.current && !navRef.current.contains(event.target)) {
        setOpenNav(null);
      }
    }
    document.addEventListener('click', handleClickOutside);
    
    const handleResize = () => {
      setOpenNav(null);
      if (window.innerWidth >= 1024) {
        setMobileOpen(false);
        setMobileAccordion(null);
      }
    };
    window.addEventListener('resize', handleResize);
    
    return () => {
      document.removeEventListener('click', handleClickOutside);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useLayoutEffect(() => {
    if (openNav) {
      const contentEl = contentRefs.current[openNav];
      const triggerEl = triggerRefs.current[openNav];
      const menuEl = menuRef.current;
      
      if (contentEl && triggerEl && menuEl) {
        const triggerRect = triggerEl.getBoundingClientRect();
        const menuRect = menuEl.getBoundingClientRect();
        
        const width = contentEl.offsetWidth;
        const height = contentEl.offsetHeight;
        
        const triggerCenterLeft = (triggerRect.left - menuRect.left) + (triggerRect.width / 2);
        let leftOffset = triggerCenterLeft - (width / 2);
        
        setMetrics({ width, height, left: leftOffset, show: true });

        setTriggerMetrics(prev => {
          const isFresh = !prev.show;
          return {
            left: triggerRect.left - menuRect.left,
            top: triggerRect.top - menuRect.top,
            width: triggerRect.width,
            height: triggerRect.height,
            show: true,
            isSliding: !isFresh
          };
        });
      }
    } else {
      setMetrics(prev => ({ ...prev, show: false }));
      setTriggerMetrics(prev => ({ ...prev, show: false, isSliding: false }));
    }
    setOptionMetrics(prev => ({ ...prev, show: false, isSliding: false }));
  }, [openNav]);

  const handleDropdownMouseMove = (e) => {
    const item = e.target.closest('.dd-product-item, .dd-column-link');
    if (item) {
      clearTimeout(optionHoverTimer.current);
      optionHoverTimer.current = null;
      const container = item.closest('.morph-dropdown-contents');
      if (!container) return;
      const cRect = container.getBoundingClientRect();
      const iRect = item.getBoundingClientRect();
      
      setOptionMetrics(prev => {
        const isFresh = !prev.show;
        if (prev.show && prev.left === iRect.left - cRect.left && prev.top === iRect.top - cRect.top) return prev;
        
        return {
          left: iRect.left - cRect.left,
          top: iRect.top - cRect.top,
          width: iRect.width,
          height: iRect.height,
          show: true,
          isSliding: !isFresh
        };
      });
    } else {
      if (!optionHoverTimer.current) {
        optionHoverTimer.current = setTimeout(() => {
          setOptionMetrics(prev => ({ ...prev, show: false, isSliding: false }));
        }, 50);
      }
    }
  };

  const handleDropdownMouseLeave = () => {
    clearTimeout(optionHoverTimer.current);
    optionHoverTimer.current = setTimeout(() => {
      setOptionMetrics(prev => ({ ...prev, show: false, isSliding: false }));
    }, 50);
  };

  const toggleNav = (id) => {
    setOpenNav(openNav === id ? null : id);
  };

  const toggleMobileAccordion = (id) => {
    setMobileAccordion(mobileAccordion === id ? null : id);
  };

  // Mobile nav data
  const mobileNavSections = [
    {
      id: 'capabilities',
      label: 'Capabilities',
      items: [
        { icon: Activity, name: 'AI Intake Engine', sub: 'Whisper-fidelity audio capture', badge: 'v2.0', color: 'blue' },
        { icon: Brain, name: 'Diagnostic Assistant', sub: 'Differential diagnosis suggestions', color: 'purple' },
        { icon: Layout, name: 'Smart Registry', sub: 'High-density patient dashboards', color: 'teal' },
        { icon: ClipboardList, name: 'Auto-Prescription', sub: 'Instant RX generation', color: 'green' },
      ]
    },
    {
      id: 'solutions',
      label: 'Solutions',
      items: [
        { icon: Stethoscope, name: 'Outpatient Care', sub: 'General Practice, Specialist, Pediatric', color: 'blue' },
        { icon: Thermometer, name: 'Emergency Medicine', sub: 'Rapid Intake, Trauma, Acute Care', color: 'teal' },
        { icon: ShieldCheck, name: 'Compliance AI', sub: 'HIPAA Audit, Integrity, Billing', color: 'purple' },
      ]
    },
    {
      id: 'resources',
      label: 'Resources',
      items: [
        { icon: FileText, name: 'Documentation', path: '/documentation' },
        { icon: BookOpen, name: 'Medical Blog', path: '/about' },
        { icon: Database, name: 'API Reference', path: '/documentation' },
        { icon: HelpCircle, name: 'FAQ', path: '/faq' },
        { icon: Mail, name: 'Contact Medical Support', path: '/contact' },
      ]
    }
  ];

  return (
    <>
      {/* Desktop overlay */}
      <div 
        className={`fixed inset-0 z-[190] bg-black/15 backdrop-blur-[2px] transition-all duration-500 ease-out pointer-events-none ${
          openNav ? 'opacity-100' : 'opacity-0'
        }`}
        aria-hidden="true"
      />

      <nav
        ref={navRef}
        className={`fixed top-3 sm:top-5 z-[200] w-[calc(100%-16px)] sm:w-[calc(100%-32px)] lg:w-[calc(100%-80px)] max-w-7xl left-1/2 -translate-x-1/2 bg-white/85 backdrop-blur-[32px] backdrop-saturate-200 border border-border shadow-nav rounded-full h-14 sm:h-16 flex items-center px-1 transition-all duration-[500ms] ease-[cubic-bezier(0.16,1,0.3,1)] hover:bg-white/95 hover:shadow-nav-hover ${openNav ? '!bg-black/[0.04] !backdrop-blur-xl !border-white/30 !shadow-[0_24px_64px_rgba(0,0,0,0.1),inset_0_0_0_1px_rgba(255,255,255,0.4)]' : ''}`}
      >
        <div className="flex items-center w-full justify-between">
          <div className="flex-1 flex justify-start pl-2">
            <Link className="flex items-center gap-2 sm:gap-2.5 no-underline shrink-0 transition-opacity hover:opacity-80 group" to="/">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-accent rounded-full flex items-center justify-center shadow-[0_4px_12px_rgba(0,0,0,0.15)] transition-all duration-300">
                <span className="text-white font-black text-md sm:text-lg">S</span>
              </div>
              <div className="font-serif text-[20px] sm:text-[21px] lg:text-[23px] text-text tracking-[-0.02em]">
                Superhumanly <span className="italic text-accent font-medium">Doctors</span>
              </div>
            </Link>
          </div>

          {/* === DESKTOP NAV (lg+) === */}
          <div className="hidden lg:flex flex-none items-center justify-center gap-1.5 relative px-4" ref={menuRef}>
            <div
              className="absolute bg-white rounded-full z-0 pointer-events-none shadow-sm"
              style={{
                left: triggerMetrics.left,
                top: triggerMetrics.top,
                width: triggerMetrics.width,
                height: triggerMetrics.height,
                opacity: triggerMetrics.show ? 1 : 0,
                transform: triggerMetrics.show ? 'scale(1)' : 'scale(0)',
                transition: triggerMetrics.isSliding 
                  ? 'all 0.4s cubic-bezier(0.16, 1, 0.3, 1)' 
                  : 'opacity 0.25s ease, transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
                transformOrigin: 'center'
              }}
            />

            <button
              ref={el => triggerRefs.current['capabilities'] = el}
              className={`relative z-10 flex items-center gap-1.5 px-3.5 py-3 rounded-full text-sm font-semibold cursor-pointer bg-transparent border-none font-sans transition-all duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] whitespace-nowrap tracking-[-0.01em] hover:bg-black/5 hover:text-text ${openNav === 'capabilities' ? '!bg-transparent text-text' : 'text-text2'}`}
              onClick={() => toggleNav('capabilities')}
            >
              Capabilities
              <svg className={`w-[13px] h-[13px] opacity-100 transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${openNav === 'capabilities' ? 'rotate-180' : ''}`} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 6l4 4 4-4"/></svg>
            </button>

            <button
              ref={el => triggerRefs.current['solutions'] = el}
              className={`relative z-10 flex items-center gap-1.5 px-3.5 py-3 rounded-full text-sm font-semibold cursor-pointer bg-transparent border-none font-sans transition-all duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] whitespace-nowrap tracking-[-0.01em] hover:bg-black/5 hover:text-text ${openNav === 'solutions' ? '!bg-transparent text-text' : 'text-text2'}`}
              onClick={() => toggleNav('solutions')}
            >
              Solutions
              <svg className={`w-[13px] h-[13px] opacity-60 transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${openNav === 'solutions' ? 'rotate-180' : ''}`} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 6l4 4 4-4"/></svg>
            </button>

            <button
              ref={el => triggerRefs.current['resources'] = el}
              className={`relative z-10 flex items-center gap-1.5 px-3.5 py-3 rounded-full text-sm font-semibold cursor-pointer bg-transparent border-none font-sans transition-all duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] whitespace-nowrap tracking-[-0.01em] hover:bg-black/5 hover:text-text ${openNav === 'resources' ? '!bg-transparent text-text' : 'text-text2'}`}
              onClick={() => toggleNav('resources')}
            >
              Resources
              <svg className={`w-[13px] h-[13px] opacity-60 transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${openNav === 'resources' ? 'rotate-180' : ''}`} viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 6l4 4 4-4"/></svg>
            </button>

            {/* SHARED MORPHING DROPDOWN CONTAINER */}
            <div 
              className={`morph-dropdown-wrapper ${metrics.show ? 'visible' : ''}`}
              style={{
                transform: `translateX(${metrics.left}px)`,
                width: `${metrics.width}px`,
                height: `${metrics.height}px`
              }}
            >
              <div className="morph-dropdown-bg" />
              
              <div 
                className="morph-dropdown-contents"
                onMouseMove={handleDropdownMouseMove}
                onMouseLeave={handleDropdownMouseLeave}
              >
                <div
                  className="absolute bg-white z-0 pointer-events-none"
                  style={{
                    left: optionMetrics.left,
                    top: optionMetrics.top,
                    width: optionMetrics.width,
                    height: optionMetrics.height,
                    opacity: optionMetrics.show ? 1 : 0,
                    transform: optionMetrics.show ? 'scale(1)' : 'scale(0)',
                    borderRadius: '20px',
                    boxShadow: '0 12px 36px -6px rgba(0,0,0,0.12), 0 4px 12px -4px rgba(0,0,0,0.08), 0 0 0 1px rgba(0,0,0,0.02)',
                    transition: optionMetrics.isSliding
                      ? 'all 0.3s cubic-bezier(0.16, 1, 0.3, 1)'
                      : 'opacity 0.2s ease, transform 0.25s cubic-bezier(0.16, 1, 0.3, 1)',
                    transformOrigin: 'center'
                  }}
                />
                
                {/* Capabilities Content */}
                <div 
                  ref={el => contentRefs.current['capabilities'] = el}
                  className={`morph-content ${openNav === 'capabilities' ? 'active' : ''}`}
                >
                  <div className="mega-dropdown-header">
                    <span>Clinical Modules</span>
                  </div>
                  <div className="mega-grid-2">
                    <a className="dd-product-item" href="#">
                      <div className="dpi-ico blue"><Activity size={20} /></div>
                      <div className="dpi-body">
                        <div className="dpi-name">AI Intake Engine <span className="dpi-badge">v2.0</span></div>
                        <div className="dpi-sub">Whisper-fidelity audio capture with clinical symptom extraction.</div>
                      </div>
                    </a>
                    <a className="dd-product-item" href="#">
                      <div className="dpi-ico purple"><Brain size={20} /></div>
                      <div className="dpi-body">
                        <div className="dpi-name">Diagnostic Assistant</div>
                        <div className="dpi-sub">Differential diagnosis suggestions based on real-time encounter data.</div>
                      </div>
                    </a>
                    <a className="dd-product-item" href="#">
                      <div className="dpi-ico teal"><Layout size={20} /></div>
                      <div className="dpi-body">
                        <div className="dpi-name">Smart Registry</div>
                        <div className="dpi-sub">High-density patient dashboards with continuous real-time search.</div>
                      </div>
                    </a>
                    <a className="dd-product-item" href="#">
                      <div className="dpi-ico green"><ClipboardList size={20} /></div>
                      <div className="dpi-body">
                        <div className="dpi-name">Auto-Prescription</div>
                        <div className="dpi-sub">Instant RX generation from clinical notes with safety validation.</div>
                      </div>
                    </a>
                  </div>
                </div>

                {/* Solutions Content */}
                <div 
                  ref={el => contentRefs.current['solutions'] = el}
                  className={`morph-content ${openNav === 'solutions' ? 'active' : ''}`}
                >
                  <div className="mega-grid-3">
                    <div className="dd-column">
                      <div className="dd-column-header">
                         <div className="h-ico bg-blue-50 text-blue-600"><Stethoscope size={16} /></div>
                         <div className="h-name">Outpatient Care</div>
                      </div>
                      <div className="dd-column-items">
                         <a className="dd-column-link" href="#">General Practice AI</a>
                         <a className="dd-column-link" href="#">Specialist Consultation</a>
                         <a className="dd-column-link" href="#">Pediatric Documentation</a>
                      </div>
                    </div>
                    <div className="dd-column">
                      <div className="dd-column-header">
                         <div className="h-ico bg-teal-50 text-teal-600"><Thermometer size={16} /></div>
                         <div className="h-name">Emergency Medicine</div>
                      </div>
                      <div className="dd-column-items">
                         <a className="dd-column-link" href="#">Rapid Intake Triage</a>
                         <a className="dd-column-link" href="#">Trauma Documentation</a>
                         <a className="dd-column-link" href="#">Acute Care Support</a>
                      </div>
                    </div>
                    <div className="dd-column">
                      <div className="dd-column-header">
                         <div className="h-ico bg-purple-50 text-purple-600"><ShieldCheck size={16} /></div>
                         <div className="h-name">Compliance AI</div>
                      </div>
                      <div className="dd-column-items">
                         <a className="dd-column-link" href="#">HIPAA Audit Logging</a>
                         <a className="dd-column-link" href="#">Clinical Integrity Check</a>
                         <a className="dd-column-link" href="#">Automated Billing Tags</a>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Resources Content */}
                <div 
                  ref={el => contentRefs.current['resources'] = el}
                  className={`morph-content ${openNav === 'resources' ? 'active' : ''}`}
                >
                  <div className="flex flex-col gap-1 min-w-[220px]">
                    <Link className="dd-column-link" to="/documentation">
                      <FileText size={16} className="text-muted" /> Documentation
                    </Link>
                    <a className="dd-column-link" href="/about">
                      <BookOpen size={16} className="text-muted" /> Medical Blog
                    </a>
                    <a className="dd-column-link" href="/documentation">
                      <Database size={16} className="text-muted" /> API Reference
                    </a>
                    <div className="h-px bg-border/50 my-2 mx-2" />
                    <Link className="dd-column-link" to="/faq">
                      <HelpCircle size={16} className="text-muted" /> FAQ
                    </Link>
                    <Link className="dd-column-link" to="/contact">
                      <Mail size={16} className="text-muted" /> Contact Medical Support
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* === RIGHT SIDE === */}
          <div className="flex-1 flex justify-end pr-1 sm:pr-2 gap-2 items-center">
            {/* Desktop CTA */}
            <Link 
              to={isLoggedIn ? "/portal" : "/auth"} 
              className="hidden sm:block px-4 lg:px-6 py-2.5 sm:py-3 bg-text text-white border-none rounded-full text-xs lg:text-sm font-bold cursor-pointer font-sans transition-all duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] shadow-[0_4px_12px_rgba(0,0,0,0.15)] tracking-[-0.01em] hover:bg-black active:scale-[0.98] no-underline whitespace-nowrap"
            >
              {isLoggedIn ? "My Workspace →" : "Enter Portal →"}
            </Link>

            {/* Mobile hamburger button */}
            <button
              className="lg:hidden flex items-center justify-center w-10 h-10 rounded-full bg-transparent border-none cursor-pointer text-text hover:bg-black/5 transition-colors active:scale-95"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle mobile menu"
            >
              {mobileOpen ? <X size={20} strokeWidth={2.5} /> : <Menu size={20} strokeWidth={2.5} />}
            </button>
          </div>
        </div>
      </nav>

      {/* === MOBILE DRAWER === */}
      {/* Overlay */}
      <div 
        className={`lg:hidden fixed inset-0 z-[195] bg-black/30 backdrop-blur-sm transition-opacity duration-300 ${
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setMobileOpen(false)}
      />
      
      {/* Drawer Panel */}
      <div 
        className={`lg:hidden fixed top-[72px] sm:top-[88px] left-1/2 z-[210] w-[calc(100%-16px)] sm:w-[calc(100%-32px)] max-w-7xl bg-white border border-border shadow-[0_24px_80px_rgba(0,0,0,0.1)] overflow-hidden transition-all duration-[400ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
          mobileOpen 
            ? 'opacity-100 -translate-x-1/2 translate-y-0 scale-100' 
            : 'opacity-0 -translate-x-1/2 -translate-y-3 scale-[0.98] pointer-events-none'
        }`}
        style={{ maxHeight: 'calc(100vh - 90px)' }}
      >
        <div className="overflow-y-auto max-h-[calc(100vh-110px)] p-4 sm:p-5">
          {/* Accordion Sections */}
          {mobileNavSections.map((section) => (
            <div key={section.id} className="mb-1">
              <button
                className="w-full flex items-center justify-between py-3.5 px-3 rounded-2xl text-left bg-transparent border-none cursor-pointer font-sans hover:bg-off transition-colors active:bg-off/80"
                onClick={() => toggleMobileAccordion(section.id)}
              >
                <span className="text-[15px] font-bold text-text tracking-[-0.01em]">{section.label}</span>
                <ChevronDown 
                  size={16} 
                  className={`text-muted transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                    mobileAccordion === section.id ? 'rotate-180' : ''
                  }`} 
                />
              </button>
              
              {/* Accordion Content */}
              <div 
                className="overflow-hidden transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)]"
                style={{
                  maxHeight: mobileAccordion === section.id ? `${section.items.length * 60 + 20}px` : '0px',
                  opacity: mobileAccordion === section.id ? 1 : 0,
                }}
              >
                <div className="pl-2 pr-1 pb-3 flex flex-col gap-1">
                  {section.items.map((item, idx) => (
                    <Link 
                      key={idx} 
                      to={item.path || "#"} 
                      className="flex items-center gap-3.5 px-3 py-3 rounded-xl hover:bg-off transition-colors no-underline group"
                      onClick={() => setMobileOpen(false)}
                    >
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border border-border/40 transition-colors ${
                        item.color === 'blue' ? 'bg-[#e8f1ff] text-[#0052cc]' :
                        item.color === 'purple' ? 'bg-[#f3efff] text-[#6b46ff]' :
                        item.color === 'teal' ? 'bg-[#e2f8f8] text-[#008b8b]' :
                        item.color === 'green' ? 'bg-[#edf7f1] text-[#1a7a4a]' :
                        'bg-off text-muted'
                      }`}>
                        <item.icon size={16} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-[14px] font-bold text-text flex items-center gap-2">
                          {item.name}
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          ))}

          {/* Divider */}
          <div className="h-px bg-border/40 my-3 mx-3" />

          {/* CTA Buttons */}
          <div className="flex flex-col gap-2.5 px-1 pt-2 pb-1">
            <Link 
              to={isLoggedIn ? "/portal" : "/auth"} 
              className="w-full py-3.5 bg-text text-white rounded-2xl text-[15px] font-bold text-center no-underline shadow-lg shadow-black/10 hover:bg-black transition-colors active:scale-[0.98]"
              onClick={() => setMobileOpen(false)}
            >
              {isLoggedIn ? "My Workspace →" : "Enter Portal →"}
            </Link>
            <Link 
              to="/request-trial" 
              className="w-full py-3.5 bg-off border border-border/60 text-text rounded-2xl text-[15px] font-bold text-center no-underline hover:bg-border/20 transition-colors active:scale-[0.98]"
              onClick={() => setMobileOpen(false)}
            >
              Request Trial
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
