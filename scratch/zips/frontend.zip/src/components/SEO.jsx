import { Helmet } from 'react-helmet-async';

export default function SEO({ title, description, name, type, schema, canonical }) {
  const siteTitle = "Superhumanly Doctors";
  const fullTitle = title ? `${title} | ${siteTitle}` : siteTitle;
  const siteDescription = description || "Professional clinical documentation and management portal for healthcare providers. Built for institutional medical sovereignty.";

  return (
    <Helmet>
      {/* Standard metadata tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={siteDescription} />
      
      {/* Facebook tags */}
      <meta property="og:type" content={type || 'website'} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={siteDescription} />
      <meta property="og:site_name" content={name || siteTitle} />
      
      {/* Twitter tags */}
      <meta name="twitter:creator" content={name || siteTitle} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={siteDescription} />
      
      {/* Canonical URL */}
      <link rel="canonical" href={canonical || `https://superhumanlymedical.io${window.location.pathname}`} />
      
      {/* JSON-LD Structured Data */}
      {schema && (
        <script type="application/ld+json">
          {JSON.stringify(schema)}
        </script>
      )}
    </Helmet>
  );
}
