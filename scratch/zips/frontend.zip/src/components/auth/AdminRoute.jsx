import { Navigate } from 'react-router-dom';

const AdminRoute = ({ children }) => {
  const token = localStorage.getItem('doc_token');
  const userJson = localStorage.getItem('doc_user');
  const user = userJson ? JSON.parse(userJson) : null;
  
  if (!token || !user || user.role !== 'admin') {
    return <Navigate to="/admin/login" replace />;
  }

  return children;
};

export default AdminRoute;
