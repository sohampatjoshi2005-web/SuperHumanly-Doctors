import { Navigate, useLocation } from 'react-router-dom';

const AuthRoute = ({ children }) => {
  const token = localStorage.getItem('doc_token');
  const location = useLocation();
  
  if (token) {
    // Redirect to portal if already authenticated
    return <Navigate to="/portal" replace />;
  }

  return children;
};

export default AuthRoute;
