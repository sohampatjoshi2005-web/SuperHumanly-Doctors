import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Cloud, Globe, Database, ShieldCheck, Activity, RefreshCw, AlertCircle, CheckCircle2, Server, Link2, Sparkles, AlertTriangle, Shield, Check, Plus, X } from 'lucide-react';
import { fetchEHRSystems, syncEHRRecord, fetchEHRDeltas, createEHRSystem } from '../../lib/doctorApi';

const EHRSystemCard = ({ provider_name, status, last_sync, onClick }) => {
  const Icon = provider_name === 'Epic' ? Server : provider_name === 'Cerner' ? Database : Cloud;
  const color = provider_name === 'Epic' ? 'blue' : provider_name === 'Cerner' ? 'orange' : 'purple';
  
  return (
    <button 
      onClick={onClick}
      className="bg-white border border-border/60 p-5 rounded-2xl hover:border-accent/40 transition-all group text-left w-full cursor-pointer"
    >
      <div className="flex items-center justify-between mb-4">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center relative ${
          color === 'blue' ? 'bg-blue-50 text-blue-600' :
          color === 'orange' ? 'bg-orange-50 text-orange-600' :
          'bg-purple-50 text-purple-600'
        }`}>
          {status === 'Active' && (
            <div className="absolute inset-0 bg-current rounded-xl blur-md opacity-20 animate-pulse scale-110" />
          )}
          <Icon size={20} className="relative z-10" />
        </div>
        <div className="flex flex-col items-end">
          <div className={`flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest ${
            status === 'Active' ? 'text-green-600' : 'text-orange-500'
          }`}>
            <div className={`w-1.5 h-1.5 rounded-full ${status === 'Active' ? 'bg-green-600' : 'bg-orange-500'} animate-pulse`} />
            {status}
          </div>
          <span className="text-[10px] text-muted font-medium">Last Updated: {new Date(last_sync).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
        </div>
      </div>
      <h3 className="text-[16px] font-bold text-text mb-1">{provider_name} System</h3>
      <p className="text-[12px] text-muted mb-4 leading-relaxed">Secure Cloud Connection</p>
      <div className="pt-4 border-t border-border/40 flex items-center justify-between">
        <div className="flex -space-x-1.5">
          {[1, 2, 3].map(i => (
            <div key={i} className="w-5 h-5 rounded-md bg-off border border-white flex items-center justify-center text-[7px] font-black text-muted">
              {i}
            </div>
          ))}
        </div>
        <span className="text-[11px] font-bold text-accent hover:underline flex items-center gap-1">
          Review Updates <Link2 size={12} />
        </span>
      </div>
    </button>
  );
};

export default function EHRSyncTab({ setActiveTab, activeEncounterId }) {
  const [syncing, setSyncing] = useState(false);
  const [selectedSystem, setSelectedSystem] = useState(null);
  const [systems, setSystems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deltas, setDeltas] = useState(null);
  const [syncResult, setSyncResult] = useState(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newSystemName, setNewSystemName] = useState("");
  const [newSystemStatus, setNewSystemStatus] = useState("Active");
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    loadSystems();
  }, []);

  useEffect(() => {
    if (activeEncounterId && selectedSystem) {
       loadDeltas();
    }
  }, [activeEncounterId, selectedSystem]);

  const loadDeltas = async () => {
    try {
      const data = await fetchEHRDeltas(activeEncounterId, selectedSystem.id || selectedSystem.provider_name);
      setDeltas(data);
    } catch (e) {
      console.error('Failed to load deltas:', e);
    }
  };

  const loadSystems = async () => {
    try {
      const data = await fetchEHRSystems();
      setSystems(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleAddSystem = async (e) => {
    e.preventDefault();
    if (!newSystemName) return;
    setIsAdding(true);
    try {
      await createEHRSystem(newSystemName, newSystemStatus);
      await loadSystems();
      setNewSystemName("");
      setShowAddModal(false);
    } catch (e) {
      console.error(e);
      alert("Failed to connect system");
    } finally {
      setIsAdding(false);
    }
  };

  const triggerSync = async (systemId) => {
    if (!activeEncounterId) return;
    setSyncing(true);
    try {
      const result = await syncEHRRecord(systemId, activeEncounterId);
      setSyncResult(result);
      await loadSystems();
      // Delay closing to show success
      setTimeout(() => {
        setSelectedSystem(null);
        setSyncResult(null);
      }, 3000);
    } catch (e) {
       console.error(e);
    } finally {
      setSyncing(false);
    }
  };

  const ProcessStepper = () => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
       {[
         { step: "01", title: "Compare Records", desc: "Identify differences between AI suggestions and official records.", icon: RefreshCw },
         { step: "02", title: "Review & Approve", desc: "Review and approve suggested updates to the patient record.", icon: AlertCircle },
         { step: "03", title: "Save to EHR", desc: "Securely save verified updates back to your hospital system.", icon: CheckCircle2 }
       ].map((item, i) => (
         <div key={i} className="flex gap-4 p-5 bg-white border border-border/40 rounded-2xl shadow-sm">
            <div className="w-10 h-10 rounded-xl bg-accent/5 flex items-center justify-center shrink-0">
               <item.icon size={18} className="text-accent" />
            </div>
            <div>
               <div className="text-[10px] font-black text-muted uppercase mb-1">Step {item.step}</div>
               <h4 className="text-[14px] font-bold text-text mb-1">{item.title}</h4>
               <p className="text-[12px] text-muted leading-tight">{item.desc}</p>
            </div>
         </div>
       ))}
    </div>
  );

  const SelectionRequired = () => (
    <div className="flex-1 flex flex-col items-center justify-center p-10 bg-off/30 border-2 border-dashed border-border/60 rounded-[40px] mb-10 min-h-[400px]">
       <div className="w-20 h-20 rounded-3xl bg-white border border-border/60 flex items-center justify-center mb-6 shadow-sm">
          <Activity size={32} className="text-accent animate-pulse" />
       </div>
       <h2 className="text-[24px] font-serif italic text-text mb-2">Patient Selection Required</h2>
       <p className="max-w-md text-center text-[15px] text-muted mb-8 leading-relaxed">
          The EHR Integrity Layer requires an active clinical context. Select a patient from the sidebar to begin conflict resolution.
       </p>
       <div className="flex gap-3">
          <div className="px-4 py-2 bg-text text-white rounded-xl text-[12px] font-bold flex items-center gap-2">
             <Link2 size={14} /> Sidebar Active
          </div>
          <div className="px-4 py-2 bg-white border border-border/60 rounded-xl text-[12px] font-bold text-muted">
             HMS Gateway: Online
          </div>
       </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col p-6 overflow-y-auto custom-scrollbar">
      <div className="flex flex-col lg:flex-row items-start justify-between gap-8 mb-12">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/5 border border-accent/10 mb-6">
            <ShieldCheck size={14} className="text-accent" />
            <span className="text-[10px] font-black uppercase tracking-widest text-accent">Secure Verified Sync</span>
          </div>
          <h1 className="text-[36px] font-serif tracking-tight text-text leading-tight mb-4">
            EHR Sync <span className="italic text-accent">Workspace</span>
          </h1>
          <p className="text-[16px] text-muted font-medium leading-relaxed">
            Review AI suggestions and sync verified data with your hospital's electronic health records. Use this space to approve updates and ensure institutional accuracy.
          </p>
        </div>
        <div className="flex flex-col items-end gap-2">
           <button 
             onClick={() => alert("Re-polling HSM gateways...")}
             disabled={syncing}
             className="px-6 py-3 bg-text text-white rounded-[18px] text-[14px] font-bold flex items-center gap-2 shadow-xl shadow-black/10 active:scale-95 transition-all"
           >
             <RefreshCw size={16} className={syncing ? 'animate-spin' : ''} />
             {syncing ? 'Connecting...' : 'Refresh Records'}
           </button>
           <div className="text-[11px] font-medium text-muted italic">System Connection Verified</div>
        </div>
      </div>

      <ProcessStepper />

      {!activeEncounterId ? (
        <SelectionRequired />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
           {systems.map((sys, idx) => (
            <EHRSystemCard 
              key={idx}
              {...sys}
              onClick={() => setSelectedSystem(sys)} 
            />
          ))}

          <button 
            onClick={() => setShowAddModal(true)}
            className="bg-off/30 border-2 border-dashed border-border/60 p-5 rounded-2xl hover:border-accent/40 hover:bg-white transition-all group flex flex-col items-center justify-center min-h-[160px] cursor-pointer"
          >
            <div className="w-10 h-10 rounded-full bg-white border border-border/40 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Plus size={20} className="text-muted group-hover:text-accent transition-colors" />
            </div>
            <span className="text-[13px] font-bold text-muted group-hover:text-text">Add Hospital System</span>
          </button>

          {systems.length === 0 && !loading && <div className="col-span-4 py-12 text-center opacity-40 italic">Currently disconnected from hospital systems.</div>}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 flex-1">
        <div className="xl:col-span-2 bg-off border border-border/60 rounded-[28px] p-8">
           <div className="flex items-center justify-between mb-8">
              <h3 className="text-[18px] font-bold text-text flex items-center gap-2">
                <ShieldCheck size={20} className="text-accent" /> 
                Sync Activity
              </h3>
              <div className="text-[11px] font-black text-muted uppercase tracking-[0.2em]">Connection Status</div>
           </div>
           
           <div className="space-y-4">
              {[
                { event: "PATIENT.DISCHARGE", system: "Epic", status: "Processed", time: "12:44:02 PM" },
                { event: "LAB_RESULT.READY", system: "Cerner", status: "Processed", time: "12:42:15 PM" },
                { event: "MED_RECON.UPDATE", system: "Athena", status: "Queued", time: "12:45:10 PM" },
                { event: "AUTH_VERIFY.INIT", system: "Epic", status: "Processed", time: "12:38:55 PM" },
              ].map((log, i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-white border border-border/40 rounded-xl">
                   <div className="flex items-center gap-4">
                      <div className="w-2 h-2 rounded-full bg-accent" />
                      <div>
                         <div className="text-[13px] font-bold text-text">{log.event}</div>
                         <div className="text-[11px] font-medium text-muted">via {log.system} Cloud Bridge</div>
                      </div>
                   </div>
                   <div className="flex items-center gap-6">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-tighter ${
                        log.status === 'Processed' ? 'bg-green-50 text-green-600' : 'bg-orange-50 text-orange-600'
                      }`}>{log.status}</span>
                      <span className="text-[11px] font-mono text-muted font-bold">{log.time}</span>
                   </div>
                </div>
              ))}
           </div>
        </div>

        <div className="flex flex-col gap-6">
          <div className="bg-white border-2 border-accent/10 rounded-[28px] p-8 shadow-xl shadow-accent/5">
            <div className="flex items-center justify-between mb-6">
               <h3 className="text-[17px] font-black text-text flex items-center gap-2 uppercase tracking-tight">
                 <Shield size={18} className="text-accent" /> 
                 Sync Status
               </h3>
               <span className="text-[10px] font-black bg-orange-50 text-orange-600 px-2 py-0.5 rounded-full uppercase tracking-widest">3 Pending Review</span>
            </div>
            
            <div className="space-y-5">
               <div className="flex items-center justify-between">
                  <span className="text-[13px] font-medium text-muted">Note Accuracy</span>
                  <div className="flex items-center gap-2">
                     <div className="w-16 h-1 bg-green/10 rounded-full overflow-hidden">
                        <div className="w-full h-full bg-green"></div>
                     </div>
                     <span className="text-[11px] font-black text-green">100%</span>
                  </div>
               </div>
               <div className="flex items-center justify-between">
                  <span className="text-[13px] font-medium text-muted">Billing Verification</span>
                  <div className="flex items-center gap-2">
                     <div className="w-16 h-1 bg-orange-400/10 rounded-full overflow-hidden">
                        <div className="w-[65%] h-full bg-orange-400"></div>
                     </div>
                     <span className="text-[11px] font-black text-orange-600">65%</span>
                  </div>
               </div>
            </div>

            <div className="mt-8 p-4 bg-orange-50 border border-orange-100 rounded-2xl">
               <div className="flex items-center gap-3 mb-2">
                  <AlertTriangle size={16} className="text-orange-600" />
                  <span className="text-[12px] font-bold text-orange-900">Billing Alert</span>
               </div>
               <p className="text-[11px] text-orange-900 leading-relaxed mb-4">
                 Some records have unverified billing codes. Please review them to avoid claim issues.
               </p>
               <button 
                 onClick={() => setActiveTab('ambient')}
                 className="w-full py-2.5 bg-white border border-orange-200 text-orange-700 rounded-lg text-[11px] font-black uppercase tracking-widest hover:bg-orange-100 transition-all"
               >
                 Resolve in Billing View
               </button>
            </div>
          </div>

          <div className="bg-text text-white rounded-[28px] p-8 relative overflow-hidden flex-1">
           <div className="absolute top-0 right-0 w-32 h-32 bg-accent/20 blur-[60px] rounded-full"></div>
           <h3 className="text-[18px] font-serif italic font-medium mb-6 relative z-10">System Performance</h3>
           
           <div className="space-y-6 relative z-10">
              <div className="flex flex-col gap-2">
                 <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-white">
                    <span>Uptime Stability</span>
                    <span>100.0%</span>
                 </div>
                 <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                    <div className="w-full h-full bg-accent-vibrant"></div>
                 </div>
              </div>
              <div className="flex flex-col gap-2">
                 <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-white">
                    <span>FHIR Throughput</span>
                    <span>2.4k req/m</span>
                 </div>
                 <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                    <div className="w-[85%] h-full bg-white"></div>
                 </div>
              </div>
              <div className="flex flex-col gap-2">
                 <div className="flex justify-between text-[11px] font-black uppercase tracking-widest text-white">
                    <span>Encryption Latency</span>
                    <span>12ms</span>
                 </div>
                 <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                    <div className="w-[15%] h-full bg-green-400"></div>
                 </div>
              </div>
           </div>

           <div className="mt-12 p-5 border border-white/10 bg-white/5 rounded-2xl">
              <div className="flex items-center gap-3 mb-3">
                 <AlertCircle size={16} className="text-accent-vibrant" />
                 <span className="text-[12px] font-bold">Network Alert</span>
              </div>
              <p className="text-[11px] text-white font-medium leading-relaxed">
                Epic Node Node-NYC-A1 is undergoing scheduled maintenance in 14 minutes.
              </p>
           </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-[1001] flex items-center justify-center p-6 lg:p-12">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-md"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-md rounded-[32px] shadow-2xl relative z-10 overflow-hidden border border-border"
            >
              <div className="p-6 border-b border-border flex items-center justify-between bg-off/30">
                <h3 className="text-[18px] font-bold text-text">Connect New System</h3>
                <button onClick={() => setShowAddModal(false)} className="w-8 h-8 rounded-full hover:bg-white border border-transparent hover:border-border flex items-center justify-center transition-all">
                  <X size={16} className="text-muted" />
                </button>
              </div>
              <form onSubmit={handleAddSystem} className="p-8 space-y-6">
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-muted">Hospital / Provider Name</label>
                  <input 
                    autoFocus
                    type="text" 
                    value={newSystemName}
                    onChange={(e) => setNewSystemName(e.target.value)}
                    placeholder="e.g. Mayo Clinic, Cleveland Clinic"
                    className="w-full px-5 py-3.5 bg-off/50 border border-border rounded-xl text-[14px] focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-muted">Initial Status</label>
                  <div className="grid grid-cols-2 gap-3">
                    {['Active', 'Standby'].map(status => (
                      <button
                        key={status}
                        type="button"
                        onClick={() => setNewSystemStatus(status)}
                        className={`py-2.5 rounded-xl text-[12px] font-bold border transition-all ${
                          newSystemStatus === status 
                          ? 'bg-text text-white border-text' 
                          : 'bg-white text-muted border-border hover:border-muted/30'
                        }`}
                      >
                        {status}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="pt-4">
                  <button 
                    type="submit"
                    disabled={isAdding || !newSystemName}
                    className="w-full py-4 bg-accent text-white rounded-2xl text-[15px] font-bold shadow-lg shadow-accent/20 hover:bg-black transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isAdding ? (
                      <RefreshCw size={18} className="animate-spin" />
                    ) : (
                      <Plus size={18} />
                    )}
                    {isAdding ? 'Initializing...' : 'Connect System'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}

        {selectedSystem && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 lg:p-12">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedSystem(null)}
              className="absolute inset-0 bg-black/40 backdrop-blur-md"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-5xl h-[80vh] rounded-[40px] shadow-2xl relative z-10 overflow-hidden flex flex-col border border-border"
            >
              <div className="p-8 border-b border-border flex items-center justify-between shrink-0 bg-off/30">
                 <div>
                   <div className={`text-[11px] font-black uppercase tracking-[0.2em] mb-1 ${selectedSystem.provider_name === 'Epic' ? 'text-blue-600' : 'text-orange-600'}`}>Review Data Updates</div>
                   <h2 className="text-[28px] font-serif italic text-text">{selectedSystem.provider_name} <span className="text-muted font-normal ml-2">Approve Changes</span></h2>
                 </div>
                 <button onClick={() => setSelectedSystem(null)} className="w-12 h-12 rounded-full bg-white border border-border flex items-center justify-center hover:bg-off transition-all">
                    <Activity size={20} className="text-muted" />
                 </button>
              </div>

              <div className="flex-1 overflow-y-auto p-10">
                <div className="grid grid-cols-2 gap-12 h-full">
                  <div className="flex flex-col gap-6">
                    <div className="text-[11px] font-black text-muted uppercase tracking-widest px-1">Current EHR Data</div>
                    <div className="bg-off/50 border border-border/40 rounded-[28px] p-8 space-y-8 flex-1">
                       <div className="space-y-2 opacity-50">
                          <label className="text-[10px] font-black uppercase tracking-widest">Saved Diagnosis</label>
                          <div className="text-[16px] font-bold">
                             {typeof deltas?.hms_record?.diagnosis === 'string' ? deltas.hms_record.diagnosis : (typeof deltas?.hms_record?.diagnosis === 'object' ? JSON.stringify(deltas.hms_record.diagnosis) : "Connection to EHR...")}
                          </div>
                       </div>
                       <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-widest text-muted">Verified Billing Codes</label>
                          <div className="flex flex-wrap gap-2">
                             {Array.isArray(deltas?.hms_record?.billing_codes) && deltas.hms_record.billing_codes.map((code, cIdx) => (
                               <span key={cIdx} className="px-2 py-1 bg-off border border-border/60 rounded text-[12px] font-mono font-bold text-muted">
                                 {typeof code === 'string' ? code : (code && typeof code === 'object' ? (code.code || 'N/A') : 'N/A')}
                               </span>
                             ))}
                          </div>
                       </div>
                       <div className="space-y-2 opacity-50">
                          <label className="text-[10px] font-black uppercase tracking-widest">Active Medications</label>
                          <div className="text-[14px] font-medium">Lisinopril 10mg O.D.</div>
                       </div>
                    </div>
                  </div>

                  <div className="flex flex-col gap-6">
                    <div className="text-[11px] font-black text-accent uppercase tracking-widest px-1 flex items-center gap-2">
                       <Sparkles size={12} /> Suggested AI Updates
                    </div>
                    <div className="bg-white border-2 border-accent/20 rounded-[28px] p-8 space-y-8 flex-1 shadow-xl shadow-accent/5">
                       <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-widest text-accent">New Suggestions</label>
                          <div className="p-4 bg-accent/5 rounded-2xl border border-accent/10">
                             <div className="text-[11px] font-black uppercase text-accent mb-2">Updated Diagnosis</div>
                             <div className="text-[16px] font-bold text-text">
                               {typeof deltas?.workspace_proposal?.diagnosis === 'string' ? deltas.workspace_proposal.diagnosis : (typeof deltas?.workspace_proposal?.diagnosis === 'object' ? JSON.stringify(deltas.workspace_proposal.diagnosis) : "Analyzing...")}
                             </div>
                          </div>
                       </div>
                       
                       <div className="space-y-4">
                           <label className="text-[10px] font-black uppercase tracking-widest text-muted">New Billing Codes</label>
                           <div className="flex flex-wrap gap-2">
                             {Array.isArray(deltas?.workspace_proposal?.billing_codes) && deltas.workspace_proposal.billing_codes.map((code, cIdx) => (
                               <div key={cIdx} className="px-3 py-1.5 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
                                 <Check size={10} className="text-green-600" />
                                 <span className="text-[12px] font-mono font-bold text-green-700">
                                   {typeof code === 'string' ? code : (code && typeof code === 'object' ? (code.code || 'N/A') : 'N/A')}
                                 </span>
                               </div>
                             ))}
                             {(!deltas?.workspace_proposal?.billing_codes || (Array.isArray(deltas.workspace_proposal.billing_codes) && deltas.workspace_proposal.billing_codes.length === 0)) && (
                               <span className="text-[12px] italic opacity-40">No verified codes to sync</span>
                             )}
                          </div>
                       </div>

                       <div className="space-y-4 border-t border-border/40 pt-6">
                          <label className="text-[10px] font-black uppercase tracking-widest text-muted font-serif italic">Prescription Logic Update</label>
                          <div className="text-[13px] text-text font-medium leading-relaxed bg-off/30 p-4 rounded-xl">
                            {deltas?.workspace_proposal?.rx_summary || "No medication updates suggested."}
                          </div>
                       </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-8 border-t border-border bg-white flex items-center justify-between shrink-0">
                 <div className="text-[12px] font-medium text-muted">Review Required: Changes must be approved before saving to the hospital system.</div>
                  <div className="flex items-center gap-4">
                     {syncResult ? (
                       <div className="flex items-center gap-3 px-6 py-3 bg-green-50 border border-green-200 rounded-full">
                          <CheckCircle2 size={16} className="text-green-600" />
                          <div className="flex flex-col">
                            <span className="text-[11px] font-black uppercase text-green-700 leading-none mb-0.5">Success</span>
                            <span className="text-[9px] font-mono text-green-600/60 uppercase">{syncResult.transaction_id}</span>
                          </div>
                       </div>
                     ) : (
                       <>
                        <button onClick={() => setSelectedSystem(null)} className="px-8 py-3 rounded-full text-[14px] font-bold text-text bg-off hover:bg-border/40 transition-all">Dismiss</button>
                        <button 
                          onClick={() => triggerSync(selectedSystem.id)} 
                          disabled={syncing || !activeEncounterId}
                          className="px-8 py-3 rounded-full text-[14px] font-bold text-white bg-accent shadow-lg shadow-accent/20 hover:bg-black transition-all disabled:opacity-50"
                        >
                          {syncing ? 'Saving Updates...' : 'Save to Hospital System'}
                        </button>
                       </>
                     )}
                  </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
