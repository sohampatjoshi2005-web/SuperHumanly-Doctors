import { useState, useEffect } from 'react';
import { Users, UserPlus, Shield, Activity, TrendingUp, CheckCircle, Clock, AlertCircle, Search, Mail, Key, FileDown, Stethoscope, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import { fetchClinicMembers, addClinicDoctor, fetchClinicStats, downloadClinicReport } from '../../lib/doctorApi';

export default function ClinicTab() {
  const [members, setMembers] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({ username: '', email: '', password: '', full_name: '' });
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [membersData, statsData] = await Promise.all([
        fetchClinicMembers(),
        fetchClinicStats()
      ]);
      setMembers(membersData);
      setStats(statsData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      setIsExporting(true);
      setError(null);
      await downloadClinicReport();
    } catch (err) {
      setError('Export failed. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleAddDoctor = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    try {
      await addClinicDoctor(formData);
      setSuccess('Doctor onboarded successfully!');
      setFormData({ username: '', email: '', password: '', full_name: '' });
      setShowAddModal(false);
      loadData();
    } catch (err) {
      setError(err.message);
    }
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-accent border-t-transparent rounded-full animate-spin"></div>
          <p className="text-muted font-bold animate-pulse">Syncing Clinic Registry...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col p-8 overflow-y-auto custom-scrollbar bg-off/30">
      {/* Header */}
      <div className="flex justify-between items-start mb-10">
        <div>
          <h1 className="font-serif text-[40px] tracking-tight text-text leading-tight mb-2">
            Clinic <span className="italic text-accent">Management</span>
          </h1>
          <p className="text-muted font-medium pl-1 flex items-center gap-2">
            <Shield size={16} className="text-accent" />
            {stats?.clinic_name || 'Autonomous Clinical Institution'}
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <button 
            onClick={handleExport}
            disabled={isExporting}
            className={`flex items-center gap-2.5 px-6 py-3.5 bg-off text-text rounded-2xl font-bold border border-border/40 transition-all active:scale-[0.98] ${isExporting ? 'opacity-50 cursor-not-allowed' : 'hover:bg-border/20'}`}
          >
            {isExporting ? (
              <div className="w-4 h-4 border-2 border-text border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <FileDown size={18} className="text-accent" />
            )}
            {isExporting ? 'Generating Report...' : 'Export Monthly Audit'}
          </button>
          
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2.5 px-6 py-3.5 bg-text text-white rounded-2xl font-bold shadow-xl shadow-text/10 hover:bg-accent transition-all active:scale-[0.98]"
          >
            <UserPlus size={18} /> Onboard Physician
          </button>
        </div>
      </div>

      {/* Advanced Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        {/* Top Diagnoses */}
        <div className="bg-white p-8 rounded-[40px] border border-border/50 shadow-sm">
          <h3 className="text-lg font-black tracking-tight text-text mb-6 flex items-center gap-3">
            <Stethoscope size={20} className="text-accent" />
            Primary Clinical Focus
          </h3>
          <div className="space-y-4">
            {stats?.top_diagnoses?.length > 0 ? (
              stats.top_diagnoses.map((diag, idx) => (
                <div key={idx} className="flex flex-col gap-2">
                  <div className="flex justify-between items-center px-1">
                    <span className="text-[13px] font-bold text-text2 tracking-tight">{diag.name}</span>
                    <span className="text-[11px] font-black text-accent">{diag.count} Cases</span>
                  </div>
                  <div className="h-2 w-full bg-off rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(diag.count / stats.total_encounters) * 100}%` }}
                      className="h-full bg-accent rounded-full"
                    />
                  </div>
                </div>
              ))
            ) : (
              <div className="py-12 text-center">
                <div className="w-12 h-12 rounded-2xl bg-off flex items-center justify-center text-muted/20 mx-auto mb-4">
                  <Activity size={24} />
                </div>
                <p className="text-sm font-bold text-muted uppercase tracking-widest">Awaiting Clinical Data</p>
              </div>
            )}
          </div>
        </div>

        {/* Staff Efficiency */}
        <div className="bg-white p-8 rounded-[40px] border border-border/50 shadow-sm">
          <h3 className="text-lg font-black tracking-tight text-text mb-6 flex items-center gap-3">
            <TrendingUp size={20} className="text-accent" />
            Documentation Velocity
          </h3>
          <div className="space-y-4">
             {stats?.staff_performance?.map((staff, idx) => (
                <div key={idx} className="flex items-center justify-between p-4 bg-off/40 rounded-2xl border border-border/20">
                   <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center text-accent font-black text-[10px]">
                        {staff.name[0].toUpperCase()}
                      </div>
                      <span className="text-sm font-bold text-text2">{staff.name}</span>
                   </div>
                   <div className="flex items-center gap-2">
                      <span className="text-xs font-black text-text">{staff.encounters}</span>
                      <span className="text-[10px] font-bold text-muted uppercase tracking-tight">Encounters</span>
                   </div>
                </div>
             ))}
          </div>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white p-6 rounded-[32px] border border-border/50 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-accent/5 flex items-center justify-center text-accent">
              <Users size={24} />
            </div>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.15em] text-muted">Clinical Staff</p>
              <p className="text-2xl font-black text-text">{stats?.team_size || 0}</p>
            </div>
          </div>
          <div className="h-1.5 w-full bg-off rounded-full overflow-hidden">
             <div className="h-full bg-accent rounded-full" style={{ width: '65%' }}></div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-[32px] border border-border/50 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-green-50 flex items-center justify-center text-green-600">
              <Activity size={24} />
            </div>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.15em] text-muted">Total Encounters</p>
              <p className="text-2xl font-black text-text">{stats?.total_encounters || 0}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-green-600 font-bold text-xs">
            <TrendingUp size={14} /> +12% from last month
          </div>
        </div>

        <div className="bg-white p-6 rounded-[32px] border border-border/50 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600">
              <CheckCircle size={24} />
            </div>
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.15em] text-muted">Patient Registry</p>
              <p className="text-2xl font-black text-text">{stats?.total_patients || 0}</p>
            </div>
          </div>
          <div className="text-[11px] font-bold text-muted uppercase tracking-widest">Across all providers</div>
        </div>
      </div>

      {/* Members List */}
      <div className="bg-white rounded-[40px] border border-border/50 shadow-sm overflow-hidden mb-8">
        <div className="px-8 py-6 border-b border-border/40 flex items-center justify-between bg-white/50 backdrop-blur-md">
          <h3 className="text-lg font-black tracking-tight text-text flex items-center gap-3">
            Physician Directory
            <span className="px-2.5 py-0.5 rounded-full bg-accent/10 text-accent text-[11px] font-black">{members.length}</span>
          </h3>
          <div className="flex items-center gap-2 px-4 py-2 bg-off rounded-full text-muted text-sm font-medium border border-border/40">
            <Search size={16} />
            <input type="text" placeholder="Search staff..." className="bg-transparent border-none outline-none text-text placeholder:text-muted/60 w-48" />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-off/20">
                <th className="px-8 py-4 text-[11px] font-black uppercase tracking-[0.2em] text-muted border-b border-border/30">Provider</th>
                <th className="px-8 py-4 text-[11px] font-black uppercase tracking-[0.2em] text-muted border-b border-border/30">Role</th>
                <th className="px-8 py-4 text-[11px] font-black uppercase tracking-[0.2em] text-muted border-b border-border/30">Onboarded</th>
                <th className="px-8 py-4 text-[11px] font-black uppercase tracking-[0.2em] text-muted border-b border-border/30 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {members.map((member, idx) => (
                <tr key={member.id} className="group hover:bg-accent/5 transition-colors">
                  <td className="px-8 py-5 border-b border-border/30">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-accent to-accent-dark flex items-center justify-center text-white font-black text-sm">
                        {member.full_name?.split(' ').map(n=>n[0]).join('') || member.username[0].toUpperCase()}
                      </div>
                      <div>
                        <p className="font-black text-text tracking-tight">{member.full_name || member.username}</p>
                        <p className="text-xs text-muted font-medium">{member.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5 border-b border-border/30">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                      member.role === 'clinic_admin' ? 'bg-purple-50 text-purple-600' : 'bg-blue-50 text-blue-600'
                    }`}>
                      {member.role.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-8 py-5 border-b border-border/30">
                    <div className="flex items-center gap-2 text-muted text-xs font-bold">
                      <Clock size={14} />
                      {new Date(member.created_at).toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-8 py-5 border-b border-border/30 text-right">
                    <button className="p-2 text-muted hover:text-accent transition-colors">
                      <Settings size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[2000] flex items-center justify-center p-6">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] w-full max-w-[500px] overflow-hidden shadow-2xl border border-border"
          >
            <div className="p-10">
              <div className="flex justify-between items-start mb-8">
                <div className="w-14 h-14 rounded-2xl bg-accent/5 flex items-center justify-center text-accent">
                  <UserPlus size={28} />
                </div>
                <button onClick={() => setShowAddModal(false)} className="p-2 text-muted hover:text-text">
                  <Clock className="rotate-45" size={24} />
                </button>
              </div>

              <h2 className="font-serif text-[32px] tracking-tight text-text mb-2">Onboard <span className="italic text-accent">New Physician</span></h2>
              <p className="text-muted font-medium mb-8">Assign credentials and provision access to the clinic registry.</p>

              <form onSubmit={handleAddDoctor} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-muted ml-1">Full Professional Name</label>
                  <div className="relative">
                    <Users className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                    <input 
                      type="text" required placeholder="Dr. Jane Smith"
                      value={formData.full_name} onChange={e => setFormData({...formData, full_name: e.target.value})}
                      className="w-full h-14 pl-12 pr-4 bg-off border-none rounded-2xl text-text font-bold placeholder:text-muted/20 outline-none focus:ring-2 ring-accent/20 transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <div className="space-y-2">
                    <label className="text-[11px] font-black uppercase tracking-widest text-muted ml-1">Username</label>
                    <div className="relative">
                      <Activity className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                      <input 
                        type="text" required placeholder="jsmith"
                        value={formData.username} onChange={e => setFormData({...formData, username: e.target.value})}
                        className="w-full h-14 pl-12 pr-4 bg-off border-none rounded-2xl text-text font-bold placeholder:text-muted/40 outline-none focus:ring-2 ring-accent/20 transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[11px] font-black uppercase tracking-widest text-muted ml-1">Temporary PW</label>
                    <div className="relative">
                      <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                      <input 
                        type="password" required placeholder="••••••••"
                        value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})}
                        className="w-full h-14 pl-12 pr-4 bg-off border-none rounded-2xl text-text font-bold placeholder:text-muted/40 outline-none focus:ring-2 ring-accent/20 transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-muted ml-1">Professional Email</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                    <input 
                      type="email" required placeholder="jane.smith@hospital.org"
                      value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})}
                      className="w-full h-14 pl-12 pr-4 bg-off border-none rounded-2xl text-text font-bold placeholder:text-muted/20 outline-none focus:ring-2 ring-accent/20 transition-all"
                    />
                  </div>
                </div>

                {error && (
                  <div className="p-4 bg-red-50 rounded-2xl border border-red-100 flex items-center gap-3 text-red-600 text-sm font-bold">
                    <AlertCircle size={18} /> {error}
                  </div>
                )}

                <button 
                  type="submit"
                  className="w-full h-16 bg-text text-white rounded-full font-black text-lg shadow-xl shadow-text/10 hover:bg-accent transition-all active:scale-[0.98] mt-6"
                >
                  Confirm Onboarding
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
