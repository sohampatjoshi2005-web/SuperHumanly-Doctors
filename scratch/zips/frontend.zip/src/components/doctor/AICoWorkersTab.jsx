import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { UserCheck, FileText, Heart, Users, Cpu, Settings, Activity, ShieldCheck, Zap, Terminal, X, Play, Info } from 'lucide-react';
import { fetchSwarmStatus, fetchAgentLogs, triggerAgentTask } from '../../lib/doctorApi';

const AgentCard = ({ name, role, status, activeTasks, duty, icon: Icon, color, onCommand }) => (
  <div className="bg-white border border-border/60 p-6 rounded-[28px] hover:border-accent/40 transition-all group overflow-hidden relative">
    <div className={`absolute top-0 right-0 w-32 h-32 blur-[50px] rounded-full translate-x-1/2 -translate-y-1/2 transition-colors ${
      color === 'blue' ? 'bg-blue-50/50 group-hover:bg-blue-50' :
      color === 'purple' ? 'bg-purple-50/50 group-hover:bg-purple-50' :
      color === 'green' ? 'bg-green-50/50 group-hover:bg-green-50' :
      'bg-orange-50/50 group-hover:bg-orange-50'
    }`}></div>

    <div className="relative z-10">
      <div className="flex items-center justify-between mb-8">
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border transition-all ${
          color === 'blue' ? 'bg-blue-50 border-blue-100 text-blue-600' :
          color === 'purple' ? 'bg-purple-50 border-purple-100 text-purple-600' :
          color === 'green' ? 'bg-green-50 border-green-100 text-green-600' :
          'bg-orange-50 border-orange-100 text-orange-600'
        }`}>
          <Icon size={24} />
        </div>
        <div className="flex flex-col items-end">
          <span className={`text-[10px] font-black uppercase tracking-[0.2em] px-2.5 py-1 rounded-full ${
            status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-off text-muted'
          }`}>
            {status === 'Active' ? 'Working' : 'Ready'}
          </span>
        </div>
      </div>

      <h3 className="text-[20px] font-bold text-text mb-1">{name}</h3>
      <p className="text-[13px] font-medium text-muted mb-4">{role}</p>
      
      <div className="flex items-center gap-2 mb-6 p-2.5 bg-off/50 rounded-xl border border-border/40">
         <Zap size={12} className="text-accent" />
         <span className="text-[11px] font-bold text-text/60 italic">{duty}</span>
      </div>

      <div className="space-y-3 mb-8">
        <div className="flex items-center justify-between text-[11px] font-bold text-muted uppercase tracking-widest">
           <span>Efficiency Rate</span>
           <span>{activeTasks}%</span>
        </div>
        <div className="w-full h-1 bg-off rounded-full overflow-hidden">
           <div 
             className={`h-full transition-all duration-500 ${
               color === 'blue' ? 'bg-blue-600' :
               color === 'purple' ? 'bg-purple-600' :
               color === 'green' ? 'bg-green-600' :
               'bg-orange-600'
             }`} 
             style={{ width: `${activeTasks}%` }} 
           />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
         <button onClick={onCommand} className="py-3 bg-text text-white rounded-xl text-[12px] font-bold hover:bg-black transition-all active:scale-95">Assign Task</button>
         <button 
           onClick={() => {
             const logs = document.getElementById('activity-history');
             if (logs) logs.scrollIntoView({ behavior: 'smooth' });
           }}
           className="py-3 bg-off text-text rounded-xl text-[12px] font-bold hover:bg-border/60 transition-all border border-border/40"
         >
           View History
         </button>
      </div>
    </div>
    {status === 'Active' && (
      <div className="absolute inset-0 border-2 border-accent/20 rounded-[28px] pointer-events-none">
        <div className="absolute inset-0 bg-accent/5 animate-pulse" />
      </div>
    )}
  </div>
);

const CommandModal = ({ agent, onClose, onExecute }) => {
  const [isProcessing, setIsProcessing] = useState(false);

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-black/40 backdrop-blur-md">
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white w-full max-w-lg rounded-[40px] shadow-2xl p-10 relative border border-border"
      >
        <button onClick={onClose} className="absolute top-8 right-8 text-muted hover:text-text">
           <X size={24} />
        </button>
        
        <div className="flex items-center gap-4 mb-8">
           <div className={`w-16 h-16 rounded-2xl flex items-center justify-center bg-off border border-border/60`}>
              <Zap size={32} className="text-accent" />
           </div>
           <div>
              <div className="text-[10px] font-black uppercase tracking-widest text-muted mb-1">Clinical Support Team</div>
              <h2 className="text-[28px] font-serif italic text-text">{agent.name} <span className="font-normal text-muted">Assistant</span></h2>
           </div>
        </div>

        <p className="text-[15px] text-muted leading-relaxed mb-8">
          Request {agent.name} to handle a specific clinical task. This assistant is specialized in <span className="font-bold text-text underline decoration-accent/30 lowercase">{agent.role}</span>.
        </p>

        <div className="space-y-4 mb-10">
           <div className="text-[11px] font-black uppercase tracking-widest text-muted mb-2">Key Responsibilities</div>
           {[
             "Complex Clinical Reasoning",
             "Patient Record Synchronization",
             "Data-Driven Insights"
           ].map((cap, i) => (
             <div key={i} className="flex items-center gap-3 p-4 bg-off/50 border border-border/40 rounded-2xl">
                <ShieldCheck size={16} className="text-accent" />
                <span className="text-[13px] font-bold text-text">{cap}</span>
             </div>
           ))}
        </div>

        <button 
          disabled={isProcessing}
          onClick={async () => { 
            setIsProcessing(true);
            await onExecute(agent.name); 
            setIsProcessing(false);
            onClose(); 
          }}
          className={`w-full py-4 rounded-2xl text-[16px] font-bold shadow-lg transition-all flex items-center justify-center gap-3 ${
            isProcessing ? 'bg-muted text-white cursor-not-allowed' : 'bg-accent text-white shadow-accent/20 hover:bg-black'
          }`}
        >
          {isProcessing ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <Play size={18} fill="currentColor" />
          )}
          {isProcessing ? 'Processing Task...' : 'Start Clinical Task'}
        </button>
      </motion.div>
    </div>
  );
};

export default function AICoWorkersTab() {
  const [agents, setAgents] = useState([]);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [notification, setNotification] = useState(null);
  const [indices, setIndices] = useState([
    { label: 'Response Speed', value: '14ms', trend: -2 },
    { label: 'Data Efficiency', value: '92%', trend: +5 },
    { label: 'Verification Score', value: '1.0', trend: 0 },
    { label: 'System Accuracy', value: 'Verified', trend: 0 }
  ]);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 3000); 
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const [swarmData, logData] = await Promise.all([
        fetchSwarmStatus(),
        fetchAgentLogs(20)
      ]);
      setAgents(swarmData);
      setLogs(logData);
      
      setIndices(prev => prev.map(idx => {
        if (idx.label === 'Response Speed') {
          const newVal = Math.max(8, Math.min(24, parseInt(idx.value) || 14 + (Math.random() > 0.5 ? 1 : -1)));
          return { ...idx, value: `${newVal}ms` };
        }
        if (idx.label === 'Data Efficiency') {
          const newVal = Math.max(85, Math.min(98, (parseInt(idx.value) || 92) + (Math.random() > 0.8 ? 1 : -1)));
          return { ...idx, value: `${newVal}%` };
        }
        return idx;
      }));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleExecuteTask = async (agentName) => {
     try {
       await triggerAgentTask(agentName);
       setNotification(`${agentName} has started the assigned task.`);
       setTimeout(() => setNotification(null), 4000);
       loadData(); 
     } catch (e) {
       console.error("Task failed:", e);
     }
  };

  return (
    <div className="h-full flex flex-col p-6 overflow-y-auto custom-scrollbar relative">
      <AnimatePresence>
        {notification && (
          <motion.div 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            className="absolute top-6 left-1/2 -translate-x-1/2 z-[2000] px-6 py-3 bg-text text-white rounded-2xl shadow-2xl flex items-center gap-3 border border-white/10"
          >
            <ShieldCheck size={18} className="text-accent" />
            <span className="text-[14px] font-bold">{notification}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col lg:flex-row items-end justify-between gap-6 mb-12">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-border/20 mb-6">
             <Cpu size={14} className="text-muted" />
             <span className="text-[10px] font-black uppercase tracking-widest text-muted">AI Medical Assistants</span>
          </div>
          <h1 className="text-[42px] font-serif tracking-tight text-text leading-[0.9] mb-4">
            AI Assistant <br/>
            <span className="italic text-accent">Support Team</span>
          </h1>
          <p className="text-[16px] text-muted font-medium leading-relaxed">
            Manage your digital support team. These AI assistants handle administrative tasks and background processing so you can focus on patient care. Every task operates with <span className="font-bold text-text underline decoration-accent/20">Full Clinician Oversight</span>.
          </p>
        </div>
        <div className="flex items-center gap-6">
           <div className="text-right">
              <div className="text-[10px] font-black uppercase tracking-widest text-muted mb-1">System Status ID</div>
              <div className="text-[14px] font-mono font-bold text-accent">SWARM-THETA-9</div>
           </div>
           <button className="w-12 h-12 rounded-2xl bg-off border border-border/60 flex items-center justify-center text-text hover:bg-accent hover:text-white transition-all">
              <Settings size={20} />
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-10">
        {agents.map((agent, idx) => (
          <AgentCard 
            key={idx}
            {...agent}
            icon={
              agent.name === 'Atlas' ? UserCheck :
              agent.name === 'Lumina' ? FileText :
              agent.name === 'Echo' ? Users :
              Heart
            }
            onCommand={() => setSelectedAgent(agent)}
          />
        ))}
        {agents.length === 0 && !loading && [1,2,3,4].map(i => <div key={i} className="h-[280px] bg-off/50 rounded-[28px] animate-pulse" />)}
      </div>

      <AnimatePresence>
         {selectedAgent && (
           <CommandModal 
             agent={selectedAgent} 
             onClose={() => setSelectedAgent(null)} 
             onExecute={handleExecuteTask}
           />
         )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-10">
         <div className="lg:col-span-2 bg-off/50 border border-border/60 rounded-[32px] p-8 flex flex-col relative overflow-hidden group/graph">
            {/* AMBIENT BACKGROUND DECO */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 blur-[80px] rounded-full -mr-20 -mt-20"></div>
            
            <div className="flex items-center justify-between mb-8 relative z-10">
               <h3 className="text-[18px] font-bold text-text flex items-center gap-3">
                  <Activity size={20} className="text-accent" />
                  Assistant Collaboration Map
               </h3>
               <div className="text-[10px] font-black uppercase tracking-widest text-muted">Activity Overview</div>
            </div>

            <div className="flex-1 relative flex items-center justify-center min-h-[300px]">
               {/* SVG TOPOLOGY GRAPH */}
               <svg className="w-full h-full absolute inset-0 pointer-events-none">
                  <motion.line 
                    initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 2, repeat: Infinity }}
                    x1="25%" y1="30%" x2="75%" y2="70%" stroke="rgba(0, 82, 204, 0.15)" strokeWidth="2" strokeDasharray="4 4" 
                  />
                  <motion.line 
                    initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
                     x1="75%" y1="30%" x2="25%" y2="70%" stroke="var(--color-accent)" strokeWidth="1" strokeDasharray="4 4" opacity={0.2}
                  />
               </svg>

               <div className="grid grid-cols-2 gap-x-48 gap-y-24 relative z-10">
                  {agents.length > 0 ? agents.map((agent, i) => (
                    <motion.div 
                      key={agent.name}
                      animate={{ 
                        scale: agent.status === 'Active' ? [1, 1.1, 1] : [1, 1.05, 1],
                        boxShadow: agent.status === 'Active' 
                          ? ["0 0 0px rgba(0,82,204,0)", "0 0 30px rgba(0,82,204,0.3)", "0 0 0px rgba(0,82,204,0)"]
                          : ["0 0 0px rgba(0,82,204,0)", "0 0 20px rgba(0,82,204,0.1)", "0 0 0px rgba(0,82,204,0)"]
                      }}
                      transition={{ duration: agent.status === 'Active' ? 1.5 : 3, repeat: Infinity, delay: i * 0.7 }}
                      className="w-20 h-20 rounded-2xl bg-white border border-border shadow-sm flex flex-col items-center justify-center gap-1 group/node cursor-help"
                    >
                       <div className="text-[11px] font-black text-text">{agent.name}</div>
                       <div className={`w-1.5 h-1.5 rounded-full ${agent.status === 'Active' ? 'bg-accent animate-ping' : 'bg-green-500 animate-pulse'}`} />
                    </motion.div>
                  )) : ['Atlas', 'Lumina', 'Echo', 'Pathos'].map((name, i) => (
                    <div key={name} className="w-20 h-20 rounded-2xl bg-white border border-border shadow-sm flex flex-col items-center justify-center gap-1 opacity-20">
                       <div className="text-[11px] font-black text-text">{name}</div>
                       <div className="w-1.5 h-1.5 rounded-full bg-muted" />
                    </div>
                  ))}
               </div>

                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    className="w-64 h-64 border border-accent/10 rounded-full border-dashed"
                  />
               </div>
            </div>
         </div>

         <div className="bg-white border border-border/60 rounded-[32px] p-8 flex flex-col">
            <div className="flex items-center justify-between mb-6">
                <h3 className="text-[17px] font-bold text-text">Performance Stats</h3>
                 <Info size={14} className="text-muted" />
            </div>
            <div className="space-y-6">
               {indices.map((stat, i) => (
                 <div key={i} className="flex flex-col gap-2">
                    <div className="flex justify-between items-end">
                       <span className="text-[11px] font-black text-muted uppercase tracking-widest">{stat.label}</span>
                       <span className="text-[14px] font-bold text-text">{stat.value}</span>
                    </div>
                    <div className="w-full h-1 bg-off rounded-full overflow-hidden">
                       <motion.div 
                         initial={false}
                         animate={{ 
                           width: stat.label === 'Response Speed' ? '30%' : 
                                  stat.label === 'Data Efficiency' ? '85%' : '100%' 
                         }}
                         className="h-full bg-accent/40 rounded-full" 
                       />
                    </div>
                 </div>
               ))}
            </div>
         </div>
      </div>

      <div id="activity-history" className="bg-white border border-border text-text rounded-[32px] p-8 relative overflow-hidden flex flex-col min-h-[400px]">
         <div className="flex items-center justify-between mb-8 border-b border-border pb-6">
            <h3 className="text-[20px] font-bold flex items-center gap-3">
              <Terminal size={24} className="text-accent" />
              Activity History
            </h3>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-off border border-border">
               <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
               <span className="text-[10px] font-black uppercase tracking-widest text-muted">System Active</span>
            </div>
         </div>
         
         <div className="flex-1 text-[13px] space-y-4 overflow-y-auto custom-scrollbar pr-4">
            {logs.map((log, i) => (
              <div key={i} className="group/log relative flex items-start gap-4 p-4 hover:bg-off/50 rounded-2xl transition-colors border border-transparent hover:border-border/40">
                 <div className="shrink-0 w-20 text-[11px] font-bold text-muted">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                 </div>
                 <div className="flex-1">
                    <span className="font-bold text-accent mr-2">{log.agent_name}:</span> 
                    <span className="text-muted font-medium">{log.message}</span>
                    {log.reasoning && (
                      <div className="mt-2 p-3 bg-off rounded-xl text-[11px] italic text-muted border border-border/40">
                         {log.reasoning}
                      </div>
                    )}
                 </div>
                 <div className="shrink-0">
                    <span className="text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full bg-green-50 text-green-600 border border-green-100">
                        Verified
                    </span>
                 </div>
              </div>
            ))}
            {logs.length === 0 && !loading && <div className="py-20 text-center text-muted/40 italic">Waiting for assistant activity...</div>}
         </div>

         <div className="mt-8 pt-8 border-t border-border flex items-center justify-between">
            <div className="flex items-center gap-8">
               <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-muted mb-1">Total Processing</div>
                  <div className="text-[18px] font-bold text-text">4.2 TFlops</div>
               </div>
               <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-muted mb-1">Clinic Oversight</div>
                  <div className="text-[18px] font-bold text-accent">Active</div>
               </div>
            </div>
            <div className="flex items-center gap-2 text-muted font-black text-[12px] uppercase tracking-[0.2em]">
               Doctor-in-the-Loop Protocol <ShieldCheck size={16} className="text-green-500" />
            </div>
         </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar-light::-webkit-scrollbar { width: 3px; }
        .custom-scrollbar-light::-webkit-scrollbar-track { background: rgba(255,255,255,0.05); }
        .custom-scrollbar-light::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
      `}} />
    </div>
  );
}
