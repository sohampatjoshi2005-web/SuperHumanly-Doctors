import { useState, useRef, useEffect } from 'react';
import { Upload, FileText, Send, AlertTriangle, FileJson, CheckCircle2, Edit3, Mic, Plus, Play, Moon, HeartPulse, Droplets, AlignLeft, Activity, ShieldCheck, Square, ArrowRight, ClipboardCheck, Clock, X, FileAudio, Copy, RefreshCw, Database, Mail, Download, Check, AlertCircle, Stethoscope, ClipboardList, UserCircle, User, Info, Sparkles, ChevronDown, Languages, Globe, Lock, Zap, Share } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { jsPDF } from 'jspdf';
import { processAudio, processText, sendEmail, updateEncounterCodes, getTaskStatus, fetchPatientRisks, generateShareLink, fetchCustomerHistory, fetchEncounterById } from '../../lib/doctorApi';
import ClinicalAlert from '../clinical/ClinicalAlert';
import { NeuralOrb, SegmentedProgress, SecureStatusBadge, ClinicalWaveform, SignalMeter, CaptureStatus, SynthesisSlab, SynthesisTelemetry } from '../ui/IntakeVisuals';
import ClinicalAudioPlayer from '../ui/ClinicalAudioPlayer';
import LongitudinalTimeline from '../ui/LongitudinalTimeline';
import EncounterDetailModal from '../ui/EncounterDetailModal';

export default function WorkflowTab({
  selectedCustomer,
  encounterToLoad,
  onEncounterActive,
  trialData,
  onUpgradeClick,
  onTrialRefresh
}) {
  const [inputType, setInputType] = useState('audio');
  const [transcript, setTranscript] = useState('');
  const [audioFile, setAudioFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [editedRx, setEditedRx] = useState('');
  const [verifiedCodes, setVerifiedCodes] = useState([]); // Track clinician-verified codes
  const [language, setLanguage] = useState('en-IN'); // Ambient note language
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [isRxEditing, setIsRxEditing] = useState(false);
  const langRef = useRef(null);

  const languages = [
    { code: 'en-IN', label: 'English', native: 'India' },
    { code: 'hi-IN', label: 'Hindi', native: 'हिन्दी' },
    { code: 'bn-IN', label: 'Bengali', native: 'বাংলা' },
    { code: 'kn-IN', label: 'Kannada', native: 'ಕನ್ನಡ' },
    { code: 'ml-IN', label: 'Malayalam', native: 'മലയാളം' },
    { code: 'mr-IN', label: 'Marathi', native: 'मराठी' },
    { code: 'od-IN', label: 'Odia', native: 'ଓଡ଼ିଆ' },
    { code: 'pa-IN', label: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
    { code: 'ta-IN', label: 'Tamil', native: 'தமிழ்' },
    { code: 'te-IN', label: 'Telugu', native: 'తెలుగు' },
    { code: 'gu-IN', label: 'Gujarati', native: 'ગુજરાતી' },
    { code: 'as-IN', label: 'Assamese', native: 'অসমীয়া' },
    { code: 'ur-IN', label: 'Urdu', native: 'اردو' },
    { code: 'ne-IN', label: 'Nepali', native: 'नेपाली' },
    { code: 'kok-IN', label: 'Konkani', native: 'कोंकणी' },
    { code: 'ks-IN', label: 'Kashmiri', native: 'कॉशुर' },
    { code: 'sd-IN', label: 'Sindhi', native: 'सिंधी' },
    { code: 'sa-IN', label: 'Sanskrit', native: 'संस्कृतम्' },
    { code: 'sat-IN', label: 'Santali', native: 'संताली' },
    { code: 'mni-IN', label: 'Manipuri', native: 'মৈতৈলোন' },
    { code: 'brx-IN', label: 'Bodo', native: 'बर' },
    { code: 'mai-IN', label: 'Maithili', native: 'मैथिली' },
    { code: 'doi-IN', label: 'Dogri', native: 'डोगरी' },
  ];

  const currentLang = languages.find(l => l.code === language) || languages[0];

  useEffect(() => {
    function handleClickOutside(event) {
      if (langRef.current && !langRef.current.contains(event.target)) {
        setIsLangOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const [emailTo, setEmailTo] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(null);
  const [sendError, setSendError] = useState(null);
  const [processingStep, setProcessingStep] = useState(0);
  const [isCopied, setIsCopied] = useState(false);
  const [isExported, setIsExported] = useState(false);
  const [isShared, setIsShared] = useState(false);
  const [showCodingInfo, setShowCodingInfo] = useState(false);
  const [reviewMobileTab, setReviewMobileTab] = useState('summary');
  const [currentEncounterId, setCurrentEncounterId] = useState(null);
  const [risks, setRisks] = useState([]);

  // Sync local currentEncounterId to parent
  useEffect(() => {
    if (currentEncounterId && onEncounterActive) {
      onEncounterActive(currentEncounterId);
    }
  }, [currentEncounterId]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isBillingVisible, setIsBillingVisible] = useState(false);
  const [patientHistory, setPatientHistory] = useState([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  const [activeRightTab, setActiveRightTab] = useState('history'); // 'history' or 'blueprint'
  const [selectedHistoryEncounter, setSelectedHistoryEncounter] = useState(null);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isHistoryLoadingDetail, setIsHistoryLoadingDetail] = useState(false);

  const reasoningSteps = [
    "Analyzing phonetic patterns & clinical vocabulary...",
    "Cross-referencing medical ontology & ICD-10...",
    "Identifying speaker entities and clinical context...",
    "Synthesizing SOAP structure and assessment logic...",
    "Validating diagnostic coherence and plan safety..."
  ];
  const [reasoningStepIdx, setReasoningStepIdx] = useState(0);

  useEffect(() => {
    if (isProcessing) {
      const interval = setInterval(() => {
        setReasoningStepIdx(prev => (prev + 1) % reasoningSteps.length);
      }, 3500);
      return () => clearInterval(interval);
    } else {
      setReasoningStepIdx(0);
    }
  }, [isProcessing]);
  // Fetch Patient History when selectedCustomer changes
  useEffect(() => {
    if (selectedCustomer?.id) {
      const loadHistory = async () => {
        setIsHistoryLoading(true);
        try {
          const history = await fetchCustomerHistory(selectedCustomer.id);
          setPatientHistory(history);
        } catch (e) {
          console.error("Failed to load patient history:", e);
        } finally {
          setIsHistoryLoading(false);
        }
      };
      loadHistory();
    } else {
      setPatientHistory([]);
    }
  }, [selectedCustomer?.id]);

  const handleEncounterClick = async (encounterId) => {
    setIsHistoryLoadingDetail(true);
    try {
      const fullEncounter = await fetchEncounterById(encounterId);
      setSelectedHistoryEncounter(fullEncounter);
      setIsHistoryModalOpen(true);
    } catch (e) {
      console.error("Failed to fetch encounter details:", e);
      alert("Unable to load clinical record details. Please try again.");
    } finally {
      setIsHistoryLoadingDetail(false);
    }
  };

  const billingRef = useRef(null);
  const scrollContainerRef = useRef(null);
  const getIconForSection = (title) => {
    const type = title.toLowerCase().replace(/\s+/g, '-');
    return {
      "patient-summary": <UserCircle size={16} />,
      "symptoms": <Activity size={16} />,
      "assessment": <Stethoscope size={16} />,
      "plan": <ClipboardList size={16} />,
      "red-flags": <AlertCircle size={16} />,
      "follow-up": <Clock size={16} />
    }[type] || <FileText size={16} />;
  };

  const highlightClinicalTerms = (text, plainText = false) => {
    if (!text) return text;

    // Sanitize: Detect and collapse massive word repetitions (AI hallucinations)
    // e.g., AcetaminophenAcetaminophen -> Acetaminophen
    let sanitizedText = text.replace(/(\b[A-Za-z]{3,})\1{2,}/gi, '$1');

    if (plainText) return sanitizedText;

    // Patterns for medications, metrics, ICD codes, and clinical findings
    const patterns = [
      { regex: /\b(ICD-10 [A-Z]\d{2}(?:\.\d+)?)\b/gi, className: "bg-[#7c3aed]/8 text-[#7c3aed] px-1.5 py-0.5 rounded-md font-black ring-1 ring-[#7c3aed]/20" }, // ICD Codes
      { regex: /\b(\d+(?:\s*[-–—to]+\s*\d+)?(?:\.\d+)?\s*(?:°F|°C|mg|ml|kg|L|glasses|per day|day|history|years?|months?|daily))\b/gi, className: "text-accent font-black border-b-2 border-accent/20 hover:border-accent/40 transition-colors" }, // Metrics, Dosing & Ranges
      { regex: /\b(PO|Q6H|PRN|BID|TID|QID|AC|PC|HS|QD|QOD|SL|IV|IM|SubQ|By Mouth|As Needed|Every \d+ to \d+ Hours|Every \d+ Hours|Once Daily|Twice Daily|Three Times Daily|Four Times Daily|At Bedtime|Before Meals|After Meals|Immediately|Sublingual|Intramuscular|Intravenous|Tablet|Tablets|Capsule|Capsules)\b/gi, className: "text-accent font-black bg-accent/5 px-1 rounded shadow-sm" },
      { regex: /\b(Acetaminophen|ORS|fever|infection|viral|asthma|allergy|dizziness|dehydration|cough|congestion|fever relief|medication|sore throat|swallowing|fatigue|appetite|taste perception|distress|consultation|hydration status)\b/gi, className: "text-text font-extrabold decoration-accent/10 decoration-2 underline-offset-2 underline hover:decoration-accent/40 transition-all" }, // Clinical terms
    ];

    let parts = [sanitizedText];
    patterns.forEach(({ regex, className }, patternIdx) => {
      let newParts = [];
      parts.forEach((part, partIdx) => {
        if (typeof part !== 'string') {
          newParts.push(part);
          return;
        }

        // Reset regex lastIndex before using it on a new part
        regex.lastIndex = 0;

        const splitParts = part.split(regex);
        splitParts.forEach((sp, i) => {
          // If the part matches the regex, it was a captured group (the delimiter)
          // We check using a non-global version to avoid lastIndex issues during the check
          const isMatch = sp && sp.match(new RegExp(regex.source, regex.flags.replace('g', '')));

          if (isMatch) {
            newParts.push(<span key={`term-${patternIdx}-${partIdx}-${i}`} className={className}>{sp}</span>);
          } else if (sp !== undefined && sp !== "") {
            newParts.push(sp);
          }
        });
      });
      parts = newParts;
    });

    return parts;
  };

  const renderBulletedContent = (text, type) => {
    if (!text) return null;

    // Split by common bullet patterns: - or * or \n- or \n*
    const items = text.split(/\n(?=[-*\d])|(?<=\n)-|(?<=\n)\*|^[-*\d]\s+/).filter(i => i.trim());

    if (items.length <= 1 && !text.startsWith('-') && !text.startsWith('*')) {
      return (
        <p className={`text-[16px] leading-[1.8] font-medium whitespace-pre-wrap break-words [overflow-wrap:anywhere] ${type === 'red-flags' ? 'text-[#9f1239]' :
          type === 'assessment' ? 'text-text font-black' :
            'text-text/80'
          }`}>
          {highlightClinicalTerms(translateMedicalTerms(text))}
        </p>
      );
    }

    return (
      <ul className="flex flex-col gap-2.5">
        {items.map((item, idx) => (
          <li key={idx} className="flex items-start gap-3 group/item">
            <div className={`mt-2.5 w-1.5 h-1.5 rounded-full shrink-0 transition-transform group-hover/item:scale-125 ${type === 'red-flags' ? 'bg-[#e11d48]/40' :
              type === 'plan' ? 'bg-[#16a34a]/40' :
                type === 'assessment' ? 'bg-[#7c3aed]/40' :
                  'bg-accent/40'
              }`} />
            <span className={`text-[15.5px] leading-[1.8] font-medium break-words [overflow-wrap:anywhere] ${type === 'red-flags' ? 'text-[#9f1239]' :
              type === 'assessment' ? 'text-text font-bold' :
                'text-text/80'
              }`}>
              {highlightClinicalTerms(translateMedicalTerms(item.replace(/^[-*\d]\s+/, '').trim()))}
            </span>
          </li>
        ))}
      </ul>
    );
  };

  // --- [NEW] HIGH-FIDELITY CLINICAL BLUEPRINT COMPONENTS ---

  const ClinicalCanvas = ({ children }) => (
    <div className="flex-1 overflow-y-auto custom-scrollbar lg:pr-2 lg:-mr-2 min-h-0 bg-white/50 relative">
      {/* Institutional Dot-Grid Background */}
      <div className="absolute inset-0 pointer-events-none" style={{ 
        backgroundImage: 'radial-gradient(circle, #e2e8f0 1px, transparent 1px)', 
        backgroundSize: '24px 24px',
        opacity: 0.4
      }} />
      
      {/* Global Logic Thread (Vertical Connection) */}
      <div className="absolute left-[39px] top-8 bottom-8 w-[1px] bg-gradient-to-b from-accent/20 via-accent/10 to-transparent z-0" />
      
      <div className="relative z-10 flex flex-col gap-12 py-8">
        {children}
      </div>
    </div>
  );

  const ClinicalSlab = ({ icon, title, children, color = "text-accent", delay = 0 }) => (
    <motion.div
      initial={{ opacity: 0, x: 10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay }}
      className="flex flex-col gap-5 relative group/slab px-4 lg:px-6"
    >
      {/* Slab Header (Unified Row) */}
      <div className="flex items-center gap-5">
        {/* ID Column */}
        <div className={`w-10 h-10 rounded-xl bg-white border border-border/40 flex items-center justify-center shadow-sm transition-all group-hover/slab:border-accent/30 duration-300 relative z-20 ${color}`}>
          {icon}
        </div>
        {/* Title Column */}
        <div className="text-[12px] font-black uppercase tracking-[0.25em] text-text/80">
          {title}
        </div>
      </div>

      {/* Content Column (Indented) */}
      <div className="pl-14 relative">
        {/* Connector Node */}
        <div className="absolute left-[2.5px] top-0 w-2 h-2 rounded-full bg-white border-2 border-border/60 group-hover/slab:border-accent transition-all duration-300 z-20" />
        {children}
      </div>
    </motion.div>
  );

  const DiagnosticTruthBanner = ({ diagnosis }) => {
    if (!diagnosis) return null;
    const icdMatch = diagnosis.match(/\(ICD-10 ([A-Z]\d{2}(?:\.\d+)?)\)/i);
    const cleanDiagnosis = diagnosis.replace(/\(ICD-10 .*\)/i, '').trim();
    const icdCode = icdMatch ? icdMatch[1] : null;

    return (
      <div className="flex flex-col gap-3 group/diagnosis relative">
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-4 flex-wrap">
             <h3 className="text-[28px] lg:text-[32px] font-black text-text tracking-tighter leading-none group-hover/diagnosis:text-accent transition-colors">
                {cleanDiagnosis}
             </h3>
             {icdCode && (
               <div className="px-2.5 py-1 bg-off border border-border/60 rounded-md flex items-center gap-2 shadow-sm">
                  <Database size={10} className="text-muted" />
                  <span className="text-[11px] font-bold text-muted uppercase tracking-wider">{icdCode}</span>
               </div>
             )}
          </div>
          <div className="flex items-center gap-6">
             <div className="flex items-center gap-3">
                <div className="flex gap-0.5 items-end h-3">
                   {[40, 70, 50, 90, 60, 80].map((h, i) => (
                      <motion.div 
                        key={i}
                        initial={{ height: "20%" }}
                        animate={{ height: `${h}%` }}
                        transition={{ repeat: Infinity, duration: 1 + i*0.2, repeatType: "reverse" }}
                        className="w-[2px] bg-green rounded-full" 
                      />
                   ))}
                </div>
                <span className="text-[10px] font-black text-green uppercase tracking-widest">98.4% AI Confidence Index</span>
             </div>
             <div className="h-3 w-[1px] bg-border/40" />
             <div className="flex items-center gap-2">
                <ShieldCheck size={12} className="text-accent/30" />
                <span className="text-[10px] font-bold text-muted/30 uppercase tracking-widest">Protocol Verified</span>
             </div>
          </div>
        </div>
        
        {/* Subtle Logic Trace */}
        <div className="absolute -left-14 top-0 bottom-0 w-[2px] bg-accent/10 rounded-full overflow-hidden">
           <motion.div 
             animate={{ y: ["-100%", "200%"] }} 
             transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
             className="w-full h-1/3 bg-gradient-to-b from-transparent via-accent to-transparent"
           />
        </div>
      </div>
    );
  };

  const PharmacologicalMatrix = ({ medicines }) => {
    if (!medicines || medicines.length === 0) return null;
    return (
      <div className="flex flex-col border border-border/40 rounded-2xl overflow-hidden bg-white/40 backdrop-blur-sm shadow-sm">
        <div className="grid grid-cols-[1fr_auto_auto] gap-4 px-6 py-3 bg-off/50 border-b border-border/30 text-[10px] font-black text-muted uppercase tracking-[0.2em]">
          <div>Medication Identifier</div>
          <div className="text-center">Protocol</div>
          <div className="text-right">Route</div>
        </div>
        <div className="flex flex-col divide-y divide-border/20">
          {medicines.map((med, idx) => (
            <div key={idx} className="grid grid-cols-[1fr_auto_auto] gap-4 px-6 py-5 group/med hover:bg-accent/[0.02] transition-colors items-center">
              <div className="flex flex-col gap-1">
                <div className="text-[17px] font-bold text-text group-hover/med:text-accent transition-colors">
                  {med.medication || med.name}
                </div>
                <div className="text-[12px] text-muted italic flex items-center gap-2">
                  <Info size={12} className="text-accent/40" />
                  "{med.instructions || med.sig}"
                </div>
              </div>
              <div className="flex flex-col items-center gap-1.5">
                <div className="px-2 py-0.5 bg-accent/5 text-accent text-[11px] font-black rounded uppercase tracking-wider border border-accent/10">
                  {med.dosage}
                </div>
                <div className="text-[9px] font-bold text-muted/60 uppercase tracking-widest">
                  {med.frequency}
                </div>
              </div>
              <div className="text-right">
                <div className="w-10 h-10 rounded-lg bg-off border border-border/40 flex items-center justify-center text-text/40 group-hover/med:border-accent/30 group-hover/med:text-accent transition-all shadow-inner">
                  <Zap size={18} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const PharmacyLabelCard = ({ med }) => (
    <div className="bg-white border border-border/40 rounded-[28px] p-6 shadow-sm hover:shadow-xl transition-all duration-300 group/med relative overflow-hidden flex flex-col justify-between min-h-[180px]">
       <div className="relative z-10">
          <div className="flex justify-between items-start mb-4">
             <div className="flex flex-col gap-1">
                <div className="text-[10px] font-black text-accent/40 uppercase tracking-[0.2em] mb-1">Medication Identifier</div>
                <h4 className="text-[20px] font-black text-text group-hover/med:text-accent transition-colors tracking-tight leading-tight">{med.name}</h4>
             </div>
             <div className="px-3 py-1.5 bg-text text-white text-[10px] font-black rounded-xl uppercase tracking-widest shadow-lg group-hover/med:bg-accent transition-all">
                {med.duration}
             </div>
          </div>
          
          <div className="flex items-center gap-4 mb-6">
             <div className="flex items-center gap-2 px-2.5 py-1 bg-accent/5 border border-accent/10 rounded-lg">
                <span className="text-[12px] font-black text-accent uppercase">{med.dosage}</span>
             </div>
             <div className="h-4 w-[1px] bg-border/60" />
             <div className="flex items-center gap-2 text-muted/60">
                <Clock size={14} />
                <span className="text-[12px] font-bold">{med.frequency}</span>
             </div>
          </div>
       </div>

       {med.instructions && (
          <div className="mt-auto p-4 bg-off/50 border border-border/40 rounded-[20px] flex items-start gap-3 relative z-10 transition-all group-hover/med:bg-accent/[0.03] group-hover/med:border-accent/10">
             <div className="w-8 h-8 rounded-xl bg-white border border-border/60 flex items-center justify-center text-accent/40 shadow-sm shrink-0">
                <Info size={14} />
             </div>
             <div className="flex flex-col gap-1">
                <span className="text-[9px] font-black text-muted/40 uppercase tracking-widest">SIG INSTRUCTIONS</span>
                <p className="text-[13px] font-bold text-text/70 italic leading-snug">"{med.instructions}"</p>
             </div>
          </div>
       )}

       {/* Industrial Texture */}
       <div className="absolute top-0 right-0 w-24 h-24 bg-accent/[0.015] rounded-full -mr-12 -mt-12 blur-3xl" />
       <div className="absolute bottom-4 right-4 opacity-5 pointer-events-none">
          <Activity size={40} className="text-accent" />
       </div>
    </div>
  );

  const LifestyleProtocolGrid = ({ advice, followUp }) => {
    // Advice is often an array or a newline separated string
    const adviceItems = typeof advice === 'string' ? advice.split('\n').filter(i => i.trim()).slice(0, 4) : 
                       Array.isArray(advice) ? advice.slice(0, 4) : [];
    
    const icons = [<Droplets size={18} />, <Moon size={18} />, <HeartPulse size={18} />, <Zap size={18} />];
    const colors = ['text-blue-500', 'text-indigo-500', 'text-rose-500', 'text-amber-500'];
    const bgColors = ['bg-blue-50', 'bg-indigo-50', 'bg-rose-50', 'bg-amber-50'];

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pl-11">
         {adviceItems.map((item, idx) => (
           <div key={idx} className="p-4 bg-white border border-border/60 rounded-2xl shadow-sm hover:shadow-md transition-all group/insight flex items-start gap-4">
              <div className={`w-10 h-10 rounded-xl ${bgColors[idx % 4]} ${colors[idx % 4]} flex items-center justify-center shrink-0 shadow-sm group-hover/insight:scale-110 transition-transform`}>
                 {icons[idx % 4]}
              </div>
              <div className="flex flex-col gap-1">
                 <span className="text-[10px] font-black text-muted/40 uppercase tracking-widest">Protocol {idx + 1}</span>
                 <p className="text-[14px] font-bold text-text/70 leading-tight italic">{item.replace(/^-\s*/, '').replace(/^\d+\.\s*/, '')}</p>
              </div>
           </div>
         ))}
         
         {followUp && (
           <div className="sm:col-span-2 p-5 bg-[#7c3aed]/5 border border-[#7c3aed]/10 rounded-3xl flex items-start gap-5 group/follow relative overflow-hidden">
              <div className="w-12 h-12 rounded-2xl bg-white border border-[#7c3aed]/20 text-[#7c3aed] flex items-center justify-center shrink-0 shadow-sm group-hover/follow:rotate-12 transition-transform relative z-10">
                 <Clock size={24} />
              </div>
              <div className="flex flex-col gap-1 relative z-10">
                 <span className="text-[11px] font-black text-[#7c3aed] uppercase tracking-[0.2em]">Follow-Up Criteria</span>
                 <p className="text-[15px] font-bold text-text/70 leading-relaxed italic">{Array.isArray(followUp) ? followUp.join(' ') : followUp.replace('\n', ' ')}</p>
              </div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-[#7c3aed]/5 rounded-full blur-2xl" />
           </div>
         )}
      </div>
    );
  };

  const parseClinicalSummary = (res) => {
    if (!res) return [];

    // Support both the full result object and just the text for backward compatibility
    const text = typeof res === 'string' ? res : res.patient_summary;
    const summarySections = typeof res === 'object' ? res.summary_sections : null;

    const sections = [];
    const headers = ["Symptoms", "Assessment", "Plan", "Red Flags", "Follow-up"];

    // 1. Try structured summary_sections first
    if (summarySections && typeof summarySections === 'object') {
      // Ensure we always have these headers in this order if possible
      headers.forEach(header => {
        const content = summarySections[header] || summarySections[header.toLowerCase()];
        if (content && content.length > 5) {
          sections.push({
            title: header,
            content: content,
            type: header.toLowerCase().replace(/\s+/g, '-'),
            icon: getIconForSection(header)
          });
        }
      });

      // Add any other sections present in summary_sections that aren't in standard headers
      Object.entries(summarySections).forEach(([title, content]) => {
        const isStandard = headers.some(h => h.toLowerCase() === title.toLowerCase());
        if (!isStandard && content && content.length > 5) {
          sections.push({
            title: title.charAt(0).toUpperCase() + title.slice(1),
            content,
            type: title.toLowerCase().replace(/\s+/g, '-'),
            icon: getIconForSection(title)
          });
        }
      });

      if (sections.length > 0) return sections;
    }

    // 2. Fallback to regex parsing for legacy data or strings
    if (text) {
      const allHeaders = ["Patient Summary", ...headers];
      const regex = new RegExp(`^(${allHeaders.join('|')}):`, 'gm');
      const splits = text.split(regex);
      for (let i = 1; i < splits.length; i += 2) {
        const title = splits[i].trim();
        const content = splits[i + 1]?.trim() || "";
        if (title && content && content.length > 2) {
          sections.push({
            title,
            content,
            type: title.toLowerCase().replace(/\s+/g, '-'),
            icon: getIconForSection(title)
          });
        }
      }
    }

    if (sections.length === 0 && text) {
      sections.push({ title: "Clinical Summary", content: text, type: "generic", icon: <FileText size={16} /> });
    }
    return sections;
  };

  const parsePrescriptionText = (text) => {
    if (!text) return null;

    const result = {
      diagnosis: '',
      icdCode: '',
      confidence: 0,
      verified: true,
      medications: [],
      advice: [],
      followUp: '',
      disclaimer: ''
    };

    // 1. Primary Diagnosis & ICD
    const diagnosisMatch = text.match(/PRIMARY DIAGNOSIS: (.*)/i);
    if (diagnosisMatch) {
      const rawDiag = diagnosisMatch[1].trim();
      const icdMatch = rawDiag.match(/\(ICD-10 ([A-Z]\d{2}(?:\.\d+)?)\)/i);
      result.diagnosis = rawDiag.replace(/\(ICD-10 .*\)/i, '').trim();
      result.icdCode = icdMatch ? icdMatch[1] : '';
    }

    // 1.5 Confidence Score
    const confidenceMatch = text.match(/CONFIDENCE: (\d+(?:\.\d+)?)%/i);
    if (confidenceMatch) {
      result.confidence = parseFloat(confidenceMatch[1]);
    }

    // 2. Pharmacological Interventions
    const pharmacologicalSection = text.split(/PHARMACOLOGICAL INTERVENTIONS:/i)[1]?.split(/NON-PHARMACOLOGICAL ADVICE/i)[0];
    if (pharmacologicalSection) {
      const medBlocks = pharmacologicalSection.split(/\d+\.\s+/).filter(b => b.trim());
      result.medications = medBlocks.map(block => {
        const lines = block.split('\n').map(l => l.trim()).filter(l => l);
        const name = lines[0];
        const doseMatch = block.match(/Dose\/Freq: (.*)/i);
        const durationMatch = block.match(/Duration: (.*)/i);
        const instructionsMatch = block.match(/Patient Instructions: (.*)/i);

        return {
          name,
          dose: doseMatch ? doseMatch[1].trim() : '',
          duration: durationMatch ? durationMatch[1].trim() : '',
          protocol: instructionsMatch ? instructionsMatch[1].trim() : ''
        };
      }).filter(m => m.name);
    }

    // 3. Non-Pharmacological Advice
    const adviceSection = text.split(/NON-PHARMACOLOGICAL ADVICE & CLINICAL GUIDANCE:/i)[1]?.split(/FOLLOW-UP PLAN:/i)[0];
    if (adviceSection) {
      result.advice = adviceSection.split(/\n\s*[-•*›]+\s*|\s*- -/).map(a => {
        // Clean leading dashes, bullets, or extra whitespace
        return a.trim().replace(/^[-•*›\s]+/, '').trim();
      }).filter(a => a && a.length > 2 && !a.includes('PHARMACOLOGICAL'));
    }

    // 4. Follow-up Plan
    const followUpSection = text.split(/FOLLOW-UP PLAN:/i)[1]?.split(/===+|DISCLAIMER:/i)[0];
    if (followUpSection) {
      result.followUp = followUpSection.split(/\n\s*[-•*›]+\s*|\s*- -/).map(a => {
        // Clean leading dashes, bullets, or extra whitespace
        return a.trim().replace(/^[-•*›\s]+/, '').trim();
      }).filter(a => a && a.length > 2).join('. ');
    }

    // 5. Disclaimer
    const disclaimerMatch = text.match(/DISCLAIMER: (.*)/is);
    if (disclaimerMatch) result.disclaimer = disclaimerMatch[1].trim();

    return result;
  };

  /**
   * Cleans messy AI-generated ASCII dividers and redundant headers
   * for a more professional clinical document look.
   */
  const cleanPrescriptionText = (text) => {
    if (!text) return '';
    return text
      .replace(/^CLINICAL DOCUMENTATION & PRESCRIPTION[\s\S]*?(?=PRIMARY DIAGNOSIS:)/i, '') // Remove top noise
      .replace(/^[=-]{10,}/gm, '') // Remove long ASCII lines
      .replace(/^\s*[-•*›]+\s*[-•*›]+\s*/gm, '• ') // Fix double bullets like "- -"
      .replace(/^\s*[-*›]\s+/gm, '• ') // Standardize other bullets to dots
      .replace(/\n{3,}/g, '\n\n') // Normalize excessive whitespace
      .trim();
  };

  const translateMedicalTerms = (text) => {
    if (!text) return text;
    
    // 1. Dynamic regex for hourly ranges like Q4-6H, q8-12h, etc.
    let translated = text.replace(/\bQ(\d+)-(\d+)H\b/gi, (match, p1, p2) => {
      return `Every ${p1} to ${p2} Hours`;
    });

    // 2. Fixed dictionary for standard abbreviations
    const terms = {
      'PO': 'By Mouth',
      'PRN': 'As Needed',
      'p.r.n.': 'As Needed',
      'as req': 'As Needed',
      'q6h': 'Every 6 Hours',
      'q4h': 'Every 4 Hours',
      'q8h': 'Every 8 Hours',
      'q12h': 'Every 12 Hours',
      'q24h': 'Every 24 Hours',
      'Q4-6H': 'Every 4 to 6 Hours',
      'QD': 'Once Daily',
      'BID': 'Twice Daily',
      'TID': 'Three Times Daily',
      'QID': 'Four Times Daily',
      'HS': 'At Bedtime',
      'AC': 'Before Meals',
      'PC': 'After Meals',
      'stat': 'Immediately',
      'SL': 'Sublingual',
      'IM': 'Intramuscular',
      'IV': 'Intravenous',
      'tab': 'Tablet',
      'tabs': 'Tablets',
      'cap': 'Capsule',
      'caps': 'Capsules',
      'mcg': 'Micrograms',
      'mg': 'mg',
      'ml': 'ml',
      'oz': 'Ounces',
      'tsp': 'Teaspoon',
      'tbsp': 'Tablespoon'
    };

    Object.entries(terms).forEach(([abbr, full]) => {
      const regex = new RegExp(`\\b${abbr}\\b`, 'gi');
      translated = translated.replace(regex, full);
    });
    return translated;
  };

  const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const fileInputRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const typingTimeoutRef = useRef(null);

  // Sync isTyping state
  useEffect(() => {
    if (transcript.length > 0) {
      setIsTyping(true);
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = setTimeout(() => setIsTyping(false), 1000);
    } else {
      setIsTyping(false);
    }
    return () => {
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    };
  }, [transcript]);

  // Observer for Billing Section Discovery
  useEffect(() => {
    if (!result) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsBillingVisible(entry.isIntersecting);
      },
      {
        root: scrollContainerRef.current,
        threshold: 0.1
      }
    );

    if (billingRef.current) {
      observer.observe(billingRef.current);
    }

    return () => observer.disconnect();
  }, [result]);

  const [recordingDuration, setRecordingDuration] = useState(0);
  const [codingExplanation, setCodingExplanation] = useState('');
  const [hoveredBillingIdx, setHoveredBillingIdx] = useState(null);
  const timerRef = useRef(null);
  const canvasRef = useRef(null);
  const audioCtxRef = useRef(null);
  const analyserRef = useRef(null);
  const animationRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const abortControllerRef = useRef(null);
  const intervalRef = useRef(null);

  const revokeAudioPreview = (file) => {
    if (file?.preview) {
      URL.revokeObjectURL(file.preview);
    }
  };

  const clearAudioState = () => {
    revokeAudioPreview(audioFile);
    setAudioFile(null);
    setIsUploading(false);
    setIsVerified(false);
    setUploadProgress(0);
  };

  const cleanupRecordingSession = async () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    if (audioCtxRef.current) {
      try {
        await audioCtxRef.current.close();
      } catch {
        // Ignore redundant close attempts from fast UI transitions.
      }
      audioCtxRef.current = null;
    }
    analyserRef.current = null;
  };

  useEffect(() => {
    if (encounterToLoad) {
      setResult({
        ...encounterToLoad,
        transcript: encounterToLoad.transcript || '',
        patient_summary: encounterToLoad.patient_summary || '',
        rx_summary: encounterToLoad.rx_text || '',
        rx_json: encounterToLoad.rx_json || {},
        diagnosis: encounterToLoad.diagnosis || encounterToLoad.rx_json?.diagnosis || null,
        medicines: encounterToLoad.rx_json?.medicines || [],
        summary_sections: encounterToLoad.clinical_data?.summary_sections || null,
        billing_codes: encounterToLoad.codes_json?.codes || []
      });

      setEditedRx(cleanPrescriptionText(encounterToLoad.rx_text) || '');
      setVerifiedCodes(encounterToLoad.codes_json?.codes || []);
      setCurrentEncounterId(encounterToLoad.id);
      setAudioFile(null);
      setTranscript('');
      setIsRxEditing(false);
      setReviewMobileTab('summary');
    } else {
      setResult(null);
      setEditedRx('');
      setReviewMobileTab('summary');
      setIsRxEditing(false);
    }
  }, [encounterToLoad]);

  // Sync editedRx when result changes (e.g. after handleGenerate or Regenerate)
  useEffect(() => {
    if (result?.rx_summary && !editedRx) {
      setEditedRx(cleanPrescriptionText(result.rx_summary));
    }
    if (result?.billing_codes) {
      setVerifiedCodes(result.billing_codes.map(c => ({
        ...c,
        verified: c.confidence >= 0.85
      })));
    }
  }, [result]);

  const [isDragging, setIsDragging] = useState(false);

  const handleFileSelect = (file) => {
    if (file && file.type.startsWith('audio/')) {
      clearAudioState();

      const fileWithPreview = Object.assign(file, {
        preview: URL.createObjectURL(file)
      });

      // START ASYNCHRONOUS INTAKE SIMULATION
      setAudioFile(fileWithPreview);
      setIsUploading(true);
      setIsVerified(false);
      setUploadProgress(0);

      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 15 + 5;
        if (progress >= 100) {
          progress = 100;
          setUploadProgress(100);
          clearInterval(interval);

          // Final Handshake Delay
          setTimeout(() => {
            setIsUploading(false);
            setIsVerified(true);
          }, 600);
        } else {
          setUploadProgress(progress);
        }
      }, 150);

    } else {
      alert("Please select a valid audio file.");
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    setIsVerified(false);
    setUploadProgress(0);
    handleFileSelect(e.dataTransfer.files[0]);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleStopSummary = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    setIsProcessing(false);
    setProcessingStep(0);
  };

  const mockResult = {
    patient_summary: "## CHIEF COMPLAINT\nPersistent non-productive cough and mild dyspnea for 3 days.\n\n## ASSESSMENT\nAcute Upper Respiratory Infection with secondary bronchial irritation. Rule out early-stage community-acquired pneumonia.\n\n## RED FLAGS\n- High fever (>102°F)\n- Hemoptysis\n- Significant resting tachycardia\n\n## PLAN\n1. Amoxicillin 500mg TID for 7 days.\n2. Albuterol inhaler q4-6h prn for dyspnea.\n3. Follow up in 48h if symptoms persist.",
    diagnosis: "Acute Upper Respiratory Infection (ICD-10 J06.9)",
    medicines: [
      { name: "Amoxicillin", dosage: "500mg", frequency: "TID (Three times daily)", duration: "7 Days", instructions: "Take with food to minimize GI upset. Complete the full course even if feeling better." },
      { name: "Albuterol Inhaler", dosage: "90mcg", frequency: "Q4-6H PRN (As needed)", duration: "Until resolved", instructions: "Rinse mouth after use. 2 puffs per dose for shortness of breath." }
    ],
    advice: "Maintain aggressive hydration (2-3L/day).\nRest in semi-fowler position (elevated head).\nMonitor temperature every 4 hours.\nAvoid smoke and environmental irritants.",
    follow_up: "Return immediately for high fever (>102.5°F), hemoptysis, or worsening dyspnea. Follow up in clinic in 48 hours."
  };

  // Priority: Real result (loaded from timeline/generation) > Tutorial Mock Result > Nothing
  const displayedResult = result || (window.superhumanly_mock_active === 'workflow' ? mockResult : null);
  const isMockActive = window.superhumanly_mock_active === 'workflow';

  useEffect(() => {
    const handleTutorialMock = () => {
      // Still set state for consistency, but logic now uses displayedResult
      if (!result) {
        setResult(mockResult);
      }
    };

    const handleClear = () => {
      setResult(null);
      setEditedRx('');
    };

    window.addEventListener('superhumanly-tutorial-mock', handleTutorialMock);
    window.addEventListener('superhumanly-tutorial-clear', handleClear);
    return () => {
      window.removeEventListener('superhumanly-tutorial-mock', handleTutorialMock);
      window.removeEventListener('superhumanly-tutorial-clear', handleClear);
    };
  }, [result]);

  // Fetch risks for the selected customer
  useEffect(() => {
    if (selectedCustomer) {
      loadRisks();
    } else {
      setRisks([]);
    }
  }, [selectedCustomer]);

  const loadRisks = async () => {
    try {
      const data = await fetchPatientRisks(selectedCustomer.id);
      setRisks(data);
    } catch (e) {
      console.error("Failed to load patient risks", e);
    }
  };

  const handleRiskAction = (action) => {
    if (action.type === 'navigation') {
      // In a real app, handle tab switching or scrolling
      console.log('Navigating to:', action.payload);
    } else {
      alert(`Initiating Protocol: ${action.label}`);
    }
  };

  useEffect(() => {
    return () => {
      clearInterval(intervalRef.current);
      clearInterval(timerRef.current);
      revokeAudioPreview(audioFile);
      cleanupRecordingSession();
    };
  }, [audioFile]);

  const handleGenerate = async () => {
    if (!selectedCustomer) return;

    // TRIAL GATE ENFORCEMENT
    if (trialData?.is_expired) {
      onUpgradeClick();
      return;
    }

    setIsProcessing(true);
    setSendSuccess(null);
    setProcessingStep(1); // "Structuring Clinical Narrative"
    abortControllerRef.current = new AbortController();

    try {
      let taskData;
      if ((inputType === 'audio' || inputType === 'record') && audioFile) {
        taskData = await processAudio(audioFile, selectedCustomer.id, emailTo, 'Prescription Summary', abortControllerRef.current.signal, language);
      } else if (inputType === 'text' && transcript) {
        taskData = await processText(transcript, selectedCustomer.id, emailTo, 'Prescription Summary', abortControllerRef.current.signal);
      } else {
        alert("Please provide input data.");
        setIsProcessing(false);
        return;
      }

      const taskId = taskData.task_id;
      if (!taskId) throw new Error("No Task ID received from server.");

      // START POLLING
      const pollTask = async () => {
        try {
          const statusData = await getTaskStatus(taskId);
          console.log('Task Status:', statusData);

          if (statusData.ready) {
            if (statusData.status === 'SUCCESS') {
              const data = statusData.result;
              setResult(data);
              setReviewMobileTab('summary');
              setIsRxEditing(false);
              setCurrentEncounterId(data.encounter_id);
              setEditedRx(cleanPrescriptionText(data.rx_summary) || '');
              setVerifiedCodes(data.billing_codes || []);

              // Notify Sidebar to refresh timeline
              window.dispatchEvent(new CustomEvent('superhumanly-encounter-created', { detail: { customerId: selectedCustomer.id } }));

              // Refresh trial status
              if (onTrialRefresh) onTrialRefresh();

              setIsProcessing(false);
              setProcessingStep(0);
              clearInterval(intervalRef.current);
            } else {
              throw new Error(statusData.error || "Background task failed.");
            }
          } else {
            // Handle RETRY specifically
            if (statusData.status === 'RETRY') {
              setProcessingStep(99); // Custom step for Quota Wait
            } else {
              setProcessingStep(prev => (prev === 99 ? 1 : (prev % 4) + 1));
            }
          }
        } catch (pollError) {
          console.error('Polling Error:', pollError);
          setIsProcessing(false);
          setProcessingStep(0);
          clearInterval(intervalRef.current);
          alert("Error tracking background task.");
        }
      };

      intervalRef.current = setInterval(pollTask, 2000);

    } catch (e) {
      if (e.name === 'AbortError') return;
      console.error(e);
      alert("Error starting clinical analysis.");
      setIsProcessing(false);
      setProcessingStep(0);
    }
  };

  const startRecording = async () => {
    if (isRecording) return;

    try {
      await cleanupRecordingSession();
      clearAudioState();
      setRecordingDuration(0);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      // Setup Web Audio API for Visualization
      audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)();
      analyserRef.current = audioCtxRef.current.createAnalyser();
      const source = audioCtxRef.current.createMediaStreamSource(stream);
      source.connect(analyserRef.current);
      analyserRef.current.fftSize = 256;

      const bufferLength = analyserRef.current.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const draw = () => {
        if (!canvasRef.current || !analyserRef.current) return;
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;

        animationRef.current = requestAnimationFrame(draw);
        analyserRef.current.getByteFrequencyData(dataArray);

        ctx.clearRect(0, 0, width, height);

        const barWidth = (width / bufferLength) * 2;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const barHeight = (dataArray[i] / 255) * height;

          // PREMIUM GRADIENT: Deep medical blue to vibrant accent
          const gradient = ctx.createLinearGradient(0, height, 0, 0);
          gradient.addColorStop(0, 'rgba(0, 78, 179, 0.2)');
          gradient.addColorStop(0.5, 'rgba(0, 195, 255, 0.8)');
          gradient.addColorStop(1, 'rgba(0, 78, 179, 1)');

          ctx.fillStyle = gradient;

          // Rounded bars for clinical look
          const radius = barWidth / 2;
          ctx.beginPath();
          ctx.roundRect(x, height - barHeight, barWidth, barHeight, [radius, radius, 0, 0]);
          ctx.fill();

          x += barWidth + 3;
        }
      };

      draw();

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const file = new File([audioBlob], 'live_recording.wav', { type: 'audio/wav' });

        // Add preview URL for consistency with File Upload
        const fileWithPreview = Object.assign(file, {
          preview: URL.createObjectURL(audioBlob)
        });

        setAudioFile(fileWithPreview);
        mediaStreamRef.current = null;
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);

      timerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);

    } catch (err) {
      console.error(err);
      alert('Microphone access denied or error occurred.');
    }
  };

  const stopRecording = async () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      await cleanupRecordingSession();
    }
  };

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSendEmail = async () => {
    if (!emailTo || !isValidEmail(emailTo)) return;
    setIsSending(true);
    setSendSuccess(null);
    setSendError(null);

    try {
      const res = await sendEmail(editedRx, emailTo);
      setSendSuccess(`Dispatched to ${emailTo}`);
    } catch (e) {
      setSendError(e.message || "Dispatch failed. Please retry.");
    } finally {
      setIsSending(false);
      // Auto-clear success message, but keep errors for troubleshooting
      if (!sendError) {
        setTimeout(() => setSendSuccess(null), 8000);
      }
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(editedRx);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleDownloadPDF = () => {
    const doc = new jsPDF();
    let currentY = 0;
    const PAGE_HEIGHT = 297;
    const MARGIN_BOTTOM = 25;
    const patientName = selectedCustomer?.name || 'Patient';

    // Internal helper to ensure branding (Blue Accent) on every page
    const renderInstitutionalBranding = () => {
      doc.setFillColor(0, 78, 179);
      doc.rect(0, 0, 8, PAGE_HEIGHT, 'F');
    };

    // Internal helper for page breaks
    const ensureSpace = (neededHeight) => {
      if (currentY + neededHeight > PAGE_HEIGHT - MARGIN_BOTTOM) {
        doc.addPage();
        renderInstitutionalBranding();
        currentY = 20; // Reset with margin
        return true;
      }
      return false;
    };

    // 1. INSTITUTIONAL HEADER & IDENTITY
    renderInstitutionalBranding();

    // Header Vector Sigil
    doc.setFillColor(0, 78, 179);
    doc.rect(20, 20, 10, 10, 'F');
    doc.setFillColor(255, 255, 255);
    doc.rect(24, 21.5, 2, 7, 'F');
    doc.rect(21.5, 24, 7, 2, 'F');

    // Header Typography
    doc.setTextColor(17, 17, 17);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('SUPERHUMANLY', 35, 26);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text('CLINICAL ADVISORY & DOCUMENTATION', 35, 31);

    doc.setFillColor(240, 249, 255);
    doc.roundedRect(150, 18, 40, 8, 2, 2, 'F');
    doc.setTextColor(0, 78, 179);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text('VERIFIED ENCOUNTER', 154, 23.5);

    doc.setDrawColor(232, 232, 228);
    doc.line(20, 45, 190, 45);

    // 2. STRUCTURED METADATA GRID
    doc.setFontSize(8);
    doc.setTextColor(80, 80, 80);
    doc.setFont('helvetica', 'normal');
    doc.text('PATIENT IDENTITY', 20, 55);
    doc.text('GENESIS DATE', 110, 55);

    doc.setFontSize(11);
    doc.setTextColor(17, 17, 17);
    doc.setFont('helvetica', 'bold');
    doc.text(patientName.toUpperCase(), 20, 62);
    const dateStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    doc.text(`${dateStr} @ ${timeStr}`, 110, 62);

    doc.setFontSize(8);
    doc.setTextColor(80, 80, 80);
    doc.setFont('helvetica', 'normal');
    doc.text('CLINICAL IDENTIFIER', 20, 75);
    doc.text('DOCUMENT CLASS', 110, 75);

    doc.setFontSize(11);
    doc.setTextColor(17, 17, 17);
    doc.setFont('helvetica', 'bold');
    doc.text(`ID# ${selectedCustomer?.id || 'ALPHA-001'}`, 20, 82);
    doc.text('PRESCRIPTION & PLAN', 110, 82);

    doc.line(20, 92, 190, 92);
    currentY = 105;

    // 3. CLINICAL ASSESSMENT SUMMARY
    ensureSpace(10);
    doc.setTextColor(0, 78, 179);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('I. CLINICAL ASSESSMENT SUMMARY', 20, currentY);
    currentY += 10;

    const parsedSections = parseClinicalSummary(result?.patient_summary);
    parsedSections.forEach((section) => {
      const lines = doc.splitTextToSize(section.content, 170);
      const blockHeight = (lines.length * 5) + 15;

      ensureSpace(blockHeight);

      doc.setFontSize(8.5);
      doc.setTextColor(0, 78, 179);
      doc.setFont('helvetica', 'bold');
      doc.text(section.title.toUpperCase(), 20, currentY);
      currentY += 6;

      doc.setTextColor(68, 68, 68);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.text(lines, 20, currentY);
      currentY += (lines.length * 5) + 8;

      doc.setDrawColor(245, 245, 245);
      doc.line(20, currentY - 4, 60, currentY - 4);
    });

    currentY += 10;

    // 4. PLAN & PRESCRIPTION SECTION
    ensureSpace(30); // Header + some table space
    doc.setTextColor(0, 78, 179);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('II. FINALIZED PLAN & PRESCRIPTION', 20, currentY);

    // Rx Sigil (Watermark style)
    doc.setTextColor(240, 240, 240);
    doc.setFont('times', 'italic');
    doc.setFontSize(54);
    doc.text('Rx', 165, currentY + 15);

    currentY += 6;

    // Table Header
    doc.setFillColor(252, 252, 252);
    doc.rect(20, currentY, 170, 8, 'F');
    doc.setDrawColor(240, 240, 240);
    doc.line(20, currentY + 8, 190, currentY + 8);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7);
    doc.setTextColor(80, 80, 80);
    doc.text('MEDICATION IDENTITY', 25, currentY + 5.5);
    doc.text('DOSAGE & UNIT', 100, currentY + 5.5);
    doc.text('ADMINISTRATION SCHEDULE', 145, currentY + 5.5);
    currentY += 8;

    // Data Rows Logic - Intelligently decide between Table and Text
    const rawRxJson = result?.rx_json;
    const rxData = Array.isArray(rawRxJson) ? rawRxJson : (rawRxJson ? [rawRxJson] : []);
    const isStructured = rxData.some(item => item && typeof item === 'object' && (item.medication || item.name));

    if (isStructured) {
      // STRUCTURED TABLE LAYOUT
      rxData.forEach((item, index) => {
        ensureSpace(12);
        if (index % 2 === 1) {
          doc.setFillColor(252, 252, 252);
          doc.rect(20, currentY, 170, 12, 'F');
        }

        doc.setTextColor(17, 17, 17);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        const medName = String(item.medication || item.name || 'Prescription Item');
        doc.text(medName.toUpperCase(), 25, currentY + 7.5);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(68, 68, 68);
        doc.text(String(item.dosage || item.dose || 'As directed'), 100, currentY + 7.5);
        doc.text(String(item.frequency || item.schedule || 'O.D.'), 145, currentY + 7.5);

        currentY += 12;
      });
    } else if (editedRx && editedRx.trim().length > 0) {
      // UNSTRUCTURED FALLBACK (PROFESSIONAL BULLETS)
      const rxLines = editedRx.split('\n').filter(l => l.trim().length > 0);
      rxLines.forEach((line, index) => {
        const cleanLine = line.replace(/^[•\-\*]\s*/, '');
        const lines = doc.splitTextToSize(cleanLine, 158);
        const blockHeight = (lines.length * 5) + 4;

        ensureSpace(blockHeight);

        if (index % 2 === 1) {
          doc.setFillColor(252, 252, 252);
          doc.rect(20, currentY, 170, blockHeight, 'F');
        }

        doc.setTextColor(68, 68, 68);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        doc.text('•', 25, currentY + 6);
        doc.text(lines, 32, currentY + 6);

        currentY += blockHeight;
      });
    } else {
      // EMPTY STATE
      ensureSpace(15);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text('No specific pharmacological plan or prescription items documented for this encounter.', 25, currentY + 8);
      currentY += 15;
    }

    currentY += 15;
    ensureSpace(30);

    // 5. SIGNATURE & VERIFICATION
    doc.setDrawColor(230, 230, 230);
    doc.line(20, currentY, 100, currentY);
    doc.setFontSize(8);
    doc.setTextColor(80, 80, 80);
    doc.text('PHYSICIAN SIGNATURE (DIGITAL)', 20, currentY + 5);

    // Security Seal Watermark
    doc.setTextColor(230, 230, 230);
    doc.setFontSize(32);
    const sealX = 120;
    const sealY = currentY;
    doc.saveGraphicsState();
    doc.setGState(new doc.GState({ opacity: 0.12 }));
    doc.text('HIGH FIDELITY', sealX, sealY, { angle: 15 });
    doc.restoreGraphicsState();

    // 6. FOOTER (Branding & Boilerplate) - Fix it firmly if possible or relative
    const footerY = 285;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(180, 180, 180);
    doc.text('Distributed via Superhumanly AI Clinical Protocol.', 20, footerY);
    doc.text(`Page Documentation 01/01`, 160, footerY);

    doc.save(`${patientName.replace(/\s+/g, '_')}_Clinical_Export.pdf`);

    // Success Feedback
    setIsExported(true);
    setTimeout(() => setIsExported(false), 2000);
  };

  const handleShareLink = async () => {
    if (!currentEncounterId) return;
    try {
      const res = await generateShareLink(currentEncounterId);
      const shareUrl = `${window.location.origin}/share/${res.token}`;
      await navigator.clipboard.writeText(shareUrl);
      setIsShared(true);
      setTimeout(() => setIsShared(false), 2000);
    } catch (e) {
      console.error(e);
      alert('Failed to generate share link.');
    }
  };

  const hasMissingFields = () => {
    if (!result?.rx_json) return false;
    return JSON.stringify(result.rx_json).toLowerCase().includes('missing') ||
      Object.values(result.rx_json).some(v => v === null || v === '');
  };

  const prescriptionEditorRows = Math.max(18, editedRx.split('\n').length + 4);

  return (
    <div className="flex-1 px-4 py-5 lg:p-6 h-auto lg:h-full flex flex-col overflow-x-hidden lg:overflow-hidden relative">
      {/* Immersive background decoration */}
      <div className="absolute top-10 right-10 w-96 h-96 bg-accent/5 blur-[120px] rounded-full pointer-events-none -z-10"></div>

      <ClinicalAlert risks={risks} onAction={handleRiskAction} />

      {/* Header with clear Progressive Step Guidance */}
      {/* Header with clear Progressive Step Guidance */}
      <div id="tutorial-workflow-header" className="flex flex-col lg:flex-row lg:items-center justify-between mb-4 lg:mb-6 shrink-0 px-1 lg:px-2 gap-4 lg:gap-0 h-auto lg:h-[72px]">
        <div>
          <div className="flex justify-center lg:hidden mb-3">
            <div className={`inline-flex text-[12px] font-black tracking-[0.16em] px-3 py-1.5 rounded-full uppercase transition-all duration-500 shadow-sm ${!result ? 'text-white bg-[#0052cc]' : 'text-white bg-[#0052cc]'}`}>
              {!result ? 'Step 01' : 'Step 02'}
            </div>
          </div>
          <div className="flex items-center gap-3 mb-2 lg:mb-2 text-center lg:text-left justify-center lg:justify-start">
            <div className={`hidden lg:inline-flex text-[12px] lg:text-[14px] font-black tracking-widest px-3 lg:px-4 py-1 lg:py-1.5 rounded-full uppercase transition-all duration-500 shadow-sm ${!result ? 'text-white bg-accent' : 'text-white bg-accent'}`}>
              {!result ? 'Step 01' : 'Step 02'}
            </div>
            <h1 className={`font-serif text-[30px] sm:text-[34px] lg:text-[38px] leading-[1.02] tracking-[-0.04em] transition-all duration-500 transition-origin-left ${!result ? 'text-text' : 'text-text'}`}>
              {!result ? 'Ambient Workspace' : 'Review Assessment'}
            </h1>
          </div>
          <p className="text-[15px] lg:text-[15px] font-semibold text-text/80 lg:text-muted text-center lg:text-left mx-auto lg:mx-0 max-w-[34rem] leading-relaxed">
            {!result ? 'Ambient Digital Note-Taking. Provide encounter data via voice or text.' : 'High-fidelity clinical extracts gathered for review.'}
          </p>
        </div>

        <div className="hidden lg:flex flex-1 lg:flex-none">
          {!result ? (
            <div className="text-center lg:text-right">
              <div className="text-[12px] lg:text-[14px] font-black tracking-widest px-3 lg:px-4 py-1 lg:py-1.5 rounded-full uppercase inline-block text-muted bg-off border border-border/20 shadow-sm">
                Step 02 Review
              </div>
              <div className="text-[12px] lg:text-[14px] font-bold mt-2 text-text opacity-70">Clinical Documentation</div>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-6 min-w-0 pr-2"
            >
              <div className="flex flex-col items-start gap-1.5 min-w-0 relative">
                {/* STABILIZED STATUS AREA (Absolute to prevent shift) */}
                <div className="flex flex-col gap-1 px-1">
                  <h3 className="text-text flex items-center gap-4 h-[32px]">
                    <div className="text-[12px] lg:text-[13px] font-black tracking-widest px-3 py-1 rounded-full uppercase text-white bg-accent shadow-sm shrink-0">
                      Step 03
                    </div>
                    <div className="relative min-w-[280px] h-full flex items-center">
                      <AnimatePresence mode="wait">
                        {isSending ? (
                          <motion.span
                            key="sending"
                            initial={{ opacity: 0, x: -5 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 5 }}
                            className="absolute left-0 flex items-center gap-2 text-accent text-[18px] font-black tracking-[-0.02em] whitespace-nowrap"
                          >
                            <Activity size={18} className="animate-pulse" />
                            Emailing Digital Rx...
                          </motion.span>
                        ) : (
                          <motion.span
                            key="idle"
                            initial={{ opacity: 0, x: -5 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 5 }}
                            className="absolute left-0 flex items-center gap-1 text-[18px] lg:text-[22px] font-black tracking-[-0.02em] whitespace-nowrap"
                          >
                            Email to <span className="text-accent ml-1">{selectedCustomer?.name?.split(' ')[0] || 'Patient'}</span>
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </div>
                  </h3>
                </div>

                <motion.div
                  layout
                  className={`flex items-center gap-2 h-[48px] bg-white border rounded-full p-1 shadow-sm transition-all min-w-[320px] lg:min-w-[500px] ${emailTo && !isValidEmail(emailTo) ? 'border-[#ffcccc] bg-[#fffcfc]' :
                    emailTo && isValidEmail(emailTo) ? 'border-accent/40 bg-[#fbfdff]' :
                      'border-border/60'
                    } focus-within:shadow-md focus-within:border-accent/40`}
                >
                  <div className="pl-3 pr-1 text-muted">
                    <Mail size={20} className={emailTo && isValidEmail(emailTo) ? 'text-accent' : ''} />
                  </div>
                  <motion.div layout className="flex-1">
                    <input
                      type="email"
                      placeholder="patient@email.com"
                      className="w-full bg-transparent border-none text-[15px] font-heavy outline-none placeholder:text-muted placeholder:font-medium px-2"
                      value={emailTo}
                      onChange={(e) => {
                        setEmailTo(e.target.value);
                        if (sendError) setSendError(null);
                      }}
                    />
                  </motion.div>
                  <button
                    className={`px-6 h-full rounded-full text-[14px] font-black transition-all flex items-center justify-center cursor-pointer shrink-0 active:scale-95 border-none group ${isSending ? 'bg-accent/40 text-white cursor-wait' :
                      sendSuccess ? 'bg-green text-white cursor-default' :
                        sendError ? 'bg-[#d94040] text-white hover:bg-black' :
                          isValidEmail(emailTo)
                            ? 'bg-accent text-white hover:bg-black hover:scale-[1.03] shadow-[0_8px_20px_rgba(0,82,204,0.2)] hover:shadow-[0_12px_28px_rgba(0,0,0,0.2)]'
                            : 'bg-muted/10 text-muted cursor-not-allowed'
                      }`}
                    onClick={handleSendEmail}
                    disabled={isSending || (sendSuccess && !sendError) || (!isValidEmail(emailTo) && !sendError)}
                  >
                    <AnimatePresence mode="wait">
                      {isSending ? (
                        <motion.div key="sending" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="typing-dot">
                          <span></span><span></span><span></span>
                        </motion.div>
                      ) : sendSuccess ? (
                        <motion.span key="success" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} className="flex items-center gap-2 whitespace-nowrap">
                          <CheckCircle2 size={14} /> Dispatched!
                        </motion.span>
                      ) : sendError ? (
                        <motion.span key="error" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} className="flex items-center gap-2 whitespace-nowrap">
                          <AlertTriangle size={14} /> Retry Dispatch
                        </motion.span>
                      ) : (
                        <motion.span key="idle" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} className="flex items-center gap-2 whitespace-nowrap">
                          Send Email <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </button>
                </motion.div>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {displayedResult && (
        <div className="lg:hidden mb-5">
          <div className="flex items-center bg-off p-1 rounded-full border border-border/40 w-full">
            {[
              { id: 'summary', label: 'Summary' },
              { id: 'prescription', label: 'Prescription' },
              { id: 'billing', label: 'Billing' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setReviewMobileTab(tab.id)}
                className="relative flex-1 px-3 py-3 rounded-full text-[14.5px] font-black text-center tracking-tight"
              >
                <span className={`relative z-10 transition-colors ${reviewMobileTab === tab.id ? 'text-white' : 'text-muted'}`}>
                  {tab.label}
                </span>
                {reviewMobileTab === tab.id && (
                  <motion.div
                    layoutId="mobileReviewSectionTab"
                    className="absolute inset-0 rounded-full bg-black shadow-lg"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.45 }}
                  />
                )}
              </button>
            ))}
          </div>
          <div className="mt-5 pb-4 border-b border-border/40">
            {reviewMobileTab === 'summary' && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-[24px] font-black text-text tracking-tight">Medical Summary</h2>
                  <p className="text-[15px] font-medium text-muted leading-relaxed">AI-generated patient encounter analysis</p>
                </div>
                <div className="flex flex-row items-stretch gap-3">
                  <button
                    onClick={handleGenerate}
                    disabled={isProcessing}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-accent text-white hover:bg-black rounded-full text-[14px] font-black transition-all cursor-pointer group shadow-lg active:scale-95"
                  >
                    {isProcessing ? <div className="typing-dot"><span></span><span></span><span></span></div> : <><RefreshCw size={18} /> Regenerate</>}
                  </button>
                  <button
                    onClick={() => {
                      setResult(null);
                      clearAudioState();
                      setTranscript('');
                      setReviewMobileTab('summary');
                    }}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white border border-border hover:bg-off hover:border-text/20 text-text rounded-full text-[14px] font-black transition-all cursor-pointer group shadow-sm active:scale-95"
                  >
                    <Plus size={18} /> New
                  </button>
                </div>
              </div>
            )}
            {reviewMobileTab === 'prescription' && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-[24px] font-black text-text tracking-tight">Prescription</h2>
                  <p className="text-[15px] font-medium text-muted leading-relaxed">Finalize prescription and clinical notes.</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white border border-border/60 text-black/90 rounded-full transition-all shadow-sm active:scale-95"
                  >
                    {isCopied ? <Check size={18} className="text-green" /> : <Copy size={18} />}
                    {isCopied ? 'Copied' : 'Copy'}
                  </button>
                  <button
                    onClick={handleShareLink}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white border border-border/60 text-black/90 rounded-full transition-all shadow-sm active:scale-95"
                  >
                    {isShared ? <Check size={18} className="text-green" /> : <Share size={18} />}
                    {isShared ? 'Link Copied' : 'Share'}
                  </button>
                  <button
                    onClick={handleDownloadPDF}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-text text-white rounded-full transition-all shadow-lg active:scale-95"
                  >
                    <Download size={18} /> Export
                  </button>
                </div>
              </div>
            )}
            {reviewMobileTab === 'billing' && (
              <div className="space-y-3">
                <div className="flex items-start gap-2.5 min-w-0">
                  <Database size={16} className="text-accent shrink-0 mt-1" />
                  <div className="min-w-0">
                    <h2 className="text-[18px] font-black text-text tracking-tight leading-tight break-words">Billing & Reimbursement Support</h2>
                    <p className="text-[15px] font-medium text-muted leading-relaxed break-words">Review coding support, complexity assessment, and reimbursement suggestions.</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SYMMETRICAL SPLIT LAYOUT (6/6) -> NOW SCROLLABLE WORKSPACE */}
      <div ref={scrollContainerRef} className={`flex-1 overflow-visible ${!displayedResult ? 'lg:overflow-hidden' : 'lg:overflow-y-auto'} custom-scrollbar lg:pr-2 lg:-mr-2 flex flex-col relative`}>

        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-5 flex-1 min-h-0 lg:min-h-full ${result ? 'mb-6' : 'mb-0'}`}>

          {/* LEFT PANE: Input Section & Results */}
          <div className="flex flex-col gap-4 lg:gap-6 h-auto lg:h-full pr-0 min-h-0 relative">
            {/* AMBIENT BREATHING AURA (Phase 2 Upgrade) */}
            <AnimatePresence>
              {isRecording && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{
                    opacity: [0.3, 0.6, 0.3],
                    scale: [1, 1.02, 1],
                  }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -inset-4 bg-accent/5 blur-[40px] rounded-[40px] -z-10 pointer-events-none"
                />
              )}
            </AnimatePresence>

            <motion.div
              id="tutorial-workflow-workspace"
              animate={{
                opacity: 1,
                scale: 1
              }}
              className="flex-1 bg-white border border-border/90 rounded-[32px] p-5 lg:p-6 shadow-[0_8px_30px_rgba(0,0,0,0.02)] flex flex-col min-h-0 overflow-visible lg:overflow-hidden relative z-10 transition-all duration-700"
            >

              <AnimatePresence mode="wait">
                {!displayedResult ? (
                  <motion.div
                    key="step-01"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="flex flex-col flex-1 h-auto lg:h-full"
                  >
                    <AnimatePresence mode="wait">
                      {isProcessing ? (
                        <motion.div
                          key="left-processing"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="flex-1 flex flex-col items-center justify-center text-center p-8 lg:p-12 min-h-[500px] relative overflow-hidden"
                        >
                          {/* SCANNING LINE EFFECT */}
                          <motion.div
                            animate={{ y: ["0%", "500%", "0%"] }}
                            transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
                            className="absolute top-0 left-0 right-0 h-[1px] bg-accent/20 z-20 pointer-events-none shadow-[0_0_15px_rgba(0,82,204,0.3)]"
                          />

                          {/* INSTITUTIONAL STATUS INDICATOR */}
                          <div className="absolute top-8 left-1/2 -translate-x-1/2">
                            <SecureStatusBadge label="Clinical Synthesis Engine Active" status="info" />
                          </div>

                          <div className="mb-12 relative">
                            <NeuralOrb progress={processingStep * 25 + 12} isProcessing={true} />

                            {/* DATA PULSE RING */}
                            <motion.div
                              animate={{ scale: [1, 1.4, 1], opacity: [0, 0.2, 0] }}
                              transition={{ duration: 2, repeat: Infinity }}
                              className="absolute inset-0 border-2 border-accent rounded-full -m-4"
                            />
                          </div>

                          <div className="flex flex-col items-center gap-4">
                            <h2 className="text-[32px] font-black text-text tracking-tighter uppercase mb-0">Synthesizing</h2>

                            <div className="h-8 flex items-center justify-center">
                              <AnimatePresence mode="wait">
                                <motion.div
                                  key={reasoningStepIdx}
                                  initial={{ opacity: 0, y: 8 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  exit={{ opacity: 0, y: -8 }}
                                  className="flex items-center gap-3 px-4 py-1.5 bg-accent/5 rounded-full border border-accent/10"
                                >
                                  <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                                  <span className="text-[11px] font-black text-accent uppercase tracking-[0.2em]">
                                    {reasoningSteps[reasoningStepIdx]}
                                  </span>
                                </motion.div>
                              </AnimatePresence>
                            </div>

                            <p className="text-[14px] font-medium text-muted/50 max-w-[340px] mt-4 leading-relaxed italic">
                              Executing high-fidelity clinical synthesis protocols against patient encounter stream.
                            </p>
                          </div>

                          <div className="mt-16 w-full max-w-[280px] relative">
                            <div className="flex justify-between items-end mb-4 px-1">
                              <div className="flex flex-col items-start">
                                <span className="text-[9px] font-black text-muted/30 uppercase tracking-[0.2em] mb-1">Engine Load</span>
                                <span className="text-[11px] font-black text-text uppercase tracking-widest">Clinical-L2</span>
                              </div>
                              <div className="text-right">
                                <span className="text-[20px] font-black text-accent font-mono tracking-tighter">
                                  {Math.min(99, Math.round(processingStep * 25 + (reasoningStepIdx * 5) + 12))}%
                                </span>
                              </div>
                            </div>
                            <SegmentedProgress progress={processingStep * 25 + (reasoningStepIdx * 5) + 12} segments={20} />
                          </div>
                        </motion.div>
                      ) : (
                        <div className="flex flex-col flex-1">
                          {/* HARDWARE CONTROL BEZEL */}
                          <div className="flex justify-center mb-6 relative z-50 w-full">
                            <div className="flex items-center p-1.5 bg-off/60 rounded-full border border-border/50 shadow-sm backdrop-blur-md transition-all">

                              {/* Unified Sliding Input Toggle */}
                              <div className="flex items-center relative">
                                {['audio', 'record', 'text'].map(type => (
                                  <button
                                    key={type}
                                    className={`relative w-[130px] flex items-center justify-center gap-2.5 h-[44px] rounded-full text-[14px] font-black tracking-tight cursor-pointer transition-all duration-300 capitalize z-10 ${inputType === type ? 'text-white' : 'text-muted/70 hover:text-text hover:bg-white/60'}`}
                                    onClick={() => setInputType(type)}
                                  >
                                    <span className="relative z-20 flex items-center gap-2">
                                      {type === 'audio' && <Upload size={17} strokeWidth={2} />}
                                      {type === 'record' && <Mic size={18} strokeWidth={2} />}
                                      {type === 'text' && <AlignLeft size={17} strokeWidth={2} />}
                                      {type === 'audio' ? 'File' : type}
                                    </span>
                                    {inputType === type && (
                                      <motion.div
                                        layoutId="activeInputTab"
                                        className="absolute inset-0 bg-accent rounded-full shadow-md shadow-accent/20"
                                        transition={{ type: "spring", bounce: 0.2, duration: 0.5 }}
                                      />
                                    )}
                                  </button>
                                ))}
                              </div>

                              {/* Divider */}
                              <div className="w-[1px] h-5 bg-border/60 mx-1.5" />

                              {/* Hardware Language Selector */}
                              <div ref={langRef} className="relative group">
                                <div
                                  onClick={() => setIsLangOpen(!isLangOpen)}
                                  className="flex items-center justify-center gap-2.5 px-5 h-[44px] rounded-full min-w-[145px] cursor-pointer hover:bg-white/60 transition-all"
                                >
                                  <Languages size={17} strokeWidth={2} className="text-accent" />
                                  <span className="text-md font-black tracking-tight text-text">
                                    {currentLang.label}
                                  </span>
                                  <motion.div animate={{ rotate: isLangOpen ? 180 : 0 }} transition={{ duration: 0.3 }}>
                                    <ChevronDown size={15} strokeWidth={3} className="text-muted/50 group-hover:text-accent transition-colors" />
                                  </motion.div>
                                </div>

                                <AnimatePresence>
                                  {isLangOpen && (
                                    <motion.div
                                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                      animate={{ opacity: 1, y: 0, scale: 1 }}
                                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                                      className="absolute top-[calc(100%+12px)] right-0 lg:left-1/6 lg:-translate-x-1/2 w-[260px] bg-white rounded-[20px] border border-border/40 shadow-[0_24px_48px_-12px_rgba(0,0,0,0.12)] z-[100] overflow-hidden p-1.5 origin-top"
                                    >
                                      <div className="px-3 py-2.5 border-b border-border/10 mb-1 flex items-center justify-between">
                                        <div className="text-[10px] font-bold uppercase tracking-widest text-muted/60">Select Region</div>
                                        <Languages size={14} className="text-accent/50" />
                                      </div>
                                      <div className="max-h-[320px] overflow-y-auto custom-scrollbar pr-1">
                                        <div className="grid grid-cols-1 gap-0.5">
                                          {languages.map((lang) => (
                                            <button
                                              key={lang.code}
                                              onClick={() => {
                                                setLanguage(lang.code);
                                                setIsLangOpen(false);
                                              }}
                                              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-[14px] transition-all duration-200 group/item ${language === lang.code
                                                ? 'bg-accent/8'
                                                : 'hover:bg-accent/5 hover:scale-[1.01] active:scale-[0.99]'
                                                }`}
                                            >
                                              <span className={`text-[14px] font-bold ${language === lang.code ? 'text-accent' : 'text-text/80 group-hover/item:text-text'}`}>
                                                {lang.label}
                                              </span>
                                              <div className="flex items-center gap-2.5">
                                                <span className={`text-[14px] font-medium ${language === lang.code ? 'text-accent/80' : 'text-muted/80 group-hover/item:text-text/50'}`}>
                                                  {lang.native}
                                                </span>
                                                {language === lang.code && (
                                                  <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
                                                    <Check size={14} strokeWidth={3} className="text-accent" />
                                                  </motion.div>
                                                )}
                                              </div>
                                            </button>
                                          ))}
                                        </div>
                                      </div>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </div>
                            </div>
                          </div>

                          {/* Focal Input UI - Unified Border Container */}
                          <div className="relative z-10 px-0 h-[26rem] sm:h-[28rem] lg:h-[540px] mb-4">
                            <motion.div
                              className={`h-full rounded-[28px] transition-all duration-500 border-2 overflow-hidden flex flex-col relative group ${inputType === 'audio'
                                ? 'border-dashed border-border/80 bg-off/5'
                                : 'border-solid border-border/60 bg-white shadow-sm'
                                }`}
                              animate={{
                                borderColor: inputType === 'audio' ? 'rgba(0,0,0,0.08)' : 'rgba(0,0,0,0.1)',
                              }}
                            >
                              <AnimatePresence mode="wait">
                                {inputType === 'audio' ? (
                                  <motion.div
                                    key="audio"
                                    initial={{ opacity: 0, scale: 0.98 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.98 }}
                                    transition={{ duration: 0.3, ease: "easeOut" }}
                                    className="h-full w-full"
                                  >
                                    <div
                                      className={`h-full min-h-[340px] lg:min-h-0 flex flex-col items-center justify-center cursor-pointer transition-all font-sans group relative ${isDragging ? 'bg-accent-light/50 scale-[1.01]' : 'hover:bg-accent-light/30'}`}
                                      onClick={() => fileInputRef.current?.click()}
                                      onDragOver={handleDragOver}
                                      onDragLeave={handleDragLeave}
                                      onDrop={handleDrop}
                                    >
                                      <input type="file" ref={fileInputRef} className="hidden" accept="audio/*" onChange={(e) => handleFileSelect(e.target.files[0])} />

                                      <AnimatePresence mode="wait">
                                        {isUploading ? (
                                          <motion.div
                                            key="uploading"
                                            initial={{ opacity: 0, y: 10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            exit={{ opacity: 0, scale: 0.9 }}
                                            className="flex flex-col items-center justify-center h-full w-full px-10 py-12 relative overflow-hidden"
                                          >
                                            {/* Ambient Background Glows */}
                                            <div className="absolute top-1/4 -left-10 w-40 h-40 bg-accent/5 blur-3xl rounded-full" />
                                            <div className="absolute bottom-1/4 -right-10 w-40 h-40 bg-accent/5 blur-3xl rounded-full" />

                                            {/* Institutional Centerpiece */}
                                            <div className="mb-10 relative">
                                              <NeuralOrb progress={uploadProgress} isProcessing={true} />
                                            </div>

                                            {/* High-Fidelity Progress System */}
                                            <div className="w-full max-w-[320px] flex flex-col items-center gap-6 relative z-10">
                                              <SegmentedProgress progress={uploadProgress} segments={24} />

                                              <div className="flex flex-col items-center gap-2">
                                                <AnimatePresence mode="wait">
                                                  <motion.div
                                                    key={uploadProgress < 30 ? "v" : uploadProgress < 70 ? "f" : uploadProgress < 95 ? "p" : "s"}
                                                    initial={{ opacity: 0, y: 5, filter: "blur(4px)" }}
                                                    animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                                                    exit={{ opacity: 0, y: -5, filter: "blur(4px)" }}
                                                    className="text-[11px] font-black uppercase tracking-[0.25em] text-accent/80"
                                                  >
                                                    {uploadProgress < 30 ? "Validating Waveform" : uploadProgress < 70 ? "Filtering Background Noise" : uploadProgress < 95 ? "Preparing AI Context" : "Institutional Handshake"}
                                                  </motion.div>
                                                </AnimatePresence>

                                                <div className="flex items-baseline gap-1">
                                                  <span className="text-[20px] font-black text-text font-mono tracking-tight">
                                                    {Math.round(uploadProgress)}
                                                  </span>
                                                  <span className="text-[12px] font-bold text-muted/60 uppercase tracking-widest">% Complete</span>
                                                </div>
                                              </div>
                                            </div>

                                            {/* Subtle Data Stream Particles (Decoration) */}
                                            <div className="absolute inset-0 pointer-events-none opacity-20">
                                              {Array.from({ length: 6 }).map((_, i) => (
                                                <motion.div
                                                  key={i}
                                                  initial={{ x: Math.random() * 400 - 200, y: 400, opacity: 0 }}
                                                  animate={{ y: -100, opacity: [0, 1, 0] }}
                                                  transition={{
                                                    duration: 2 + Math.random() * 2,
                                                    repeat: Infinity,
                                                    delay: i * 0.4,
                                                    ease: "linear"
                                                  }}
                                                  className="absolute w-1 h-1 bg-accent rounded-full"
                                                  style={{ left: `${10 + i * 15}%` }}
                                                />
                                              ))}
                                            </div>
                                          </motion.div>
                                        ) : audioFile && audioFile.name !== 'live_recording.wav' && isVerified ? (
                                          <motion.div
                                            key="file-card"
                                            initial={{ opacity: 0, scale: 0.98, filter: "blur(8px)" }}
                                            animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                                            exit={{ opacity: 0, scale: 0.95, filter: "blur(8px)" }}
                                            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                                            className="w-full h-full min-h-[340px] lg:min-h-0 p-8 flex flex-col justify-center relative group overflow-hidden"
                                          >
                                            {/* Precision Background Pattern */}
                                            <div className="absolute inset-0 opacity-[0.03] pointer-events-none"
                                              style={{ backgroundImage: 'radial-gradient(circle, #004eb3 1px, transparent 1px)', backgroundSize: '24px 24px' }}
                                            />

                                            <div className="absolute top-6 right-6 z-20">
                                              <button
                                                onClick={(e) => {
                                                  e.stopPropagation();
                                                  clearAudioState();
                                                }}
                                                className="inline-flex items-center gap-2 px-3 py-1.5 text-muted/60 hover:text-[#d94040] hover:bg-red-50/80 rounded-xl transition-all cursor-pointer border border-transparent hover:border-red-100 group/x text-[11px] font-black uppercase tracking-wider"
                                              >
                                                <X size={14} className="group-hover/x:rotate-90 transition-transform" />
                                                Clear Intake
                                              </button>
                                            </div>

                                            <div className="relative z-10 flex flex-col gap-8">
                                              {/* File Header Section */}
                                              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                                                <div className="w-20 h-20 bg-accent/5 text-accent rounded-[24px] flex items-center justify-center shadow-inner border border-accent/10 relative overflow-hidden shrink-0 group-hover:scale-105 transition-transform duration-500">
                                                  <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent" />
                                                  <FileAudio size={36} className="relative z-10" />
                                                </div>

                                                <div className="text-center sm:text-left flex-1 min-w-0 flex flex-col gap-3">
                                                  <div className="text-[20px] lg:text-[24px] font-black text-text truncate uppercase tracking-tight leading-tight">
                                                    {audioFile.name}
                                                  </div>

                                                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4">
                                                    <div className="flex items-center gap-2 px-2.5 py-1 bg-off/80 backdrop-blur-sm rounded-md border border-border/40 text-[11px] font-black text-muted/80 uppercase tracking-widest shadow-sm">
                                                      <Database size={12} className="text-accent/40" />
                                                      {(audioFile.size / 1024 / 1024).toFixed(2)} MB
                                                    </div>
                                                    <SecureStatusBadge label="Clinical Intake Secured" status="success" />
                                                  </div>
                                                </div>
                                              </div>

                                              {/* HIGH-FIDELITY CUSTOM PLAYER */}
                                              {audioFile.preview && (
                                                <motion.div
                                                  initial={{ y: 20, opacity: 0 }}
                                                  animate={{ y: 0, opacity: 1 }}
                                                  transition={{ delay: 0.2 }}
                                                  className="w-full"
                                                >
                                                  <ClinicalAudioPlayer src={audioFile.preview} />
                                                </motion.div>
                                              )}

                                              {/* Institutional Footnote */}
                                              <div className="flex items-center justify-center sm:justify-start gap-2 text-[10px] font-bold text-muted/40 uppercase tracking-[0.2em]">
                                                <ClipboardCheck size={12} /> HIPAA COMPLIANT DATA ENCRYPTION ACTIVE
                                              </div>
                                            </div>
                                          </motion.div>
                                        ) : (
                                          <motion.div
                                            key="dropzone"
                                            initial={{ opacity: 0 }}
                                            animate={{ opacity: 1 }}
                                            exit={{ opacity: 0 }}
                                            className="z-10 flex flex-col items-center justify-center relative py-10 px-6 w-full h-full min-h-[340px] lg:min-h-0"
                                          >
                                            {/* PRECISION DOT GRID BG */}
                                            <div className="text-[24px] font-black text-text mb-3 tracking-tight">Clinical Encounter Intake</div>
                                            <p className="text-[15px] font-medium text-muted/80 flex items-center gap-2 mb-10">
                                              Drop audio file here or <span className="text-accent font-bold cursor-pointer hover:underline underline-offset-4 decoration-accent/40">browse system</span>
                                            </p>

                                            <div className="relative group/drop mb-10">
                                              <motion.div
                                                animate={{
                                                  scale: isDragging ? 1.1 : 1,
                                                  boxShadow: isDragging ? '0 20px 40px rgba(0,82,204,0.2)' : '0 12px 32px rgba(0,0,0,0.06)'
                                                }}
                                                className={`w-24 h-24 rounded-[32px] flex items-center justify-center transition-all duration-500 relative z-10 border-2 ${isDragging ? 'bg-accent border-accent text-white' : 'bg-white border-border/60 text-accent group-hover/drop:border-accent/40 group-hover/drop:bg-accent/[0.02]'}`}
                                              >
                                                <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent rounded-[32px] pointer-events-none" />
                                                {isDragging ? <Activity size={36} strokeWidth={2.5} /> : <Upload size={36} strokeWidth={2.5} className="group-hover/drop:-translate-y-1 transition-transform" />}

                                                {isDragging && (
                                                  <motion.div
                                                    animate={{ scale: [1, 1.8], opacity: [0.4, 0] }}
                                                    transition={{ duration: 1.5, repeat: Infinity }}
                                                    className="absolute inset-0 bg-accent rounded-[32px] -z-10"
                                                  />
                                                )}
                                              </motion.div>
                                            </div>

                                            <div className="mt-8 flex flex-col items-center gap-6 w-full">
                                              <div className="flex gap-3">
                                                <span className="flex items-center gap-1.5 px-4 py-1.5 bg-white rounded-xl text-[10px] font-black text-text/60 shadow-sm border border-border/40 uppercase tracking-[0.15em]">
                                                  <Sparkles size={12} className="text-accent" /> AI-SUPPORTED
                                                </span>
                                                <span className="flex items-center gap-1.5 px-4 py-1.5 bg-white rounded-xl text-[10px] font-black text-text/60 shadow-sm border border-border/40 uppercase tracking-[0.15em]">
                                                  <CheckCircle2 size={12} className="text-green" /> ENCRYPTION ACTIVE
                                                </span>
                                              </div>

                                              {/* Clinical Intelligence Feature Matrix */}
                                              <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 w-full mt-4 pt-8 border-t border-border/10 px-8">
                                                {[
                                                  { icon: <Activity size={20} />, label: "Vital Signs", detail: "AI Extract" },
                                                  { icon: <ClipboardList size={20} />, label: "Care Plans", detail: "Draft Generation" },
                                                  { icon: <Stethoscope size={20} />, label: "Diagnosis", detail: "ICD-10 Mapping" },
                                                  { icon: <Clock size={20} />, label: "Timestamps", detail: "Event Logging" }
                                                ].map((feat, idx) => (
                                                  <div key={idx} className="flex flex-col items-center text-center group/feat">
                                                    <div className="w-12 h-12 rounded-2xl bg-off/50 flex items-center justify-center text-muted group-hover/feat:bg-accent/5 group-hover/feat:text-accent transition-all mb-0">
                                                      {feat.icon}
                                                    </div>
                                                    <div className="text-[12px] font-black text-text/80 uppercase mb-1">{feat.label}</div>
                                                    <div className="text-[10px] font-bold text-muted/60 uppercase">{feat.detail}</div>
                                                  </div>
                                                ))}
                                              </div>
                                            </div>
                                          </motion.div>
                                        )}
                                      </AnimatePresence>
                                    </div>
                                  </motion.div>
                                ) : inputType === 'record' ? (
                                  <motion.div
                                    key="record"
                                    initial={{ opacity: 0, scale: 0.98 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.98 }}
                                    transition={{ duration: 0.3, ease: "easeOut" }}
                                    className="h-full min-h-[340px] lg:min-h-0 w-full flex items-center justify-center p-4"
                                  >
                                    <AnimatePresence mode="wait">
                                      {isRecording ? (
                                        <motion.div
                                          key="recording"
                                          initial={{ opacity: 0, y: 10 }}
                                          animate={{ opacity: 1, y: 0 }}
                                          exit={{ opacity: 0, scale: 1.1 }}
                                          className="flex flex-col items-center w-full min-h-[340px] lg:min-h-0 bg-white/40 backdrop-blur-md rounded-[32px] p-4 lg:p-5 relative overflow-hidden justify-center"
                                        >
                                          {/* Ambient Glow Line */}

                                          <div className="w-full flex items-center justify-between mb-24">
                                            <div className="flex flex-col gap-4">
                                              <CaptureStatus isActive={true} />
                                              <SignalMeter level={92} />
                                            </div>

                                            <div className="flex flex-col items-end gap-1">
                                              <span className="text-[10px] font-black text-muted/40 uppercase tracking-[0.25em]">Elapsed Session</span>
                                              <div className="text-[28px] font-mono font-black text-text tracking-[-0.05em] leading-none">
                                                {formatDuration(recordingDuration)}
                                              </div>
                                            </div>
                                          </div>

                                          {/* Professional Waveform Visualization */}
                                          <div className="w-full mb-12 relative">
                                            <ClinicalWaveform isActive={true} color="accent" />
                                            <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-transparent to-white/10 pointer-events-none" />
                                          </div>

                                          <div className="flex flex-col items-center gap-6">
                                            <motion.button
                                              whileHover={{ scale: 1.05 }}
                                              whileTap={{ scale: 0.95 }}
                                              onClick={stopRecording}
                                              className="w-18 h-18 bg-accent text-white rounded-full flex items-center justify-center shadow-[0_20px_40px_rgba(0,0,0,0.2)] cursor-pointer hover:bg-black transition-all group/stop relative"
                                            >
                                              <div className="absolute inset-0 rounded-full border border-black/5" />
                                              <Square size={24} fill="white" className="group-hover/stop:scale-110 transition-transform relative z-10" />
                                            </motion.button>
                                            <span className="text-[11px] font-black text-muted/60 uppercase tracking-[0.3em]">End Capture Session</span>
                                          </div>
                                        </motion.div>
                                      ) : audioFile && audioFile.name === 'live_recording.wav' ? (
                                        <motion.div
                                          key="captured"
                                          initial={{ opacity: 0, scale: 0.98, filter: "blur(8px)" }}
                                          animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                                          exit={{ opacity: 0, scale: 0.95, filter: "blur(8px)" }}
                                          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                                          className="w-full h-full min-h-[340px] lg:min-h-0 p-8 flex flex-col justify-center relative group overflow-hidden"
                                        >
                                          {/* Precision Background Pattern */}
                                          <div className="absolute inset-0 opacity-[0.03] pointer-events-none"
                                            style={{ backgroundImage: 'radial-gradient(circle, #004eb3 1px, transparent 1px)', backgroundSize: '24px 24px' }}
                                          />

                                          <div className="absolute top-6 right-6 z-20">
                                            <button
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                clearAudioState();
                                              }}
                                              className="inline-flex items-center gap-2 px-3 py-1.5 text-muted/60 hover:text-[#d94040] hover:bg-red-50/80 rounded-xl transition-all cursor-pointer border border-transparent hover:border-red-100 group/x text-[11px] font-black uppercase tracking-wider"
                                            >
                                              <X size={14} className="group-hover/x:rotate-90 transition-transform" />
                                              Discard
                                            </button>
                                          </div>

                                          <div className="relative z-10 flex flex-col gap-8">
                                            {/* File Header Section */}
                                            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                                              <div className="w-20 h-20 bg-green/5 text-green rounded-[24px] flex items-center justify-center shadow-inner border border-green/10 relative overflow-hidden shrink-0 group-hover:scale-105 transition-transform duration-500">
                                                <div className="absolute inset-0 bg-gradient-to-br from-green/10 to-transparent" />
                                                <Mic size={36} className="relative z-10" />
                                              </div>

                                              <div className="text-center sm:text-left flex-1 min-w-0 flex flex-col gap-3">
                                                <div className="text-[20px] lg:text-[24px] font-black text-text uppercase tracking-tight leading-tight">
                                                  Encounter Captured
                                                </div>

                                                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4">
                                                  <div className="flex items-center gap-2 px-2.5 py-1 bg-off/80 backdrop-blur-sm rounded-md border border-border/40 text-[11px] font-black text-muted/80 uppercase tracking-widest shadow-sm">
                                                    <Clock size={12} className="text-accent/40" />
                                                    {formatDuration(recordingDuration)}
                                                  </div>
                                                  <SecureStatusBadge label="High Fidelity Secured" status="success" />
                                                </div>
                                              </div>
                                            </div>

                                            {/* CUSTOM PLAYER */}
                                            {audioFile.preview && (
                                              <motion.div
                                                initial={{ y: 20, opacity: 0 }}
                                                animate={{ y: 0, opacity: 1 }}
                                                transition={{ delay: 0.2 }}
                                                className="w-full"
                                              >
                                                <ClinicalAudioPlayer src={audioFile.preview} />
                                              </motion.div>
                                            )}

                                            {/* Actions & Footnote */}
                                            <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                                              <div className="flex items-center gap-2 text-[10px] font-bold text-muted/40 uppercase tracking-[0.2em]">
                                                <ClipboardCheck size={12} /> ENCRYPTED CLINICAL HANDSHAKE READY
                                              </div>

                                              <button
                                                onClick={startRecording}
                                                className="px-6 py-2 bg-white/40 backdrop-blur-md border border-border/20 rounded-xl text-[10px] font-black text-muted/60 hover:text-red-500 hover:border-red-100 hover:bg-red-50/50 transition-all cursor-pointer uppercase tracking-[0.2em] shadow-sm active:scale-95"
                                              >
                                                Abandon & Re-Record
                                              </button>
                                            </div>
                                          </div>
                                        </motion.div>
                                      ) : (
                                        <motion.div
                                          key="idle"
                                          initial={{ opacity: 0 }}
                                          animate={{ opacity: 1 }}
                                          exit={{ opacity: 0 }}
                                          className="flex flex-col items-center justify-center px-6 relative w-full h-full min-h-[340px] lg:min-h-0"
                                        >

                                          <div className="text-[22px] font-black text-text mb-2 tracking-tight">Active Encounter Intake</div>
                                          <div className="text-[14px] font-bold text-muted text-center leading-relaxed mb-10">
                                            Real-time capture with automated transcription & noise suppression.
                                          </div>

                                          <div className="relative mb-10">
                                            <motion.div
                                              animate={{ scale: [1, 1.15, 1], opacity: [0.2, 0.4, 0.2] }}
                                              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                                              className="absolute -inset-10 bg-accent/20 rounded-full blur-3xl"
                                            />
                                            <button
                                              onClick={startRecording}
                                              className="w-19 h-19 bg-text text-white rounded-full flex items-center justify-center hover:scale-110 transition-all duration-500 shadow-[0_20px_50px_rgba(0,0,0,0.15)] hover:bg-black cursor-pointer relative z-10 group"
                                            >
                                              <div className="absolute inset-0 bg-accent/10 rounded-full animate-ping scale-125 opacity-20 group-hover:opacity-40 transition-opacity"></div>
                                              <Mic size={28} className="relative z-10 transition-transform" />
                                            </button>
                                          </div>

                                          <div className="flex flex-col items-center gap-6 w-full">
                                            <div className="flex gap-4">
                                              <span className="px-3 py-1 bg-off rounded-lg text-[10px] font-black text-muted uppercase border border-border/10 tracking-[0.1em]">STUDIO QUALITY</span>
                                              <span className="px-3 py-1 bg-off rounded-lg text-[10px] font-black text-muted uppercase border border-border/10 tracking-[0.1em]">HIPAA SECURE</span>
                                            </div>

                                            {/* Intelligence Markers */}
                                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 w-full mt-4 pt-8 border-t border-border/10 px-8">
                                              {[
                                                { icon: <Activity size={20} />, label: "Biometric ID", detail: "Speaker Diary" },
                                                { icon: <ClipboardList size={20} />, label: "Med-Context", detail: "NER Extraction" },
                                                { icon: <Stethoscope size={20} />, label: "Clean Feed", detail: "Noise Cancel" },
                                                { icon: <Clock size={20} />, label: "Sync-Cloud", detail: "Instant Save" }
                                              ].map((feat, idx) => (
                                                <div key={idx} className="flex flex-col items-center text-center group/feat">
                                                  <div className="w-12 h-12 rounded-2xl bg-off/50 flex items-center justify-center text-muted group-hover/feat:bg-accent/5 group-hover/feat:text-accent transition-all mb-0">
                                                    {feat.icon}
                                                  </div>
                                                  <div className="text-[12px] font-black text-text/80 uppercase mb-1">{feat.label}</div>
                                                  <div className="text-[10px] font-bold text-muted/60 uppercase">{feat.detail}</div>
                                                </div>
                                              ))}
                                            </div>
                                          </div>
                                        </motion.div>
                                      )}
                                    </AnimatePresence>
                                  </motion.div>
                                ) : (
                                  <motion.div
                                    key="text"
                                    initial={{ opacity: 0, scale: 0.98 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.98 }}
                                    transition={{ duration: 0.3, ease: "easeOut" }}
                                    className="h-full w-full relative flex flex-col group/text"
                                  >
                                    {/* BLUEPRINT PATTERN BG */}
                                    <div className="absolute inset-0 opacity-[0.02] pointer-events-none"
                                      style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, #000 1px, transparent 0)', backgroundSize: '16px 16px' }} />

                                    <textarea
                                      className="w-full h-full border-none bg-off/20 p-4 text-[17px] leading-[1.6] outline-none focus:bg-white/50 transition-all resize-none placeholder-muted/40 font-sans shadow-inner relative z-10"
                                      placeholder="Synthesize patient encounter notes or paste raw clinical transcripts here..."
                                      value={transcript}
                                      onChange={(e) => setTranscript(e.target.value)}
                                    />

                                    {/* INTEGRATED CONTROLS */}
                                    <div className="hidden lg:flex absolute bottom-4 right-6 items-center justify-start z-20 pointer-events-none">
                                      <motion.div layout className="flex items-center gap-3">
                                        <AnimatePresence mode="popLayout">
                                          {transcript.length > 0 && (
                                            <motion.button
                                              layout="position"
                                              initial={{ opacity: 0, x: -10 }}
                                              animate={{ opacity: 1, x: 0 }}
                                              exit={{ opacity: 0, x: -10 }}
                                              onClick={() => setTranscript('')}
                                              className="pointer-events-auto p-2 bg-white border border-border/10 text-muted hover:text-[#d94040] hover:bg-red-50 rounded-lg shadow-sm transition-all"
                                            >
                                              <X size={14} />
                                            </motion.button>
                                          )}
                                        </AnimatePresence>
                                        <motion.button
                                          layout="position"
                                          onClick={async () => {
                                            const text = await navigator.clipboard.readText();
                                            setTranscript(prev => prev + text);
                                          }}
                                          className="pointer-events-auto p-2 bg-white border border-border/10 text-accent hover:bg-accent-light rounded-lg shadow-sm transition-all flex items-center gap-2 text-[10px] font-black uppercase"
                                        >
                                          <Copy size={13} /> Paste
                                        </motion.button>
                                      </motion.div>
                                    </div>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </motion.div>
                          </div>
                        </div>
                      )}
                    </AnimatePresence>

                    {/* Action Bar for Step 01 - Institutional Grade Action Center */}
                    <div className="mt-0 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-6 relative z-10 pt-8 border-t border-border/40">
                      <div className="flex items-center gap-4">
                        {!selectedCustomer ? (
                          <motion.div
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-[#fff0f0]/60 backdrop-blur-sm border border-[#fdd] text-[#d94040] shadow-sm"
                          >
                            <div className="relative flex">
                              <div className="absolute inset-0 bg-[#d94040]/20 rounded-full animate-ping" />
                              <AlertTriangle size={15} className="relative z-10" />
                            </div>
                            <span className="text-[11px] font-black tracking-[0.12em] uppercase">Patient Required</span>
                          </motion.div>
                        ) : (
                          <motion.div
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-accent/5 backdrop-blur-sm border border-accent/10 text-accent shadow-sm"
                          >
                            <div className="relative flex">
                              <div className="absolute inset-0 bg-accent/20 rounded-full animate-ping" />
                              <div className="w-2.5 h-2.5 rounded-full bg-accent relative z-10" />
                            </div>
                            <span className="text-[11px] font-black tracking-[0.12em] uppercase">Ready for Clinical Intake</span>
                          </motion.div>
                        )}
                      </div>

                      <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-4">
                        <button
                          className={`group relative w-full lg:w-auto px-10 h-[56px] rounded-full text-[15px] font-black transition-all duration-500 cursor-pointer overflow-hidden shadow-[0_20px_40px_rgba(0,0,0,0.12)] active:scale-[0.98] min-w-[260px] flex items-center justify-center ${isProcessing
                            ? 'bg-[#d94040] text-white hover:bg-black'
                            : 'bg-text text-white disabled:opacity-30 disabled:grayscale'
                            }`}
                          onClick={isProcessing ? handleStopSummary : handleGenerate}
                          disabled={!isProcessing && (isUploading || (!audioFile && !transcript && !encounterToLoad) || !selectedCustomer)}
                        >
                          {/* Interactive Sheen Effect */}
                          <div className="absolute inset-0 w-1/2 h-full bg-white/10 -skew-x-[25deg] -translate-x-[200%] group-hover:translate-x-[250%] transition-transform duration-1000 ease-in-out" />

                          {isProcessing ? (
                            <div className="relative z-10 flex items-center gap-4">
                              <div className="typing-dot scale-110">
                                <span className="!bg-white"></span>
                                <span className="!bg-white"></span>
                                <span className="!bg-white"></span>
                              </div>
                              <span className="tracking-tight uppercase">Stop Analysis</span>
                              <Square size={14} className="fill-current" />
                            </div>
                          ) : (
                            <div className="relative z-10 flex items-center gap-3">
                              <span className="tracking-tight">Generate Medical Summary</span>
                              <ArrowRight size={18} className="group-hover:translate-x-1.5 transition-transform duration-300" />
                            </div>
                          )}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="step-02"
                    initial={{ opacity: 0, y: 40 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ type: "spring", damping: 20, stiffness: 100 }}
                    className="flex flex-col h-auto lg:h-full min-h-0 flex-1 overflow-visible lg:overflow-hidden"
                  >
                    {/* Institutional Command Header */}
                    <div id="tutorial-workflow-review" className="flex flex-col gap-5 mb-4 pb-5 border-b border-border/40 shrink-0">
                      {/* Primary Control Row */}
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-accent/[0.03] border border-accent/10 flex items-center justify-center shadow-sm">
                            <FileText size={20} className="text-accent" />
                          </div>
                          <div className="flex flex-col">
                            <h2 className="text-[22px] font-black text-text tracking-tight leading-none">Medical Summary</h2>
                            <p className="text-[12px] font-medium text-muted/60 mt-1">Institutional Clinical Intelligence Report</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={handleGenerate}
                            disabled={isProcessing}
                            className={`relative flex items-center justify-center gap-2.5 px-5 py-2.5 rounded-full text-[13px] font-black uppercase tracking-wider transition-all duration-500 active:scale-95 group overflow-hidden ${
                              isProcessing 
                                ? 'bg-accent/5 text-accent border border-accent/20 cursor-wait min-w-[140px]' 
                                : 'bg-accent text-white hover:bg-black shadow-md border border-accent hover:border-black'
                            }`}
                          >
                            {isProcessing ? (
                              <div className="flex items-center gap-2.5">
                                <div className="relative w-4 h-4">
                                  <div className="absolute inset-0 border-2 border-accent/10 rounded-full" />
                                  <div className="absolute inset-0 border-2 border-accent border-t-transparent rounded-full animate-spin" />
                                  <div className="absolute inset-1 bg-accent/20 rounded-full animate-pulse" />
                                </div>
                                <span className="animate-pulse">Synthesizing</span>
                              </div>
                            ) : (
                              <>
                                <RefreshCw size={15} className="group-hover:rotate-180 transition-transform duration-700" />
                                <span>Regenerate</span>
                              </>
                            )}
                          </button>

                          <button
                            onClick={() => {
                              setResult(null);
                              clearAudioState();
                              setTranscript('');
                              setReviewMobileTab('summary');
                            }}
                            className="flex items-center justify-center gap-2 px-5 py-2.5 bg-white hover:bg-off border border-border/60 hover:border-text/20 text-text/60 hover:text-text rounded-full text-[13px] font-black uppercase tracking-wider transition-all duration-300 active:scale-95 group"
                          >
                            <Plus size={15} className="group-hover:rotate-90 transition-transform" />
                            <span>New</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className={`flex-col gap-0 flex-1 overflow-visible lg:overflow-y-auto custom-scrollbar lg:pr-2 pb-10 min-h-0 ${reviewMobileTab === 'summary' ? 'flex' : 'hidden lg:flex'}`}>
                      {/* Harmonized Medical Summary Content - Embedded View */}
                      {/* Industry Standard SOAP Note View */}
                      <div className="flex flex-col gap-4">
                        {displayedResult.patient_summary && (
                          <motion.div
                            initial={{ opacity: 0, y: -5 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="mb-4 relative group/narrative"
                          >
                            <div className="flex items-center gap-2 mb-2">
                              <Sparkles size={14} className="text-accent" />
                              <div className="text-[10px] font-black text-accent uppercase tracking-[0.2em]">Clinical Narrative</div>
                              <div className="h-[1px] flex-1 bg-border/40 ml-2" />
                              <button
                                onClick={() => {
                                  const rawText = highlightClinicalTerms(translateMedicalTerms(displayedResult.patient_summary), true);
                                  navigator.clipboard.writeText(rawText);
                                  setIsCopied(true);
                                  setTimeout(() => setIsCopied(false), 2000);
                                }}
                                className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-accent/20 bg-accent/[0.03] text-[10px] font-black text-accent hover:bg-accent hover:text-white transition-all shadow-sm group/copy"
                              >
                                {isCopied ? <Check size={12} /> : <Copy size={12} className="group-hover/copy:scale-110 transition-transform" />}
                                {isCopied ? 'Copied' : 'Copy'}
                              </button>
                            </div>

                            <div className="relative pl-3 border-l-2 border-accent/20">
                              <p className="text-[18px] lg:text-[19px] font-bold text-text leading-[1.6] tracking-tight break-words [overflow-wrap:anywhere]">
                                {highlightClinicalTerms(translateMedicalTerms(displayedResult.patient_summary))}
                              </p>
                            </div>
                          </motion.div>
                        )}

                        {/* SOAP Bins */}
                        {[
                          { title: 'Subjective', content: displayedResult?.soap?.subjective || displayedResult?.clinical_data?.soap?.subjective, icon: <User size={20} />, color: '#0052cc' },
                          { title: 'Objective', content: displayedResult?.soap?.objective || displayedResult?.clinical_data?.soap?.objective, icon: <Activity size={20} />, color: '#111111' },
                          { title: 'Assessment', content: displayedResult?.soap?.assessment || displayedResult?.clinical_data?.soap?.assessment || displayedResult?.assessment_text, icon: <Stethoscope size={20} />, color: '#7c3aed' },
                          { title: 'Plan', content: displayedResult?.soap?.plan || displayedResult?.clinical_data?.soap?.plan || displayedResult?.plan_text, icon: <ClipboardList size={20} />, color: '#16a34a' }
                        ].some(s => s.content) ? (
                          [
                            { title: 'Subjective', content: displayedResult?.soap?.subjective || displayedResult?.clinical_data?.soap?.subjective, icon: <User size={20} />, color: '#0052cc' },
                            { title: 'Objective', content: displayedResult?.soap?.objective || displayedResult?.clinical_data?.soap?.objective, icon: <Activity size={20} />, color: '#111111' },
                            { title: 'Assessment', content: displayedResult?.soap?.assessment || displayedResult?.clinical_data?.soap?.assessment || displayedResult?.assessment_text, icon: <Stethoscope size={20} />, color: '#7c3aed' },
                            { title: 'Plan', content: displayedResult?.soap?.plan || displayedResult?.clinical_data?.soap?.plan || displayedResult?.plan_text, icon: <ClipboardList size={20} />, color: '#16a34a' }
                          ].map((section, sidx) => section.content && (
                            <motion.div
                              key={sidx}
                              initial={{ opacity: 0, x: -5 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: sidx * 0.05 }}
                              className="flex flex-col gap-4 relative group/section"
                            >
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-[14px] bg-white border border-border/40 flex items-center justify-center shadow-sm transition-all group-hover/section:border-accent/30 duration-300 relative z-10" style={{ color: section.color }}>
                                  {section.icon}
                                </div>
                                <div className="text-[13px] font-black uppercase tracking-[0.2em] text-text/80">
                                  {section.title}
                                </div>
                              </div>

                              <div className="pl-12 relative">
                                <div className="absolute left-[19px] top-0 bottom-0 w-[1.5px] bg-border/20 rounded-full" />
                                <div className="absolute left-[16.5px] top-3.5 w-1.5 h-1.5 rounded-full bg-white border-2 border-border/60 group-hover/section:border-accent transition-all duration-300 z-10" />
                                <div className="py-0.5">
                                  {renderBulletedContent(section.content, section.title.toLowerCase())}
                                </div>
                              </div>
                            </motion.div>

                          ))
                        ) : (
                          /* Fallback to traditional sections if no SOAP data */
                          parseClinicalSummary(displayedResult).map((section, idx) => (
                            <motion.div
                              key={idx}
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: idx * 0.05 }}
                              className="flex flex-col gap-4 relative group"
                            >
                              <div className={`text-[12px] font-black uppercase tracking-[0.2em] flex items-center gap-3 ${section.type === 'red-flags' ? 'text-[#e11d48]' :
                                section.type === 'plan' ? 'text-[#16a34a]' :
                                  section.type === 'assessment' ? 'text-[#7c3aed]' :
                                    'text-accent/80'
                                }`}>
                                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${section.type === 'red-flags' ? 'bg-[#e11d48]/10' :
                                  section.type === 'plan' ? 'bg-[#16a34a]/10' :
                                    section.type === 'assessment' ? 'bg-[#7c3aed]/10' :
                                      'bg-accent/10'
                                  }`}>
                                  {section.icon}
                                </div>
                                {section.title}
                              </div>

                              <div className="pl-11 relative">
                                <div className="absolute left-4 top-0 bottom-0 w-[2px] bg-border/20 rounded-full" />
                                <div className="py-1">
                                  {renderBulletedContent(section.content, section.type)}
                                </div>
                              </div>
                            </motion.div>
                          ))
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>

          <div className={`${!displayedResult ? 'hidden lg:block' : 'block'} lg:col-span-1 h-full min-h-0`}>
            <div className="bg-white border border-border/90 rounded-[32px] shadow-[0_8px_30px_rgba(0,0,0,0.02)] h-full flex flex-col relative overflow-visible lg:overflow-hidden p-5 lg:p-6">

              {!result ? (
                isProcessing ? (
                  <motion.div
                    key="phantom-construction"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex-1 flex flex-col gap-10 p-6 lg:p-10 z-10"
                  >
                    <div className="flex flex-col gap-2 mb-2">
                      <div className="text-[10px] font-black text-accent tracking-[0.3em] uppercase">Phase: Clinical Blueprint Construction</div>
                      <h3 className="text-[24px] font-black text-text tracking-tight">Structured Document Birth</h3>
                    </div>

                    <div className="space-y-12">
                      <SynthesisSlab label="Subjective Data Extraction" step={1} currentStep={processingStep} icon={User} />
                      <SynthesisSlab label="Clinical Objective Synthesis" step={2} currentStep={processingStep} icon={Activity} />
                      <SynthesisSlab label="Differential Assessment Mapping" step={3} currentStep={processingStep} icon={Stethoscope} />
                      <SynthesisSlab label="Protocol Plan Formulation" step={4} currentStep={processingStep} icon={ClipboardList} />
                    </div>

                    <SynthesisTelemetry progress={processingStep * 25} confidence={98.4} />
                  </motion.div>
                ) : (
                  <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                    {/* Step 01 Right Pane Content - High Fidelity History View */}
                    <div className="flex flex-col gap-2 mb-8 shrink-0">
                      <div className="flex items-center justify-between">
                        <div className="text-[10px] font-black text-accent tracking-[0.3em] uppercase">Clinical Context Bridge</div>
                        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-off rounded-lg border border-border/10">
                          <Lock size={10} className="text-muted/40" />
                          <span className="text-[9px] font-black text-muted uppercase tracking-[0.2em]">Secure Ledger</span>
                        </div>
                      </div>
                      <h3 className="text-[24px] font-black text-text tracking-tight">Longitudinal History</h3>
                    </div>

                    <div className="flex-1 overflow-y-auto custom-scrollbar lg:pr-2 lg:-mr-2 min-h-0">
                      <LongitudinalTimeline history={patientHistory} isLoading={isHistoryLoading} onEncounterClick={handleEncounterClick} />
                    </div>
                  </div>
                )
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex-col h-auto lg:h-full z-10 min-h-0 ${reviewMobileTab === 'prescription' ? 'flex' : 'hidden lg:flex'}`}
                >
                    {/* Institutional Prescription Header */}
                    <div className="flex flex-col gap-5 mb-4 pb-5 border-b border-border/40 shrink-0">
                      {/* Control Row */}
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-accent/[0.03] border border-accent/10 flex items-center justify-center shadow-sm">
                            <Edit3 size={20} className="text-accent" />
                          </div>
                          <div className="flex flex-col">
                            <h2 className="text-[22px] font-black text-text tracking-tight leading-none">Prescription</h2>
                            <p className="text-[12px] font-medium text-muted/60 mt-1">Institutional Pharmacy Integration Layer</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setIsRxEditing(!isRxEditing)}
                            className={`p-2.5 rounded-xl transition-all shadow-sm active:scale-95 group border ${isRxEditing ? 'bg-accent text-white border-accent' : 'bg-white border-border/60 text-muted/60 hover:text-accent hover:border-accent/40'}`}
                            title={isRxEditing ? "View Structured" : "Manual Refinement"}
                          >
                            {isRxEditing ? <FileText size={18} /> : <Edit3 size={18} />}
                          </button>

                          <button
                            onClick={handleCopy}
                            className="p-2.5 bg-white border border-border/60 text-muted/60 hover:text-accent hover:border-accent/40 rounded-xl transition-all shadow-sm active:scale-95 group"
                            title="Copy to EMR"
                          >
                            <AnimatePresence mode="wait">
                              {isCopied ? (
                                <motion.div key="check" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }}>
                                  <Check size={18} className="text-green" />
                                </motion.div>
                              ) : (
                                <motion.div key="copy" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }}>
                                  <Copy size={18} className="group-hover:rotate-6 transition-transform" />
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </button>

                          <button
                            onClick={handleShareLink}
                            className="p-2.5 bg-white border border-border/60 text-muted/60 hover:text-accent hover:border-accent/40 rounded-xl transition-all shadow-sm active:scale-95 group"
                            title="Share Secure Link"
                          >
                            <AnimatePresence mode="wait">
                              {isShared ? (
                                <motion.div key="check" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }}>
                                  <Check size={18} className="text-green" />
                                </motion.div>
                              ) : (
                                <motion.div key="share" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }}>
                                  <Share size={18} className="group-hover:text-accent transition-colors" />
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </button>

                          <button
                            onClick={handleDownloadPDF}
                            className="flex items-center gap-2 px-4 py-2.5 bg-text text-white hover:bg-black rounded-xl transition-all shadow-md active:scale-95 group"
                          >
                            <AnimatePresence mode="wait">
                              {isExported ? (
                                <motion.div key="check" className="flex items-center gap-2" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }}>
                                  <Check size={16} />
                                  <span className="text-[11px] font-black uppercase tracking-wider">Saved</span>
                                </motion.div>
                              ) : (
                                <motion.div key="download" className="flex items-center gap-2" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }}>
                                  <Download size={16} className="group-hover:translate-y-0.5 transition-transform" />
                                  <span className="text-[11px] font-black uppercase tracking-wider">Export</span>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Full-Height Institutional Prescription Workspace - Matching Medical Summary Style */}
                    <div className="flex-1 flex flex-col min-h-0">
                      {displayedResult && (
                        <motion.div
                          initial={{ opacity: 0, y: -5 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="flex-1 flex flex-col min-h-0 group/narrative overflow-hidden relative bg-white"
                        >
                          <div className="flex-1 relative flex flex-col min-h-0">
                            {isRxEditing ? (
                                <div className="flex-1 flex flex-col relative bg-off/5">
                                    <div className="flex-1 relative flex flex-col min-h-0">
                                      <textarea
                                        className="flex-1 w-full bg-transparent outline-none text-[17px] lg:text-[18px] font-semibold text-text leading-[1.8] tracking-tight resize-none placeholder:text-muted/30 custom-scrollbar caret-accent"
                                        value={editedRx}
                                        onChange={(e) => setEditedRx(e.target.value)}
                                        placeholder="Enter clinical synthesis..."
                                        style={{ height: '100%', minHeight: 'calc(100vh - 440px)' }}
                                      />
                                    </div>
                                </div>
                            ) : (
                              <div className="flex-1 overflow-y-auto custom-scrollbar relative">
                                <div className="relative z-10 flex flex-col min-h-0">
                                  {(() => {
                                    const parsedRx = parsePrescriptionText(editedRx);
                                    if (!parsedRx) return (
                                      <div className="flex flex-col items-center justify-center h-48 text-[#9CA3AF] italic text-[14px]">
                                        Awaiting clinical synthesis...
                                      </div>
                                    );

                                    return (
                                      <div className="flex flex-col gap-10 p-1">
                                        {/* 1. DIAGNOSIS SECTION */}
                                        <div className="flex flex-col gap-3">
                                          <div className="flex items-center gap-2">
                                            <Sparkles size={14} className="text-accent" />
                                            <div className="text-[11px] font-black text-accent uppercase tracking-[0.2em]">Clinical Diagnosis</div>
                                            <div className="h-[1px] flex-1 bg-border/40 ml-2" />
                                          </div>
                                          <div className="flex justify-between items-center relative pl-4 border-l-2 border-accent/20">
                                            <div className="flex items-center gap-3 flex-wrap">
                                              <h3 className="text-[21px] font-black text-text tracking-tight leading-tight">
                                                {parsedRx.diagnosis}
                                              </h3>
                                              {parsedRx.icdCode && (
                                                <div className="px-2.5 py-1 bg-[#F3F4F6] text-[#6B7280] rounded-full text-[12px] font-bold">
                                                  {parsedRx.icdCode}
                                                </div>
                                              )}
                                            </div>
                                            <div className="flex items-center gap-6 text-[13px] font-medium text-[#10B981] shrink-0">
                                              <div className="flex items-center gap-1.5">
                                                <div className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
                                                {parsedRx.confidence > 0 ? parsedRx.confidence : 99.2}% Accuracy
                                              </div>
                                              <div className="flex items-center gap-1.5 px-3 py-1 bg-[#F0FDF4] rounded-lg border border-[#DCFCE7] text-[11px] font-black uppercase tracking-wider">
                                                <Check size={12} /> Verified
                                              </div>
                                            </div>
                                          </div>
                                        </div>

                                        {/* 2. INTERVENTIONS SECTION */}
                                        <div className="flex flex-col gap-5">
                                          <div className="flex items-center gap-2">
                                            <ClipboardCheck size={14} className="text-accent" />
                                            <span className="text-[11px] font-black text-accent uppercase tracking-[0.2em]">Pharmacological Interventions</span>
                                            <div className="h-[1px] flex-1 bg-border/40 ml-2" />
                                          </div>
                                          <div className="flex flex-col gap-6">
                                            {parsedRx.medications.map((med, midx) => (
                                              <div key={midx} className="relative group/med">
                                                <div className="grid grid-cols-12 gap-6 items-start">
                                                  {/* Medication & Protocol */}
                                                  <div className="col-span-12 lg:col-span-6 flex flex-col gap-1">
                                                    <div className="text-[16px] font-black text-text uppercase tracking-tight flex items-center gap-2">
                                                      <span className="text-accent/40">{midx + 1}.</span>
                                                      {med.name}
                                                    </div>
                                                    <div className="text-[14px] font-medium text-muted/80 italic leading-relaxed pl-6 border-l border-border/40 mt-1">
                                                      {translateMedicalTerms(med.protocol) || 'As directed.'}
                                                    </div>
                                                  </div>

                                                  {/* Dose & Freq */}
                                                  <div className="col-span-6 lg:col-span-3 flex flex-col gap-1.5">
                                                    <div className="flex items-center gap-2">
                                                      <div className="w-1 h-3 bg-accent/20 rounded-full" />
                                                      <span className="text-[10px] font-black text-muted/50 uppercase tracking-widest">Dose / Freq</span>
                                                    </div>
                                                    <div className="text-[15px] font-bold text-accent pl-3">
                                                      {translateMedicalTerms(med.dose) || '—'}
                                                    </div>
                                                  </div>

                                                  {/* Duration */}
                                                  <div className="col-span-6 lg:col-span-3 flex flex-col gap-1.5">
                                                    <div className="flex items-center gap-2">
                                                      <div className="w-1 h-3 bg-text/10 rounded-full" />
                                                      <span className="text-[10px] font-black text-muted/50 uppercase tracking-widest">Duration</span>
                                                    </div>
                                                    <div className="text-[15px] font-bold text-text pl-3">
                                                      {translateMedicalTerms(med.duration) || 'As Needed'}
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            ))}
                                          </div>
                                        </div>

                                        {/* 3. ADVICE SECTION */}
                                        <div className="flex flex-col gap-4">
                                          <div className="flex items-center gap-2">
                                            <Sparkles size={14} className="text-accent/60" />
                                            <span className="text-[11px] font-black text-accent uppercase tracking-[0.2em]">Clinical Guidance</span>
                                            <div className="h-[1px] flex-1 bg-border/40 ml-2" />
                                          </div>
                                          <div className="flex flex-col gap-3 pl-4 border-l-2 border-border/20">
                                            {parsedRx.advice.map((item, aidx) => (
                                              <div key={aidx} className="flex items-start gap-3 text-[15px] text-text/80 leading-relaxed">
                                                <span className="text-accent font-black mt-0.5">›</span>
                                                <span>{translateMedicalTerms(item)}</span>
                                              </div>
                                            ))}
                                          </div>
                                        </div>

                                        {/* 4. FOLLOW-UP SECTION */}
                                        <div className="flex flex-col gap-4">
                                          <div className="flex items-center gap-2">
                                            <Clock size={14} className="text-[#9CA3AF]" />
                                            <span className="text-[11px] font-black text-accent uppercase tracking-[0.2em]">Follow-up Plan</span>
                                            <div className="h-[1px] flex-1 bg-border/40 ml-2" />
                                          </div>
                                          <div className="pl-4 border-l-2 border-border/20 text-[15px] text-text/80 leading-relaxed font-semibold">
                                            {translateMedicalTerms(parsedRx.followUp)}
                                          </div>
                                        </div>
                                        {/* 5. DISCLAIMER */}
                                        <div className="mt-8 pt-8 border-t border-border/10">
                                          <div className="pl-4 border-l-2 border-border/40">
                                            <p className="text-[11px] font-bold text-muted/60 uppercase tracking-wider leading-relaxed">
                                              Disclaimer: This clinical documentation is synthesized with AI assistance. Clinical verification is mandatory before implementation.
                                            </p>
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })()}
                                </div>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </div>
                </motion.div>
              )}
            </div>
          </div>
        </div>

        {/* --- [NEW] BILLING & REIMBURSEMENT SUPPORT (FULL WIDTH STANDALONE) --- */}
        <AnimatePresence>
          {result && (
            <motion.div
              ref={billingRef}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`mt-4 bg-transparent lg:bg-white border-0 lg:border border-border/60 rounded-none lg:rounded-[32px] p-0 lg:p-8 shadow-none lg:shadow-sm mb-1 ${reviewMobileTab === 'billing' ? 'block' : 'hidden lg:block'}`}
            >
              <div className="hidden lg:flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-6 mb-8 min-w-0 border-b border-border/40 pb-6">
                <div className="flex items-center gap-4 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-accent/[0.03] border border-accent/10 flex items-center justify-center shadow-sm">
                    <Database size={20} className="text-accent" />
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <h3 className="text-[20px] font-black text-text tracking-tight leading-none">Institutional Revenue Center</h3>
                      <button
                        onClick={() => setShowCodingInfo(!showCodingInfo)}
                        className={`p-1 rounded-full transition-all ${showCodingInfo ? 'bg-accent text-white' : 'text-muted/40 hover:bg-off hover:text-accent'}`}
                      >
                        <Info size={12} />
                      </button>
                    </div>
                    <p className="text-[12px] font-medium text-muted/60 mt-1">Billing & Reimbursement Integrity Hub</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-off/50 rounded-xl border border-border/40 shadow-sm">
                    <div className="text-[10px] font-black text-muted/40 uppercase tracking-[0.2em] whitespace-nowrap">AI Accuracy Index</div>
                    <div className="h-4 w-[1px] bg-border/40 mx-1" />
                    {isSyncing ? (
                      <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.5 }} className="flex items-center gap-1.5 text-accent text-[11px] font-black uppercase tracking-wider">
                        <RefreshCw size={10} className="animate-spin" /> Syncing
                      </motion.div>
                    ) : (
                      <div className="text-[12px] font-black text-accent tracking-tight">98.4%</div>
                    )}
                  </div>
                </div>
              </div>

              <AnimatePresence>
                {showCodingInfo && (
                  <motion.div
                    layout
                    initial={{ opacity: 0, height: 0, marginBottom: 0 }}
                    animate={{ opacity: 1, height: 'auto', marginBottom: 20 }}
                    exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="bg-accent/[0.03] border border-accent/10 rounded-2xl p-6 text-[14.5px] leading-relaxed text-muted">
                      <div className="flex items-center gap-2 mb-4 text-accent font-bold">
                        <Sparkles size={16} />
                        <span className="text-[16px] tracking-tight">Revenue Integrity Assistant</span>
                      </div>
                      <ul className="space-y-4 list-none p-0 m-0">
                        <li className="flex gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                          <span>AI captures billable <strong className="font-bold text-text">ICD-10</strong> and <strong className="font-bold text-text">CPT</strong> codes directly from your clinical dialogue to ensure no service is overlooked.</span>
                        </li>
                        <li className="flex gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                          <span>Simply verify the suggestions to maintain accurate documentation and maximize reimbursement integrity.</span>
                        </li>
                      </ul>
                      <div className="mt-5 pt-4 border-t border-accent/5 flex items-center gap-2 text-[13px] font-bold text-accent/60 uppercase tracking-wider">
                        <CheckCircle2 size={14} />
                        <span>Verified codes sync instantly to the patient's record</span>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {result && (
                <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-4 mb-8">
                  {/* Status Badges Group */}
                  <div className="flex items-center gap-2 p-1 bg-off/50 border border-border/40 rounded-[14px]">
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-white border border-border/40 rounded-[10px] shadow-sm">
                      <div className={`w-1.5 h-1.5 rounded-full ${result.vitals_check ? 'bg-green animate-pulse' : 'bg-muted/30'}`} />
                      <span className="text-[10px] font-black uppercase tracking-wider text-text/60">Vitals Sync</span>
                    </div>
                    
                    <div className={`flex items-center gap-2 px-3 py-1.5 border rounded-[10px] shadow-sm ${
                      result.complexity === 'High' ? 'bg-red-50/50 border-red-100 text-red-600' :
                      result.complexity === 'Moderate' ? 'bg-orange-50/50 border-orange-100 text-orange-600' : 
                      'bg-blue-50/50 border-blue-100 text-blue-600'
                    }`}>
                      <Activity size={12} />
                      <span className="text-[10px] font-black uppercase tracking-wider">
                        {result.complexity || 'Low'} MDM
                      </span>
                    </div>
                  </div>

                  {/* Reasoning Narrative */}
                  {result.codes_reasoning && (
                    <div className="flex-1 flex items-center gap-3 pl-2">
                      <div className="w-[2px] h-6 bg-border/40 rounded-full shrink-0" />
                      <div className="text-[13px] font-medium text-muted/60 italic leading-relaxed [overflow-wrap:anywhere]">
                        <span className="text-[10px] font-black uppercase tracking-wider text-muted/30 not-italic mr-2">Rationale:</span>
                        {result.codes_reasoning}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <motion.div layout className="flex flex-col gap-3" onMouseLeave={() => setHoveredBillingIdx(null)}>
                {verifiedCodes.length > 0 ? (
                  verifiedCodes.map((code, idx) => (
                    <BillingCodeItem
                      key={`${code.code}-${idx}`}
                      code={code}
                      idx={idx}
                      isHovered={hoveredBillingIdx === idx}
                      onMouseEnter={() => setHoveredBillingIdx(idx)}
                      onToggle={async () => {
                        const newCodes = [...verifiedCodes];
                        newCodes[idx].verified = !newCodes[idx].verified;
                        setVerifiedCodes(newCodes);

                        // Instant Sync to Backend
                        if (currentEncounterId) {
                          setIsSyncing(true);
                          try {
                            await updateEncounterCodes(currentEncounterId, newCodes);
                            console.log('Billing codes synced instantly.');
                          } catch (err) {
                            console.error('Instant sync failed:', err);
                          } finally {
                            setTimeout(() => setIsSyncing(false), 800);
                          }
                        }
                      }}
                    />
                  ))
                ) : (
                  <div className="col-span-full py-16 px-4 bg-off/5 rounded-[32px] border border-dashed border-border/60 flex flex-col items-center text-center relative overflow-hidden group">
                    {/* Subtle Background blueprint grid */}
                    <div className="absolute inset-0 opacity-[0.02] pointer-events-none"
                      style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, #000 1px, transparent 0)', backgroundSize: '24px 24px' }} />

                    <div className="relative mb-8">
                      <motion.div
                        animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                        className="w-24 h-24 bg-white rounded-[24px] shadow-[0_8px_30px_rgba(0,0,0,0.04)] border border-border/40 flex items-center justify-center relative z-10"
                      >
                        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" className="text-accent/40">
                          <rect x="8" y="10" width="32" height="28" rx="2" stroke="currentColor" strokeWidth="2" />
                          <path d="M14 18H34" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                          <path d="M14 24H34" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                          <path d="M14 30H24" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                          <motion.circle
                            cx="32" cy="30" r="6"
                            stroke="currentColor" strokeWidth="2" fill="white"
                            animate={{ x: [-2, 2, -2], y: [-1, 1, -1] }}
                            transition={{ duration: 4, repeat: Infinity }}
                          />
                          <path d="M37 35L42 40" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                        </svg>
                      </motion.div>
                      <div className="absolute -inset-4 bg-accent/5 blur-2xl rounded-full -z-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                    </div>

                    <div className="flex items-center gap-2 mb-4">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent/40 animate-pulse" />
                      <span className="text-[11px] font-black text-accent/60 uppercase tracking-[0.2em]">Awaiting Clinical Context</span>
                    </div>

                    <h4 className="text-[20px] font-black text-text mb-3 tracking-tight">Revenue Cycle Intelligence</h4>
                    <p className="text-[15px] font-medium text-muted/60 max-w-[380px] leading-relaxed">
                      ICD-10 and CPT suggestions will generate automatically once the <strong className="text-text font-black">Clinical Summary</strong> is finalized.
                    </p>
                  </div>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <EncounterDetailModal
          encounter={selectedHistoryEncounter}
          isOpen={isHistoryModalOpen}
          onClose={() => setIsHistoryModalOpen(false)}
        />
      </div>
    </div>
  );
}

function BillingCodeItem({ code, idx, onToggle, isHovered, onMouseEnter }) {
  const [showReasoning, setShowReasoning] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{
        layout: { duration: 0.4, ease: [0.23, 1, 0.32, 1] },
        opacity: { duration: 0.2 },
        scale: { duration: 0.2 }
      }}
      onMouseEnter={onMouseEnter}
      className={`group flex flex-col p-5 rounded-[24px] border transition-all duration-300 min-w-0 overflow-hidden ${code.verified
        ? 'bg-[#f0fdf4]/30 border-[#bbf7d0]/60 ring-1 ring-[#bbf7d0]/10 shadow-sm'
        : 'bg-white border-border/60 hover:border-accent/40 shadow-[0_2px_10px_rgba(0,0,0,0.02)]'
        }`}
    >
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-5 min-w-0 w-full sm:w-auto">
          {/* Code Badge */}
          <div className={`w-14 h-14 rounded-2xl flex flex-col items-center justify-center shrink-0 border transition-colors duration-300 ${
            code.verified 
              ? 'bg-white border-[#bbf7d0] text-green shadow-sm' 
              : 'bg-off/50 border-border/40 text-accent/80'
          }`}>
            <span className="text-[10px] font-black uppercase tracking-tighter opacity-40 leading-none mb-1">
              {code.system === 'ICD-10-CM' ? 'ICD-10' : code.system || 'ICD-10'}
            </span>
            <span className="text-[15px] font-black tracking-tight leading-none">{code.code}</span>
          </div>

          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className="text-[10px] font-black text-accent uppercase tracking-[0.2em]">Clinical Designation</span>
              <div className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-widest ${
                code.category === 'Primary' || code.category === 'Primary Diagnosis' ? 'bg-accent text-white' : 'bg-off text-muted/60'
              }`}>
                {code.category?.includes('Primary') ? 'Primary' : 'Secondary'}
              </div>
              {code.confidence < 0.85 && !code.verified && (
                <div className="flex items-center gap-1 text-[9px] font-black text-[#e11d48] uppercase bg-[#fff1f2] px-1.5 py-0.5 rounded border border-[#fee2e2]">
                  <AlertTriangle size={8} /> High Review Priority
                </div>
              )}
            </div>
            <h4 className="text-[17px] font-black text-text tracking-tight leading-tight truncate">
              {code.description}
            </h4>
          </div>
        </div>

        <div className="flex items-center gap-4 shrink-0 self-end sm:self-center">
          <button
            onClick={() => setShowReasoning(!showReasoning)}
            className={`p-2 rounded-lg transition-all ${showReasoning ? 'bg-accent/5 text-accent' : 'text-muted/20 hover:text-accent'}`}
            title="View Justification"
          >
            <ChevronDown size={18} className={`transition-transform duration-300 ${showReasoning ? 'rotate-180' : ''}`} />
          </button>
          <div className="h-8 w-[1px] bg-border/40 hidden sm:block" />
          <button
            onClick={onToggle}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-500 active:scale-90 ${
              code.verified 
                ? 'bg-green text-white shadow-lg shadow-green/20 rotate-0' 
                : 'bg-off border border-border/60 text-muted/20 hover:border-accent hover:text-accent rotate-90'
            }`}
          >
            <Check size={20} strokeWidth={3} />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {(showReasoning || (isHovered && code.justification)) && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-4 pt-4 border-t border-border/40">
              <div className="bg-off/40 rounded-xl p-3 text-[13px] font-medium text-muted/60 leading-relaxed italic border border-border/20">
                <span className="text-[10px] font-black uppercase tracking-wider text-muted/30 not-italic mr-2">Clinical Logic:</span>
                {code.justification || "Suggested based on diagnostic alignment."}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function ChevronRightArrow() {
  return <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l6-6-6-6" /></svg>;
}
