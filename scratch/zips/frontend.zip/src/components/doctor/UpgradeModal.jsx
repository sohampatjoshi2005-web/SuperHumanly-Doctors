import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ShieldCheck, Zap, Phone, Building, User, CheckCircle2, ArrowRight } from 'lucide-react';
import { requestUpgrade } from '../../lib/doctorApi';

export default function UpgradeModal({ isOpen, onClose, trialData }) {
  const [step, setStep] = useState('form'); // 'form' or 'success'
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    clinic_name: '',
    phone_number: ''
  });
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await requestUpgrade(formData);
      setStep('success');
    } catch (err) {
      setError('Failed to submit request. Please try again or contact support.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-md"
          />
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-[500px] bg-white rounded-[32px] shadow-[0_30px_100px_rgba(0,0,0,0.25)] overflow-hidden"
          >
            {/* Header Gradient */}
            <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-br from-accent/10 to-transparent pointer-events-none" />
            
            <button 
              onClick={onClose}
              className="absolute top-6 right-6 p-2 text-muted hover:text-text hover:bg-off rounded-full transition-all z-10"
            >
              <X size={20} />
            </button>

            <div className="p-10 pt-12 relative z-0">
              {step === 'form' ? (
                <>
                  <div className="flex items-center gap-3 mb-6">
                     <div className="w-12 h-12 bg-accent/10 rounded-2xl flex items-center justify-center text-accent">
                        <Zap size={24} />
                     </div>
                     <div>
                        <h2 className="text-[24px] font-serif text-text leading-tight">Professional License</h2>
                        <p className="text-[14px] font-medium text-muted">Unlock unlimited clinical intelligence.</p>
                     </div>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-widest text-muted mb-2 ml-1">Practitioner Name</label>
                      <div className="relative">
                        <User className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                        <input 
                          required
                          type="text" 
                          placeholder="Dr. John Smith"
                          className="w-full h-14 bg-off/50 border border-border/80 rounded-2xl pl-12 pr-4 text-[15px] font-bold outline-none focus:border-accent/40 focus:bg-white transition-all shadow-sm"
                          value={formData.full_name}
                          onChange={e => setFormData({...formData, full_name: e.target.value})}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-widest text-muted mb-2 ml-1">Clinic / Facility</label>
                      <div className="relative">
                        <Building className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                        <input 
                          required
                          type="text" 
                          placeholder="Central Medical Centre"
                          className="w-full h-14 bg-off/50 border border-border/80 rounded-2xl pl-12 pr-4 text-[15px] font-bold outline-none focus:border-accent/40 focus:bg-white transition-all shadow-sm"
                          value={formData.clinic_name}
                          onChange={e => setFormData({...formData, clinic_name: e.target.value})}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-black uppercase tracking-widest text-muted mb-2 ml-1">Direct Phone</label>
                      <div className="relative">
                        <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={18} />
                        <input 
                          required
                          type="tel" 
                          placeholder="+1 (555) 000-0000"
                          className="w-full h-14 bg-off/50 border border-border/80 rounded-2xl pl-12 pr-4 text-[15px] font-bold outline-none focus:border-accent/40 focus:bg-white transition-all shadow-sm"
                          value={formData.phone_number}
                          onChange={e => setFormData({...formData, phone_number: e.target.value})}
                        />
                      </div>
                    </div>

                    {error && (
                      <p className="text-red-500 text-sm font-medium px-1">{error}</p>
                    )}

                    <button 
                      disabled={loading}
                      type="submit"
                      className="w-full h-14 bg-text text-white rounded-2xl font-black uppercase tracking-widest text-[13px] shadow-xl shadow-text/10 hover:bg-black active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                    >
                      {loading ? 'Processing Request...' : 'Submit Upgrade Request'}
                      {!loading && <ArrowRight size={18} />}
                    </button>

                    <div className="flex items-center justify-center gap-4 pt-4 border-t border-border/40">
                       <div className="flex items-center gap-1.5">
                          <ShieldCheck size={14} className="text-accent" />
                          <span className="text-[10px] font-black uppercase tracking-tighter text-muted">HIPAA Compliant</span>
                       </div>
                       <div className="w-1 h-1 bg-border rounded-full" />
                       <div className="flex items-center gap-1.5">
                          <CheckCircle2 size={14} className="text-accent" />
                          <span className="text-[10px] font-black uppercase tracking-tighter text-muted">Secure SSL</span>
                       </div>
                    </div>
                  </form>
                </>
              ) : (
                <div className="text-center py-6">
                  <div className="w-20 h-20 bg-accent/10 text-accent rounded-[32px] flex items-center justify-center mx-auto mb-8 animate-bounce">
                    <CheckCircle2 size={40} />
                  </div>
                  <h2 className="text-[28px] font-serif text-text mb-4">Request Received</h2>
                  <p className="text-[16px] font-medium text-muted leading-relaxed mb-10">
                    Our team has been notified. A clinical integration specialist will reach out to <strong>{formData.clinic_name}</strong> within 24 hours to finalize your professional license.
                  </p>
                  <button 
                    onClick={onClose}
                    className="px-10 py-4 bg-off text-text rounded-2xl font-black uppercase tracking-widest text-[12px] hover:bg-border transition-all"
                  >
                    Return to Portal
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
