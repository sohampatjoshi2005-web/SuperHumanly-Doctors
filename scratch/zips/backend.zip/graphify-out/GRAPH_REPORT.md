# Graph Report - healthcare-backend  (2026-05-15)

## Corpus Check
- 107 files · ~26,392 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 721 nodes · 1097 edges · 84 communities (52 shown, 32 thin omitted)
- Extraction: 73% EXTRACTED · 27% INFERRED · 0% AMBIGUOUS · INFERRED: 297 edges (avg confidence: 0.71)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `c8a12d20`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_API Processing Pipeline|API Processing Pipeline]]
- [[_COMMUNITY_Patient & Encounter CRUD|Patient & Encounter CRUD]]
- [[_COMMUNITY_Clinical Intelligence & Admin|Clinical Intelligence & Admin]]
- [[_COMMUNITY_LangGraph Node Orchestration|LangGraph Node Orchestration]]
- [[_COMMUNITY_Authentication & RBAC|Authentication & RBAC]]
- [[_COMMUNITY_Database Seeding & Lifecycle|Database Seeding & Lifecycle]]
- [[_COMMUNITY_Transcription Engine|Transcription Engine]]
- [[_COMMUNITY_Graph State & Schemas|Graph State & Schemas]]
- [[_COMMUNITY_Email & Upgrade Flow|Email & Upgrade Flow]]
- [[_COMMUNITY_Formatting & Background Tasks|Formatting & Background Tasks]]
- [[_COMMUNITY_Transcription Benchmarks|Transcription Benchmarks]]
- [[_COMMUNITY_Billing Node & Service|Billing Node & Service]]
- [[_COMMUNITY_Validation & Streamlit|Validation & Streamlit]]
- [[_COMMUNITY_AI Agents Router|AI Agents Router]]
- [[_COMMUNITY_Clinic Reporting|Clinic Reporting]]
- [[_COMMUNITY_Clinical Risk Detection|Clinical Risk Detection]]
- [[_COMMUNITY_Architecture Concepts|Architecture Concepts]]
- [[_COMMUNITY_Async DB Operations|Async DB Operations]]
- [[_COMMUNITY_Prescription Extraction|Prescription Extraction]]
- [[_COMMUNITY_LLM Factory & Summary|LLM Factory & Summary]]
- [[_COMMUNITY_Application Config|Application Config]]
- [[_COMMUNITY_Text Cleanup Pipeline|Text Cleanup Pipeline]]
- [[_COMMUNITY_Data Schemas|Data Schemas]]
- [[_COMMUNITY_Trial Gating|Trial Gating]]
- [[_COMMUNITY_EHR Sync Tests|EHR Sync Tests]]
- [[_COMMUNITY_MongoDB Migration|MongoDB Migration]]
- [[_COMMUNITY_ASR Tool|ASR Tool]]
- [[_COMMUNITY_Mailer Tool|Mailer Tool]]
- [[_COMMUNITY_Docker Compose|Docker Compose]]
- [[_COMMUNITY_Deploy Guide|Deploy Guide]]
- [[_COMMUNITY_API Documentation|API Documentation]]
- [[_COMMUNITY_Postgres Setup|Postgres Setup]]
- [[_COMMUNITY_Requirements|Requirements]]
- [[_COMMUNITY_Backend API Docs|Backend API Docs]]
- [[_COMMUNITY_Gemini Config|Gemini Config]]
- [[_COMMUNITY_Risk Service Internals|Risk Service Internals]]
- [[_COMMUNITY_Encounter Schema|Encounter Schema]]
- [[_COMMUNITY_Billing Schema|Billing Schema]]
- [[_COMMUNITY_Rx Schema|Rx Schema]]
- [[_COMMUNITY_EHR Models|EHR Models]]
- [[_COMMUNITY_Clinical Concepts|Clinical Concepts]]
- [[_COMMUNITY_AKI Detection|AKI Detection]]
- [[_COMMUNITY_Community 56|Community 56]]
- [[_COMMUNITY_Community 57|Community 57]]
- [[_COMMUNITY_Community 58|Community 58]]
- [[_COMMUNITY_Community 59|Community 59]]
- [[_COMMUNITY_Community 60|Community 60]]
- [[_COMMUNITY_Community 61|Community 61]]
- [[_COMMUNITY_Community 62|Community 62]]
- [[_COMMUNITY_Community 63|Community 63]]
- [[_COMMUNITY_Community 64|Community 64]]
- [[_COMMUNITY_Community 65|Community 65]]
- [[_COMMUNITY_Community 66|Community 66]]
- [[_COMMUNITY_Community 67|Community 67]]
- [[_COMMUNITY_Community 68|Community 68]]
- [[_COMMUNITY_Community 70|Community 70]]
- [[_COMMUNITY_Community 71|Community 71]]
- [[_COMMUNITY_Community 72|Community 72]]
- [[_COMMUNITY_Community 73|Community 73]]
- [[_COMMUNITY_Community 74|Community 74]]
- [[_COMMUNITY_Community 75|Community 75]]
- [[_COMMUNITY_Community 76|Community 76]]
- [[_COMMUNITY_Community 77|Community 77]]
- [[_COMMUNITY_Community 78|Community 78]]
- [[_COMMUNITY_Community 79|Community 79]]
- [[_COMMUNITY_Community 80|Community 80]]
- [[_COMMUNITY_Community 81|Community 81]]
- [[_COMMUNITY_Community 82|Community 82]]
- [[_COMMUNITY_Community 83|Community 83]]

## God Nodes (most connected - your core abstractions)
1. `get_session()` - 74 edges
2. `SQLModel Data Models` - 49 edges
3. `Database Session Management` - 35 edges
4. `User` - 26 edges
5. `Encounter` - 24 edges
6. `Customer` - 21 edges
7. `AuditLog` - 14 edges
8. `process_clinical_task()` - 14 edges
9. `Editing this README` - 14 edges
10. `scoped_select()` - 13 edges

## Surprising Connections (you probably didn't know these)
- `Intelligence Analytics Router` --implements--> `Clinical Documentation Automation`  [INFERRED]
  app/api/v1/intelligence.py → README.md
- `Docker Compose Orchestration` --references--> `FastAPI Application Entry`  [EXTRACTED]
  docker-compose.yml → app/main.py
- `LangGraph Clinical Pipeline` --implements--> `Clinical Documentation Automation`  [INFERRED]
  app/core/langgraph/graph.py → README.md
- `generate_from_transcript()` --calls--> `Encounter`  [INFERRED]
  streamlit_app.py → app/db_models.py
- `generate_from_transcript()` --calls--> `create_encounter()`  [INFERRED]
  streamlit_app.py → app/services/storage_service.py

## Hyperedges (group relationships)
- **API Router Layer** — v1_auth, v1_trials, v1_ehr, v1_clinic_admin, v1_tasks, v1_intelligence, v1_agents [EXTRACTED 1.00]
- **LangGraph Processing Pipeline** — nodes_transcription, nodes_cleanup, nodes_extraction, nodes_validation, nodes_formatting, nodes_email, nodes_billing [EXTRACTED 1.00]
- **LLM-Powered Clinical Services** — services_rx, services_summary, services_billing, services_intelligence, services_llm_factory [EXTRACTED 1.00]
- **Background Processing System** — workers_ai_tasks, workers_audit, core_celery [EXTRACTED 1.00]

## Communities (84 total, 32 thin omitted)

### Community 0 - "API Processing Pipeline"
Cohesion: 0.18
Nodes (7): FastAPI Application Entry, Docker Compose Orchestration, AI Agents Router, Authentication Router, Clinic Admin Router, Task Status Router, Trial Request Router

### Community 1 - "Patient & Encounter CRUD"
Cohesion: 0.05
Nodes (65): get_session(), Returns a select statement for the given model class,      automatically filtere, scoped_select(), get_clinic_stats(), get_diagnostic_accuracy_report(), get_efficiency_benchmarks(), get_provider_benchmarks(), create_customer() (+57 more)

### Community 2 - "Clinical Intelligence & Admin"
Cohesion: 0.09
Nodes (59): AdherenceLog, AuditLog, Clinic, Customer, Encounter, ExternalResource, HMSRecord, IntelligenceMessage (+51 more)

### Community 3 - "LangGraph Node Orchestration"
Cohesion: 0.09
Nodes (25): Multi-Provider ASR, Celery Task Queue, LangGraph Pipeline, Billing Node, Cleanup Node, Email Node, Extraction Node, Formatting Node (+17 more)

### Community 4 - "Authentication & RBAC"
Cohesion: 0.12
Nodes (16): clear_clinic_id(), get_clinic_id(), Retrieve the current clinic ID from the request context., Clear the current clinic ID context., Set the current clinic ID in the request context., set_clinic_id(), create_access_token(), create_access_token_with_context() (+8 more)

### Community 5 - "Database Seeding & Lifecycle"
Cohesion: 0.13
Nodes (15): init_db(), EHRSystem, Defines a connected EHR system (e.g. Epic, Cerner)., Defines a connected EHR system (e.g. Epic, Cerner)., seed_clinic_data(), seed_ehr_systems(), seed_fhir_data(), health_check() (+7 more)

### Community 6 - "Transcription Engine"
Cohesion: 0.16
Nodes (19): transcription_node(), BenchmarkSample, char_error_rate(), _edit_distance(), load_manifest(), main(), normalize_for_metrics(), run_benchmark() (+11 more)

### Community 7 - "Graph State & Schemas"
Cohesion: 0.08
Nodes (19): RxState, RxState, billing_node(), LangGraph node to extract billing and coding information from the cleaned transc, cds_node(), Extract clinical risk indicators from the corrected transcript., BillingAnalysis, BillingCode (+11 more)

### Community 8 - "Email & Upgrade Flow"
Cohesion: 0.25
Nodes (5): email_node(), send_email(), send_rx_email(), Submit an upgrade request form.     Persists to SQL and notifies the Superhumanl, request_upgrade()

### Community 9 - "Formatting & Background Tasks"
Cohesion: 0.04
Nodes (30): generate_from_transcript(), cleanup_node(), extraction_node(), formatting_node(), Detects if a referral is needed and generates a draft letter., referral_node(), validation_node(), AgentFeedback (+22 more)

### Community 10 - "Transcription Benchmarks"
Cohesion: 0.04
Nodes (47): 1. API Layer (`app/api/v1/`), 2. LangGraph Pipeline (`app/core/langgraph/`), 3. Service Layer (`app/services/`), 4. Data Layer, 5. Background Workers (`app/workers/`), Additional Utilities, AI / ML Stack, Alternative Frontend (+39 more)

### Community 11 - "Billing Node & Service"
Cohesion: 0.05
Nodes (42): 0) Prereqs (local machine), 1) Create AWS credentials (new user), 2) Enable Bedrock model access (one-time), 3.1 Create a key pair (for SSH), 3.2 Create a Security Group (allow SSH + app ports), 3.3 Launch the instance, 3) Create an EC2 instance (Ubuntu), 4) SSH into EC2 and install dependencies (+34 more)

### Community 12 - "Validation & Streamlit"
Cohesion: 0.08
Nodes (24): Add your files, Authors and acknowledgment, Badges, code:json ([), code:bash (python3 scripts/benchmark_transcription.py --manifest benchm), code:block3 (cd existing_repo), Collaborate with your team, Contributing (+16 more)

### Community 13 - "AI Agents Router"
Cohesion: 0.29
Nodes (6): get_agent_logs(), get_swarm_status(), Fetch the health and status of the entire medical agent swarm.     Returns a dir, Fetch real-time activity logs from the agent swarm., Trigger a specific task for an agent., trigger_agent_task()

### Community 14 - "Clinic Reporting"
Cohesion: 0.13
Nodes (14): generate_clinic_report_pdf(), Generates a professional clinical institution performance report., add_doctor_to_clinic(), export_clinic_report(), get_accuracy_benchmarks(), get_clinic_stats(), get_efficiency_benchmarks(), list_clinic_members() (+6 more)

### Community 15 - "Clinical Risk Detection"
Cohesion: 0.25
Nodes (7): ClinicalRisk, detect_risks(), Scans the encounter history for a specific customer to detect clinical risks, Helper class for risk alerts, get_patient_risks(), Fetch proactive clinical risks for a specific patient., Fetch proactive clinical risks for a specific patient.

### Community 16 - "Architecture Concepts"
Cohesion: 0.33
Nodes (6): Background Worker Architecture, Clinical Documentation Automation, HIPAA Compliance, LangGraph Clinical Pipeline, Multi-Tenant Architecture, Project README

### Community 17 - "Async DB Operations"
Cohesion: 0.33
Nodes (5): async_db_operation(), Database helper utilities Provides wrappers for async-friendly database operatio, Run synchronous database operations in a thread pool     This prevents blocking, Decorator to automatically run sync DB operations in threadpool          Usage:, run_sync_in_threadpool()

### Community 18 - "Prescription Extraction"
Cohesion: 0.1
Nodes (21): flush_audit_logs_sync(), log_audit_batched(), Sync operation to flush queued logs to PostgreSQL, Sync operation to flush queued logs to PostgreSQL with hash-chaining., Queue audit log for batching (non-blocking, ~<1ms), Queue audit log for batching (non-blocking, ~<1ms), compute_event_hash(), get_canonical_json() (+13 more)

### Community 19 - "LLM Factory & Summary"
Cohesion: 0.1
Nodes (20): code:bash (export CORS_ALLOW_ORIGINS="http://localhost:5173,http://127.), code:bash (curl "http://<EC2_PUBLIC_IP>:8000/v1/customers"), code:json ({ "name": "Sathya" }), code:bash (curl -X POST "http://<EC2_PUBLIC_IP>:8000/v1/customers" \), code:bash (curl -X POST "http://<EC2_PUBLIC_IP>:8000/v1/process-audio" ), code:json ({), code:bash (curl -X POST "http://<EC2_PUBLIC_IP>:8000/v1/process-text" \), CORS (Frontend Access) (+12 more)

### Community 20 - "Application Config"
Cohesion: 0.33
Nodes (4): BaseSettings, Fail-fast check for critical production keys., Fail-fast check for critical production keys., Settings

### Community 21 - "Text Cleanup Pipeline"
Cohesion: 0.16
Nodes (16): map_customer_to_patient(), map_encounter_to_bundle(), map_encounter_to_fhir(), map_to_condition(), map_to_document_reference(), map_to_flags(), map_to_medication_request(), Validates a dictionary against a specific FHIR resource type. (+8 more)

### Community 22 - "Data Schemas"
Cohesion: 0.67
Nodes (3): BillingCode Schema, UnifiedEncounterAnalysis Schema, Prescription Schema

### Community 23 - "Trial Gating"
Cohesion: 0.67
Nodes (3): Trial Gating System, Usage Metering Service, Upgrade Request Router

### Community 25 - "EHR Sync Tests"
Cohesion: 0.67
Nodes (3): Settings & Config, Auth Dependencies, Secure Share Router

### Community 56 - "Community 56"
Cohesion: 0.18
Nodes (5): Database Session Management, get_trial_status(), Get current trial status for the doctor., Daily task to refresh clinical graphs for all active clinics.     Ensures the Gr, update_all_clinic_graphs_task()

### Community 57 - "Community 57"
Cohesion: 0.24
Nodes (5): Exchange the authorization code for an access token., Fetch SMART configuration from the FHIR server's .well-known endpoint., Generate PKCE code_verifier and code_challenge., Prepare the authorization URL and PKCE/state context., SMARTAuthService

### Community 58 - "Community 58"
Cohesion: 0.22
Nodes (7): get_async_session(), Get async database session for high-performance queries, Get async database session for high-performance queries, increment_usage(), Atomically increments the usage count for a user.     Returns the new count., process_audio(), process_text()

### Community 59 - "Community 59"
Cohesion: 0.22
Nodes (8): code:bash (curl -X POST "http://127.0.0.1:8000/v1/process-audio" \), code:json ({), code:bash (curl -X POST "http://127.0.0.1:8000/v1/process-text" \), Doctor Support Backend API, POST `/v1/process-audio`, POST `/v1/process-text`, Prescription Schema (RX JSON), Required Env Vars (Backend)

### Community 60 - "Community 60"
Cohesion: 0.25
Nodes (8): SQLModel Data Models, AKI Risk Detection, MongoDB Migration Script, Customer Seeding Script, seed(), Intelligence Seeding Script, Risk Detection Service, Intelligence Analytics Router

### Community 61 - "Community 61"
Cohesion: 0.22
Nodes (8): code:bash (docker run --name doctor-support-postgres \), code:bash (export DATABASE_URL="postgresql+psycopg2://postgres:postgres), code:bash (cd "/Users/sathya/Downloads/customer support/doctor support"), Local Postgres Setup (Doctor Support), Notes, Option A: Docker Postgres (recommended), Option B: SQLite (default), Run the app

### Community 62 - "Community 62"
Cohesion: 0.29
Nodes (6): admin_get_clinic_graph(), get_clinic_graph(), get_clinic_insights(), Returns the clinical knowledge graph for the user's clinic., Returns high-level graph insights and clusters for the clinic., Admin-only: Returns the graph for any specific clinic.

### Community 63 - "Community 63"
Cohesion: 0.29
Nodes (6): Check current SMART connection status., Step 1: Initiate SMART on FHIR launch., Step 2: Handle SMART on FHIR callback., smart_callback(), smart_launch(), smart_status()

### Community 64 - "Community 64"
Cohesion: 0.33
Nodes (3): FHIRSearchService, Search for FHIR resources of a specific type., Pull Medications, Observations, and Allergies for the patient.

### Community 66 - "Community 66"
Cohesion: 0.5
Nodes (4): EHR Synchronization, EHR Reconciliation Service, EHR Sync Tests, EHR Integration Router

### Community 67 - "Community 67"
Cohesion: 0.5
Nodes (3): Answer, Q: Why does process_clinical_task connect 5 communities, Source Nodes

### Community 68 - "Community 68"
Cohesion: 0.5
Nodes (3): run_recon(), Syncs PostgreSQL UsageMeter with PostgreSQL AuditLog events.     Identifies and, reconcile_usage_meters()

## Knowledge Gaps
- **271 isolated node(s):** `Returns a select statement for the given model class,      automatically filtere`, `Get async database session for high-performance queries`, `Defines a connected EHR system (e.g. Epic, Cerner).`, `Simulates a record in an external Hospital Management System (HMS).     Used for`, `Stores the genesis hash for a clinic's audit vault.` (+266 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **32 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `get_session()` connect `Patient & Encounter CRUD` to `Community 64`, `Clinical Intelligence & Admin`, `Authentication & RBAC`, `Database Seeding & Lifecycle`, `Community 71`, `Community 74`, `AI Agents Router`, `Clinic Reporting`, `Clinical Risk Detection`, `Prescription Extraction`, `Community 56`, `Community 58`, `Community 60`, `Community 63`?**
  _High betweenness centrality (0.120) - this node is a cross-community bridge._
- **Why does `SQLModel Data Models` connect `Community 60` to `API Processing Pipeline`, `Patient & Encounter CRUD`, `Clinical Intelligence & Admin`, `Authentication & RBAC`, `Database Seeding & Lifecycle`, `Formatting & Background Tasks`, `AI Agents Router`, `Clinic Reporting`, `Clinical Risk Detection`, `Prescription Extraction`, `Text Cleanup Pipeline`, `Community 56`, `Community 58`, `Community 62`, `Community 63`, `Community 64`, `Community 65`, `Community 66`, `Community 69`, `Community 70`, `Community 71`, `Community 72`, `Community 74`?**
  _High betweenness centrality (0.120) - this node is a cross-community bridge._
- **Why does `process_clinical_task()` connect `Patient & Encounter CRUD` to `Clinical Intelligence & Admin`, `Transcription Engine`, `Graph State & Schemas`, `Email & Upgrade Flow`, `Formatting & Background Tasks`?**
  _High betweenness centrality (0.093) - this node is a cross-community bridge._
- **Are the 70 inferred relationships involving `get_session()` (e.g. with `get_current_user()` and `seed_initial_admin()`) actually correct?**
  _`get_session()` has 70 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Returns a select statement for the given model class,      automatically filtere`, `Get async database session for high-performance queries`, `Defines a connected EHR system (e.g. Epic, Cerner).` to the rest of the system?**
  _271 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Patient & Encounter CRUD` be split into smaller, more focused modules?**
  _Cohesion score 0.05 - nodes in this community are weakly interconnected._
- **Should `Clinical Intelligence & Admin` be split into smaller, more focused modules?**
  _Cohesion score 0.09 - nodes in this community are weakly interconnected._