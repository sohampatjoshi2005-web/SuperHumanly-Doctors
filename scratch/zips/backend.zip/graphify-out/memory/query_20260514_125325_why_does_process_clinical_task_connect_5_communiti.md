---
type: "query"
date: "2026-05-14T12:53:25.536495+00:00"
question: "Why does process_clinical_task connect 5 communities"
contributor: "graphify"
source_nodes: ["process_clinical_task", "transcribe_audio", "analyze_encounter_unified", "format_prescription_text", "send_rx_email", "create_encounter"]
---

# Q: Why does process_clinical_task connect 5 communities

## Answer

process_clinical_task is the Celery background task orchestrator that bridges Transcription, Intelligence, Formatting, Email, and Storage communities. It is a healthy orchestrator - not a god function - because it delegates all domain logic to specialized services and only performs sequencing.

## Source Nodes

- process_clinical_task
- transcribe_audio
- analyze_encounter_unified
- format_prescription_text
- send_rx_email
- create_encounter