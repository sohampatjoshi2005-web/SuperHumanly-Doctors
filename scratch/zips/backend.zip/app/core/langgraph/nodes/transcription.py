from typing import Dict, Any
from app.core.langgraph.tools.asr import asr_tool


def transcription_node(state: Dict[str, Any]) -> Dict[str, Any]:
    audio_path = state.get("audio_path")
    if not audio_path:
        raise ValueError("audio_path is required")

    transcript = asr_tool(audio_path)
    return {"transcript": transcript}
