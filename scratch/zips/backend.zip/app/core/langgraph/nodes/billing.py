from app.services.billing_service import extract_billing_info


def billing_node(state):
    """
    LangGraph node to extract billing and coding information from the cleaned transcript.
    """
    transcript = state.get("cleaned_text") or state.get("transcript")
    
    if not transcript:
        return {"billing": None}
        
    billing = extract_billing_info(transcript)
    return {"billing": billing}
