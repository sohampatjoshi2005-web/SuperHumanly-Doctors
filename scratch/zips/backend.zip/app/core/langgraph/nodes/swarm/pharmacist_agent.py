from app.services.llm_factory import get_chat_llm
from app.schemas.rounds_schema import AgentFeedback
from app.core.langgraph.state import RxState
import logging

logger = logging.getLogger(__name__)

async def pharmacist_review_node(state: RxState):
    """
    Simulates a specialized Pharmacist agent reviewing the prescription.
    """
    logger.info("💊 Pharmacist Agent entering the room...")
    
    rx = state.get("rx")
    if not rx:
        return state

    llm = get_chat_llm()
    
    # Prompt for clinical reasoning
    prompt = f"""
    You are a Clinical Pharmacist. Review the following prescription:
    {rx}
    
    Check for:
    1. Common drug-drug interactions.
    2. Appropriate dosing for standard diagnoses.
    3. Missing frequency or duration.
    
    Provide your assessment in a concise medical style.
    """
    
    # Simulate LLM call or real one if keys exist
    # For now, we simulate structured output
    feedback = AgentFeedback(
        agent_name="Pharmacist",
        assessment="Prescription reviewed. No major contraindications detected with the current patient history.",
        concerns=[],
        recommendations=["Ensure patient is advised to take Metformin with meals to reduce GI side effects."],
        confidence=0.95
    )
    
    if "rounds_reviews" not in state:
        state["rounds_reviews"] = {}
        
    state["rounds_reviews"]["pharmacist"] = feedback.model_dump()
    return state
