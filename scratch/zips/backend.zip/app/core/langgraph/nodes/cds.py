from typing import Any, Dict
from app.schemas.cds_schema import CDSAnalysis
from app.services.llm_factory import get_chat_llm

async def cds_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract clinical risk indicators from the corrected transcript.
    """
    cleaned_text = state.get("cleaned_text", "")
    if not cleaned_text:
        return {"cds": CDSAnalysis(risks=[], summary="No text to analyze.")}

    llm = get_chat_llm()
    structured_llm = llm.with_structured_output(CDSAnalysis)

    prompt = f"""
    You are a clinical decision support AI. Analyze the following medical encounter transcript 
    and identify any high-risk clinical indicators. 
    Focus on:
    - Sepsis indicators (fever, confusion, low blood pressure, tachycardia)
    - Fall Risk (unsteady gait, history of falls, dizziness)
    - Pressure Ulcer risk (immobility, poor nutrition)
    - Respiratory Distress
    - Cardiac Risk
    
    If no risks are found, return an empty list of risks.
    
    Transcript:
    {cleaned_text}
    """
    
    try:
        cds_result = await structured_llm.ainvoke(prompt)
        return {"cds": cds_result}
    except Exception as e:
        print(f"Error in CDS extraction: {e}")
        return {"cds": CDSAnalysis(risks=[], summary=f"Error analyzing risks: {str(e)}")}
