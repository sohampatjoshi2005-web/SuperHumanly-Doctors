from typing import Dict, Any
from app.services.rx_service import clean_transcript


def cleanup_node(state: Dict[str, Any]) -> Dict[str, Any]:
    transcript = state.get("transcript", "")
    cleaned = clean_transcript(transcript)
    return {"cleaned_text": cleaned}
