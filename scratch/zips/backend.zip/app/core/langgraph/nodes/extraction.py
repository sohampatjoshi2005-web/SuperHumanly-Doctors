from typing import Dict, Any
from app.services.rx_service import extract_prescription


def extraction_node(state: Dict[str, Any]) -> Dict[str, Any]:
    cleaned = state.get("cleaned_text", "")
    rx = extract_prescription(cleaned)
    return {"rx": rx}
