from typing import TypedDict, Optional, List
from langgraph.graph import StateGraph, END

from app.schemas.rx_schema import Prescription
from app.schemas.billing_schema import BillingAnalysis
from app.schemas.cds_schema import CDSAnalysis
from app.core.langgraph.nodes.transcription import transcription_node
from app.core.langgraph.nodes.cleanup import cleanup_node
from app.core.langgraph.nodes.extraction import extraction_node
from app.core.langgraph.nodes.validation import validation_node
from app.core.langgraph.nodes.formatting import formatting_node
from app.core.langgraph.nodes.billing import billing_node
from app.core.langgraph.nodes.cds import cds_node
from app.core.langgraph.nodes.email import email_node
from app.core.langgraph.nodes.swarm.pharmacist_agent import pharmacist_review_node
from app.core.langgraph.nodes.swarm.internist_agent import internist_review_node
from app.core.langgraph.nodes.swarm.rounds_consensus import rounds_consensus_node
from app.core.langgraph.nodes.referral import referral_node
from app.core.langgraph.nodes.wellness import wellness_node
from app.core.langgraph.state import RxState


def build_graph():
    graph = StateGraph(RxState)

    graph.add_node("transcription", transcription_node)
    graph.add_node("cleanup", cleanup_node)
    graph.add_node("extraction", extraction_node)
    graph.add_node("validation", validation_node)
    graph.add_node("formatting", formatting_node)
    graph.add_node("billing", billing_node)
    graph.add_node("cds", cds_node)
    graph.add_node("pharmacist_review", pharmacist_review_node)
    graph.add_node("internist_review", internist_review_node)
    graph.add_node("consensus", rounds_consensus_node)
    graph.add_node("referral", referral_node)
    graph.add_node("wellness", wellness_node)
    graph.add_node("email", email_node)

    graph.set_entry_point("transcription")
    graph.add_edge("transcription", "cleanup")
    graph.add_edge("cleanup", "extraction")
    graph.add_edge("extraction", "validation")
    graph.add_edge("validation", "formatting")
    graph.add_edge("formatting", "billing")
    graph.add_edge("billing", "cds")
    graph.add_edge("cds", "pharmacist_review")
    graph.add_edge("pharmacist_review", "internist_review")
    graph.add_edge("internist_review", "consensus")
    graph.add_edge("consensus", "referral")
    graph.add_edge("referral", "wellness")
    graph.add_edge("wellness", "email")
    graph.add_edge("email", END)

    return graph.compile()
