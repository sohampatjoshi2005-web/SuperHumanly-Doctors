from typing import TypedDict, Optional, List, Dict, Any
from app.schemas.rx_schema import Prescription
from app.schemas.billing_schema import BillingAnalysis
from app.schemas.cds_schema import CDSAnalysis

class RxState(TypedDict, total=False):
    audio_path: str
    transcript: str
    cleaned_text: str
    rx: Prescription
    validation_errors: List[str]
    rx_text: str
    billing: BillingAnalysis
    cds: CDSAnalysis
    rounds_reviews: Dict[str, Any]
    rounds_report: Dict[str, Any]
    referral_data: Optional[Dict[str, Any]]
    wellness_data: Optional[Dict[str, Any]]
    to_email: Optional[str]
    email_subject: Optional[str]
    email_status: Optional[str]
    email_message_id: Optional[str]
    email_error: Optional[str]
