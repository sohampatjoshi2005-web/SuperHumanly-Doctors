from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from app.api.v1.auth import get_current_admin
from app.db_models import TrialRequest, User, AuditLog
from app.db import get_session
from app.services.audit_vault_service import verify_audit_chain
from sqlmodel import select, func
from datetime import datetime
from pydantic import BaseModel

router = APIRouter(prefix="/admin", tags=["admin"])

class AdminStats(BaseModel):
    total_trials: int
    pending_trials: int
    approved_trials: int
    total_doctors: int

@router.get("/stats", response_model=AdminStats)
async def get_admin_stats(admin: User = Depends(get_current_admin)):
    with get_session() as session:
        total = session.exec(select(func.count(TrialRequest.id))).one()
        pending = session.exec(select(func.count(TrialRequest.id)).where(TrialRequest.status == "pending")).one()
        approved = session.exec(select(func.count(TrialRequest.id)).where(TrialRequest.status == "approved")).one()
        doctors = session.exec(select(func.count(User.id)).where(User.role == "doctor")).one()
    
    return {
        "total_trials": total,
        "pending_trials": pending,
        "approved_trials": approved,
        "total_doctors": doctors
    }

@router.get("/trials", response_model=List[TrialRequest])
async def list_trials(admin: User = Depends(get_current_admin)):
    with get_session() as session:
        return session.exec(select(TrialRequest).order_by(TrialRequest.created_at.desc())).all()

class TrialStatusUpdate(BaseModel):
    status: str # 'approved' or 'rejected'

@router.patch("/trials/{trial_id}")
async def update_trial_status(
    trial_id: str, 
    update: TrialStatusUpdate, 
    admin: User = Depends(get_current_admin)
):
    with get_session() as session:
        trial = session.get(TrialRequest, trial_id)
        if not trial:
            raise HTTPException(status_code=404, detail="Trial request not found")
        
        trial.status = update.status
        trial.processed_at = datetime.utcnow()
        trial.processed_by = admin.username
        session.add(trial)
        session.commit()
    
    return {"status": "success", "message": f"Trial state transitioned to {update.status}"}

@router.post("/promote/{username}")
async def promote_user(username: str, admin: User = Depends(get_current_admin)):
    with get_session() as session:
        user = session.exec(select(User).where(User.username == username)).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        user.role = "admin"
        session.add(user)
        session.commit()
    return {"status": "success", "message": f"User {username} promoted to Administrative Sovereign"}

@router.get("/audit/verify")
async def verify_audit_logs(
    clinic_id: Optional[str] = None, 
    admin: User = Depends(get_current_admin)
):
    """
    Verifies the integrity of the audit chain for a clinic or global logs.
    """
    with get_session() as session:
        stmt = select(AuditLog)
        if clinic_id:
            stmt = stmt.where(AuditLog.clinic_id == clinic_id)
        else:
            stmt = stmt.where(AuditLog.clinic_id == None)
        
        stmt = stmt.order_by(AuditLog.created_at.asc())
        logs = session.exec(stmt).all()
        
        if not logs:
            return {"status": "verified", "count": 0, "message": "No logs found to verify."}
            
        is_valid = verify_audit_chain(logs)
        
        if not is_valid:
            raise HTTPException(status_code=418, detail="Audit chain integrity violation detected! The vault has been compromised.")
            
        return {
            "status": "verified",
            "count": len(logs),
            "last_hash": logs[-1].event_hash,
            "integrity_score": 1.0,
            "message": "Audit vault integrity confirmed. No tampering detected."
        }
