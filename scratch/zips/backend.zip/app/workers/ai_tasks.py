from celery import shared_task
import logging
import os
from typing import Optional, Dict, Any
from datetime import datetime

from app.core.langgraph.graph import build_graph
from app.services.rx_service import clean_transcript, extract_prescription
from app.services.formatting_service import format_prescription_text
from app.core.langgraph.tools.mailer import send_rx_email
from app.services.summary_service import generate_patient_summary
from app.services.billing_service import extract_billing_info
from app.services.storage_service import create_encounter, create_referral, create_followups
from app.db_models import Encounter, AuditLog
from app.core.config import settings

logger = logging.getLogger(__name__)

@shared_task(
    bind=True, 
    max_retries=5, 
    default_retry_delay=60, # 1 minute
    queue="clinical.routine"
)
def process_clinical_task(
    self, 
    data_type: str, # 'text' or 'audio'
    payload: Dict[str, Any],
    doctor_id: str,
    customer_id: Optional[str] = None,
    username: str = "unknown",
    clinic_id: Optional[str] = None
):
    """
    Main background task for processing clinical documentation.
    """
    start_time = datetime.utcnow()
    logger.info(f"🚀 Starting {data_type} processing task for doctor {doctor_id} in clinic {clinic_id}")
    
    try:
        from app.services.intelligence_service import analyze_encounter_unified
        from app.schemas.rx_schema import Prescription
        
        # Unified Analysis (1 LLM Call)
        if data_type == "text":
            transcript = payload.get("transcript", "")
        else:
            # Audio flow: 1. Transcribe (Local or Dedicated ASR Quota) -> 2. Unified Analysis (Gemini Quota)
            from app.services.transcription_service import transcribe_audio
            audio_path = payload.get("audio_path")
            language = payload.get("language")
            logger.info(f"🎙️ Transcribing audio: {audio_path} with language: {language}")
            transcript = transcribe_audio(audio_path, language=language)
            
        # Fetch Patient History for context
        history_context = ""
        if customer_id:
            from app.db import get_session
            from sqlmodel import select
            with get_session() as session:
                # Fetch last 3 encounters for longitudinal context
                history_encounters = session.exec(
                    select(Encounter)
                    .where(Encounter.customer_id == customer_id)
                    .order_by(Encounter.created_at.desc())
                    .limit(3)
                ).all()
                
                if history_encounters:
                    history_context = "### PATIENT LONGITUDINAL HISTORY (Last 3 Encounters):\n"
                    for he in history_encounters:
                        date_str = he.created_at.strftime("%Y-%m-%d")
                        history_context += f"- Date: {date_str} | Diagnosis: {he.diagnosis or 'Unspecified'} | Summary: {he.patient_summary or 'None'}\n"
            logger.info(f"📜 Injected {len(history_encounters)} past encounters into context.")

        analysis = analyze_encounter_unified(transcript, historical_context=history_context)
        
        # Map unified analysis to result structure
        result = {
            "transcript": transcript,
            "cleaned_text": analysis.patient_summary,
            "patient_summary": analysis.patient_summary,
            "rx": Prescription(
                diagnosis=analysis.diagnosis,
                medicines=analysis.medicines,
                advice=analysis.advice,
                follow_up=analysis.follow_up,
                confidence_score=analysis.confidence_score if hasattr(analysis, 'confidence_score') else 0.98
            ),
            "rx_text": format_prescription_text(Prescription(
                diagnosis=analysis.diagnosis,
                medicines=analysis.medicines,
                advice=analysis.advice,
                follow_up=analysis.follow_up,
                confidence_score=analysis.confidence_score if hasattr(analysis, 'confidence_score') else 0.98
            )),
            "billing": analysis, # Contains vitals_check, complexity, etc
            "confidence_score": analysis.confidence_score if hasattr(analysis, 'confidence_score') else 0.98,
            "email_status": "skipped",
            "email_message_id": None
        }

        # Handle Email
        email_status = result.get("email_status", "skipped")
        message_id = result.get("email_message_id")
        recipient = payload.get("to_email") or settings.email_default_to
        subject = payload.get("email_subject") or "Prescription Summary"

        if data_type == "text" and settings.resend_api_key and recipient:
            try:
                message_id = send_rx_email(subject=subject, text_body=result["rx_text"], to_email=recipient)
                email_status = "sent"
            except Exception as e:
                logger.error(f"❌ Email sending failed: {e}")
                email_status = "failed"

        # Save to Database
        encounter_id = None
        billing = result["billing"]
        rx = result["rx"]

        if customer_id:
            # LOG AGENT START
            from app.services.audit_service import log_audit
            log_audit(
                actor="Lumina",
                action="ANALYZE",
                resource_type="encounter",
                resource_id="pending",
                extra_metadata={"status": "processing", "doctor_id": doctor_id, "clinic_id": clinic_id}
            )

            enc = Encounter(
                doctor_id=doctor_id,
                clinic_id=clinic_id,
                customer_id=customer_id,
                audio_filename=payload.get("audio_filename") if data_type == "audio" else None,
                transcript=result["transcript"],
                diagnosis=analysis.diagnosis if hasattr(analysis, 'diagnosis') else None,
                patient_summary=result["patient_summary"],
                rx_json=rx.model_dump() if hasattr(rx, 'model_dump') else rx,
                rx_text=result["rx_text"],
                vitals_check=billing.vitals_check if billing else None,
                complexity=billing.complexity if billing else None,
                codes_reasoning=billing.codes_reasoning if billing else None,
                codes_json={"codes": [c.model_dump() for c in billing.billing_codes]} if billing else None,
                email_to=recipient,
                email_subject=subject,
                email_status=email_status,
                email_message_id=message_id,
                clinical_data={
                    "risk_indicators": [r.model_dump() for r in analysis.risk_indicators],
                    "summary_sections": analysis.summary_sections,
                    "soap": {
                        "subjective": analysis.subjective,
                        "objective": analysis.objective,
                        "assessment": analysis.assessment_text,
                        "plan": analysis.plan_text
                    }
                },
                rounds_report=result.get("rounds_report"),
                original_codes_json={"codes": [c.model_dump() for c in billing.billing_codes]} if billing else None,
                documentation_duration_sec=int((datetime.utcnow() - start_time).total_seconds()),
                confidence_score=result.get("confidence_score")
            )
            saved_enc = create_encounter(enc)
            encounter_id = saved_enc.id

            # CREATE REFERRAL IF DETECTED
            referral_data = result.get("referral_data")
            if referral_data:
                from app.db_models import Referral
                referral = Referral(
                    encounter_id=encounter_id,
                    doctor_id=doctor_id,
                    patient_id=customer_id,
                    specialty=referral_data.get("specialty"),
                    reason=referral_data.get("reason"),
                    priority=referral_data.get("priority"),
                    letter_text=referral_data.get("letter_text"),
                    insurance_notes=referral_data.get("insurance_notes"),
                    status="Draft"
                )
                create_referral(referral)
                logger.info(f"📄 AI Referral Draft created for encounter {encounter_id}")

            # CREATE FOLLOWUPS IF DETECTED
            wellness_data = result.get("wellness_data")
            if wellness_data and "followups" in wellness_data:
                from app.db_models import PatientFollowup
                followups = []
                for f in wellness_data["followups"]:
                    followup = PatientFollowup(
                        encounter_id=encounter_id,
                        doctor_id=doctor_id,
                        patient_id=customer_id,
                        instruction=f.get("instruction"),
                        due_date=datetime.fromisoformat(f.get("due_date")),
                        status="Pending"
                    )
                    followups.append(followup)
                
                create_followups(followups)
                logger.info(f"🧘 {len(wellness_data['followups'])} AI Follow-ups created for encounter {encounter_id}")

            # LOG AGENT SUCCESS
            log_audit(
                actor="Atlas",
                action="SYNC",
                resource_type="encounter",
                resource_id=encounter_id,
                extra_metadata={"status": "completed", "doctor_id": doctor_id, "clinic_id": clinic_id}
            )

        # Cleanup audio file if it exists
        if data_type == "audio" and os.path.exists(payload.get("audio_path")):
            try:
                os.remove(payload.get("audio_path"))
                logger.info(f"🧹 Cleaned up temp file: {payload.get('audio_path')}")
            except:
                pass

        return {
            "encounter_id": encounter_id,
            "transcript": result["transcript"],
            "cleaned_text": result["cleaned_text"],
            "patient_summary": result["patient_summary"],
            "summary_sections": analysis.summary_sections,
            "soap": {
                "subjective": analysis.subjective,
                "objective": analysis.objective,
                "assessment": analysis.assessment_text,
                "plan": analysis.plan_text
            },
            "rx": result["rx"].model_dump() if hasattr(result["rx"], 'model_dump') else result["rx"],
            "rx_text": result["rx_text"],
            "rx_summary": result["rx_text"], # ALIGN WITH FRONTEND
            "vitals_check": billing.vitals_check if billing else None,
            "complexity": billing.complexity if billing else None,
            "codes_reasoning": billing.codes_reasoning if billing else None,
            "billing_codes": [c.model_dump() for c in billing.billing_codes] if billing else [],
            "diagnosis": analysis.diagnosis,
            "medicines": [m.model_dump() for m in analysis.medicines] if analysis.medicines else [],
            "advice": analysis.advice,
            "follow_up": analysis.follow_up,
            "risk_indicators": [r.model_dump() for r in analysis.risk_indicators],
            "rounds_report": result.get("rounds_report"),
            "referral_data": result.get("referral_data"),
            "wellness_data": result.get("wellness_data"),
            "email_status": email_status,
            "email_message_id": message_id,
            "confidence_score": result.get("confidence_score")
        }

    except Exception as e:
        logger.error(f"❌ Clinical task failed: {e}")
        if "429" in str(e) or "Resource Exhausted" in str(e):
            logger.info("⏳ Quota exhausted. Retrying with exponential backoff...")
            raise self.retry(exc=e, countdown=2 ** self.request.retries * 10)
        raise self.retry(exc=e, countdown=60 * (self.request.retries + 1))
