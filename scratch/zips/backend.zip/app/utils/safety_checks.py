from typing import List
from app.schemas.rx_schema import Prescription


def find_missing_fields(rx: Prescription) -> List[str]:
    missing = []
    for idx, med in enumerate(rx.medicines, start=1):
        if not med.dosage:
            missing.append(f"medicine[{idx}].dosage")
        if not med.frequency:
            missing.append(f"medicine[{idx}].frequency")
        if not med.duration:
            missing.append(f"medicine[{idx}].duration")
    return missing
