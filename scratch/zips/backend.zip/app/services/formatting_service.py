from app.schemas.rx_schema import Prescription


def format_prescription_text(rx: Prescription) -> str:
    lines = []
    
    lines.append("CLINICAL DOCUMENTATION & PRESCRIPTION")
    lines.append("=" * 40)
    
    if rx.patient_name:
        lines.append(f"PATIENT: {rx.patient_name}")
    if rx.age is not None:
        lines.append(f"AGE: {rx.age}")
    if rx.gender:
        lines.append(f"GENDER: {rx.gender}")
    
    lines.append("-" * 40)
    
    if (rx.diagnosis):
        lines.append(f"PRIMARY DIAGNOSIS: {rx.diagnosis}")
        lines.append(f"CONFIDENCE: {rx.confidence_score * 100:.1f}%")
    
    lines.append("\nPHARMACOLOGICAL INTERVENTIONS:")
    if not rx.medicines:
        lines.append("No pharmacological treatment prescribed at this time.")
    else:
        for idx, med in enumerate(rx.medicines, start=1):
            lines.append(f"{idx}. {med.name.upper()}")
            lines.append(f"   Dose/Freq: {med.dosage} {med.frequency}")
            lines.append(f"   Duration: {med.duration}")
            if med.instructions:
                lines.append(f"   Patient Instructions: {med.instructions}")
            lines.append("")

    lines.append("NON-PHARMACOLOGICAL ADVICE & CLINICAL GUIDANCE:")
    if rx.advice:
        lines.append(f"- {rx.advice}")
    else:
        lines.append("- Continue supportive care as discussed.")

    lines.append("\nFOLLOW-UP PLAN:")
    if rx.follow_up:
        lines.append(f"- {rx.follow_up}")
    else:
        lines.append("- Return as needed if symptoms fail to resolve or exacerbate.")

    lines.append("\n" + "=" * 40)
    lines.append("DISCLAIMER: This documentation is generated with AI assistance. Clinical verification is mandatory before implementation.")
    
    return "\n".join(lines).strip()
