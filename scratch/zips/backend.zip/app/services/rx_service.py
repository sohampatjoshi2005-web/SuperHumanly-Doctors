from pathlib import Path
import ast
import json
import re
from pydantic import ValidationError
from app.schemas.rx_schema import Prescription
from app.utils.text_normalize import normalize_text
from app.core.config import settings
from app.services.llm_factory import get_chat_llm


from pathlib import Path
from typing import Optional
from app.schemas.rx_schema import Prescription
from app.utils.text_normalize import normalize_text
from app.services.llm_factory import get_chat_llm
from langchain_core.prompts import PromptTemplate


def _load_prompt() -> str:
    prompt_path = Path("app/core/prompts/rx_extraction.prompt")
    return prompt_path.read_text(encoding="utf-8")


def clean_transcript(transcript: str) -> str:
    return normalize_text(transcript)


def extract_prescription(transcript: str) -> Prescription:
    """
    Modern Extraction Logic:
    Utilizes LangChain's structured output binding to ensure strict schema adherence
    without fragile manual JSON regex parsing.
    """
    llm = get_chat_llm()
    
    # Bind the schema to the LLM
    structured_llm = llm.with_structured_output(Prescription)
    
    template = _load_prompt() + "\n\nTRANSCRIPT:\n{transcript}"
    
    prompt = PromptTemplate(
        template=template,
        input_variables=["transcript"]
    )
    
    chain = prompt | structured_llm
    
    try:
        # Structured output handles parsing and validation natively
        return chain.invoke({"transcript": transcript})
    except Exception as e:
        # Fallback for older models or edge-case parsing failures
        print(f"⚠️ Structured extraction failed: {str(e)}. Falling back to robust parsing.")
        
        # We can re-implement a simpler version of the parser if needed, 
        # but with_structured_output is the industry standard now.
        from langchain_core.output_parsers import PydanticOutputParser
        parser = PydanticOutputParser(pydantic_object=Prescription)
        
        fallback_prompt = PromptTemplate(
            template="{text}\n\n{format_instructions}",
            input_variables=["text"],
            partial_variables={"format_instructions": parser.get_format_instructions()},
        )
        
        fallback_chain = fallback_prompt | llm | parser
        return fallback_chain.invoke({"text": template.format(transcript=transcript)})
