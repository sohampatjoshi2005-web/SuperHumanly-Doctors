from app.services.llm_factory import get_chat_llm
from app.schemas.encounter_intelligence_schema import UnifiedEncounterAnalysis
from app.schemas.rx_schema import Medicine
from app.schemas.billing_schema import BillingCode
from app.schemas.cds_schema import RiskIndicator
from langchain_core.prompts import PromptTemplate
from langchain_core.messages import SystemMessage, HumanMessage
import logging

logger = logging.getLogger(__name__)

# [PROMPT] - High-Fidelity Clinical Intelligence Template
UNIFIED_SYSTEM_MESSAGE = """You are a board-certified clinical documentation specialist.
Your goal is to transform clinical dialogue into a GOLD-STANDARD, industry-level SOAP note and structured prescription.

STYLE & TONE:
- Use formal medical terminology and standard SIG codes (PO, BID, pc, etc.).
- Maintain a highly organized, bulleted format (using '-').
- Be concise but clinically exhaustive.

CRITICAL INSTRUCTIONS:
1. Return ONLY a single, valid JSON object.
2. NO markdown backticks. NO conversational text.
3. ALL keys are mandatory.
4. SOAP BINS:
   - 'subjective': Patient's history, symptoms, and chief complaint.
   - 'objective': Vitals, physical exam findings, and discussed labs.
   - 'assessment_text': Diagnosis and clinical reasoning.
   - 'plan_text': Comprehensive treatment strategy.
5. 'summary_sections' MUST also be populated with concise bullets for UI quick-view.
6. 'medicines' must use SIG formatting in instructions (e.g., 'Take 1 tab PO BID pc').
7. 'confidence_score' MUST reflect your internal certainty (0.0 to 1.0) based on transcript clarity and medical completeness. High certainty (0.95+) means all clinical details are explicit and unambiguous. Low certainty (<0.85) means key details were inferred or transcript was noisy. Use non-mock values (e.g., 0.94, 0.97, 0.89)."""

UNIFIED_HUMAN_TEMPLATE = """Analyze the following clinical transcript and provide the structured output.

GOLD-STANDARD EXAMPLE (SOAP + SIG):
{{
  "subjective": "- Patient reports 3-day history of sharp parasternal pain.\\n- Pain worsens with deep inspiration and lateral movement.\\n- History of recent upper respiratory infection noted.",
  "objective": "- HR: 78 bpm, BP: 122/80 mmHg, SpO2: 98% on RA.\\n- Tenderness on palpation at 3rd and 4th left costochondral junctions.\\n- Lung sounds clear bilaterally; no murmurs.",
  "assessment_text": "- Costochondritis (ICD-10 M94.0).\\n- Differential Diagnosis: Pleurisy ruled out by absence of friction rub.",
  "plan_text": "- Naproxen 500mg PO BID for 7 days.\\n- Apply heat to affected area BID.\\n- Avoid strenuous chest-wall engagement.",
  "clinical_notes": "- SOAP note generated for chest wall tenderness.",
  "diagnosis": "Costochondritis (ICD-10 M94.0)",
  "medicines": [
    {{ "name": "Naproxen", "dosage": "500mg", "frequency": "BID", "duration": "7 days", "instructions": "Take 1 tab PO BID pc" }}
  ],
  "advice": "- Apply local heat twice daily.\\n- Rest from heavy lifting.",
  "follow_up": "- Return if symptoms fail to resolve in 10 days.",
  "vitals_check": true,
  "complexity": "Moderate",
  "codes_reasoning": "Localized tenderness supporting M94.0.",
  "billing_codes": [
    {{ 
      "code": "M94.0", "system": "ICD-10-CM", "description": "Chondrocostal junction syndrome", 
      "justification": "Primary diagnosis based on palpation evidence.", "category": "Primary", "confidence": 0.99,
      "evidence": ["tender at the junctions"]
    }}
  ],
  "risk_indicators": [],
  "summary_sections": {{
    "Symptoms": "- Sharp parasternal pain.\\n- Pleuritic nature.",
    "Assessment": "- Likely costochondritis.",
    "Plan": "- NSAIDs and local heat.",
    "Red Flags": "- Radiation to jaw/arm.\\n- Severe dyspnea.",
    "Follow-up": "- 10 days."
  }},
  "patient_summary": "You have inflammation in your rib cartilage. We've prescribed anti-inflammatories."
}}

TRANSCRIPT:
{transcript}

FINAL REMINDER: Return a HIGH-FIDELITY SOAP note with structured SIG codes."""

from tenacity import retry, stop_after_attempt, wait_exponential

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=10),
    reraise=True
)
def analyze_encounter_unified(transcript: str, historical_context: str = "") -> UnifiedEncounterAnalysis:
    """
    Perform all clinical intelligence analysis in a single LLM call.
    Uses SystemMessage and HumanMessage for maximum prompt adherence.
    Integrates historical context if provided (Phase 47).
    """
    llm = get_chat_llm()
    
    # Force JSON mode in model_kwargs if possible
    if hasattr(llm, "model_kwargs"):
        llm.model_kwargs["response_format"] = {"type": "json_object"}
    
    def safe_parse(content: str) -> UnifiedEncounterAnalysis:
        import re
        import json
        # Strip markdown and noise
        content = re.sub(r'```json\s*', '', content, flags=re.IGNORECASE)
        content = re.sub(r'```\s*', '', content)
        content = content.strip()
        
        start = content.find('{')
        end = content.rfind('}')
        if start != -1 and end != -1:
            content = content[start:end+1]
        
        return UnifiedEncounterAnalysis.model_validate_json(content)

    # Prepare historical block
    history_block = f"\n\n{historical_context}" if historical_context else ""
    
    # Inject history into human message
    human_content = UNIFIED_HUMAN_TEMPLATE.format(transcript=transcript)
    if history_block:
        # Insert history before the transcript
        human_content = human_content.replace("TRANSCRIPT:", f"{historical_context}\n\nTRANSCRIPT:")

    messages = [
        SystemMessage(content=UNIFIED_SYSTEM_MESSAGE),
        HumanMessage(content=human_content)
    ]

    try:
        logger.info(f"🧠 Invoking Clinical Intelligence Extraction (History: {'Yes' if historical_context else 'No'})...")
        response = llm.invoke(messages)
        content = response.content if hasattr(response, 'content') else str(response)
        analysis = safe_parse(content)
        logger.info(f"DEBUG: Extracted patient_summary (len={len(analysis.patient_summary)})")
        return analysis

    except Exception as e:
        logger.warning(f"⚠️ Primary extraction failed: {e}. Initiating Hardened Reflection...")
        
        try:
            # Reflection: Re-send with explicit error feedback
            error_details = str(e)
            reflection_messages = [
                SystemMessage(content=UNIFIED_SYSTEM_MESSAGE + "\n\nCRITICAL: Your previous response was INVALID. You MUST return the COMPLETE object with all fields correctly typed."),
                HumanMessage(content=f"ERROR: {error_details}\n\nPlease re-analyze and provide COMPLETE JSON for this transcript:\n\n{historical_context}\n\nTRANSCRIPT:\n{transcript}")
            ]
            
            correction_response = llm.invoke(reflection_messages)
            correction_content = correction_response.content if hasattr(correction_response, 'content') else str(correction_response)
            
            analysis = safe_parse(correction_content)
            logger.info(f"DEBUG: Reflection patient_summary (len={len(analysis.patient_summary)})")
            return analysis
            
        except Exception as reflection_error:
            logger.error(f"❌ Hardened reflection failed: {reflection_error}")
            raise reflection_error
