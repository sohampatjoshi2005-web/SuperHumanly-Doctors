from pathlib import Path
from langchain_core.prompts import PromptTemplate
from app.services.llm_factory import get_chat_llm
from app.schemas.billing_schema import BillingAnalysis


def _load_prompt() -> str:
    prompt_path = Path("app/core/prompts/billing_extraction.prompt")
    return prompt_path.read_text(encoding="utf-8")


def extract_billing_info(transcript: str) -> BillingAnalysis:
    """
    Extracts ICD-10, CPT, and Complexity info from clinical transcript.
    """
    llm = get_chat_llm()
    structured_llm = llm.with_structured_output(BillingAnalysis)
    
    template = _load_prompt() + "\n\nTRANSCRIPT:\n{transcript}"
    
    prompt = PromptTemplate(
        template=template,
        input_variables=["transcript"]
    )
    
    chain = prompt | structured_llm
    
    try:
        return chain.invoke({"transcript": transcript})
    except Exception as e:
        print(f"⚠️ Billing extraction failed: {str(e)}")
        # Return a safe empty object if extraction fails
        return BillingAnalysis(
            vitals_check=False,
            complexity="Low",
            codes_reasoning="Failed to perform automated coding analysis.",
            codes=[]
        )
