from __future__ import annotations

from app.core.config import settings


def get_chat_llm(model: str | None = None):
    """
    Returns a LangChain chat model based on env config.

    - LLM_PROVIDER=bedrock -> langchain-aws ChatBedrockConverse
    - LLM_PROVIDER=openai  -> langchain-openai ChatOpenAI (also works for Ollama/OpenAI-compatible via API_BASE_URL)
    """

    provider = (settings.llm_provider or "openai").strip().lower()

    if provider in {"bedrock", "aws", "aws-bedrock"}:
        # Lazy import so local dev doesn't require AWS deps unless used.
        from langchain_aws import ChatBedrockConverse

        kwargs = {
            "model": model or settings.bedrock_model_id,
            "region_name": settings.bedrock_region,
            "temperature": 0,
        }
        # If using an ARN (common for inference profiles), langchain-aws requires the provider.
        if str(model or settings.bedrock_model_id).startswith("arn:"):
            # langchain-aws expects `provider=` (e.g. "anthropic") when modelId is an ARN.
            kwargs["provider"] = settings.bedrock_provider

        return ChatBedrockConverse(**kwargs)
    
    if provider == "google":
        from langchain_google_genai import ChatGoogleGenerativeAI
        
        # Strictly use the model from settings or argument
        return ChatGoogleGenerativeAI(
            model=model or settings.gemini_model,
            google_api_key=settings.gemini_api_key,
            temperature=0,
        )

    if provider == "groq":
        from langchain_groq import ChatGroq
        from langchain_google_genai import ChatGoogleGenerativeAI
        
        # Translate OpenAI model names to Groq equivalents if needed
        groq_model = model or settings.groq_model
        if "gpt-4" in groq_model or "gpt-3.5" in groq_model:
            groq_model = "llama-3.3-70b-versatile"

        primary = ChatGroq(
            model=groq_model,
            groq_api_key=settings.groq_api_key,
            temperature=0,
        )
        
        fallback = ChatGoogleGenerativeAI(
            model=settings.gemini_model,
            google_api_key=settings.gemini_api_key,
            temperature=0,
        )
        
        return primary.with_fallbacks([fallback])
        
    if provider == "puter":
        from langchain_openai import ChatOpenAI
        
        return ChatOpenAI(
            model=model or "claude-3-5-sonnet", # Puter usually supports standard model names
            api_key=settings.puter_api_key,
            base_url="https://api.puter.com/v1",
            temperature=0,
        )

    # Default: OpenAI-compatible (OpenAI, Ollama, vLLM, etc.)
    from langchain_openai import ChatOpenAI

    api_key = settings.openai_api_key or "ollama"
    
    if settings.api_base_url:
        return ChatOpenAI(
            model=model or settings.openai_model,
            api_key=api_key,
            base_url=settings.api_base_url,
            temperature=0,
        )
    else:
        return ChatOpenAI(
            model=model or settings.openai_model,
            api_key=settings.openai_api_key,
            temperature=0,
        )
